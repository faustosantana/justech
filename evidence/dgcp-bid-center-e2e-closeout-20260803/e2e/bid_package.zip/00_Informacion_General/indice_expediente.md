# Índice del expediente — PROCURADURIA-DAF-CM-2026-0117

Generado: 2026-08-03T03:34:35.035973+00:00

1. **Oferta técnica** — faltante
2. **Fichas técnicas** — faltante
3. **Especificaciones técnicas** — faltante
4. **Tiempo de entrega** — faltante
5. **RPE vigente** — faltante
6. **Certificación DGII** — faltante
7. **Certificación TSS** — faltante
8. **Registro Mercantil** — faltante
9. **Cédula representante legal** — faltante
10. **Poder / autorización** — faltante
11. **Oferta económica** — faltante
12. **Condiciones de pago** — faltante
13. **SNCC F.033** — faltante
14. **SNCC F.034** — faltante
15. **SNCC F.042** — faltante
16. **Garantía de cumplimiento de contrato** — faltante
17. **Muestras físicas solicitadas en pliego** — faltante