# Laptop Classification Audit

**Generado:** 2026-06-11T21:19:35.959686+00:00

## Totales
- Líneas con `product_type=laptop` (antes del filtro estricto): **31**
- Laptops válidas (`excluded_from_laptop=false`): **31**
- Excluidas de búsqueda laptop: **281**

## Validación crítica: «1Y Keep Your HD»
- Filas encontradas: **1**
- ¿Aparece en búsqueda laptop?: **NO — OK**

  - `1Y Keep Your HD` | hoja=Warranties | tipo=warranty | excluido=True | precio=8.93

## Warranties clasificadas como laptop (debe ser 0)
- Count FAIL: **0**

## Ejemplos laptops válidas
- Dell Pro 14 PC14250 14 ENG U5 225U 16GB 512GB W11P 1Y | Comercial fila 35 | USD 818.51
- Lenovo Thinkbook 16 G8, Intel CORE 5 210H, 16GB 512SSD, Windows 11 Pro, 	1-year, | Laptop Local fila 16 | USD 857.95
- Dell Pro Silver 14in SPA U5 235U 16GB 512GB SSD W11Pr 3Ywar | Comercial fila 17 | USD 902.11
- Dell Pro Silver 14 ENG U5 235U 16GB 512GB SSD W11P 3Y | Comercial fila 40 | USD 922.11
- Dell Pro 15 Ess PV15250 15.6in SPA i7-1355U 512GB 16GB W11P | Comercial fila 15 | USD 933.20

## Ejemplos líneas descartadas/excluidas
- 1Y Carry In to 1Y AW Eilte Care | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y AW Elite Care | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt Plus | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt Plus | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y Prem Spt Plus | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 1Y AW Eilte Care | hoja=Warranties | tipo=warranty | razón=garantía / servicio
- 1Y Carry In to 3Y AW Elite Care | hoja=Warranties | tipo=warranty | razón=garantía / servicio

## Hojas excluidas de comparación laptop
- Warranties, Accesorios, Support, Services, Loc.ID, Alloc, etc.

## Criterio PASS
- «1Y Keep Your HD» NO en search?q=laptop
- 0 warranties con excluded_from_laptop=false
