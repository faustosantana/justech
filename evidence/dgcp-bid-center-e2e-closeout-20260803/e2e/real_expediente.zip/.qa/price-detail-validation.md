# Price Detail Validation

**Generado:** 2026-06-11T21:19:43.995115+00:00

## GET /api/v1/prices/products/{id}
- HTTP: 200
- Producto muestra: `cb04032f-1be3-4329-b74d-00674a01af5e`

## Compare laptop 16GB 512GB
- HTTP: 200
- Mejor: Dell — USD 818.51
- Fuente: Dell Jun1 2026.xlsx / Comercial fila 35
- Fecha lista: 2026-06-10T15:30:44Z

