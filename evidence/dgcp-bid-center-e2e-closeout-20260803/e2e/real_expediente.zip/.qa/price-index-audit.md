# Price Index Audit

**Generado:** 2026-06-11T21:19:32.312038+00:00
**Parser:** v2.3
**Carpeta:** `/source/justechai/03_PROVEEDORES`

## Totales (parser dry-run)

- Archivos: **0**
- Productos indexables: **0**
- Laptops: **0**

## Estado BD (tenant actual)

- Archivos indexados: **2**
- Productos en BD: **424**
- Laptops en BD: **31**

