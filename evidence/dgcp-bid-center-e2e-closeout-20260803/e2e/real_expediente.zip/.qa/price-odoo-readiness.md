# Price Odoo Readiness

**Generado:** 2026-06-11T21:19:43.995115+00:00

## GET /api/v1/prices/products/{id}/odoo-match
- HTTP: 200
- Encontrado: **True**
- Acción: `open_odoo_product`
- Mensaje: Producto encontrado en Odoo: Dell Pro 14 Pc14255 Ryzen Ai 5 Pro 340 16gb 512gb W11p English Keyboard Silver 3 Year Basic

## Política
- No crear cotización/producto en Odoo automáticamente
- Búsqueda controlada por SKU/MPN/modelo

