# Price Quote Draft Validation

**Generado:** 2026-06-11T21:19:43.995115+00:00

## GET /api/v1/prices/quote-drafts
- HTTP: 200
- Total borradores: **0**

## Flujo operativo
- POST /prices/quote-drafts crea borrador + tarea ventas + notificación
- Visible en /prices/drafts y /tasks

