# Price Search Validation

**Generado:** 2026-06-11T21:19:43.995115+00:00

## GET /api/v1/prices/search?q=laptop
- HTTP: 200
- Total: **31**
- «Keep Your HD» en resultados: **0** (OK)

## GET /api/v1/prices/search?categoria=laptop&ram_gb=16&almacenamiento_gb=512
- HTTP: 200
- Total: **5**

## Criterio
- Solo laptops válidas (excluded_from_laptop=false)
- Sin warranties/accesorios en búsqueda laptop
- preferred_price = PRECIO FINAL en hojas Comercial/Laptop Local

