"""Índice comercial local — datos de Odoo para búsqueda e historial."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models.mixins import UUIDPrimaryKeyMixin


class CommercialSearchDocument(UUIDPrimaryKeyMixin, Base):
    """Cabecera de documento comercial indexado desde Odoo."""

    __tablename__ = "commercial_search_documents"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "source_system",
            "source_model",
            "source_id",
            "company_id",
            name="uq_commercial_search_doc",
        ),
        Index("ix_commercial_doc_tenant_date", "tenant_id", "date"),
        Index("ix_commercial_doc_tenant_customer", "tenant_id", "customer_id"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    company_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    source_system: Mapped[str] = mapped_column(String(32), nullable=False, default="odoo")
    source_model: Mapped[str] = mapped_column(String(64), nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)
    document_type: Mapped[str] = mapped_column(String(32), nullable=False)
    document_number: Mapped[str | None] = mapped_column(String(128))
    document_status: Mapped[str | None] = mapped_column(String(64))
    customer_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    customer_name: Mapped[str | None] = mapped_column(Text)
    customer_rnc: Mapped[str | None] = mapped_column(String(32))
    date: Mapped[date | None] = mapped_column(Date, nullable=True)
    currency: Mapped[str | None] = mapped_column(String(8))
    total: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    salesperson: Mapped[str | None] = mapped_column(String(256))
    supplier_name: Mapped[str | None] = mapped_column(String(256))
    raw_payload_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class CommercialSearchItem(UUIDPrimaryKeyMixin, Base):
    """Línea comercial indexada — unidad principal de búsqueda."""

    __tablename__ = "commercial_search_items"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "source_system",
            "source_model",
            "source_id",
            "company_id",
            name="uq_commercial_search_item",
        ),
        Index("ix_commercial_item_tenant_date", "tenant_id", "date"),
        Index("ix_commercial_item_tenant_product", "tenant_id", "product_id"),
        Index("ix_commercial_item_tenant_customer", "tenant_id", "customer_id"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    company_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    document_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("commercial_search_documents.id", ondelete="SET NULL"), nullable=True
    )
    source_system: Mapped[str] = mapped_column(String(32), nullable=False, default="odoo")
    source_model: Mapped[str] = mapped_column(String(64), nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)
    document_type: Mapped[str] = mapped_column(String(32), nullable=False)
    document_number: Mapped[str | None] = mapped_column(String(128))
    document_status: Mapped[str | None] = mapped_column(String(64))
    customer_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    customer_name: Mapped[str | None] = mapped_column(Text)
    customer_rnc: Mapped[str | None] = mapped_column(String(32))
    product_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    product_name: Mapped[str | None] = mapped_column(Text)
    sku: Mapped[str | None] = mapped_column(String(128))
    brand: Mapped[str | None] = mapped_column(String(128))
    model: Mapped[str | None] = mapped_column(String(128))
    description: Mapped[str | None] = mapped_column(Text)
    quantity: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    total: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    currency: Mapped[str | None] = mapped_column(String(8))
    date: Mapped[date | None] = mapped_column(Date, nullable=True)
    salesperson: Mapped[str | None] = mapped_column(String(256))
    supplier_name: Mapped[str | None] = mapped_column(String(256))
    margin: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    margin_pct: Mapped[Decimal | None] = mapped_column(Numeric(8, 2))
    search_blob: Mapped[str | None] = mapped_column(Text)
    raw_payload_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class CommercialPriceHistory(UUIDPrimaryKeyMixin, Base):
    """Historial de precios de venta indexados."""

    __tablename__ = "commercial_price_history"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "source_system",
            "source_model",
            "source_id",
            "company_id",
            name="uq_commercial_price_history",
        ),
        Index("ix_commercial_price_tenant_product", "tenant_id", "product_id"),
        Index("ix_commercial_price_tenant_date", "tenant_id", "date"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    company_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    source_system: Mapped[str] = mapped_column(String(32), nullable=False, default="odoo")
    source_model: Mapped[str] = mapped_column(String(64), nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)
    product_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    product_name: Mapped[str | None] = mapped_column(Text)
    sku: Mapped[str | None] = mapped_column(String(128))
    brand: Mapped[str | None] = mapped_column(String(128))
    model: Mapped[str | None] = mapped_column(String(128))
    customer_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    customer_name: Mapped[str | None] = mapped_column(Text)
    unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    currency: Mapped[str | None] = mapped_column(String(8))
    date: Mapped[date | None] = mapped_column(Date, nullable=True)
    document_number: Mapped[str | None] = mapped_column(String(128))
    document_type: Mapped[str | None] = mapped_column(String(32))
    margin: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    margin_pct: Mapped[Decimal | None] = mapped_column(Numeric(8, 2))
    salesperson: Mapped[str | None] = mapped_column(String(256))
    raw_payload_json: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class CustomerPurchaseHistory(UUIDPrimaryKeyMixin, Base):
    """Agregado de compras por cliente y producto."""

    __tablename__ = "customer_purchase_history"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "company_id",
            "customer_id",
            "product_id",
            name="uq_customer_purchase_history",
        ),
        Index("ix_customer_purchase_tenant_customer", "tenant_id", "customer_id"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    company_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    customer_id: Mapped[int] = mapped_column(Integer, nullable=False)
    customer_name: Mapped[str | None] = mapped_column(Text)
    customer_rnc: Mapped[str | None] = mapped_column(String(32))
    product_id: Mapped[int] = mapped_column(Integer, nullable=False)
    product_name: Mapped[str | None] = mapped_column(Text)
    sku: Mapped[str | None] = mapped_column(String(128))
    brand: Mapped[str | None] = mapped_column(String(128))
    model: Mapped[str | None] = mapped_column(String(128))
    total_quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False, default=0)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False, default=0)
    purchase_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    last_purchase_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    last_unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    currency: Mapped[str | None] = mapped_column(String(8))
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ProductSalesHistory(UUIDPrimaryKeyMixin, Base):
    """Agregado de ventas por producto."""

    __tablename__ = "product_sales_history"
    __table_args__ = (
        UniqueConstraint("tenant_id", "company_id", "product_id", name="uq_product_sales_history"),
        Index("ix_product_sales_tenant_product", "tenant_id", "product_id"),
    )

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    company_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    product_id: Mapped[int] = mapped_column(Integer, nullable=False)
    product_name: Mapped[str | None] = mapped_column(Text)
    sku: Mapped[str | None] = mapped_column(String(128))
    brand: Mapped[str | None] = mapped_column(String(128))
    model: Mapped[str | None] = mapped_column(String(128))
    total_quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False, default=0)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False, default=0)
    sale_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    avg_unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    min_unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    max_unit_price: Mapped[Decimal | None] = mapped_column(Numeric(18, 4))
    last_sale_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    top_customer_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    top_customer_name: Mapped[str | None] = mapped_column(Text)
    currency: Mapped[str | None] = mapped_column(String(8))
    indexed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class CommercialSearchSyncState(Base):
    """Watermark de sincronización incremental por modelo Odoo."""

    __tablename__ = "commercial_search_sync_state"

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), primary_key=True
    )
    source_model: Mapped[str] = mapped_column(String(64), primary_key=True)
    watermark: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(Text)
    records_indexed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
