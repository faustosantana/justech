"""Modelo — roles adicionales por persona (merge sin duplicar)."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import Boolean, Date, DateTime, ForeignKey, Numeric, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class CompanyPersonRole(Base):
    __tablename__ = "company_person_roles"
    __table_args__ = {"schema": "jaios"}

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("jaios.tenants.id", ondelete="CASCADE"), nullable=False
    )
    person_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("jaios.company_representatives.id", ondelete="CASCADE"), nullable=False
    )
    company_profile_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("jaios.licitador_company_profiles.id", ondelete="CASCADE"), nullable=False
    )
    role_type: Mapped[str] = mapped_column(String(64), nullable=False)
    can_sign: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    can_participate_in_bids: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    ownership_percentage: Mapped[Decimal | None] = mapped_column(Numeric(5, 2), nullable=True)
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
