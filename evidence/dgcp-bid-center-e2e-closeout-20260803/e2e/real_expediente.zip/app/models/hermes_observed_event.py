"""Eventos observados por Hermes — WhatsApp, correo, etc."""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import DateTime, ForeignKey, Numeric, String, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models.mixins import TimestampMixin, UUIDPrimaryKeyMixin

OBSERVATION_STATUSES = (
    "detected",
    "pending_review",
    "validated",
    "discarded",
    "converted_task",
    "converted_opportunity",
    "converted_supplier",
    "converted_draft",
)

OBSERVATION_CHANNELS = ("email", "whatsapp", "outlook", "manual")


class HermesObservedEvent(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "hermes_observed_events"

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    channel: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    direction: Mapped[str] = mapped_column(String(16), nullable=False, default="inbound")
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="detected", index=True)
    detected_type: Mapped[str] = mapped_column(String(64), nullable=False, default="unknown", index=True)
    confidence: Mapped[Decimal] = mapped_column(Numeric(4, 3), nullable=False, default=Decimal("0"))
    summary: Mapped[str] = mapped_column(Text, nullable=False, default="")
    source_ref: Mapped[str | None] = mapped_column(String(255), index=True)
    source_meta: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    customer: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    products: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    suppliers_mentioned: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    recommended_actions: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    analysis: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    draft_response: Mapped[str | None] = mapped_column(Text)
    draft_internal: Mapped[str | None] = mapped_column(Text)
    raw_subject: Mapped[str | None] = mapped_column(Text)
    raw_from: Mapped[str | None] = mapped_column(String(255))
    raw_body_preview: Mapped[str | None] = mapped_column(Text)
    received_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), index=True)
    reviewer_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL")
    )
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    converted_resource_type: Mapped[str | None] = mapped_column(String(64))
    converted_resource_id: Mapped[str | None] = mapped_column(String(128))
