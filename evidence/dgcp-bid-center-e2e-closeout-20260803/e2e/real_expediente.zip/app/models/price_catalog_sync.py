"""Programación e historial de sincronización de catálogos de precios."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.models.mixins import TimestampMixin, UUIDPrimaryKeyMixin


class PriceCatalogSyncSchedule(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "price_catalog_sync_schedules"

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    is_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    sync_days: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    sync_hour_utc: Mapped[int] = mapped_column(Integer, nullable=False, default=10)
    include_file_lists: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    include_omega: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    include_ingram: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    include_cecomsa: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    next_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class PriceCatalogSyncJob(UUIDPrimaryKeyMixin, Base):
    __tablename__ = "price_catalog_sync_jobs"

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True
    )
    trigger: Mapped[str] = mapped_column(String(32), nullable=False, default="manual")
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="running")
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    duration_ms: Mapped[int | None] = mapped_column(Integer)
    summary: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict)
    errors: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
