"""Catálogo canónico de aplicaciones del shell JAIOS (menú principal).

Fuente de verdad del launcher: module_key, ruta, permisos y orden.
El frontend MODULE_REGISTRY aporta iconografía/nav interna; este catálogo
decide visibilidad y estado para GET /api/v1/modules.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ModuleAvailability = Literal["available", "disabled", "forbidden", "coming_soon"]


@dataclass(frozen=True)
class AppCatalogEntry:
    module_key: str
    name: str
    description: str
    route: str
    order: int
    required_permissions: tuple[str, ...] = ()
    """Si vacío, se usa la regla de permiso por module_key (ver resolve)."""
    admin_only: bool = False
    tenant_module_key: str | None = None
    """Clave en tenant_modules cuando difiere (p.ej. prices, suppliers)."""
    feature_flag: str | None = None
    badge: str | None = None
    beta: bool = False
    coming_soon: bool = False
    icon_key: str = "app"


# Catálogo alineado con frontend/src/lib/modules/registry.ts (ids / rutas).
APP_CATALOG: tuple[AppCatalogEntry, ...] = (
    AppCatalogEntry(
        module_key="lottery",
        name="Lottery IA",
        description="Resultados, consulta histórica y Lotería IA",
        route="/lottery",
        order=10,
        required_permissions=("lottery.access", "lottery_view", "view_modules"),
        tenant_module_key="lottery",
        badge="IA",
        icon_key="lottery",
    ),
    AppCatalogEntry(
        module_key="licitaciones",
        name="Licitaciones",
        description="Bid Center y oportunidades DGCP",
        route="/apps/licitaciones",
        order=20,
        required_permissions=("view_dgcp",),
        tenant_module_key="dgcp",
        icon_key="licitaciones",
    ),
    AppCatalogEntry(
        module_key="ventas",
        name="Ventas",
        description="Pedidos, cotizaciones y pipeline comercial",
        route="/apps/ventas",
        order=30,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="ventas",
    ),
    AppCatalogEntry(
        module_key="crm",
        name="CRM",
        description="Leads, contactos y oportunidades",
        route="/apps/crm",
        order=40,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="crm",
    ),
    AppCatalogEntry(
        module_key="compras",
        name="Compras",
        description="Proveedores, contratos y compras",
        route="/apps/compras",
        order=50,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="compras",
    ),
    AppCatalogEntry(
        module_key="proveedores",
        name="Proveedores",
        description="Directorio e inteligencia de suplidores",
        route="/apps/proveedores",
        order=60,
        required_permissions=(),
        tenant_module_key="suppliers",
        icon_key="proveedores",
    ),
    AppCatalogEntry(
        module_key="documentos",
        name="Documentos",
        description="Repositorio y expedientes documentales",
        route="/apps/documentos",
        order=70,
        required_permissions=("view_documents", "view_modules"),
        tenant_module_key="documents",
        icon_key="documentos",
    ),
    AppCatalogEntry(
        module_key="comunicaciones",
        name="Comunicaciones",
        description="Bandeja unificada y canales",
        route="/apps/comunicaciones",
        order=80,
        required_permissions=("view_modules",),
        icon_key="comunicaciones",
    ),
    AppCatalogEntry(
        module_key="clientes",
        name="Clientes",
        description="Clientes y cuentas Odoo",
        route="/apps/clientes",
        order=90,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="clientes",
    ),
    AppCatalogEntry(
        module_key="facturacion",
        name="Facturación",
        description="Facturas y cuentas por cobrar",
        route="/apps/facturacion",
        order=100,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="facturacion",
    ),
    AppCatalogEntry(
        module_key="finanzas",
        name="Finanzas",
        description="Vista financiera (cuando esté habilitada)",
        route="/apps/facturacion",
        order=105,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        coming_soon=True,
        icon_key="finanzas",
    ),
    AppCatalogEntry(
        module_key="helpdesk",
        name="Helpdesk / Soporte",
        description="Tickets y soporte (próximamente)",
        route="",
        order=110,
        coming_soon=True,
        icon_key="helpdesk",
    ),
    AppCatalogEntry(
        module_key="precios",
        name="Inteligencia de Precios",
        description="Búsqueda y alertas de precios",
        route="/apps/precios",
        order=120,
        required_permissions=(),
        tenant_module_key="prices",
        icon_key="precios",
    ),
    AppCatalogEntry(
        module_key="tareas",
        name="Tareas",
        description="Pendientes y asignaciones",
        route="/apps/tareas",
        order=130,
        required_permissions=("view_modules",),
        tenant_module_key="tasks",
        icon_key="tareas",
    ),
    AppCatalogEntry(
        module_key="calendario",
        name="Calendario",
        description="Calendario y correo Microsoft 365",
        route="/apps/calendario",
        order=140,
        required_permissions=("view_m365",),
        tenant_module_key="m365",
        icon_key="calendario",
    ),
    AppCatalogEntry(
        module_key="empresas-grupo",
        name="Empresas del Grupo",
        description="Expedientes legales y fiscales del grupo",
        route="/apps/empresas-grupo",
        order=150,
        required_permissions=("view_documents", "view_modules"),
        tenant_module_key="documents",
        icon_key="empresas",
    ),
    AppCatalogEntry(
        module_key="agentes-ia",
        name="Agentes IA",
        description="Bandeja inteligente y Hermes",
        route="/apps/agentes-ia",
        order=160,
        required_permissions=("view_assistant", "view_modules"),
        tenant_module_key="hermes",
        badge="Beta",
        beta=True,
        icon_key="agentes",
    ),
    AppCatalogEntry(
        module_key="inventario",
        name="Inventario",
        description="Stock y almacenes",
        route="/apps/inventario",
        order=170,
        required_permissions=("view_odoo",),
        tenant_module_key="odoo",
        icon_key="inventario",
    ),
    AppCatalogEntry(
        module_key="reportes",
        name="Reportes",
        description="Reportes operativos",
        route="/apps/reportes",
        order=180,
        required_permissions=("view_modules",),
        icon_key="reportes",
    ),
    AppCatalogEntry(
        module_key="configuracion",
        name="Configuración",
        description="Administración del tenant",
        route="/configuracion",
        order=900,
        admin_only=True,
        icon_key="config",
    ),
)


def list_catalog() -> tuple[AppCatalogEntry, ...]:
    return APP_CATALOG
