"""Capa 1 — Clasificador de intención del Copiloto JAIOS.

Determina QUÉ tipo de interacción es el mensaje antes de consultar cualquier índice.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum

from app.schemas.assistant import AssistantQueryRequest
from app.services.business_intent_router import BusinessIntent, BusinessIntentRouter, ParsedBusinessQuestion
from app.services.business_terms import detect_product_in_text, normalize_question


class AssistantTopIntent(str, Enum):
    GENERAL_CHAT = "general_chat"
    IDENTITY = "identity_question"
    HELP = "help"
    COMMERCIAL_SEARCH = "commercial_search"
    DGCP = "dgcp_query"
    REPOSITORY = "repository_query"
    ERP = "erp_query"
    TASKS = "tasks_query"
    M365 = "m365_query"
    ENTERPRISE_SEARCH = "enterprise_search_query"
    RECORD_CONTEXT = "record_context"
    UNKNOWN = "unknown"


@dataclass
class AssistantIntentResult:
    intent: AssistantTopIntent
    business: ParsedBusinessQuestion
    product_label: str | None = None
    product_terms: list[str] | None = None


class AssistantIntentClassifier:
    GENERAL_CHAT_EXACT = frozenset({
        "hola", "hello", "hi", "hey", "holi",
        "buenos dias", "buenos días", "buenas tardes", "buenas noches",
        "gracias", "muchas gracias", "ok", "vale", "perfecto", "entendido",
        "adios", "adiós", "chau", "bye", "good morning", "good afternoon",
    })

    GENERAL_CHAT_PATTERNS = (
        r"^(?:hola|hello|hi|hey)[\s!?.,]*$",
        r"^(?:buenos?\s+d[ií]as?|buenas?\s+tardes|buenas?\s+noches)[\s!?.,]*$",
        r"^(?:c[oó]mo\s+est[aá]s?|qu[eé]\s+tal)[\s!?.,]*$",
        r"^(?:gracias|muchas\s+gracias)[\s!?.,]*$",
    )

    HELP_SIGNALS = (
        "ayuda", "help", "qué puedes hacer", "que puedes hacer",
        "cómo funciona", "como funciona", "qué sabes hacer", "que sabes hacer",
        "para qué sirves", "para que sirves", "qué haces", "que haces",
    )

    COMMERCIAL_VERBS = (
        "buscar", "busca", "necesito", "requiero", "cotiz", "precio", "precios",
        "lista de precios", "listas de precios", "me sale", "comparar", "alternativa",
        "proveedor", "stock", "disponible", "cuánto cuesta", "cuanto cuesta",
        "mejor precio", "más barato", "mas barato", "más barata", "mas barata",
    )

    PRODUCT_CATEGORY_HINTS = (
        "laptop", "laptops", "notebook", "impresora", "servidor", "switch",
        "monitor", "desktop", "computadora", "toner", "cartucho", "router",
        "firewall", "licencia", "microsoft", "dell", "hp", "lenovo", "cisco",
    )

    RECORD_DEICTIC = (
        "este equipo", "este producto", "esta licitación", "esta licitacion",
        "este proceso", "del proceso", "de este", "de esta", "aquí", "aqui",
    )

    IDENTITY_PATTERNS = (
        r"^(?:qui[eé]n\s+eres|quien\s+eres|qu[eé]\s+eres|que\s+eres|pres[eé]ntate|presentate)[\s!?.,]*$",
        r"^(?:qui[eé]n\s+eres\s+t[uú]|quien\s+eres\s+tu)[\s!?.,]*$",
    )

    SALES_RANKING_SIGNALS = (
        "cliente le hemos vendido más", "cliente nos ha comprado más",
        "cliente ha comprado más", "quién nos ha comprado más", "quien nos ha comprado más",
        "producto más vendido", "producto mas vendido", "cliente compró más", "cliente compro más",
    )

    @classmethod
    def classify(
        cls,
        question: str,
        payload: AssistantQueryRequest | None = None,
        conv=None,
    ) -> AssistantIntentResult:
        q = normalize_question(question)
        lowered = q.lower().strip().rstrip("?!.")
        business = BusinessIntentRouter.classify(q)
        product_label, product_terms = detect_product_in_text(q)

        if cls._is_general_chat(lowered):
            return AssistantIntentResult(
                intent=AssistantTopIntent.GENERAL_CHAT,
                business=business,
            )

        if cls._is_identity(lowered):
            return AssistantIntentResult(
                intent=AssistantTopIntent.IDENTITY,
                business=business,
            )

        if cls._is_help(lowered):
            return AssistantIntentResult(
                intent=AssistantTopIntent.HELP,
                business=business,
            )

        if payload and cls._is_record_context(q, lowered, payload):
            return AssistantIntentResult(
                intent=AssistantTopIntent.RECORD_CONTEXT,
                business=business,
                product_label=product_label,
                product_terms=product_terms,
            )

        if business.intent == BusinessIntent.DGCP:
            return AssistantIntentResult(
                intent=AssistantTopIntent.DGCP,
                business=business,
                product_label=business.product_label,
                product_terms=business.product_terms,
            )

        if business.intent == BusinessIntent.DOCUMENT:
            return AssistantIntentResult(
                intent=AssistantTopIntent.REPOSITORY,
                business=business,
            )

        if business.intent in (
            BusinessIntent.SALES,
            BusinessIntent.PURCHASE,
            BusinessIntent.CUSTOMER_FINANCE,
            BusinessIntent.SUPPLIER,
        ):
            return AssistantIntentResult(
                intent=AssistantTopIntent.ERP,
                business=business,
                product_label=business.product_label,
                product_terms=business.product_terms,
            )

        if business.intent == BusinessIntent.TASKS:
            return AssistantIntentResult(
                intent=AssistantTopIntent.TASKS,
                business=business,
            )

        if business.intent == BusinessIntent.M365:
            return AssistantIntentResult(
                intent=AssistantTopIntent.M365,
                business=business,
            )

        if business.intent == BusinessIntent.ENTERPRISE_SEARCH:
            return AssistantIntentResult(
                intent=AssistantTopIntent.ENTERPRISE_SEARCH,
                business=business,
            )

        if business.intent == BusinessIntent.PRICE or cls._is_commercial_search(lowered, product_label):
            return AssistantIntentResult(
                intent=AssistantTopIntent.COMMERCIAL_SEARCH,
                business=business,
                product_label=business.product_label or product_label,
                product_terms=business.product_terms or product_terms,
            )

        return AssistantIntentResult(
            intent=AssistantTopIntent.UNKNOWN,
            business=business,
            product_label=product_label,
            product_terms=product_terms,
        )

    @classmethod
    def _is_general_chat(cls, lowered: str) -> bool:
        if lowered in cls.GENERAL_CHAT_EXACT:
            return True
        return any(re.match(pat, lowered) for pat in cls.GENERAL_CHAT_PATTERNS)

    @classmethod
    def _is_identity(cls, lowered: str) -> bool:
        return any(re.match(pat, lowered) for pat in cls.IDENTITY_PATTERNS)

    @classmethod
    def _is_help(cls, lowered: str) -> bool:
        return any(sig in lowered for sig in cls.HELP_SIGNALS)

    @classmethod
    def _is_commercial_search(cls, lowered: str, product_label: str | None) -> bool:
        if any(v in lowered for v in cls.COMMERCIAL_VERBS):
            return True
        if product_label and any(h in lowered for h in cls.PRODUCT_CATEGORY_HINTS):
            return True
        if product_label and re.search(r"\d{2,}", lowered):
            return True
        return False

    @classmethod
    def _is_record_context(
        cls,
        question: str,
        lowered: str,
        payload: AssistantQueryRequest,
    ) -> bool:
        if not payload.current_record_id or not payload.record_type:
            return False
        if not any(d in lowered for d in cls.RECORD_DEICTIC):
            return False
        analytics = any(
            s in lowered
            for s in (
                "precio", "promedio", "vend", "margen", "historial",
                "cuánto", "cuanto", "costo", "cotiz", "recomend",
            )
        )
        return analytics or payload.record_type in ("dgcp", "dgcp_opportunity", "product")
