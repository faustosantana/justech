"""Resuelve configuración Cecomsa desde tenant settings."""

from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.integration_settings import TenantIntegrationSetting
from integrations.suppliers.config import CecomsaConnectorConfig


def _parse_bool(val) -> bool:
    if isinstance(val, bool):
        return val
    if val in (None, ""):
        return False
    return str(val).lower() in ("1", "true", "yes", "on")


async def resolve_cecomsa_config(db: AsyncSession, tenant_id: uuid.UUID) -> CecomsaConnectorConfig:
    result = await db.execute(
        select(TenantIntegrationSetting).where(
            TenantIntegrationSetting.tenant_id == tenant_id,
            TenantIntegrationSetting.provider == "cecomsa",
        )
    )
    row = result.scalar_one_or_none()
    cfg = dict(row.config) if row else {}

    enabled = cfg.get("enabled")
    if enabled is None:
        enabled = True

    return CecomsaConnectorConfig(
        enabled=_parse_bool(enabled),
        store_url=(cfg.get("store_url") or "https://www.cecomsa.com").strip(),
        currency=(cfg.get("currency") or "DOP").strip(),
        rate_limit_per_minute=int(cfg.get("rate_limit_per_minute") or 20),
        cache_ttl_seconds=int(cfg.get("cache_ttl_seconds") or 600),
        demo_mode=_parse_bool(cfg.get("demo_mode")),
        source="database" if row else "default",
    )
