"""Conversión de moneda para búsqueda comercial."""

from __future__ import annotations

from decimal import Decimal

from app.config import settings

DEFAULT_USD_DOP_RATE = Decimal("58")


def usd_dop_rate() -> Decimal:
    raw = getattr(settings, "commercial_usd_dop_rate", None) or DEFAULT_USD_DOP_RATE
    try:
        return Decimal(str(raw))
    except Exception:
        return DEFAULT_USD_DOP_RATE


def normalize_currency(currency: str | None) -> str:
    if not currency:
        return "DOP"
    c = currency.upper().replace("RD$", "DOP").strip()
    if c in ("USD", "US$", "$"):
        return "USD"
    if c in ("DOP", "RD", "PESO", "PESOS"):
        return "DOP"
    return c


def to_target_currency(
    amount: Decimal,
    from_currency: str | None,
    target: str,
) -> tuple[Decimal, bool, str | None]:
    """Convierte monto a moneda objetivo. Retorna (monto, usó_tasa_aprox, advertencia)."""
    if amount is None:
        return Decimal("0"), False, None
    src = normalize_currency(from_currency)
    tgt = normalize_currency(target)
    if src == tgt:
        return amount, False, None

    rate = usd_dop_rate()
    if src == "DOP" and tgt == "USD":
        return (amount / rate).quantize(Decimal("0.01")), True, (
            f"Conversión aproximada DOP→USD con tasa {rate}."
        )
    if src == "USD" and tgt == "DOP":
        return (amount * rate).quantize(Decimal("0.01")), True, (
            f"Conversión aproximada USD→DOP con tasa {rate}."
        )
    return amount, False, f"No tengo tasa para {src}→{tgt}; comparación puede ser imprecisa."


def format_price_dual(amount: Decimal, currency: str | None) -> str:
    src = normalize_currency(currency)
    if src == "USD":
        usd, _, _ = to_target_currency(amount, src, "USD")
        dop, approx, _ = to_target_currency(amount, src, "DOP")
        suffix = " aprox." if approx else ""
        return f"US${usd} / RD${dop}{suffix}"
    usd, approx, _ = to_target_currency(amount, src, "USD")
    label = f"RD${amount}"
    if src != "DOP":
        label = f"{currency}{amount}"
    return f"{label} aprox. US${usd}" + (" (tasa configurada)" if approx else "")
