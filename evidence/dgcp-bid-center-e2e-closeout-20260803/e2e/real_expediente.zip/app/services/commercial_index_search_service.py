"""Motor de búsqueda comercial sobre índice local Odoo."""

from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.commercial_search import (
    CommercialPriceHistory,
    CommercialSearchItem,
    CustomerPurchaseHistory,
    ProductSalesHistory,
)
from app.schemas.commercial_search import (
    CommercialPriceHistoryItem,
    CommercialPriceHistoryResponse,
    CommercialSearchFilters,
    CommercialSearchItemResponse,
    CommercialSearchResponse,
    CustomerPurchaseHistoryItem,
    CustomerPurchaseHistoryResponse,
    ProductSalesHistoryItem,
    ProductSalesHistoryResponse,
)
from app.services.commercial_product_filter import is_valid_primary_product
from app.services.commercial_currency import normalize_currency, to_target_currency
from app.services.commercial_search.intent import detect_search_intent
from app.services.hermes_commercial_formatter import format_category_price_answer
from app.services.commercial_search.normalizer import expand_synonyms, normalize_query, tokenize_query


ACCESSORY_TERMS = {
    "adaptador", "adaptadores", "adapter", "cargador", "cargadores", "charger",
    "bateria", "baterias", "battery", "cable", "cables", "funda", "case",
    "soporte", "stand", "cartucho", "toner", "tóner",
}


def _score_item(item: CommercialSearchItem, tokens: list[str], intent) -> float:
    blob = (item.search_blob or "").lower()
    if not blob:
        blob = normalize_query(
            " ".join(
                filter(
                    None,
                    [item.product_name, item.sku, item.brand, item.model, item.description, item.customer_name],
                )
            )
        )

    score = 0.0
    for token in tokens:
        if token in blob:
            score += 10.0
        elif any(token in part for part in blob.split()):
            score += 4.0

    if intent.brand and item.brand and intent.brand.lower() in item.brand.lower():
        score += 15.0
    if intent.ram_gb and item.description and f"{intent.ram_gb}gb" in item.description.lower():
        score += 8.0
    if intent.storage_gb and item.description and f"{intent.storage_gb}gb" in item.description.lower():
        score += 6.0

    name_lower = (item.product_name or item.description or "").lower()
    for ex in intent.excluded_terms:
        if ex in name_lower:
            score -= 40.0
    for ex in ACCESSORY_TERMS:
        if ex in name_lower and intent.main_products_only and intent.target_category == "laptops":
            score -= 50.0

    if item.document_type == "sale_order":
        score += 3.0
    elif item.document_type == "invoice":
        score += 2.0
    elif item.document_type == "quotation":
        score += 1.0

    if item.unit_price:
        score += 0.5
    return max(score, 0.0)


def _item_to_response(item: CommercialSearchItem, score: float) -> CommercialSearchItemResponse:
    odoo_url = None
    if item.source_model == "sale.order.line":
        odoo_url = f"/odoo/quotations/{item.document_number}" if item.document_number else None
    elif item.source_model == "account.move.line":
        odoo_url = f"/odoo/invoices/{item.document_number}" if item.document_number else None

    return CommercialSearchItemResponse(
        id=item.id,
        source_system=item.source_system,
        source_model=item.source_model,
        source_id=item.source_id,
        company_id=item.company_id,
        document_type=item.document_type,
        document_number=item.document_number,
        document_status=item.document_status,
        customer_id=item.customer_id,
        customer_name=item.customer_name,
        customer_rnc=item.customer_rnc,
        product_id=item.product_id,
        product_name=item.product_name,
        sku=item.sku,
        brand=item.brand,
        model=item.model,
        description=item.description,
        quantity=item.quantity,
        unit_price=item.unit_price,
        total=item.total,
        currency=item.currency,
        date=item.date,
        salesperson=item.salesperson,
        supplier_name=item.supplier_name,
        margin=item.margin,
        margin_pct=item.margin_pct,
        relevance_score=round(score, 2),
        odoo_url=odoo_url,
    )


class CommercialIndexSearchService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    def _apply_filters(self, stmt, filters: CommercialSearchFilters | None):
        if not filters:
            return stmt
        if filters.company_id is not None:
            stmt = stmt.where(CommercialSearchItem.company_id == filters.company_id)
        if filters.customer_id is not None:
            stmt = stmt.where(CommercialSearchItem.customer_id == filters.customer_id)
        if filters.product_id is not None:
            stmt = stmt.where(CommercialSearchItem.product_id == filters.product_id)
        if filters.document_type:
            stmt = stmt.where(CommercialSearchItem.document_type == filters.document_type)
        if filters.document_status:
            stmt = stmt.where(CommercialSearchItem.document_status.ilike(f"%{filters.document_status}%"))
        if filters.salesperson:
            stmt = stmt.where(CommercialSearchItem.salesperson.ilike(f"%{filters.salesperson}%"))
        if filters.date_from:
            stmt = stmt.where(CommercialSearchItem.date >= filters.date_from)
        if filters.date_to:
            stmt = stmt.where(CommercialSearchItem.date <= filters.date_to)
        if filters.min_amount is not None:
            stmt = stmt.where(CommercialSearchItem.total >= filters.min_amount)
        if filters.max_amount is not None:
            stmt = stmt.where(CommercialSearchItem.total <= filters.max_amount)
        return stmt

    async def search(
        self,
        query: str,
        *,
        filters: CommercialSearchFilters | None = None,
        limit: int = 50,
    ) -> CommercialSearchResponse:
        q = query.strip()
        if not q:
            return CommercialSearchResponse(query=q, total=0, items=[], filters_applied=filters)

        intent = detect_search_intent(q)
        tokens = tokenize_query(q)
        expanded = expand_synonyms(tokens)
        search_tokens = list(dict.fromkeys(tokens + expanded))[:20]

        clauses = []
        for token in search_tokens:
            pattern = f"%{token}%"
            clauses.append(CommercialSearchItem.search_blob.ilike(pattern))
            clauses.append(CommercialSearchItem.customer_name.ilike(pattern))
            clauses.append(CommercialSearchItem.product_name.ilike(pattern))
            clauses.append(CommercialSearchItem.document_number.ilike(pattern))
            clauses.append(CommercialSearchItem.sku.ilike(pattern))
            clauses.append(CommercialSearchItem.customer_rnc.ilike(pattern))

        stmt = select(CommercialSearchItem).where(
            CommercialSearchItem.tenant_id == self.tenant_id,
            or_(*clauses) if clauses else True,
        )
        stmt = self._apply_filters(stmt, filters)
        stmt = stmt.limit(min(limit * 4, 200))

        result = await self.db.execute(stmt)
        rows = list(result.scalars().all())

        scored = [(row, _score_item(row, search_tokens, intent)) for row in rows]
        scored = [(row, sc) for row, sc in scored if sc > 0]
        if intent.main_products_only and intent.target_category:
            scored = [
                (row, sc)
                for row, sc in scored
                if is_valid_primary_product(
                    product_name=row.product_name,
                    description=row.description,
                    sku=row.sku,
                    brand=row.brand,
                    intent=intent,
                )
            ]
        scored.sort(key=lambda x: x[1], reverse=True)
        top = scored[:limit]

        items = [_item_to_response(row, sc) for row, sc in top]
        index_count = await self.db.scalar(
            select(func.count()).select_from(CommercialSearchItem).where(
                CommercialSearchItem.tenant_id == self.tenant_id
            )
        )

        message = None
        if not items and (index_count or 0) == 0:
            message = "Índice comercial vacío. Ejecute sincronización desde Odoo."

        return CommercialSearchResponse(
            query=q,
            intent=intent.intent,
            target_category=intent.target_category,
            total=len(items),
            items=items,
            filters_applied=filters,
            index_available=(index_count or 0) > 0,
            message=message,
        )

    async def price_history(
        self,
        *,
        query: str | None = None,
        product_id: int | None = None,
        customer_id: int | None = None,
        date_from: date | None = None,
        date_to: date | None = None,
        limit: int = 50,
    ) -> CommercialPriceHistoryResponse:
        stmt = select(CommercialPriceHistory).where(CommercialPriceHistory.tenant_id == self.tenant_id)
        if product_id:
            stmt = stmt.where(CommercialPriceHistory.product_id == product_id)
        if customer_id:
            stmt = stmt.where(CommercialPriceHistory.customer_id == customer_id)
        if date_from:
            stmt = stmt.where(CommercialPriceHistory.date >= date_from)
        if date_to:
            stmt = stmt.where(CommercialPriceHistory.date <= date_to)
        if query:
            tokens = tokenize_query(query)
            clauses = []
            for token in tokens:
                pattern = f"%{token}%"
                clauses.append(CommercialPriceHistory.product_name.ilike(pattern))
                clauses.append(CommercialPriceHistory.sku.ilike(pattern))
                clauses.append(CommercialPriceHistory.brand.ilike(pattern))
            if clauses:
                stmt = stmt.where(or_(*clauses))
        stmt = stmt.order_by(CommercialPriceHistory.date.desc().nullslast()).limit(limit)
        result = await self.db.execute(stmt)
        rows = list(result.scalars().all())
        items = [
            CommercialPriceHistoryItem(
                id=r.id,
                product_id=r.product_id,
                product_name=r.product_name,
                sku=r.sku,
                brand=r.brand,
                customer_id=r.customer_id,
                customer_name=r.customer_name,
                unit_price=r.unit_price,
                currency=r.currency,
                date=r.date,
                document_number=r.document_number,
                document_type=r.document_type,
                margin=r.margin,
                margin_pct=r.margin_pct,
                salesperson=r.salesperson,
                source_model=r.source_model,
                source_id=r.source_id,
            )
            for r in rows
        ]
        prices = [r.unit_price for r in rows if r.unit_price]
        return CommercialPriceHistoryResponse(
            items=items,
            total=len(items),
            min_price=min(prices) if prices else None,
            max_price=max(prices) if prices else None,
            avg_price=(sum(prices) / len(prices)) if prices else None,
        )

    async def customer_history(
        self,
        *,
        customer_id: int | None = None,
        query: str | None = None,
        limit: int = 50,
    ) -> CustomerPurchaseHistoryResponse:
        stmt = select(CustomerPurchaseHistory).where(
            CustomerPurchaseHistory.tenant_id == self.tenant_id
        )
        if customer_id:
            stmt = stmt.where(CustomerPurchaseHistory.customer_id == customer_id)
        if query:
            pattern = f"%{normalize_query(query)}%"
            stmt = stmt.where(
                or_(
                    CustomerPurchaseHistory.customer_name.ilike(pattern),
                    CustomerPurchaseHistory.customer_rnc.ilike(pattern),
                    CustomerPurchaseHistory.product_name.ilike(pattern),
                )
            )
        stmt = stmt.order_by(CustomerPurchaseHistory.last_purchase_date.desc().nullslast()).limit(limit)
        result = await self.db.execute(stmt)
        rows = list(result.scalars().all())
        customer_name = rows[0].customer_name if rows else None
        return CustomerPurchaseHistoryResponse(
            customer_id=customer_id,
            customer_name=customer_name,
            items=[
                CustomerPurchaseHistoryItem(
                    id=r.id,
                    customer_id=r.customer_id,
                    customer_name=r.customer_name,
                    customer_rnc=r.customer_rnc,
                    product_id=r.product_id,
                    product_name=r.product_name,
                    sku=r.sku,
                    brand=r.brand,
                    total_quantity=r.total_quantity,
                    total_amount=r.total_amount,
                    purchase_count=r.purchase_count,
                    last_purchase_date=r.last_purchase_date,
                    last_unit_price=r.last_unit_price,
                    currency=r.currency,
                )
                for r in rows
            ],
            total=len(rows),
        )

    async def product_history(
        self,
        *,
        product_id: int | None = None,
        query: str | None = None,
        limit: int = 50,
    ) -> ProductSalesHistoryResponse:
        stmt = select(ProductSalesHistory).where(ProductSalesHistory.tenant_id == self.tenant_id)
        if product_id:
            stmt = stmt.where(ProductSalesHistory.product_id == product_id)
        if query:
            tokens = tokenize_query(query)
            clauses = []
            for token in tokens:
                pattern = f"%{token}%"
                clauses.append(ProductSalesHistory.product_name.ilike(pattern))
                clauses.append(ProductSalesHistory.sku.ilike(pattern))
                clauses.append(ProductSalesHistory.brand.ilike(pattern))
            if clauses:
                stmt = stmt.where(or_(*clauses))
        stmt = stmt.order_by(ProductSalesHistory.last_sale_date.desc().nullslast()).limit(limit)
        result = await self.db.execute(stmt)
        rows = list(result.scalars().all())
        product_name = rows[0].product_name if rows else None
        return ProductSalesHistoryResponse(
            product_id=product_id,
            product_name=product_name,
            items=[
                ProductSalesHistoryItem(
                    id=r.id,
                    product_id=r.product_id,
                    product_name=r.product_name,
                    sku=r.sku,
                    brand=r.brand,
                    model=r.model,
                    total_quantity=r.total_quantity,
                    total_amount=r.total_amount,
                    sale_count=r.sale_count,
                    avg_unit_price=r.avg_unit_price,
                    min_unit_price=r.min_unit_price,
                    max_unit_price=r.max_unit_price,
                    last_sale_date=r.last_sale_date,
                    top_customer_name=r.top_customer_name,
                    currency=r.currency,
                )
                for r in rows
            ],
            total=len(rows),
        )

    async def answer_for_hermes(
        self,
        query: str,
        *,
        limit: int = 10,
        company_id: int | None = None,
        last_sold: bool = False,
    ) -> dict:
        """Respuesta estructurada para Hermes con fuentes citadas."""
        from app.services.hermes_commercial_formatter import format_commercial_history_answer

        filters = CommercialSearchFilters(company_id=company_id) if company_id else None
        result = await self.search(query, filters=filters, limit=limit)
        items = list(result.items)
        if last_sold and items:
            items.sort(key=lambda i: i.date or date.min, reverse=True)
        if not items:
            return {
                "success": True,
                "answer": result.message or f"No encontré historial comercial indexado para «{query}».",
                "sources": [],
                "data": {"total": 0, "index_available": result.index_available},
            }

        sources = []
        for item in items[:8]:
            sources.append(
                {
                    "source_system": "odoo",
                    "source_model": item.source_model,
                    "source_id": item.source_id,
                    "document_number": item.document_number,
                    "customer": item.customer_name,
                    "unit_price": str(item.unit_price) if item.unit_price else None,
                    "date": str(item.date) if item.date else None,
                }
            )

        answer = format_commercial_history_answer(
            query=query,
            items=items,
            total=len(items),
            last_sold=last_sold,
        )

        return {
            "success": True,
            "answer": answer,
            "sources": sources,
            "data": {
                "total": len(items),
                "intent": result.intent,
                "target_category": result.target_category,
                "items": [i.model_dump(mode="json") for i in items[:5]],
            },
        }

    async def count_under_price(
        self,
        query: str,
        *,
        max_price: Decimal,
        currency: str | None = None,
        company_id: int | None = None,
        limit: int = 150,
        price_list_result: dict | None = None,
    ) -> dict:
        """Cuenta productos principales únicos bajo precio máximo (USD por defecto en preguntas en dólares)."""
        from app.schemas.commercial_search import CommercialSearchFilters

        intent = detect_search_intent(query, main_products_only=True)
        target_currency = normalize_currency(currency or "USD")
        filters = CommercialSearchFilters(company_id=company_id) if company_id else None
        result = await self.search(query, filters=filters, limit=limit)

        seen: set[str] = set()
        matched: list = []
        conversion_warnings: set[str] = set()

        for item in result.items:
            if item.unit_price is None:
                continue
            if not is_valid_primary_product(
                product_name=item.product_name,
                description=item.description,
                sku=item.sku,
                brand=item.brand,
                intent=intent,
            ):
                continue

            cmp_price, approx, warn = to_target_currency(
                item.unit_price, item.currency, target_currency
            )
            if warn:
                conversion_warnings.add(warn)
            if cmp_price <= max_price:
                key = (item.product_name or item.sku or str(item.product_id) or "").lower().strip()
                if not key or key in seen:
                    continue
                seen.add(key)
                matched.append(item)

        matched.sort(
            key=lambda i: to_target_currency(
                i.unit_price or Decimal("999999999"),
                i.currency,
                target_currency,
            )[0]
        )

        answer = format_category_price_answer(
            query=query,
            intent=intent,
            odoo_items=matched,
            max_price=max_price,
            price_currency=target_currency,
            price_list_result=price_list_result,
            conversion_warning=" ".join(conversion_warnings) if conversion_warnings else None,
        )

        return {
            "success": True,
            "answer": answer,
            "summary": answer[:2000],
            "sources": [
                {"source_system": "odoo", "type": "commercial_index"},
                {"source_system": "price_lists", "type": "search_prices"},
            ],
            "data": {
                "count": len(matched),
                "max_price": str(max_price),
                "currency": target_currency,
                "index_available": result.index_available,
                "intent": intent.intent,
                "target_category": intent.target_category,
                "excluded_accessories": True,
                "items": [i.model_dump(mode="json") for i in matched[:5]],
            },
        }
