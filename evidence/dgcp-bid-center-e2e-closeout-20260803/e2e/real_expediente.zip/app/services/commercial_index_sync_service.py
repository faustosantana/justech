"""Sincronización incremental del índice comercial desde Odoo (solo lectura)."""

from __future__ import annotations

import logging
import re
import uuid
from collections import defaultdict
from datetime import UTC, date, datetime
from decimal import Decimal

from sqlalchemy import delete, func, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.commercial_search import (
    CommercialPriceHistory,
    CommercialSearchDocument,
    CommercialSearchItem,
    CommercialSearchSyncState,
    CustomerPurchaseHistory,
    ProductSalesHistory,
)
from app.services.commercial_search.normalizer import extract_brand, normalize_query, tokenize_query
from app.services.odoo_service import OdooService
from integrations.odoo.exceptions import OdooConnectionError, OdooNotConfiguredError
from integrations.odoo.normalize import (
    odoo_date,
    odoo_dec,
    odoo_float,
    odoo_m2o_id,
    odoo_m2o_name,
    odoo_m2o_name_opt,
    odoo_str,
    odoo_str_opt,
)

logger = logging.getLogger(__name__)

SYNC_MODELS = (
    "sale.order.line",
    "account.move.line",
    "purchase.order.line",
    "crm.lead",
)

BATCH_SIZE = 500


def _parse_date(value: str | date | None) -> date | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except ValueError:
        return None


def _odoo_write_date_filter(watermark: datetime) -> str:
    """Odoo espera datetimes naive (sin timezone) en dominios."""
    dt = watermark
    if dt.tzinfo is not None:
        dt = dt.replace(tzinfo=None)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _normalize_watermark(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def _parse_odoo_datetime(value: str | datetime | None) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        except ValueError:
            return None
    return _normalize_watermark(dt)


def _extract_model_from_name(name: str | None) -> str | None:
    if not name:
        return None
    for m in re.finditer(r"\b([A-Z]{1,4}\d{3,5}[A-Z]?|\d{4}[A-Z]{1,3})\b", name.upper()):
        return m.group(1)
    return None


def _build_search_blob(**parts: str | None) -> str:
    text = " ".join(str(p) for p in parts.values() if p)
    return normalize_query(text)


class CommercialIndexSyncService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.odoo = OdooService(db, tenant_id, user_id=user_id)

    async def get_status(self) -> dict:
        items_count = await self.db.scalar(
            select(func.count()).select_from(CommercialSearchItem).where(
                CommercialSearchItem.tenant_id == self.tenant_id
            )
        )
        docs_count = await self.db.scalar(
            select(func.count()).select_from(CommercialSearchDocument).where(
                CommercialSearchDocument.tenant_id == self.tenant_id
            )
        )
        states_result = await self.db.execute(
            select(CommercialSearchSyncState).where(CommercialSearchSyncState.tenant_id == self.tenant_id)
        )
        state_rows = list(states_result.scalars().all())
        model_states = [
            {
                "model": s.source_model,
                "watermark": s.watermark.isoformat() if s.watermark else None,
                "last_run_at": s.last_run_at.isoformat() if s.last_run_at else None,
                "records_indexed": s.records_indexed,
                "last_error": s.last_error,
            }
            for s in state_rows
        ]
        last_sync = max(
            (s.last_run_at for s in state_rows if s.last_run_at),
            default=None,
        )
        return {
            "models": model_states,
            "total_items": int(items_count or 0),
            "total_documents": int(docs_count or 0),
            "last_sync_at": last_sync,
        }

    async def run_sync(
        self,
        *,
        full_reindex: bool = False,
        models: list[str] | None = None,
    ) -> dict:
        started = datetime.now(UTC)
        target_models = models or list(SYNC_MODELS)
        results: list[dict] = []

        try:
            client = await self.odoo._get_client()
            if not client.is_configured:
                return {
                    "status": "skipped",
                    "started_at": started,
                    "finished_at": datetime.now(UTC),
                    "results": [],
                    "aggregates_rebuilt": False,
                    "message": "Odoo no configurado",
                }
        except (OdooNotConfiguredError, OdooConnectionError) as exc:
            return {
                "status": "error",
                "started_at": started,
                "finished_at": datetime.now(UTC),
                "results": [],
                "aggregates_rebuilt": False,
                "message": str(exc),
            }

        partner_rnc = await self._load_partner_rnc_map(client)

        for model in target_models:
            try:
                if model == "sale.order.line":
                    count = await self._sync_sale_order_lines(client, full_reindex=full_reindex, partner_rnc=partner_rnc)
                elif model == "account.move.line":
                    count = await self._sync_invoice_lines(client, full_reindex=full_reindex, partner_rnc=partner_rnc)
                elif model == "purchase.order.line":
                    count = await self._sync_purchase_lines(client, full_reindex=full_reindex, partner_rnc=partner_rnc)
                elif model == "crm.lead":
                    count = await self._sync_crm_leads(client, full_reindex=full_reindex, partner_rnc=partner_rnc)
                else:
                    count = 0
                results.append({"model": model, "indexed": count, "error": None})
            except Exception as exc:
                logger.exception("Commercial sync failed model=%s", model)
                await self._set_sync_error(model, str(exc))
                results.append({"model": model, "indexed": 0, "error": str(exc)})

        aggregates = await self.rebuild_aggregates()
        await self.db.commit()
        return {
            "status": "completed",
            "started_at": started,
            "finished_at": datetime.now(UTC),
            "results": results,
            "aggregates_rebuilt": aggregates,
            "message": None,
        }

    async def _load_partner_rnc_map(self, client) -> dict[int, str]:
        try:
            rows = await client.search_read(
                "res.partner",
                self.odoo._domain("res.partner", [("customer_rank", ">", 0)]),
                ["id", "vat", "name"],
                limit=5000,
            )
        except OdooConnectionError:
            return {}
        return {int(r["id"]): odoo_str_opt(r.get("vat")) or "" for r in rows if r.get("id")}

    async def _get_watermark(self, model: str) -> datetime | None:
        result = await self.db.execute(
            select(CommercialSearchSyncState).where(
                CommercialSearchSyncState.tenant_id == self.tenant_id,
                CommercialSearchSyncState.source_model == model,
            )
        )
        state = result.scalar_one_or_none()
        return None if not state else state.watermark

    async def _set_sync_state(self, model: str, *, watermark: datetime, indexed: int) -> None:
        now = datetime.now(UTC)
        stmt = insert(CommercialSearchSyncState).values(
            tenant_id=self.tenant_id,
            source_model=model,
            watermark=watermark,
            last_run_at=now,
            last_error=None,
            records_indexed=indexed,
        )
        stmt = stmt.on_conflict_do_update(
            index_elements=["tenant_id", "source_model"],
            set_={
                "watermark": watermark,
                "last_run_at": now,
                "last_error": None,
                "records_indexed": CommercialSearchSyncState.records_indexed + indexed,
            },
        )
        await self.db.execute(stmt)

    async def _set_sync_error(self, model: str, error: str) -> None:
        now = datetime.now(UTC)
        stmt = insert(CommercialSearchSyncState).values(
            tenant_id=self.tenant_id,
            source_model=model,
            watermark=None,
            last_run_at=now,
            last_error=error[:2000],
            records_indexed=0,
        )
        stmt = stmt.on_conflict_do_update(
            index_elements=["tenant_id", "source_model"],
            set_={"last_run_at": now, "last_error": error[:2000]},
        )
        await self.db.execute(stmt)

    async def _upsert_document(self, **fields) -> uuid.UUID:
        now = datetime.now(UTC)
        fields.setdefault("tenant_id", self.tenant_id)
        fields.setdefault("source_system", "odoo")
        fields.setdefault("indexed_at", now)
        stmt = insert(CommercialSearchDocument).values(**fields)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_commercial_search_doc",
            set_={
                "document_type": stmt.excluded.document_type,
                "document_number": stmt.excluded.document_number,
                "document_status": stmt.excluded.document_status,
                "customer_id": stmt.excluded.customer_id,
                "customer_name": stmt.excluded.customer_name,
                "customer_rnc": stmt.excluded.customer_rnc,
                "date": stmt.excluded.date,
                "currency": stmt.excluded.currency,
                "total": stmt.excluded.total,
                "salesperson": stmt.excluded.salesperson,
                "supplier_name": stmt.excluded.supplier_name,
                "raw_payload_json": stmt.excluded.raw_payload_json,
                "indexed_at": now,
            },
        ).returning(CommercialSearchDocument.id)
        result = await self.db.execute(stmt)
        return result.scalar_one()

    async def _upsert_item(self, **fields) -> None:
        now = datetime.now(UTC)
        fields.setdefault("tenant_id", self.tenant_id)
        fields.setdefault("source_system", "odoo")
        fields.setdefault("indexed_at", now)
        stmt = insert(CommercialSearchItem).values(**fields)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_commercial_search_item",
            set_={
                k: getattr(stmt.excluded, k)
                for k in (
                    "document_id",
                    "document_type",
                    "document_number",
                    "document_status",
                    "customer_id",
                    "customer_name",
                    "customer_rnc",
                    "product_id",
                    "product_name",
                    "sku",
                    "brand",
                    "model",
                    "description",
                    "quantity",
                    "unit_price",
                    "total",
                    "currency",
                    "date",
                    "salesperson",
                    "supplier_name",
                    "margin",
                    "margin_pct",
                    "search_blob",
                    "raw_payload_json",
                    "indexed_at",
                )
            },
        )
        await self.db.execute(stmt)

    async def _upsert_price_history(self, **fields) -> None:
        now = datetime.now(UTC)
        fields.setdefault("tenant_id", self.tenant_id)
        fields.setdefault("source_system", "odoo")
        fields.setdefault("indexed_at", now)
        stmt = insert(CommercialPriceHistory).values(**fields)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_commercial_price_history",
            set_={
                "product_id": stmt.excluded.product_id,
                "product_name": stmt.excluded.product_name,
                "sku": stmt.excluded.sku,
                "brand": stmt.excluded.brand,
                "model": stmt.excluded.model,
                "customer_id": stmt.excluded.customer_id,
                "customer_name": stmt.excluded.customer_name,
                "unit_price": stmt.excluded.unit_price,
                "currency": stmt.excluded.currency,
                "date": stmt.excluded.date,
                "document_number": stmt.excluded.document_number,
                "document_type": stmt.excluded.document_type,
                "margin": stmt.excluded.margin,
                "margin_pct": stmt.excluded.margin_pct,
                "salesperson": stmt.excluded.salesperson,
                "raw_payload_json": stmt.excluded.raw_payload_json,
                "indexed_at": now,
            },
        )
        await self.db.execute(stmt)

    async def _sync_sale_order_lines(self, client, *, full_reindex: bool, partner_rnc: dict[int, str]) -> int:
        domain: list = [("order_id.state", "in", ["sale", "done", "sent", "draft"])]
        watermark = None if full_reindex else await self._get_watermark("sale.order.line")
        if watermark:
            domain.append(("write_date", ">", _odoo_write_date_filter(watermark)))

        fields = [
            "id",
            "order_id",
            "order_partner_id",
            "product_id",
            "name",
            "product_uom_qty",
            "price_unit",
            "price_subtotal",
            "write_date",
            "company_id",
        ]
        try:
            rows = await client.search_read(
                "sale.order.line",
                self.odoo._domain("sale.order.line", domain),
                fields + ["purchase_price"],
                limit=BATCH_SIZE,
                order="write_date asc",
            )
        except OdooConnectionError:
            rows = await client.search_read(
                "sale.order.line",
                self.odoo._domain("sale.order.line", domain),
                fields,
                limit=BATCH_SIZE,
                order="write_date asc",
            )

        if not rows:
            return 0

        order_ids = list({odoo_m2o_id(r.get("order_id")) for r in rows if odoo_m2o_id(r.get("order_id"))})
        orders: dict[int, dict] = {}
        if order_ids:
            order_rows = await client.search_read(
                "sale.order",
                self.odoo._domain("sale.order", [("id", "in", order_ids)]),
                ["id", "name", "state", "date_order", "user_id", "amount_total", "currency_id", "company_id"],
                limit=len(order_ids),
            )
            orders = {int(o["id"]): o for o in order_rows}

        product_ids = list({odoo_m2o_id(r.get("product_id")) for r in rows if odoo_m2o_id(r.get("product_id"))})
        products = await self._load_products(client, product_ids)

        max_write = _normalize_watermark(watermark)
        indexed = 0
        for row in rows:
            order_id = odoo_m2o_id(row.get("order_id"))
            order = orders.get(order_id or 0, {})
            partner_id = odoo_m2o_id(row.get("order_partner_id"))
            product_id = odoo_m2o_id(row.get("product_id"))
            product = products.get(product_id or 0, {})
            product_name = odoo_m2o_name(row.get("product_id")) or odoo_str(row.get("name"))
            sku = odoo_str_opt(product.get("default_code"))
            brand = extract_brand(tokenize_query(product_name), product_name) or None
            model = _extract_model_from_name(product_name)
            order_state = odoo_str(order.get("state")) if order else None
            doc_type = "quotation" if order_state in ("draft", "sent") else "sale_order"
            order_date = _parse_date(odoo_date(order.get("date_order")) if order else None)
            company_id = odoo_m2o_id(row.get("company_id")) or odoo_m2o_id(order.get("company_id") if order else None)
            customer_name = odoo_m2o_name(row.get("order_partner_id"))
            customer_rnc = partner_rnc.get(partner_id or 0)
            price = odoo_dec(row.get("price_unit"))
            cost = odoo_dec(row.get("purchase_price")) if "purchase_price" in row else None
            margin = (price - cost) if cost and cost > 0 and price else None
            margin_pct = (margin / price * 100) if margin and price else None
            currency = odoo_m2o_name_opt(order.get("currency_id")) if order else None
            salesperson = odoo_m2o_name_opt(order.get("user_id")) if order else None

            doc_id = await self._upsert_document(
                company_id=company_id,
                source_model="sale.order",
                source_id=order_id or 0,
                document_type=doc_type,
                document_number=odoo_m2o_name(row.get("order_id")),
                document_status=order_state,
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                date=order_date,
                currency=currency,
                total=odoo_dec(order.get("amount_total")) if order else odoo_dec(row.get("price_subtotal")),
                salesperson=salesperson,
                raw_payload_json={"order": order, "line": row},
            )

            search_blob = _build_search_blob(
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                customer_name=customer_name,
                customer_rnc=customer_rnc,
                document_number=odoo_m2o_name(row.get("order_id")),
            )

            await self._upsert_item(
                company_id=company_id,
                document_id=doc_id,
                source_model="sale.order.line",
                source_id=int(row["id"]),
                document_type=doc_type,
                document_number=odoo_m2o_name(row.get("order_id")),
                document_status=order_state,
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                product_id=product_id,
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                quantity=odoo_dec(row.get("product_uom_qty")),
                unit_price=price,
                total=odoo_dec(row.get("price_subtotal")),
                currency=currency,
                date=order_date,
                salesperson=salesperson,
                margin=margin,
                margin_pct=margin_pct,
                search_blob=search_blob,
                raw_payload_json={"line": row, "order": order},
            )

            if doc_type == "sale_order" and price:
                await self._upsert_price_history(
                    company_id=company_id,
                    source_model="sale.order.line",
                    source_id=int(row["id"]),
                    product_id=product_id,
                    product_name=product_name,
                    sku=sku,
                    brand=brand,
                    model=model,
                    customer_id=partner_id,
                    customer_name=customer_name,
                    unit_price=price,
                    currency=currency,
                    date=order_date,
                    document_number=odoo_m2o_name(row.get("order_id")),
                    document_type=doc_type,
                    margin=margin,
                    margin_pct=margin_pct,
                    salesperson=salesperson,
                    raw_payload_json={"line": row},
                )

            wd = row.get("write_date")
            ts = _parse_odoo_datetime(wd)
            if ts and (max_write is None or ts > max_write):
                max_write = ts
            indexed += 1

        if max_write:
            await self._set_sync_state("sale.order.line", watermark=max_write, indexed=indexed)
        return indexed

    async def _sync_invoice_lines(self, client, *, full_reindex: bool, partner_rnc: dict[int, str]) -> int:
        domain: list = [("move_id.move_type", "in", ["out_invoice", "out_refund"]), ("display_type", "=", "product")]
        watermark = None if full_reindex else await self._get_watermark("account.move.line")
        if watermark:
            domain.append(("write_date", ">", _odoo_write_date_filter(watermark)))

        rows = await client.search_read(
            "account.move.line",
            self.odoo._domain("account.move.line", domain),
            [
                "id",
                "move_id",
                "partner_id",
                "product_id",
                "name",
                "quantity",
                "price_unit",
                "price_subtotal",
                "write_date",
                "company_id",
            ],
            limit=BATCH_SIZE,
            order="write_date asc",
        )
        if not rows:
            return 0

        move_ids = list({odoo_m2o_id(r.get("move_id")) for r in rows if odoo_m2o_id(r.get("move_id"))})
        moves: dict[int, dict] = {}
        if move_ids:
            move_rows = await client.search_read(
                "account.move",
                self.odoo._domain("account.move", [("id", "in", move_ids)]),
                ["id", "name", "state", "invoice_date", "invoice_user_id", "amount_total", "currency_id", "company_id"],
                limit=len(move_ids),
            )
            moves = {int(m["id"]): m for m in move_rows}

        product_ids = list({odoo_m2o_id(r.get("product_id")) for r in rows if odoo_m2o_id(r.get("product_id"))})
        products = await self._load_products(client, product_ids)

        max_write = _normalize_watermark(watermark)
        indexed = 0
        for row in rows:
            move_id = odoo_m2o_id(row.get("move_id"))
            move = moves.get(move_id or 0, {})
            partner_id = odoo_m2o_id(row.get("partner_id"))
            product_id = odoo_m2o_id(row.get("product_id"))
            product = products.get(product_id or 0, {})
            product_name = odoo_m2o_name(row.get("product_id")) or odoo_str(row.get("name"))
            sku = odoo_str_opt(product.get("default_code"))
            brand = extract_brand(tokenize_query(product_name), product_name) or None
            model = _extract_model_from_name(product_name)
            inv_date = _parse_date(odoo_date(move.get("invoice_date")) if move else None)
            company_id = odoo_m2o_id(row.get("company_id")) or odoo_m2o_id(move.get("company_id") if move else None)
            customer_name = odoo_m2o_name(row.get("partner_id"))
            customer_rnc = partner_rnc.get(partner_id or 0)
            price = odoo_dec(row.get("price_unit"))
            currency = odoo_m2o_name_opt(move.get("currency_id")) if move else None
            salesperson = odoo_m2o_name_opt(move.get("invoice_user_id")) if move else None
            move_state = odoo_str(move.get("state")) if move else None

            doc_id = await self._upsert_document(
                company_id=company_id,
                source_model="account.move",
                source_id=move_id or 0,
                document_type="invoice",
                document_number=odoo_m2o_name(row.get("move_id")),
                document_status=move_state,
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                date=inv_date,
                currency=currency,
                total=odoo_dec(move.get("amount_total")) if move else odoo_dec(row.get("price_subtotal")),
                salesperson=salesperson,
                raw_payload_json={"move": move, "line": row},
            )

            search_blob = _build_search_blob(
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                customer_name=customer_name,
                customer_rnc=customer_rnc,
                document_number=odoo_m2o_name(row.get("move_id")),
            )

            await self._upsert_item(
                company_id=company_id,
                document_id=doc_id,
                source_model="account.move.line",
                source_id=int(row["id"]),
                document_type="invoice",
                document_number=odoo_m2o_name(row.get("move_id")),
                document_status=move_state,
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                product_id=product_id,
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                quantity=odoo_dec(row.get("quantity")),
                unit_price=price,
                total=odoo_dec(row.get("price_subtotal")),
                currency=currency,
                date=inv_date,
                salesperson=salesperson,
                search_blob=search_blob,
                raw_payload_json={"line": row, "move": move},
            )

            if price:
                await self._upsert_price_history(
                    company_id=company_id,
                    source_model="account.move.line",
                    source_id=int(row["id"]),
                    product_id=product_id,
                    product_name=product_name,
                    sku=sku,
                    brand=brand,
                    model=model,
                    customer_id=partner_id,
                    customer_name=customer_name,
                    unit_price=price,
                    currency=currency,
                    date=inv_date,
                    document_number=odoo_m2o_name(row.get("move_id")),
                    document_type="invoice",
                    salesperson=salesperson,
                    raw_payload_json={"line": row},
                )

            wd = row.get("write_date")
            ts = _parse_odoo_datetime(wd)
            if ts and (max_write is None or ts > max_write):
                max_write = ts
            indexed += 1

        if max_write:
            await self._set_sync_state("account.move.line", watermark=max_write, indexed=indexed)
        return indexed

    async def _sync_purchase_lines(self, client, *, full_reindex: bool, partner_rnc: dict[int, str]) -> int:
        domain: list = [("order_id.state", "in", ["purchase", "done"])]
        watermark = None if full_reindex else await self._get_watermark("purchase.order.line")
        if watermark:
            domain.append(("write_date", ">", _odoo_write_date_filter(watermark)))

        try:
            rows = await client.search_read(
                "purchase.order.line",
                self.odoo._domain("purchase.order.line", domain),
                [
                    "id",
                    "order_id",
                    "partner_id",
                    "product_id",
                    "name",
                    "product_qty",
                    "price_unit",
                    "price_subtotal",
                    "write_date",
                    "company_id",
                ],
                limit=BATCH_SIZE,
                order="write_date asc",
            )
        except OdooConnectionError:
            return 0

        if not rows:
            return 0

        order_ids = list({odoo_m2o_id(r.get("order_id")) for r in rows if odoo_m2o_id(r.get("order_id"))})
        orders: dict[int, dict] = {}
        if order_ids:
            order_rows = await client.search_read(
                "purchase.order",
                self.odoo._domain("purchase.order", [("id", "in", order_ids)]),
                ["id", "name", "state", "date_order", "partner_id", "amount_total", "currency_id", "company_id"],
                limit=len(order_ids),
            )
            orders = {int(o["id"]): o for o in order_rows}

        product_ids = list({odoo_m2o_id(r.get("product_id")) for r in rows if odoo_m2o_id(r.get("product_id"))})
        products = await self._load_products(client, product_ids)

        max_write = _normalize_watermark(watermark)
        indexed = 0
        for row in rows:
            order_id = odoo_m2o_id(row.get("order_id"))
            order = orders.get(order_id or 0, {})
            vendor_id = odoo_m2o_id(order.get("partner_id") if order else row.get("partner_id"))
            product_id = odoo_m2o_id(row.get("product_id"))
            product = products.get(product_id or 0, {})
            product_name = odoo_m2o_name(row.get("product_id")) or odoo_str(row.get("name"))
            sku = odoo_str_opt(product.get("default_code"))
            brand = extract_brand(tokenize_query(product_name), product_name) or None
            model = _extract_model_from_name(product_name)
            po_date = _parse_date(odoo_date(order.get("date_order")) if order else None)
            company_id = odoo_m2o_id(row.get("company_id")) or odoo_m2o_id(order.get("company_id") if order else None)
            supplier_name = odoo_m2o_name(order.get("partner_id")) if order else None
            currency = odoo_m2o_name_opt(order.get("currency_id")) if order else None
            order_state = odoo_str(order.get("state")) if order else None

            doc_id = await self._upsert_document(
                company_id=company_id,
                source_model="purchase.order",
                source_id=order_id or 0,
                document_type="purchase",
                document_number=odoo_m2o_name(row.get("order_id")),
                document_status=order_state,
                customer_id=vendor_id,
                customer_name=supplier_name,
                date=po_date,
                currency=currency,
                total=odoo_dec(order.get("amount_total")) if order else odoo_dec(row.get("price_subtotal")),
                supplier_name=supplier_name,
                raw_payload_json={"order": order, "line": row},
            )

            search_blob = _build_search_blob(
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                customer_name=supplier_name,
                document_number=odoo_m2o_name(row.get("order_id")),
            )

            await self._upsert_item(
                company_id=company_id,
                document_id=doc_id,
                source_model="purchase.order.line",
                source_id=int(row["id"]),
                document_type="purchase",
                document_number=odoo_m2o_name(row.get("order_id")),
                document_status=order_state,
                customer_id=vendor_id,
                customer_name=supplier_name,
                product_id=product_id,
                product_name=product_name,
                sku=sku,
                brand=brand,
                model=model,
                description=odoo_str(row.get("name")),
                quantity=odoo_dec(row.get("product_qty")),
                unit_price=odoo_dec(row.get("price_unit")),
                total=odoo_dec(row.get("price_subtotal")),
                currency=currency,
                date=po_date,
                supplier_name=supplier_name,
                search_blob=search_blob,
                raw_payload_json={"line": row, "order": order},
            )

            wd = row.get("write_date")
            ts = _parse_odoo_datetime(wd)
            if ts and (max_write is None or ts > max_write):
                max_write = ts
            indexed += 1

        if max_write:
            await self._set_sync_state("purchase.order.line", watermark=max_write, indexed=indexed)
        return indexed

    async def _sync_crm_leads(self, client, *, full_reindex: bool, partner_rnc: dict[int, str]) -> int:
        domain: list = []
        watermark = None if full_reindex else await self._get_watermark("crm.lead")
        if watermark:
            domain.append(("write_date", ">", _odoo_write_date_filter(watermark)))

        rows = await client.search_read(
            "crm.lead",
            self.odoo._domain("crm.lead", domain),
            [
                "id",
                "name",
                "partner_id",
                "expected_revenue",
                "probability",
                "stage_id",
                "user_id",
                "write_date",
                "company_id",
                "date_deadline",
            ],
            limit=BATCH_SIZE,
            order="write_date asc",
        )
        if not rows:
            return 0

        max_write = _normalize_watermark(watermark)
        indexed = 0
        for row in rows:
            partner_id = odoo_m2o_id(row.get("partner_id"))
            customer_name = odoo_m2o_name(row.get("partner_id")) or odoo_str(row.get("name"))
            customer_rnc = partner_rnc.get(partner_id or 0)
            company_id = odoo_m2o_id(row.get("company_id"))
            lead_name = odoo_str(row.get("name"))
            search_blob = _build_search_blob(
                product_name=lead_name,
                customer_name=customer_name,
                customer_rnc=customer_rnc,
            )

            doc_id = await self._upsert_document(
                company_id=company_id,
                source_model="crm.lead",
                source_id=int(row["id"]),
                document_type="opportunity",
                document_number=str(row["id"]),
                document_status=odoo_m2o_name_opt(row.get("stage_id")),
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                date=_parse_date(odoo_date(row.get("date_deadline"))),
                total=odoo_dec(row.get("expected_revenue")),
                salesperson=odoo_m2o_name_opt(row.get("user_id")),
                raw_payload_json={"lead": row},
            )

            await self._upsert_item(
                company_id=company_id,
                document_id=doc_id,
                source_model="crm.lead",
                source_id=int(row["id"]),
                document_type="opportunity",
                document_number=str(row["id"]),
                document_status=odoo_m2o_name_opt(row.get("stage_id")),
                customer_id=partner_id,
                customer_name=customer_name,
                customer_rnc=customer_rnc or None,
                product_name=lead_name,
                description=lead_name,
                total=odoo_dec(row.get("expected_revenue")),
                date=_parse_date(odoo_date(row.get("date_deadline"))),
                salesperson=odoo_m2o_name_opt(row.get("user_id")),
                search_blob=search_blob,
                raw_payload_json={"lead": row},
            )

            wd = row.get("write_date")
            ts = _parse_odoo_datetime(wd)
            if ts and (max_write is None or ts > max_write):
                max_write = ts
            indexed += 1

        if max_write:
            await self._set_sync_state("crm.lead", watermark=max_write, indexed=indexed)
        return indexed

    async def _load_products(self, client, product_ids: list[int]) -> dict[int, dict]:
        if not product_ids:
            return {}
        rows = await client.search_read(
            "product.product",
            self.odoo._domain("product.product", [("id", "in", product_ids)]),
            ["id", "name", "default_code", "product_tmpl_id"],
            limit=len(product_ids),
        )
        return {int(r["id"]): r for r in rows}

    async def rebuild_aggregates(self) -> bool:
        """Reconstruye tablas agregadas desde commercial_search_items."""
        now = datetime.now(UTC)
        await self.db.execute(
            delete(CustomerPurchaseHistory).where(CustomerPurchaseHistory.tenant_id == self.tenant_id)
        )
        await self.db.execute(
            delete(ProductSalesHistory).where(ProductSalesHistory.tenant_id == self.tenant_id)
        )

        result = await self.db.execute(
            select(CommercialSearchItem).where(
                CommercialSearchItem.tenant_id == self.tenant_id,
                CommercialSearchItem.document_type.in_(("sale_order", "invoice")),
                CommercialSearchItem.product_id.isnot(None),
                CommercialSearchItem.customer_id.isnot(None),
            )
        )
        items = list(result.scalars().all())

        customer_buckets: dict[tuple, dict] = defaultdict(
            lambda: {
                "total_quantity": Decimal("0"),
                "total_amount": Decimal("0"),
                "purchase_count": 0,
                "last_purchase_date": None,
                "last_unit_price": None,
                "currency": None,
                "customer_name": None,
                "customer_rnc": None,
                "product_name": None,
                "sku": None,
                "brand": None,
                "model": None,
            }
        )
        product_buckets: dict[tuple, dict] = defaultdict(
            lambda: {
                "total_quantity": Decimal("0"),
                "total_amount": Decimal("0"),
                "sale_count": 0,
                "prices": [],
                "last_sale_date": None,
                "currency": None,
                "product_name": None,
                "sku": None,
                "brand": None,
                "model": None,
                "customers": defaultdict(lambda: Decimal("0")),
            }
        )

        for item in items:
            qty = item.quantity or Decimal("0")
            amt = item.total or Decimal("0")
            ck = (item.company_id, item.customer_id, item.product_id)
            bucket = customer_buckets[ck]
            bucket["total_quantity"] += qty
            bucket["total_amount"] += amt
            bucket["purchase_count"] += 1
            bucket["customer_name"] = item.customer_name
            bucket["customer_rnc"] = item.customer_rnc
            bucket["product_name"] = item.product_name
            bucket["sku"] = item.sku
            bucket["brand"] = item.brand
            bucket["model"] = item.model
            bucket["currency"] = item.currency
            if item.date and (bucket["last_purchase_date"] is None or item.date >= bucket["last_purchase_date"]):
                bucket["last_purchase_date"] = item.date
                bucket["last_unit_price"] = item.unit_price

            pk = (item.company_id, item.product_id)
            pb = product_buckets[pk]
            pb["total_quantity"] += qty
            pb["total_amount"] += amt
            pb["sale_count"] += 1
            pb["product_name"] = item.product_name
            pb["sku"] = item.sku
            pb["brand"] = item.brand
            pb["model"] = item.model
            pb["currency"] = item.currency
            if item.unit_price:
                pb["prices"].append(item.unit_price)
            if item.date and (pb["last_sale_date"] is None or item.date >= pb["last_sale_date"]):
                pb["last_sale_date"] = item.date
            if item.customer_id:
                pb["customers"][item.customer_id] += amt

        for (company_id, customer_id, product_id), data in customer_buckets.items():
            self.db.add(
                CustomerPurchaseHistory(
                    tenant_id=self.tenant_id,
                    company_id=company_id,
                    customer_id=customer_id,
                    customer_name=data["customer_name"],
                    customer_rnc=data["customer_rnc"],
                    product_id=product_id,
                    product_name=data["product_name"],
                    sku=data["sku"],
                    brand=data["brand"],
                    model=data["model"],
                    total_quantity=data["total_quantity"],
                    total_amount=data["total_amount"],
                    purchase_count=data["purchase_count"],
                    last_purchase_date=data["last_purchase_date"],
                    last_unit_price=data["last_unit_price"],
                    currency=data["currency"],
                    indexed_at=now,
                )
            )

        for (company_id, product_id), data in product_buckets.items():
            prices = data["prices"]
            top_customer_id = None
            top_customer_name = None
            if data["customers"]:
                top_customer_id = max(data["customers"], key=data["customers"].get)
                for item in items:
                    if item.product_id == product_id and item.customer_id == top_customer_id:
                        top_customer_name = item.customer_name
                        break
            self.db.add(
                ProductSalesHistory(
                    tenant_id=self.tenant_id,
                    company_id=company_id,
                    product_id=product_id,
                    product_name=data["product_name"],
                    sku=data["sku"],
                    brand=data["brand"],
                    model=data["model"],
                    total_quantity=data["total_quantity"],
                    total_amount=data["total_amount"],
                    sale_count=data["sale_count"],
                    avg_unit_price=(sum(prices) / len(prices)) if prices else None,
                    min_unit_price=min(prices) if prices else None,
                    max_unit_price=max(prices) if prices else None,
                    last_sale_date=data["last_sale_date"],
                    top_customer_id=top_customer_id,
                    top_customer_name=top_customer_name,
                    currency=data["currency"],
                    indexed_at=now,
                )
            )

        await self.db.flush()
        return True
