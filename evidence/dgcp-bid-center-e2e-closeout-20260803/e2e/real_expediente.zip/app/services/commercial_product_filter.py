"""Filtro estricto producto principal vs accesorio — índice Odoo y Hermes."""

from __future__ import annotations

import re

from app.services.commercial_search.intent import SearchIntent
from app.services.price_classification import contains_non_laptop_keyword, is_laptop_product

# Términos que invalidan un resultado como laptop aunque diga "portátil" en el texto
LAPTOP_HARD_EXCLUDE = re.compile(
    r"(?i)(^|\b)("
    r"memoria|ram suelta|sodimm|dimm|"
    r"cargador|charger|bater[ií]a|battery|"
    r"adaptador|adapter|conversor|"
    r"docking|dock station|base para|stand para|"
    r"cd[\s-]?rom|dvd|"
    r"teclado|keyboard|mouse|rat[oó]n|"
    r"repuesto|flex|bisagra|carcasa|"
    r"pantalla suelta|lcd suelto|"
    r"disco duro suelto|hard drive suelto|"
    r"para laptop|para notebook|para port[aá]til|"
    r"compatible con laptop|upgrade ram"
    r")(\b|$)",
)

LAPTOP_STRONG_INCLUDE = re.compile(
    r"(?i)(^|\b)(laptop|notebook|port[aá]til|computadora port[aá]til|pc port[aá]til)(\b|$)",
)


def _blob(*parts: str | None) -> str:
    return " ".join(p for p in parts if p).strip()


def is_valid_laptop_record(
    *,
    product_name: str | None,
    description: str | None = None,
    sku: str | None = None,
    brand: str | None = None,
) -> bool:
    text = _blob(product_name, description, sku, brand)
    if not text:
        return False
    low = text.lower()

    if LAPTOP_HARD_EXCLUDE.search(low):
        return False
    if contains_non_laptop_keyword(low):
        return False

    if LAPTOP_STRONG_INCLUDE.search(low):
        return True

    return is_laptop_product(
        product_name or description or "",
        product_type="laptop" if "laptop" in low or "portátil" in low or "portatil" in low else None,
        ram_gb=None,
        storage_gb=None,
    )


def is_valid_primary_product(
    *,
    product_name: str | None,
    description: str | None = None,
    sku: str | None = None,
    brand: str | None = None,
    intent: SearchIntent | None,
) -> bool:
    if not intent or not intent.target_category:
        return True
    cat = intent.target_category
    if cat == "laptops":
        return is_valid_laptop_record(
            product_name=product_name,
            description=description,
            sku=sku,
            brand=brand,
        )
    if cat in ("monitors", "printers", "servers", "desktops", "networking", "ups"):
        text = _blob(product_name, description).lower()
        if contains_non_laptop_keyword(text):
            return False
        synonyms = {
            "monitors": ("monitor", "pantalla", "display"),
            "printers": ("impresora", "printer", "multifuncional"),
            "servers": ("servidor", "server", "poweredge", "proliant"),
            "desktops": ("desktop", "escritorio", "optiplex", "thinkcentre"),
            "networking": ("switch", "router", "firewall", "access point"),
            "ups": ("ups", "no break", "nobreak"),
        }
        return any(s in text for s in synonyms.get(cat, (cat,)))
    return True


def accessory_exclusion_note(intent: SearchIntent | None) -> str | None:
    if intent and intent.target_category == "laptops":
        return "Excluí memorias, CD-ROM, cargadores, baterías y accesorios porque no son laptops."
    return None
