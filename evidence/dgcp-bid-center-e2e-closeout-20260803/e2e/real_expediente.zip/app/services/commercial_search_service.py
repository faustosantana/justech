"""Búsqueda comercial — JAIOS obtiene datos, Hermes interpreta."""

from __future__ import annotations

import uuid
from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.schemas.assistant import AssistantLink, AssistantQueryResponse
from app.services.business_answer_builder import build_business_answer, links_to_dict
from app.services.business_intent_router import ParsedBusinessQuestion
from app.services.hermes_client import HermesClient
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters
from app.services.price_question_service import PriceQuestionService


class CommercialSearchService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        hermes: HermesClient | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.price_q = PriceQuestionService(db, tenant_id)
        self.price_svc = PriceIntelligenceService(db, tenant_id)
        self.hermes = hermes or HermesClient()

    async def answer(
        self,
        question: str,
        classified: ParsedBusinessQuestion,
        source_labels: list[str],
    ) -> AssistantQueryResponse:
        filters = self.price_q._parse_question(question)
        self._enrich_filters(filters, question, classified)

        if not self.price_q.has_search_criteria(filters, question):
            return AssistantQueryResponse(
                question=question,
                answer=(
                    "Indica qué producto buscas: marca, modelo, cantidad o especificaciones "
                    "(ej. «Necesito 20 laptops Dell i5 16GB»)."
                ),
                sources=["jaios"],
                query_type="commercial_search_ambiguous",
            )

        compare_mode = any(
            k in question.lower()
            for k in ("me sale mejor", "más barata", "mas barata", "comparar", "alternativas")
        )
        if compare_mode:
            result = await self.price_svc.compare(filters, question=question)
            return self.price_q._compare_response(question, result)

        search = await self.price_svc.search(filters)
        if not search.items:
            return AssistantQueryResponse(
                question=question,
                answer=(
                    "No encontré productos en listas indexadas para esa búsqueda. "
                    "Verifica que las listas estén en 03_PROVEEDORES y ejecuta make prices-sync."
                ),
                sources=["price_intelligence"],
                query_type="commercial_search",
            )

        facts = self._build_facts(question, search)
        sources = list(dict.fromkeys(["price_intelligence"] + source_labels))

        if settings.hermes_enabled and self.hermes.is_available():
            hermes_result = await self.hermes.interpret_question(
                question=question,
                context={"intent": "commercial_search", "query": question},
                facts=facts,
            )
            if hermes_result and hermes_result.summary:
                links = [
                    AssistantLink(label="Inteligencia de Precios", url="/prices", type="module"),
                ]
                return AssistantQueryResponse(
                    question=question,
                    answer=hermes_result.summary,
                    sources=list(dict.fromkeys(["hermes"] + sources)),
                    query_type="commercial_search",
                    links=links,
                    data=facts,
                )

        return self._template_response(question, search)

    @staticmethod
    def _enrich_filters(
        filters: PriceSearchFilters,
        question: str,
        classified: ParsedBusinessQuestion,
    ) -> None:
        if not filters.q and classified.product_label:
            filters.q = classified.product_label
        if not filters.q and classified.product_terms:
            filters.q = " ".join(classified.product_terms[:3])
        if not filters.q:
            from app.services.business_terms import detect_product_in_text

            label, terms = detect_product_in_text(question)
            if label:
                filters.q = label
            elif terms:
                filters.q = " ".join(terms[:3])

    @staticmethod
    def _build_facts(question: str, search) -> dict:
        results = []
        for p in search.items[:12]:
            price_val = p.preferred_price or p.price
            results.append({
                "supplier": p.supplier,
                "description": (p.description or p.sku or "")[:120],
                "price": str(price_val) if price_val is not None else None,
                "currency": p.currency,
                "stock": p.stock,
                "sku": p.sku,
                "source_file": p.source_filename,
                "source_sheet": p.source_sheet,
            })
        return {
            "query": question,
            "total": search.total,
            "results": results,
        }

    def _template_response(self, question: str, search) -> AssistantQueryResponse:
        top = search.items[:8]
        rows = []
        for p in top:
            price_val = p.preferred_price or p.price
            date_l = p.source_file_date.strftime("%d/%m/%Y") if p.source_file_date else "—"
            rows.append([
                p.supplier or "—",
                (p.description or p.sku or "—")[:80],
                f"{p.currency} {price_val}" if price_val else "—",
                p.stock if p.stock is not None else "—",
                f"{p.source_filename} ({date_l})",
            ])
        best_price = top[0].preferred_price or top[0].price
        best_date = (
            top[0].source_file_date.strftime("%d/%m/%Y") if top[0].source_file_date else "sin fecha"
        )
        structured = build_business_answer(
            intent="commercial_search",
            source="price_intelligence",
            summary=(
                f"Encontré {search.total} producto(s) en listas comerciales. "
                f"Mejor precio: {top[0].currency} {best_price} ({top[0].supplier}). "
                f"Lista del {best_date}."
            ),
            tables=[{
                "title": "Alternativas",
                "columns": ["Proveedor", "Producto", "Precio", "Stock", "Fuente"],
                "rows": rows,
            }],
        )
        links = [AssistantLink(label="Inteligencia de Precios", url="/prices", type="module")]
        structured["links"] = links_to_dict(links)
        return AssistantQueryResponse(
            question=question,
            answer=structured["summary"],
            sources=["price_intelligence"],
            query_type="commercial_search",
            structured_data=structured,
            links=links,
            data={"total": search.total},
        )
