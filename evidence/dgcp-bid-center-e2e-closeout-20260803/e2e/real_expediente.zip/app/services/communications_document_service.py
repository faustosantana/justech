"""Repositorios documentales unificados — adjuntar a WhatsApp, Outlook y Teams."""

from __future__ import annotations

import base64
import uuid
from dataclasses import dataclass
from pathlib import Path

import httpx
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.document import Document
from app.models.m365_repository import M365RepositoryFile
from app.schemas.communications import (
    CommunicationsAttachActionResponse,
    CommunicationsRepositoryItem,
    CommunicationsRepositoryListResponse,
)
from app.schemas.m365_mail import M365MailAttachmentRef, M365MailComposeRequest
from app.services.m365_file_classifier import CATEGORY_LABELS
from app.services.m365_documents_service import M365DocumentsService
from app.services.m365_graph_session import M365GraphSessionService
from app.services.m365_mail_service import M365MailService
from app.services.whatsapp_service import WhatsappService
from integrations.microsoft365.errors import GraphError

MAX_ATTACH_BYTES = 8 * 1024 * 1024

JAIOS_CATEGORY_LABELS: dict[str, str] = {
    "general": "General",
    "legal": "Documentos legales",
    "contrato": "Contratos",
    "plantilla": "Plantillas",
    "licitacion": "Licitaciones",
    "proveedor": "Proveedores",
    "cliente": "Clientes",
    "financiero": "Finanzas",
    "cotizacion": "Cotizaciones",
}

REPOSITORY_SOURCES = {
    "m365_repository": "Microsoft 365",
    "jaios_document": "Documentos JAIOS",
}


@dataclass
class ResolvedDocument:
    name: str
    mime_type: str
    content: bytes
    web_url: str | None = None
    onedrive_item_id: str | None = None


class CommunicationsDocumentService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID) -> None:
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._sessions = M365GraphSessionService(db, tenant_id, user_id)

    async def list_repository(
        self,
        *,
        search: str = "",
        category: str | None = None,
        source: str | None = None,
        limit: int = 80,
    ) -> CommunicationsRepositoryListResponse:
        items: list[CommunicationsRepositoryItem] = []
        categories: dict[str, int] = {}

        if source in (None, "", "m365_repository"):
            m365_items, m365_cats = await self._list_m365(search=search, category=category, limit=limit)
            items.extend(m365_items)
            for k, v in m365_cats.items():
                categories[k] = categories.get(k, 0) + v

        if source in (None, "", "jaios_document"):
            jaios_items, jaios_cats = await self._list_jaios(search=search, category=category, limit=limit)
            items.extend(jaios_items)
            for k, v in jaios_cats.items():
                categories[k] = categories.get(k, 0) + v

        items.sort(key=lambda x: (x.category, x.name.lower()))
        if len(items) > limit:
            items = items[:limit]

        return CommunicationsRepositoryListResponse(
            items=items,
            total=len(items),
            categories=categories,
            sources=list(REPOSITORY_SOURCES.keys()),
        )

    async def _list_m365(
        self, *, search: str, category: str | None, limit: int
    ) -> tuple[list[CommunicationsRepositoryItem], dict[str, int]]:
        q = select(M365RepositoryFile).where(
            M365RepositoryFile.tenant_id == self.tenant_id,
            M365RepositoryFile.is_folder.is_(False),
            M365RepositoryFile.is_deleted.is_(False),
        )
        if category:
            q = q.where(M365RepositoryFile.document_category == category)
        if search.strip():
            like = f"%{search.strip().lower()}%"
            q = q.where(func.lower(M365RepositoryFile.name).like(like))
        q = q.order_by(M365RepositoryFile.name).limit(limit)
        rows = list((await self.db.execute(q)).scalars().all())

        cat_q = (
            select(M365RepositoryFile.document_category, func.count())
            .where(
                M365RepositoryFile.tenant_id == self.tenant_id,
                M365RepositoryFile.is_folder.is_(False),
                M365RepositoryFile.is_deleted.is_(False),
            )
            .group_by(M365RepositoryFile.document_category)
        )
        categories = {row[0]: int(row[1]) for row in (await self.db.execute(cat_q)).all()}

        items = [
            CommunicationsRepositoryItem(
                id=str(r.id),
                source="m365_repository",
                source_label=REPOSITORY_SOURCES["m365_repository"],
                name=r.name,
                category=r.document_category,
                category_label=CATEGORY_LABELS.get(r.document_category, r.document_category),
                mime_type=r.mime_type,
                size_bytes=r.size_bytes,
                web_url=r.web_url,
                graph_item_id=r.graph_item_id,
            )
            for r in rows
        ]
        return items, categories

    async def _list_jaios(
        self, *, search: str, category: str | None, limit: int
    ) -> tuple[list[CommunicationsRepositoryItem], dict[str, int]]:
        q = select(Document).where(
            Document.tenant_id == self.tenant_id,
            Document.is_active.is_(True),
            Document.storage_path.isnot(None),
        )
        if category:
            q = q.where(Document.category == category)
        if search.strip():
            pat = f"%{search.strip()}%"
            q = q.where(
                or_(
                    Document.title.ilike(pat),
                    Document.filename.ilike(pat),
                )
            )
        q = q.order_by(Document.updated_at.desc()).limit(limit)
        rows = list((await self.db.execute(q)).scalars().all())

        cat_q = (
            select(Document.category, func.count())
            .where(
                Document.tenant_id == self.tenant_id,
                Document.is_active.is_(True),
                Document.storage_path.isnot(None),
            )
            .group_by(Document.category)
        )
        categories = {row[0]: int(row[1]) for row in (await self.db.execute(cat_q)).all()}

        items = [
            CommunicationsRepositoryItem(
                id=str(r.id),
                source="jaios_document",
                source_label=REPOSITORY_SOURCES["jaios_document"],
                name=r.filename or r.title,
                category=r.category,
                category_label=JAIOS_CATEGORY_LABELS.get(r.category, r.category),
                mime_type=r.mime_type,
                size_bytes=r.file_size or None,
                web_url=None,
            )
            for r in rows
            if r.storage_path and Path(r.storage_path).is_file()
        ]
        return items, categories

    async def resolve_item(self, source: str, item_id: str) -> ResolvedDocument | None:
        if source == "m365_repository":
            return await self._resolve_m365(uuid.UUID(item_id))
        if source == "jaios_document":
            return await self._resolve_jaios(uuid.UUID(item_id))
        return None

    async def resolve_m365_live(
        self,
        *,
        item_id: str,
        drive_id: str | None = None,
        source_type: str = "onedrive",
        name: str | None = None,
    ) -> ResolvedDocument | None:
        m365 = M365DocumentsService(self.db, self.tenant_id, self.user_id)
        try:
            item = await m365._resolve_item(item_id, drive_id=drive_id, source_type=source_type)
            content = await m365._download_item(item, drive_id=drive_id, source_type=source_type)
        except (GraphError, PermissionError, Exception):
            return None
        if not content:
            return None
        if len(content) > MAX_ATTACH_BYTES:
            raise ValueError(f"El archivo supera el límite de {MAX_ATTACH_BYTES // (1024 * 1024)} MB")
        return ResolvedDocument(
            name=name or item.name or "documento",
            mime_type=item.mime_type or "application/octet-stream",
            content=content,
            web_url=item.web_url,
            onedrive_item_id=item.id,
        )

    async def _resolve_m365(self, file_id: uuid.UUID) -> ResolvedDocument | None:
        q = await self.db.execute(
            select(M365RepositoryFile).where(
                M365RepositoryFile.id == file_id,
                M365RepositoryFile.tenant_id == self.tenant_id,
                M365RepositoryFile.is_folder.is_(False),
            )
        )
        row = q.scalar_one_or_none()
        if row is None:
            return None

        download_url = row.download_url
        onedrive_item_id = row.graph_item_id
        try:
            sess = await self._sessions.session_for_account(row.account_id)
            item = await sess.client.onedrive.get_item(row.graph_item_id)
            download_url = item.download_url or item.web_url or download_url
            onedrive_item_id = item.id or onedrive_item_id
        except (GraphError, PermissionError, Exception):
            pass

        if not download_url:
            return None

        content = await self._fetch_url(download_url)
        if content is None:
            return None
        if len(content) > MAX_ATTACH_BYTES:
            raise ValueError(f"El archivo supera el límite de {MAX_ATTACH_BYTES // (1024 * 1024)} MB")

        return ResolvedDocument(
            name=row.name,
            mime_type=row.mime_type or "application/octet-stream",
            content=content,
            web_url=row.web_url or download_url,
            onedrive_item_id=onedrive_item_id,
        )

    async def _resolve_jaios(self, doc_id: uuid.UUID) -> ResolvedDocument | None:
        q = await self.db.execute(
            select(Document).where(
                Document.id == doc_id,
                Document.tenant_id == self.tenant_id,
                Document.is_active.is_(True),
            )
        )
        row = q.scalar_one_or_none()
        if row is None or not row.storage_path:
            return None
        path = Path(row.storage_path)
        if not path.is_file():
            return None
        content = path.read_bytes()
        if len(content) > MAX_ATTACH_BYTES:
            raise ValueError(f"El archivo supera el límite de {MAX_ATTACH_BYTES // (1024 * 1024)} MB")
        return ResolvedDocument(
            name=row.filename or row.title,
            mime_type=row.mime_type or "application/octet-stream",
            content=content,
        )

    @staticmethod
    async def _fetch_url(url: str) -> bytes | None:
        try:
            async with httpx.AsyncClient(timeout=60, follow_redirects=True) as client:
                r = await client.get(url)
                r.raise_for_status()
                return r.content
        except Exception:
            return None

    async def attach_whatsapp(
        self,
        session_id: uuid.UUID,
        remote_jid: str,
        *,
        source: str,
        item_id: str,
        caption: str | None = None,
    ) -> CommunicationsAttachActionResponse:
        try:
            resolved = await self.resolve_item(source, item_id)
        except ValueError as exc:
            return CommunicationsAttachActionResponse(ok=False, channel="whatsapp", message=str(exc))
        if resolved is None:
            return CommunicationsAttachActionResponse(ok=False, channel="whatsapp", message="Documento no encontrado")
        return await self._send_whatsapp_document(session_id, remote_jid, resolved, caption)

    async def attach_whatsapp_m365(
        self,
        session_id: uuid.UUID,
        remote_jid: str,
        *,
        item_id: str,
        drive_id: str | None = None,
        source_type: str = "onedrive",
        name: str | None = None,
        caption: str | None = None,
    ) -> CommunicationsAttachActionResponse:
        try:
            resolved = await self.resolve_m365_live(
                item_id=item_id,
                drive_id=drive_id,
                source_type=source_type,
                name=name,
            )
        except ValueError as exc:
            return CommunicationsAttachActionResponse(ok=False, channel="whatsapp", message=str(exc))
        if resolved is None:
            return CommunicationsAttachActionResponse(
                ok=False,
                channel="whatsapp",
                message="No se pudo descargar el documento desde Microsoft 365",
            )
        return await self._send_whatsapp_document(session_id, remote_jid, resolved, caption)

    async def _send_whatsapp_document(
        self,
        session_id: uuid.UUID,
        remote_jid: str,
        resolved: ResolvedDocument,
        caption: str | None,
    ) -> CommunicationsAttachActionResponse:
        wa = WhatsappService(self.db, self.tenant_id, self.user_id)
        try:
            msg = await wa.send_document(
                session_id,
                remote_jid,
                filename=resolved.name,
                mimetype=resolved.mime_type,
                content_base64=base64.b64encode(resolved.content).decode("ascii"),
                caption=caption,
            )
        except Exception as exc:
            return CommunicationsAttachActionResponse(
                ok=False,
                channel="whatsapp",
                message=str(exc) or "No se pudo enviar el documento por WhatsApp",
            )
        if msg is None:
            return CommunicationsAttachActionResponse(
                ok=False, channel="whatsapp", message="Sesión no encontrada o no conectada"
            )
        return CommunicationsAttachActionResponse(
            ok=True,
            channel="whatsapp",
            message=f"Documento enviado: {resolved.name}",
            filename=resolved.name,
            message_id=str(msg.id),
        )

    async def attach_outlook(
        self,
        *,
        to: list[str],
        subject: str,
        body: str,
        source: str,
        item_id: str,
        account_id: uuid.UUID | None = None,
    ) -> CommunicationsAttachActionResponse:
        try:
            resolved = await self.resolve_item(source, item_id)
        except ValueError as exc:
            return CommunicationsAttachActionResponse(ok=False, channel="outlook", message=str(exc))
        if resolved is None:
            return CommunicationsAttachActionResponse(ok=False, channel="outlook", message="Documento no encontrado")

        ref = M365MailAttachmentRef(
            name=resolved.name,
            content_type=resolved.mime_type,
        )
        if resolved.onedrive_item_id:
            ref.onedrive_item_id = resolved.onedrive_item_id
        elif resolved.web_url:
            ref.source_url = resolved.web_url
        else:
            ref.content_base64 = base64.b64encode(resolved.content).decode("ascii")

        mail = M365MailService(self.db, self.tenant_id, self.user_id)
        result = await mail.send_mail(
            M365MailComposeRequest(
                to=to,
                subject=subject,
                body=body,
                attachments=[ref],
            ),
            account_id=account_id,
        )
        return CommunicationsAttachActionResponse(
            ok=result.ok,
            channel="outlook",
            message=result.message,
            filename=resolved.name,
            message_id=result.message_id,
        )

    async def share_teams(
        self,
        *,
        team_id: str,
        channel_id: str,
        message: str,
        source: str,
        item_id: str,
        account_id: uuid.UUID | None = None,
    ) -> CommunicationsAttachActionResponse:
        if settings.m365_read_only:
            return CommunicationsAttachActionResponse(
                ok=False, channel="teams", message="Operación de escritura bloqueada por configuración del sistema"
            )
        try:
            resolved = await self.resolve_item(source, item_id)
        except ValueError as exc:
            return CommunicationsAttachActionResponse(ok=False, channel="teams", message=str(exc))
        if resolved is None:
            return CommunicationsAttachActionResponse(ok=False, channel="teams", message="Documento no encontrado")

        link = resolved.web_url
        if not link and resolved.onedrive_item_id:
            try:
                sess = await self._sessions.session_for_account(account_id)
                item = await sess.client.onedrive.get_item(resolved.onedrive_item_id)
                link = item.web_url or item.download_url
            except (GraphError, PermissionError, Exception):
                pass

        parts = [f"<p>{message}</p>"] if message.strip() else []
        parts.append(f'<p><strong>📎 {resolved.name}</strong></p>')
        if link:
            parts.append(f'<p><a href="{link}">Abrir documento</a></p>')
        else:
            parts.append("<p><em>Documento interno JAIOS — sin enlace público</em></p>")

        try:
            sess = await self._sessions.session_for_account(account_id)
            result = await sess.client.teams.send_channel_message(
                team_id, channel_id, content="".join(parts)
            )
            msg_id = result.get("id") if isinstance(result, dict) else None
            return CommunicationsAttachActionResponse(
                ok=True,
                channel="teams",
                message=f"Documento compartido en Teams: {resolved.name}",
                filename=resolved.name,
                message_id=msg_id,
                web_url=link,
            )
        except (GraphError, PermissionError) as exc:
            return CommunicationsAttachActionResponse(ok=False, channel="teams", message=str(exc))
