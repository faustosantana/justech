"""Genera borradores de correo para información faltante de empresas licitadoras."""

from __future__ import annotations

import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.company_profile_sync_service import CompanyProfileSyncService

FIELD_LABELS = {
    "razon_social": "Razón social",
    "rnc": "RNC",
    "direccion": "Dirección fiscal",
    "telefono": "Teléfono",
    "correo": "Correo",
    "representante_legal": "Representante legal",
    "cedula_representante": "Cédula representante",
    "registro_mercantil": "Registro mercantil",
    "datos_bancarios": "Datos bancarios",
    "certificacion_dgii": "Certificación DGII",
    "certificacion_tss": "Certificación TSS",
    "certificacion_mipyme": "Certificación MIPYME",
    "certificacion_proveedor_estado": "Certificación proveedor del Estado",
}

LEGAL_DOC_TYPES = (
    "certificacion_dgii",
    "certificacion_tss",
    "certificacion_mipyme",
    "certificacion_proveedor_estado",
)


class CompanyMissingInfoEmailService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    async def draft_email(
        self,
        company_key: str,
        *,
        extra_missing: list[str] | None = None,
    ) -> dict:
        profiles = await CompanyProfileSyncService(self.db, self.tenant_id).list_profiles()
        profile = next((p for p in profiles if p["company_key"] == company_key), None)
        empresa = (profile or {}).get("razon_social") or company_key.replace("_", " ").title()
        missing = list((profile or {}).get("missing_fields") or [])
        if extra_missing:
            missing.extend(extra_missing)
        missing = list(dict.fromkeys(missing))

        lines = []
        for field in missing:
            label = FIELD_LABELS.get(field, field.replace("_", " ").title())
            lines.append(f"- {label}:")

        if not lines:
            lines.append("- (Sin campos faltantes detectados en perfil JSON)")

        body = (
            f"Hola Jennipher,\n\n"
            f"JAIOS detectó información pendiente para la empresa:\n\n"
            f"{empresa}\n\n"
            f"Documentos o datos faltantes:\n\n"
            + "\n".join(lines)
            + "\n\nUbicación donde deben colocarse en OneDrive:\n"
            f"Justech-AI/00_DATOS_EMPRESAS/{empresa.upper().replace(' ', '_')}\n"
            f"o Justech-AI/01_DOCUMENTOS_LEGALES/{empresa.upper().replace(' ', '_')}\n\n"
            "Una vez cargados los archivos, JAIOS los sincronizará automáticamente.\n\n"
            "Gracias."
        )
        subject = f"Pendientes documentales detectados — {empresa}"

        return {
            "company_key": company_key,
            "empresa": empresa,
            "subject": subject,
            "body": body,
            "missing_fields": missing,
            "can_send_outlook": True,
            "recipient": "recepcion@justech.do",
        }
