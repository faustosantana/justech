"""Campos de perfil empresarial — texto, documentos y carga a OneDrive."""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import UTC, date, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.corporate_identity import CorporateIdentityAsset
from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.schemas.documents_hub import (
    CompanyCompletionResponse,
    CompanyDocumentUploadResponse,
    CompanyFieldStatus,
    CompanyFieldUpdateRequest,
    CompanyMissingRequestPayload,
    CompanyProfileUpdateRequest,
    RequestMissingResponse,
)
from app.services.company_profile_sync_service import CompanyProfileSyncService, REQUIRED_FIELDS
from app.services.corporate_repository_unified_service import (
    CorporateRepositoryUnifiedService,
    RPE_NUMBER_PENDING_LABEL,
)
from app.services.company_representative_service import CompanyRepresentativeService
from app.services.document_access_service import resolve_knowledge_asset_access
from app.services.document_pending_service import LEGAL_LABELS, DocumentPendingService
from app.services.document_requirement_validator import validate_asset_for_requirement
from app.services.documents_hub_service import DocumentsHubService
from app.services.company_normalization_service import (
    COMPANY_KEYS,
    canonical_label,
    company_folder,
    identity_onedrive_paths,
)
from app.services.licitador_dashboard_service import LicitadorDashboardService
from integrations.microsoft365.errors import GraphError

from app.services.m365_connection_service import M365ConnectionService
from app.services.m365_graph_session import M365GraphSessionService
from app.services.repository_sync_service import RepositorySyncService

logger = logging.getLogger(__name__)

ONEDRIVE_ERROR_MSG = (
    "No se pudo subir a OneDrive. Verifique conexión Microsoft 365 y permisos Files.ReadWrite.All."
)

ONEDRIVE_ROOTS = {
    "legal": "Justech-AI/01_DOCUMENTOS_LEGALES",
    "identity": "Justech-AI/IDENTIDAD_CORPORATIVA",
    "profile": "Justech-AI/00_DATOS_EMPRESAS",
}

IDENTITY_FALLBACK_SUBPATH = "IDENTIDAD_CORPORATIVA"

# kind: text | document | hybrid
FIELD_DEFINITIONS: dict[str, dict[str, Any]] = {
    "razon_social": {"label": "Razón social", "kind": "text", "profile_field": "razon_social"},
    "nombre_comercial": {"label": "Nombre comercial", "kind": "text", "profile_field": "nombre_comercial"},
    "rnc": {"label": "RNC", "kind": "text", "profile_field": "rnc"},
    "direccion": {"label": "Dirección", "kind": "text", "profile_field": "direccion"},
    "telefono": {"label": "Teléfono", "kind": "text", "profile_field": "telefono"},
    "correo": {"label": "Correo", "kind": "text", "profile_field": "correo"},
    "representante_legal": {"label": "Representante legal", "kind": "text", "profile_field": "representante_legal"},
    "cargo_representante": {"label": "Cargo", "kind": "text", "profile_field": "cargo_representante"},
    "responsable_legal": {"label": "Responsable legal", "kind": "text", "profile_field": "responsable_legal"},
    "responsable_financiero": {"label": "Responsable financiero", "kind": "text", "profile_field": "responsable_financiero"},
    "responsable_licitaciones": {"label": "Responsable licitaciones", "kind": "text", "profile_field": "responsable_licitaciones"},
    "cedula_representante": {
        "label": "Cédula representante",
        "kind": "hybrid",
        "profile_field": "cedula_representante",
        "document_type": "cedula_representante",
        "onedrive": "legal",
    },
    "datos_bancarios": {
        "label": "Datos bancarios",
        "kind": "hybrid",
        "profile_field": "datos_bancarios",
        "document_type": "certificacion_bancaria",
        "onedrive": "legal",
    },
    "proveedor_estado": {
        "label": "Proveedor del Estado / RPE",
        "kind": "hybrid",
        "profile_field": "proveedor_estado",
        "document_type": "proveedor_estado",
        "onedrive": "legal",
    },
    "registro_mercantil": {
        "label": "Registro mercantil",
        "kind": "document",
        "document_type": "registro_mercantil",
        "onedrive": "legal",
    },
    "dgii": {"label": "Certificación DGII", "kind": "document", "document_type": "dgii", "onedrive": "legal"},
    "tss": {"label": "Certificación TSS", "kind": "document", "document_type": "tss", "onedrive": "legal"},
    "mipyme": {"label": "MIPYME", "kind": "document", "document_type": "mipyme", "onedrive": "legal"},
    "certificacion_bancaria": {
        "label": "Certificación bancaria",
        "kind": "document",
        "document_type": "certificacion_bancaria",
        "onedrive": "legal",
    },
    "poderes": {"label": "Poder legal", "kind": "document", "document_type": "poderes", "onedrive": "legal"},
    "acta_asamblea": {"label": "Acta", "kind": "document", "document_type": "acta_asamblea", "onedrive": "legal"},
    "estatutos": {"label": "Estatutos", "kind": "document", "document_type": "estatutos", "onedrive": "legal"},
    "logo": {"label": "Logo", "kind": "document", "document_type": "logo", "onedrive": "identity"},
    "firma": {
        "label": "Firma",
        "kind": "document",
        "document_type": "signature",
        "onedrive": "identity",
        "identity_type": "signature",
    },
    "sello": {
        "label": "Sello",
        "kind": "document",
        "document_type": "stamp",
        "onedrive": "identity",
        "identity_type": "stamp",
    },
    "membrete": {"label": "Membrete", "kind": "document", "document_type": "membrete", "onedrive": "identity"},
}

def _validate_field_value(field_key: str, value: str) -> str:
    cleaned = (value or "").strip()
    if not cleaned:
        raise ValueError("El valor no puede estar vacío.")
    if field_key == "correo":
        if "@" not in cleaned or "." not in cleaned.split("@")[-1]:
            raise ValueError("Ingrese un correo electrónico válido.")
    if field_key == "rnc":
        digits = cleaned.replace("-", "").replace(" ", "")
        if not digits.isdigit() or len(digits) < 9:
            raise ValueError("El RNC debe contener al menos 9 dígitos.")
    if field_key == "telefono":
        digits = "".join(c for c in cleaned if c.isdigit())
        if len(digits) < 7:
            raise ValueError("Ingrese un teléfono válido.")
    if field_key == "cedula_representante":
        digits = cleaned.replace("-", "").replace(" ", "")
        if not digits.isdigit() or len(digits) < 11:
            raise ValueError("La cédula debe contener al menos 11 dígitos.")
    return cleaned


# Columnas de perfil que almacenan datos estructurados — nunca reciben nombres de archivo.
TEXT_ONLY_PROFILE_COLUMNS = frozenset({
    "cedula_representante",
    "rnc",
    "telefono",
    "correo",
    "representante_legal",
    "cargo_representante",
})

PROFILE_FORM_FIELDS = [
    "razon_social",
    "nombre_comercial",
    "rnc",
    "direccion",
    "telefono",
    "correo",
    "representante_legal",
    "cedula_representante",
    "cargo_representante",
    "registro_mercantil",
    "proveedor_estado",
    "datos_bancarios",
    "responsable_legal",
    "responsable_financiero",
    "responsable_licitaciones",
]


class CompanyProfileFieldService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._hub = DocumentsHubService(db, tenant_id, user_id=user_id)
        self._pending = DocumentPendingService(db, tenant_id, user_id=user_id)

    async def get_completion(self, company_id: uuid.UUID) -> CompanyCompletionResponse:
        profile = await self._get_profile(company_id)
        unified = CorporateRepositoryUnifiedService(
            self.db, self.tenant_id, company_key=profile.company_key
        )
        legal_unified = await unified.resolve_legal_documents()
        normalized = await unified.enrich_profile_from_documents(profile, legal_docs=legal_unified)

        fields: list[CompanyFieldStatus] = []
        complete_count = 0
        for key in PROFILE_FORM_FIELDS:
            defn = FIELD_DEFINITIONS.get(key, {"label": key, "kind": "text"})
            kind = defn.get("kind", "text")
            profile_field = defn.get("profile_field", key)
            text_value = normalized.get(profile_field)
            if key == "proveedor_estado" and not (text_value and str(text_value).strip()):
                text_value = normalized.get("rpe_display")

            doc_type = defn.get("document_type")
            lookup_key = doc_type or key
            unified_doc = legal_unified.get(lookup_key) if kind != "text" else None

            status = "complete"
            badge = "Completo"
            unified_status: str | None = None
            onedrive_url = None
            asset_id = None
            doc_repo_id = None
            vigency = None
            uploaded_at = None
            doc_name = None

            if kind == "text":
                if not (text_value and str(text_value).strip()):
                    status, badge, unified_status = "missing", "Falta", "missing"
                else:
                    unified_status = "validated"
                    complete_count += 1
            elif kind == "document":
                if unified_doc and unified_doc.unified_status != "missing":
                    status = unified_doc.unified_status
                    badge = unified_doc.badge
                    unified_status = unified_doc.unified_status
                    doc_name = unified_doc.document_name
                    asset_id = unified_doc.knowledge_asset_id
                    doc_repo_id = unified_doc.document_id
                    vigency = unified_doc.vigency_status
                    onedrive_url = unified_doc.web_url
                    if unified_doc.unified_status in ("detected", "validated", "pending_analysis"):
                        complete_count += 1
                else:
                    status, badge, unified_status = "missing", "Falta", "missing"
            else:  # hybrid
                has_text = bool(text_value and str(text_value).strip())
                has_doc = bool(unified_doc and unified_doc.unified_status != "missing")
                rpe_pending = key == "proveedor_estado" and has_doc and normalized.get("rpe_display")
                if has_text and has_doc and not rpe_pending:
                    status, badge, unified_status = "complete", "Completo", unified_doc.unified_status if unified_doc else "validated"
                    complete_count += 1
                elif has_doc and unified_doc:
                    status = unified_doc.unified_status
                    badge = unified_doc.badge
                    unified_status = unified_doc.unified_status
                    doc_name = unified_doc.document_name
                    asset_id = unified_doc.knowledge_asset_id
                    doc_repo_id = unified_doc.document_id
                    vigency = unified_doc.vigency_status
                    onedrive_url = unified_doc.web_url
                    if rpe_pending:
                        text_value = normalized.get("rpe_display")
                        badge = RPE_NUMBER_PENDING_LABEL
                        unified_status = "pending_analysis"
                        complete_count += 1
                    elif has_text:
                        complete_count += 1
                elif has_text:
                    status, badge, unified_status = "partial", "Dato escrito", "partial"
                    complete_count += 1
                else:
                    status, badge, unified_status = "missing", "Falta", "missing"

            if unified_doc and unified_doc.knowledge_asset_id:
                know_uuid = uuid.UUID(unified_doc.knowledge_asset_id)
                asset_row = (
                    await self.db.execute(
                        select(KnowledgeAsset).where(KnowledgeAsset.id == know_uuid)
                    )
                ).scalar_one_or_none()
                if asset_row:
                    meta = asset_row.metadata_ or {}
                    uploaded_at = self._parse_dt(meta.get("uploaded_at"))
                    onedrive_url = onedrive_url or meta.get("web_url")

            view_url = None
            view_mode = None
            knowledge_asset_id = None
            resolve_id = asset_id or doc_repo_id
            if asset_id:
                access = await resolve_knowledge_asset_access(
                    self.db, uuid.UUID(str(asset_id)), tenant_id=self.tenant_id
                )
                knowledge_asset_id = str(asset_id)
                view_mode = access.view_mode
                view_url = access.local_api_path if access.view_mode == "local" else access.web_url
                onedrive_url = onedrive_url or access.web_url
            elif doc_repo_id:
                knowledge_asset_id = None
                view_url = f"/api/v1/documents/{doc_repo_id}/file"

            fields.append(
                CompanyFieldStatus(
                    field_key=key,
                    label=defn.get("label", key),
                    kind=kind,
                    status=status,
                    badge=badge,
                    unified_status=unified_status,
                    text_value=str(text_value) if text_value else None,
                    document_id=doc_repo_id or asset_id,
                    document_name=doc_name,
                    onedrive_url=onedrive_url,
                    knowledge_asset_id=knowledge_asset_id,
                    view_url=view_url,
                    view_mode=view_mode,
                    onedrive_folder=self._onedrive_folder(profile.company_key, defn.get("onedrive", "legal")),
                    vigency_status=vigency,
                    uploaded_at=uploaded_at,
                    is_required=profile_field in REQUIRED_FIELDS,
                )
            )

        for doc_key in ("dgii", "tss", "mipyme", "certificacion_bancaria", "poderes", "acta_asamblea", "estatutos"):
            if doc_key in {f.field_key for f in fields}:
                continue
            defn = FIELD_DEFINITIONS[doc_key]
            unified_doc = legal_unified.get(doc_key)
            if unified_doc and unified_doc.unified_status != "missing":
                status = unified_doc.unified_status
                badge = unified_doc.badge
                if unified_doc.unified_status in ("detected", "validated", "pending_analysis"):
                    complete_count += 1
            else:
                status, badge = "missing", "Falta"
            extra_asset_id = unified_doc.knowledge_asset_id if unified_doc else None
            extra_doc_id = unified_doc.document_id if unified_doc else None
            extra_view_url = None
            extra_view_mode = None
            extra_knowledge_asset_id = None
            if extra_asset_id:
                access = await resolve_knowledge_asset_access(
                    self.db, uuid.UUID(str(extra_asset_id)), tenant_id=self.tenant_id
                )
                extra_knowledge_asset_id = str(extra_asset_id)
                extra_view_mode = access.view_mode
                extra_view_url = access.local_api_path if access.view_mode == "local" else access.web_url
            elif extra_doc_id:
                extra_view_url = f"/api/v1/documents/{extra_doc_id}/file"
            fields.append(
                CompanyFieldStatus(
                    field_key=doc_key,
                    label=defn["label"],
                    kind="document",
                    status=status,
                    badge=badge,
                    unified_status=unified_doc.unified_status if unified_doc else "missing",
                    document_id=extra_doc_id or extra_asset_id,
                    document_name=unified_doc.document_name if unified_doc else None,
                    onedrive_url=unified_doc.web_url if unified_doc else None,
                    knowledge_asset_id=extra_knowledge_asset_id,
                    view_url=extra_view_url,
                    view_mode=extra_view_mode,
                    onedrive_folder=self._onedrive_folder(profile.company_key, "legal"),
                    vigency_status=unified_doc.vigency_status if unified_doc else None,
                    is_required=False,
                )
            )

        identity_assets = list(
            (
                await self.db.execute(
                    select(CorporateIdentityAsset).where(
                        CorporateIdentityAsset.tenant_id == self.tenant_id,
                        CorporateIdentityAsset.company_key == profile.company_key,
                        CorporateIdentityAsset.status == "disponible",
                    )
                )
            ).scalars().all()
        )
        identity_by_type = {a.asset_type: a for a in identity_assets}
        identity_knowledge = {
            a.document_type: a
            for a in (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == self.tenant_id,
                        KnowledgeAsset.company_key == profile.company_key,
                        KnowledgeAsset.folder_category == "identity",
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalars().all()
        }

        for id_key in ("logo", "firma", "sello", "membrete"):
            defn = FIELD_DEFINITIONS[id_key]
            doc_type = defn["document_type"]
            identity_type = defn.get("identity_type")
            asset_row = identity_by_type.get(identity_type) if identity_type else None
            know_row = identity_knowledge.get(doc_type)
            web_url = None
            doc_name = None
            doc_id = None
            if asset_row:
                web_url = (asset_row.metadata_ or {}).get("web_url")
                doc_name = asset_row.filename
                doc_id = str(asset_row.id)
            elif know_row:
                doc_name = know_row.filename if hasattr(know_row, "filename") else know_row.name
                doc_id = str(know_row.id)
                meta = getattr(know_row, "metadata_", {}) or {}
                web_url = meta.get("web_url") or getattr(know_row, "web_url", None)

            if asset_row or know_row:
                status, badge = "loaded", "Documento cargado"
                complete_count += 1
            else:
                status, badge = "missing", "Falta"
            fields.append(
                CompanyFieldStatus(
                    field_key=id_key,
                    label=defn["label"],
                    kind="document",
                    status=status,
                    badge=badge,
                    document_id=doc_id,
                    document_name=doc_name,
                    onedrive_url=web_url,
                    onedrive_folder=self._onedrive_folder(profile.company_key, "identity"),
                    is_required=False,
                )
            )

        total = len(fields)
        score = int((complete_count / total) * 100) if total else 0

        rep_summary = await CompanyRepresentativeService(
            self.db, self.tenant_id, user_id=self.user_id
        ).list_representatives(profile.id)
        validation_pending = rep_summary.validation_pending_count
        rep_missing = rep_summary.documents_missing_count
        has_real_reps = rep_summary.total_representatives > 0

        rep_total = 0
        rep_complete = 0
        if has_real_reps:
            for rep in rep_summary.representatives:
                for doc in rep.documents:
                    if doc.status == "missing" and doc.document_type in {
                        "cedula", "poder_notarial", "acta_designacion"
                    }:
                        rep_total += 1
                    elif doc.status == "loaded":
                        rep_total += 1
                        if doc.requires_validation:
                            if doc.validation_status == "validated":
                                rep_complete += 1
                        elif doc.validation_status != "rejected":
                            rep_complete += 1

            if rep_total:
                combined_total = total + rep_total
                combined_complete = complete_count + rep_complete
                score = int((combined_complete / combined_total) * 100) if combined_total else score

        for i, field in enumerate(fields):
            if field.field_key != "cedula_representante":
                continue
            if not has_real_reps:
                fields[i] = field.model_copy(
                    update={"status": "missing", "badge": "Sin representante asignado"}
                )
                break
            pending_ced = sum(
                1
                for r in rep_summary.representatives
                for d in r.documents
                if d.document_type == "cedula" and d.status == "loaded" and d.validation_status == "pending"
            )
            missing_ced = sum(
                1
                for r in rep_summary.representatives
                for d in r.documents
                if d.document_type == "cedula" and d.status == "missing"
            )
            validated_ced = sum(
                1
                for r in rep_summary.representatives
                for d in r.documents
                if d.document_type == "cedula" and d.validation_status == "validated"
            )
            if missing_ced > 0:
                status, badge = "missing", "Falta"
            elif pending_ced > 0:
                status, badge = "partial", "Pendiente de validar"
            elif validated_ced > 0:
                status, badge = "complete", "Cédula validada"
            else:
                status, badge = "partial", "Documento cargado"
            fields[i] = field.model_copy(update={"status": status, "badge": badge})

        if has_real_reps and (validation_pending > 0 or rep_missing > 0):
            score = min(score, 99)
        if has_real_reps and validation_pending > 0 and score >= 100:
            score = 95

        progress_note = None
        if has_real_reps and validation_pending > 0:
            progress_note = f"{validation_pending} documento(s) pendiente(s) de validar"
        elif has_real_reps and rep_missing > 0:
            progress_note = f"{rep_missing} documento(s) de representante pendiente(s)"

        has_red = any(f.badge in ("Falta", "Vencido", "Rechazada") for f in fields) or (
            has_real_reps and rep_missing > 0
        )
        has_yellow = validation_pending > 0 or any(
            f.badge in ("Pendiente de validar", "Documento cargado", "Dato escrito", "Parcial")
            for f in fields
        )
        if has_red:
            progress_semaphore = "red"
        elif has_yellow or score < 100:
            progress_semaphore = "yellow"
        else:
            progress_semaphore = "green"

        return CompanyCompletionResponse(
            company_id=str(profile.id),
            company_key=profile.company_key,
            empresa=profile.razon_social or profile.company_key,
            completeness_score=score,
            fields_complete=complete_count + (rep_complete if has_real_reps else 0),
            fields_total=total + (rep_total if has_real_reps else 0),
            fields=fields,
            validation_pending_count=validation_pending,
            representatives_count=rep_summary.total_representatives,
            progress_note=progress_note,
            progress_semaphore=progress_semaphore,
        )

    async def update_field(
        self, company_id: uuid.UUID, field_key: str, payload: CompanyFieldUpdateRequest
    ):
        defn = FIELD_DEFINITIONS.get(field_key)
        if not defn:
            raise ValueError(f"Campo desconocido: {field_key}")
        profile_field = defn.get("profile_field", field_key)
        if defn.get("kind") == "document" and not defn.get("profile_field"):
            raise ValueError(f"El campo {field_key} requiere subir un documento, no texto.")

        validated = _validate_field_value(field_key if field_key in FIELD_DEFINITIONS else profile_field, payload.value)
        update = CompanyProfileUpdateRequest(**{profile_field: validated})
        result = await self._hub.update_company(company_id, update)
        try:
            await self._push_profile_json_to_onedrive(company_id)
        except Exception:
            logger.exception("profile json onedrive push failed company=%s", company_id)
        return result

    async def upload_document(
        self,
        company_id: uuid.UUID,
        field_key: str,
        *,
        filename: str,
        content: bytes,
        content_type: str = "application/octet-stream",
        valid_until: date | None = None,
    ) -> CompanyDocumentUploadResponse:
        if settings.m365_read_only:
            raise ValueError(ONEDRIVE_ERROR_MSG)

        defn = FIELD_DEFINITIONS.get(field_key)
        if not defn:
            raise ValueError(f"Campo desconocido: {field_key}")
        if defn.get("kind") == "text":
            raise ValueError(f"El campo {field_key} es de texto. Use el endpoint de campos.")

        profile = await self._get_profile(company_id)
        onedrive_kind = defn.get("onedrive", "legal")
        folder_path = self._onedrive_folder(profile.company_key, onedrive_kind)

        try:
            sess = await M365GraphSessionService(self.db, self.tenant_id, self.user_id).session_for_account(None)
            folder = await self._resolve_upload_folder(sess, profile.company_key, onedrive_kind, folder_path)
            safe_name = filename.replace("/", "_").strip() or f"{field_key}.pdf"
            item = await sess.client.onedrive.upload_file(
                name=safe_name,
                content=content,
                folder_id=folder.id,
                content_type=content_type,
            )
        except (GraphError, PermissionError, ValueError) as exc:
            logger.warning("onedrive upload failed: %s", exc)
            raise ValueError(ONEDRIVE_ERROR_MSG) from exc

        doc_type = defn.get("document_type", field_key)
        asset = await self._index_uploaded_document(
            profile=profile,
            field_key=field_key,
            doc_type=doc_type,
            filename=safe_name,
            content=content,
            folder_path=folder_path,
            web_url=item.web_url,
            graph_item_id=item.id,
            content_type=content_type,
            valid_until=valid_until,
            identity_type=defn.get("identity_type"),
        )

        try:
            await self._pending.scan_and_upsert()
        except Exception:
            logger.exception("pending scan after upload failed")

        return CompanyDocumentUploadResponse(
            ok=True,
            message=f"Documento {safe_name} subido correctamente",
            field_key=field_key,
            filename=safe_name,
            document_id=str(asset.id),
            onedrive_url=item.web_url,
            onedrive_path=f"{folder_path}/{safe_name}",
            vigency_status=asset.vigency_status,
        )

    async def request_missing_fields(
        self, company_id: uuid.UUID, payload: CompanyMissingRequestPayload
    ) -> RequestMissingResponse:
        missing = await self._pending.get_missing_for_company(company_id)
        item_ids: list[str] = list(payload.item_ids)
        if payload.field_keys and not item_ids:
            key_set = set(payload.field_keys)
            for item in missing.pending_items:
                if item.item_key in key_set or item.item_type == "field" and item.item_key in key_set:
                    item_ids.append(item.id)
            for fk in payload.field_keys:
                defn = FIELD_DEFINITIONS.get(fk, {})
                doc_type = defn.get("document_type", fk)
                for item in missing.pending_items:
                    if item.item_key == doc_type and item.id not in item_ids:
                        item_ids.append(item.id)

        from app.schemas.documents_hub import RequestMissingPayload

        return await self._pending.request_missing(
            company_id,
            RequestMissingPayload(
                item_ids=item_ids,
                send_email=payload.send_email,
                create_task=payload.create_task,
                recipient_email=payload.recipient_email,
                copy_only=payload.copy_only,
            ),
        )

    async def sync_onedrive(self, company_id: uuid.UUID) -> dict:
        profile = await self._get_profile(company_id)
        company_key = profile.company_key
        conn = await M365ConnectionService(self.db, self.tenant_id, self.user_id).connection_state()
        if not conn.account_connected:
            raise GraphError(
                401,
                "Microsoft 365 no está conectado. Vaya a Cuentas y autorice su cuenta.",
                error_code="M365_NOT_CONNECTED",
                permission_hint="Conecte OAuth en Configuración → Cuentas Microsoft 365.",
            )

        sync = RepositorySyncService(self.db, self.tenant_id, user_id=self.user_id)
        bindings = await sync.list_bindings()
        company_bindings = [
            b for b in bindings
            if b.get("folder_key") in ("00_DATOS_EMPRESAS", "01_DOCUMENTOS_LEGALES") and b.get("id")
        ]
        if not company_bindings:
            raise GraphError(
                404,
                "No hay carpetas OneDrive configuradas para datos de empresas.",
                error_code="BINDINGS_NOT_CONFIGURED",
                permission_hint="Configure los bindings 00_DATOS_EMPRESAS y 01_DOCUMENTOS_LEGALES en Documentos → Repositorios.",
            )

        synced = []
        errors = []
        for b in company_bindings:
            folder_key = b.get("folder_key")
            binding_id = b.get("id")
            try:
                logger.info(
                    "[M365_SYNC_START] tenant=%s company=%s company_id=%s folder=%s binding=%s user=%s",
                    self.tenant_id,
                    company_key,
                    company_id,
                    folder_key,
                    binding_id,
                    self.user_id,
                )
                result = await sync.sync_binding(uuid.UUID(str(binding_id)))
                if not result.get("ok"):
                    msg = result.get("message") or "Error desconocido al sincronizar"
                    errors.append(f"{folder_key}: {msg}")
                    logger.warning(
                        "[M365_SYNC_ERROR] tenant=%s company=%s folder=%s status=FAILED reason=%s",
                        self.tenant_id,
                        company_key,
                        folder_key,
                        msg,
                    )
                else:
                    synced.append({"folder": folder_key, **result})
                    logger.info(
                        "[M365_SYNC_FINISHED] tenant=%s company=%s folder=%s status=OK indexed=%s",
                        self.tenant_id,
                        company_key,
                        folder_key,
                        result.get("indexed"),
                    )
            except GraphError as exc:
                hint = f" ({exc.permission_hint})" if exc.permission_hint else ""
                errors.append(f"{folder_key}: {exc.message}{hint}")
                logger.warning(
                    "[M365_SYNC_ERROR] tenant=%s company=%s folder=%s graph_status=%s reason=%s",
                    self.tenant_id,
                    company_key,
                    folder_key,
                    exc.status_code,
                    exc.message,
                )
            except Exception as exc:
                await self.db.rollback()
                logger.exception(
                    "[M365_SYNC_ERROR] tenant=%s company=%s folder=%s exception=%s",
                    self.tenant_id,
                    company_key,
                    folder_key,
                    type(exc).__name__,
                )
                raise GraphError(
                    502,
                    f"No pude guardar los documentos sincronizados: {exc}",
                    error_code="SYNC_DB_ERROR",
                    permission_hint="Revise logs del servidor. Puede haber archivos duplicados o sin nombre en OneDrive.",
                ) from exc

        if not synced and errors:
            raise GraphError(
                502,
                errors[0],
                error_code="SYNC_FAILED",
                permission_hint="Revise conexión M365, permisos Graph y rutas de carpetas.",
            )

        try:
            await self._pending.scan_and_upsert()
        except Exception as exc:
            await self.db.rollback()
            logger.exception(
                "[M365_SYNC_ERROR] pending scan failed company=%s: %s",
                company_key,
                exc,
            )

        return {
            "ok": len(errors) == 0,
            "synced": synced,
            "errors": errors,
            "company_key": company_key,
            "message": (
                f"Sincronización completada: {len(synced)} carpeta(s)."
                if not errors
                else f"Completado con {len(errors)} advertencia(s)."
            ),
        }

    async def _push_profile_json_to_onedrive(self, company_id: uuid.UUID) -> None:
        if settings.m365_read_only:
            return
        profile = await self._get_profile(company_id)
        folder_path = self._onedrive_folder(profile.company_key, "profile")
        payload = dict(profile.raw_json or {})
        payload.update(
            {
                "company_key": profile.company_key,
                "razon_social": profile.razon_social,
                "rnc": profile.rnc,
                "updated_at": datetime.now(UTC).isoformat(),
            }
        )
        content = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        filename = f"datos_empresa_{profile.company_key}.json"
        sess = await M365GraphSessionService(self.db, self.tenant_id, self.user_id).session_for_account(None)
        folder = await sess.client.onedrive.ensure_folder_by_path(folder_path)
        await sess.client.onedrive.upload_file(
            name=filename,
            content=content,
            folder_id=folder.id,
            content_type="application/json",
        )

    async def _index_uploaded_document(
        self,
        *,
        profile: LicitadorCompanyProfile,
        field_key: str,
        doc_type: str,
        filename: str,
        content: bytes,
        folder_path: str,
        web_url: str | None,
        graph_item_id: str | None,
        content_type: str,
        valid_until: date | None,
        identity_type: str | None,
    ) -> KnowledgeAsset:
        if content:
            rel = f"jaios/{profile.company_key}/{doc_type}/{filename}".strip("/")
        else:
            rel = f"onedrive/{folder_path}/{filename}".strip("/")
        content_hash = hashlib.sha256(content).hexdigest() if content else hashlib.sha256(
            f"link:{graph_item_id or rel}".encode()
        ).hexdigest()
        now = datetime.now(UTC)

        existing = None
        if graph_item_id:
            rows = (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == self.tenant_id,
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalars().all()
            for row in rows:
                meta = row.metadata_ or {}
                if meta.get("graph_item_id") == graph_item_id and row.document_type == doc_type:
                    existing = row
                    break
        if not existing:
            existing = (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == self.tenant_id,
                        KnowledgeAsset.relative_path == rel,
                        KnowledgeAsset.document_type == doc_type,
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalar_one_or_none()
        if not existing:
            existing = (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == self.tenant_id,
                        KnowledgeAsset.company_key == profile.company_key,
                        KnowledgeAsset.document_type == doc_type,
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalar_one_or_none()

        if not existing:
            existing = KnowledgeAsset(
                tenant_id=self.tenant_id,
                source_provider="jaios" if content else "onedrive",
                source_root="m365",
                relative_path=rel,
                folder_category="identity" if identity_type else "legal_documents",
                filename=filename,
                title=FIELD_DEFINITIONS.get(field_key, {}).get("label", filename),
                format=(filename.rsplit(".", 1)[-1] if "." in filename else "other").lower(),
                document_type=doc_type,
                company_key=profile.company_key,
            )
            self.db.add(existing)

        existing.relative_path = rel
        existing.filename = filename
        existing.document_type = doc_type
        existing.company_key = profile.company_key
        existing.source_provider = "jaios" if content else existing.source_provider or "onedrive"
        existing.folder_category = "identity" if identity_type else "legal_documents"
        existing.title = FIELD_DEFINITIONS.get(field_key, {}).get("label", filename)
        existing.mime_type = content_type
        existing.file_size = len(content)
        existing.content_hash = content_hash
        existing.valid_until = valid_until
        if valid_until and valid_until < date.today():
            existing.vigency_status = "vencido"
        else:
            existing.vigency_status = "vigente"
        existing.synced_at = now
        existing.metadata_ = {
            "graph_item_id": graph_item_id,
            "web_url": web_url,
            "uploaded_by": str(self.user_id) if self.user_id else None,
            "uploaded_at": now.isoformat(),
            "field_key": field_key,
        }
        await self.db.commit()
        await self.db.refresh(existing)

        if identity_type:
            await self._upsert_identity_asset(
                profile=profile,
                asset_type=identity_type,
                filename=filename,
                rel=rel,
                web_url=web_url,
            )
        await self._mark_profile_field_from_document(
            profile, field_key, FIELD_DEFINITIONS.get(field_key, {}), filename
        )
        return existing

    async def _mark_profile_field_from_document(
        self,
        profile: LicitadorCompanyProfile,
        field_key: str,
        defn: dict[str, Any],
        filename: str,
    ) -> None:
        """Registra vínculo documental en raw_json sin sobrescribir campos de texto estructurados."""
        profile_field = defn.get("profile_field")
        doc_to_profile = {
            "registro_mercantil": "registro_mercantil",
            "certificacion_bancaria": "datos_bancarios",
            "proveedor_estado": "proveedor_estado",
        }
        doc_type = defn.get("document_type", field_key)
        target = profile_field or doc_to_profile.get(doc_type)
        raw = dict(profile.raw_json or {})
        raw[f"{field_key}_document"] = filename
        if target and target not in TEXT_ONLY_PROFILE_COLUMNS:
            raw[target] = filename
            if hasattr(profile, target):
                setattr(profile, target, filename)
        profile.raw_json = raw
        missing = []
        normalized = CompanyProfileSyncService._normalize_json(raw)
        for f in REQUIRED_FIELDS:
            if not normalized.get(f):
                missing.append(f)
        profile.missing_fields = missing
        total = len(REQUIRED_FIELDS)
        profile.completeness_score = int(((total - len(missing)) / total) * 100) if total else 0
        await self.db.commit()

    async def _upsert_identity_asset(
        self,
        *,
        profile: LicitadorCompanyProfile,
        asset_type: str,
        filename: str,
        rel: str,
        web_url: str | None,
    ) -> None:
        row = (
            await self.db.execute(
                select(CorporateIdentityAsset).where(
                    CorporateIdentityAsset.tenant_id == self.tenant_id,
                    CorporateIdentityAsset.asset_type == asset_type,
                    CorporateIdentityAsset.company_key == profile.company_key,
                )
            )
        ).scalar_one_or_none()
        now = datetime.now(UTC)
        if not row:
            row = CorporateIdentityAsset(
                tenant_id=self.tenant_id,
                asset_type=asset_type,
                company_key=profile.company_key,
                filename=filename,
                storage_relative_path=rel,
                status="disponible",
                uploaded_by=self.user_id,
                uploaded_at=now,
            )
            self.db.add(row)
        else:
            row.filename = filename
            row.storage_relative_path = rel
            row.status = "disponible"
            row.uploaded_by = self.user_id
            row.uploaded_at = now
        row.metadata_ = {"web_url": web_url, "source": "onedrive"}
        await self.db.commit()

    async def _company_knowledge(self, company_key: str) -> dict[str, KnowledgeAsset]:
        rows = (
            await self.db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == self.tenant_id,
                    KnowledgeAsset.company_key == company_key,
                    KnowledgeAsset.is_active.is_(True),
                )
            )
        ).scalars().all()
        return {r.document_type: r for r in rows}

    @staticmethod
    def _knowledge_as_legal_item(asset: KnowledgeAsset):
        meta = asset.metadata_ or {}

        class _Item:
            pass

        item = _Item()
        item.id = str(asset.id)
        item.name = asset.filename
        item.document_type = asset.document_type
        item.vigency_status = asset.vigency_status
        item.web_url = meta.get("web_url")
        return item

    @staticmethod
    def _parse_dt(value: str | None) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    async def _get_profile(self, company_id: uuid.UUID) -> LicitadorCompanyProfile:
        row = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == company_id,
                    LicitadorCompanyProfile.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not row:
            raise ValueError("Empresa no encontrada")
        return row

    async def _resolve_upload_folder(self, sess, company_key: str, onedrive_kind: str, primary_path: str):
        client = sess.client.onedrive
        try:
            return await client.ensure_folder_by_path(primary_path)
        except (GraphError, ValueError):
            if onedrive_kind != "identity":
                raise
            _primary, fallback = identity_onedrive_paths(company_key)
            return await client.ensure_folder_by_path(fallback)

    def _onedrive_folder(self, company_key: str, kind: str) -> str:
        root = ONEDRIVE_ROOTS.get(kind, ONEDRIVE_ROOTS["legal"])
        if kind == "identity":
            primary, _fallback = identity_onedrive_paths(company_key)
            return primary
        return f"{root}/{company_folder(company_key)}"
