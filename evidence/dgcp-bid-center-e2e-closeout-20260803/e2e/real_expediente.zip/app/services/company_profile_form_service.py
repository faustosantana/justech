"""Generador de formulario HTML para completar perfil de empresa."""

from __future__ import annotations

import secrets
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.document_pending import CompanyProfileFormToken
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.schemas.documents_hub import CompanyProfileUpdateRequest, ProfileFormResponse

FORM_FIELDS = [
    ("razon_social", "Razón social", True),
    ("rnc", "RNC", True),
    ("nombre_comercial", "Nombre comercial", False),
    ("direccion", "Dirección fiscal", True),
    ("telefono", "Teléfono", True),
    ("correo", "Correo", True),
    ("representante_legal", "Representante legal", True),
    ("cedula_representante", "Cédula representante", True),
    ("cargo_representante", "Cargo", False),
    ("registro_mercantil", "Registro mercantil", True),
    ("datos_bancarios", "Datos bancarios", True),
    ("proveedor_estado", "Proveedor del Estado (RPE)", False),
    ("responsable_legal", "Responsable legal interno", False),
    ("responsable_financiero", "Responsable financiero", False),
    ("responsable_licitaciones", "Responsable licitaciones", False),
]

REQUIRED_DOCS = [
    "Registro Mercantil",
    "Certificación DGII",
    "Certificación TSS",
    "RNC",
    "Cédula representante",
    "Certificación bancaria",
]


class CompanyProfileFormService:
    TOKEN_TTL_DAYS = 14

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, *, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def generate_form(self, company_id: uuid.UUID) -> ProfileFormResponse:
        profile = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == company_id,
                    LicitadorCompanyProfile.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not profile:
            raise ValueError("Empresa no encontrada")

        token = secrets.token_urlsafe(32)
        expires = datetime.now(UTC) + timedelta(days=self.TOKEN_TTL_DAYS)
        row = CompanyProfileFormToken(
            tenant_id=self.tenant_id,
            company_profile_id=profile.id,
            token=token,
            expires_at=expires,
            created_by_user_id=self.user_id,
        )
        self.db.add(row)
        await self.db.commit()

        form_url = f"{settings.public_profile_form_base}/{token}"
        submit_url = f"{settings.public_api_base}/documents/public/profile-form/{token}"
        empresa = profile.razon_social or profile.company_key.replace("_", " ").title()
        html = self._build_html(profile, token, submit_url, empresa)

        return ProfileFormResponse(
            token=token,
            form_url=form_url,
            html=html,
            expires_at=expires,
            company_key=profile.company_key,
            empresa=empresa,
        )

    async def submit_form(self, token: str, payload: dict | CompanyProfileUpdateRequest) -> dict:
        row = (
            await self.db.execute(
                select(CompanyProfileFormToken).where(CompanyProfileFormToken.token == token)
            )
        ).scalar_one_or_none()
        if not row or row.used_at or row.expires_at < datetime.now(UTC):
            raise ValueError("Enlace inválido o expirado")

        profile = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == row.company_profile_id,
                    LicitadorCompanyProfile.tenant_id == row.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not profile:
            raise ValueError("Empresa no encontrada")

        from app.services.documents_hub_service import DocumentsHubService
        from app.services.company_representative_service import CompanyRepresentativeService

        raw = payload if isinstance(payload, dict) else payload.model_dump(exclude_unset=True)
        profile_data = {k: v for k, v in raw.items() if k in {f[0] for f in FORM_FIELDS} and v}
        if profile_data:
            hub = DocumentsHubService(self.db, row.tenant_id)
            update = CompanyProfileUpdateRequest(**profile_data)
            await hub.update_company(profile.id, update)

        reps_payload = raw.get("representatives") or []
        rep_svc = CompanyRepresentativeService(self.db, row.tenant_id)
        for item in reps_payload:
            if not isinstance(item, dict) or not (item.get("full_name") or "").strip():
                continue
            from app.services.company_representative_service import is_registered_representative_name
            if not is_registered_representative_name(str(item.get("full_name"))):
                continue
            await rep_svc.upsert_from_form(profile.id, item)

        await self.db.commit()
        refreshed = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(LicitadorCompanyProfile.id == profile.id)
            )
        ).scalar_one()
        return {
            "ok": True,
            "company_key": refreshed.company_key,
            "completeness_score": refreshed.completeness_score,
        }

    def _build_html(
        self,
        profile: LicitadorCompanyProfile,
        token: str,
        form_url: str,
        empresa: str,
    ) -> str:
        raw = profile.raw_json or {}
        fields_html = ""
        for key, label, required in FORM_FIELDS:
            val = getattr(profile, key, None) or raw.get(key) or ""
            req = "required" if required else ""
            fields_html += f"""
            <div class="field">
              <label for="{key}">{label}{" *" if required else ""}</label>
              <input type="text" id="{key}" name="{key}" value="{self._esc(str(val))}" {req} />
            </div>"""

        docs_html = "".join(
            f'<div class="field"><label>{d}</label><input type="file" name="doc_{d.replace(" ", "_")}" accept=".pdf,.jpg,.png" /></div>'
            for d in REQUIRED_DOCS
        )

        return f"""<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <title>Actualización de perfil — {self._esc(empresa)}</title>
  <style>
    body {{ font-family: system-ui, sans-serif; max-width: 640px; margin: 2rem auto; padding: 0 1rem; background: #f8fafc; }}
    h1 {{ color: #0f172a; font-size: 1.5rem; }}
    .card {{ background: #fff; border-radius: 12px; padding: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,.08); }}
    .field {{ margin-bottom: 1rem; }}
    label {{ display: block; font-weight: 600; margin-bottom: 0.25rem; color: #334155; }}
    input[type=text], input[type=email] {{ width: 100%; padding: 0.5rem; border: 1px solid #cbd5e1; border-radius: 8px; }}
    button {{ background: #2563eb; color: #fff; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; font-weight: 600; cursor: pointer; }}
    .note {{ color: #64748b; font-size: 0.875rem; margin-top: 1rem; }}
    .error {{ color: #dc2626; display: none; }}
    .ok {{ color: #16a34a; display: none; }}
  </style>
</head>
<body>
  <h1>Perfil documental — {self._esc(empresa)}</h1>
  <p class="note">Complete los campos marcados con * y adjunte los documentos solicitados.</p>
  <div class="card">
    <form id="profileForm">
      {fields_html}
      <h2>Documentos requeridos</h2>
      {docs_html}
      <p class="error" id="err"></p>
      <p class="ok" id="ok">¡Información guardada en JAIOS!</p>
      <button type="submit">Guardar en JAIOS</button>
    </form>
  </div>
  <script>
    document.getElementById('profileForm').addEventListener('submit', async (e) => {{
      e.preventDefault();
      const fd = new FormData(e.target);
      const body = {{}};
      for (const [k, v] of fd.entries()) {{
        if (!k.startsWith('doc_') && v) body[k] = v;
      }}
      const err = document.getElementById('err');
      const ok = document.getElementById('ok');
      err.style.display = 'none';
      ok.style.display = 'none';
      try {{
        const res = await fetch('{form_url}', {{
          method: 'POST',
          headers: {{ 'Content-Type': 'application/json' }},
          body: JSON.stringify(body),
        }});
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error al guardar');
        ok.style.display = 'block';
      }} catch (ex) {{
        err.textContent = ex.message;
        err.style.display = 'block';
      }}
    }});
  </script>
</body>
</html>"""

    @staticmethod
    def _esc(text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )
