"""Sincroniza perfiles de empresa desde JSON en OneDrive (00_DATOS_EMPRESAS)."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.services.company_normalization_service import normalize_company_key
from app.models.m365_repository import M365RepositoryFile

REQUIRED_FIELDS = (
    "razon_social",
    "rnc",
    "direccion",
    "telefono",
    "correo",
    "representante_legal",
    "cedula_representante",
    "registro_mercantil",
    "datos_bancarios",
)


class CompanyProfileSyncService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def sync_from_binding(self, binding_id: uuid.UUID) -> dict:
        files = (
            await self.db.execute(
                select(M365RepositoryFile).where(
                    M365RepositoryFile.tenant_id == self.tenant_id,
                    M365RepositoryFile.binding_id == binding_id,
                    M365RepositoryFile.is_folder.is_(False),
                    M365RepositoryFile.is_deleted.is_(False),
                    M365RepositoryFile.name.ilike("%.json"),
                )
            )
        ).scalars().all()

        indexed = 0
        errors: list[str] = []
        for f in files:
            try:
                await self._sync_file(f)
                indexed += 1
            except Exception as exc:
                errors.append(f"{f.name}: {exc}")

        await self.db.commit()
        return {
            "records_indexed": indexed,
            "errors": errors,
            "message": f"{indexed} perfiles de empresa sincronizados",
        }

    async def list_profiles(self) -> list[dict]:
        from app.services.company_normalization_service import CompanyNormalizationService

        rows = await CompanyNormalizationService(self.db, self.tenant_id).list_canonical_profiles()
        return [self._profile_dict(r) for r in rows]

    async def validate_all(self) -> list[dict]:
        profiles = await self.list_profiles()
        return [
            {
                **p,
                "is_complete": len(p["missing_fields"]) == 0,
            }
            for p in profiles
        ]

    async def _sync_file(self, file_row: M365RepositoryFile) -> None:
        import httpx

        from app.services.m365_graph_session import M365GraphSessionService

        download_url: str | None = None
        if self.user_id and file_row.graph_item_id:
            sess = await M365GraphSessionService(self.db, self.tenant_id, self.user_id).session_for_account()
            download_url = await sess.client.onedrive.get_download_url(file_row.graph_item_id)
            file_row.download_url = download_url
        elif file_row.download_url:
            download_url = file_row.download_url

        if not download_url:
            raise ValueError("Sin URL de descarga para el archivo JSON en OneDrive.")

        async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
            resp = await client.get(download_url)
            if resp.status_code == 401 and self.user_id and file_row.graph_item_id:
                sess = await M365GraphSessionService(self.db, self.tenant_id, self.user_id).session_for_account()
                download_url = await sess.client.onedrive.get_download_url(file_row.graph_item_id)
                file_row.download_url = download_url
                resp = await client.get(download_url)
            resp.raise_for_status()
            data = json.loads(resp.content.decode("utf-8"))

        company_key = self._company_key_from_path(file_row.parent_path, file_row.name)
        normalized = self._normalize_json(data)
        missing = [f for f in REQUIRED_FIELDS if not normalized.get(f)]

        result = await self.db.execute(
            select(LicitadorCompanyProfile).where(
                LicitadorCompanyProfile.tenant_id == self.tenant_id,
                LicitadorCompanyProfile.company_key == company_key,
            )
        )
        row = result.scalar_one_or_none()
        if not row:
            row = LicitadorCompanyProfile(tenant_id=self.tenant_id, company_key=company_key)
            self.db.add(row)

        row.razon_social = normalized.get("razon_social")
        row.nombre_comercial = normalized.get("nombre_comercial")
        row.rnc = normalized.get("rnc")
        row.direccion = normalized.get("direccion")
        row.telefono = normalized.get("telefono")
        row.correo = normalized.get("correo")
        row.representante_legal = normalized.get("representante_legal")
        row.cedula_representante = normalized.get("cedula_representante")
        row.cargo_representante = normalized.get("cargo_representante")
        row.raw_json = data
        row.missing_fields = missing
        total = len(REQUIRED_FIELDS)
        row.completeness_score = int(((total - len(missing)) / total) * 100) if total else 0
        row.graph_file_id = file_row.graph_item_id
        row.source_filename = file_row.name
        row.synced_at = datetime.now(UTC)

    @staticmethod
    def _company_key_from_path(parent_path: str, filename: str) -> str:
        parts = [p for p in parent_path.split("/") if p.strip()]
        raw = parts[-1] if parts else filename.rsplit(".", 1)[0]
        canon = normalize_company_key(raw)
        if canon:
            return canon
        stem = filename.rsplit(".", 1)[0].lower()
        if "justech" in stem:
            return "justech"
        return normalize_company_key(stem) or "unknown"

    @staticmethod
    def _normalize_json(data: dict) -> dict:
        bancos = data.get("datos_bancarios") or data.get("cuenta_bancaria") or data.get("banco")
        return {
            "razon_social": data.get("razon_social") or data.get("empresa"),
            "nombre_comercial": data.get("nombre_comercial"),
            "rnc": data.get("rnc"),
            "direccion": data.get("direccion") or data.get("direccion_fiscal"),
            "telefono": data.get("telefono") or data.get("telefono_principal"),
            "correo": data.get("correo") or data.get("correo_principal"),
            "representante_legal": data.get("representante_legal"),
            "cedula_representante": data.get("cedula_representante") or data.get("cedula"),
            "cargo_representante": data.get("cargo_representante"),
            "registro_mercantil": data.get("registro_mercantil"),
            "datos_bancarios": bancos,
            "proveedor_estado": data.get("proveedor_estado") or data.get("rpe"),
            "actividad_comercial": data.get("actividad_comercial"),
            "rubros": data.get("rubros"),
            "responsable_licitaciones": data.get("responsable_licitaciones"),
            "responsable_legal": data.get("responsable_legal"),
            "responsable_financiero": data.get("responsable_financiero"),
        }

    @staticmethod
    def _profile_dict(row: LicitadorCompanyProfile) -> dict:
        return {
            "id": str(row.id),
            "company_key": row.company_key,
            "razon_social": row.razon_social,
            "nombre_comercial": row.nombre_comercial,
            "rnc": row.rnc,
            "direccion": row.direccion,
            "telefono": row.telefono,
            "correo": row.correo,
            "representante_legal": row.representante_legal,
            "cedula_representante": row.cedula_representante,
            "cargo_representante": row.cargo_representante,
            "missing_fields": row.missing_fields or [],
            "completeness_score": row.completeness_score,
            "synced_at": row.synced_at.isoformat() if row.synced_at else None,
            "source_filename": row.source_filename,
        }
