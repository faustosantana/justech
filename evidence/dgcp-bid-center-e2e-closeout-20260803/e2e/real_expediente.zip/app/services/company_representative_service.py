"""Representantes por empresa — CRUD, documentos y validación manual."""

from __future__ import annotations

import re
import uuid
from datetime import UTC, date, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.company_person_role import CompanyPersonRole
from app.models.company_representative import CompanyRepresentative, RepresentativeDocument
from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.schemas.company_representatives import (
    RepresentativeCreateRequest,
    RepresentativeDocumentResponse,
    RepresentativeResponse,
    RepresentativesSummaryResponse,
    RepresentativeUpdateRequest,
    ValidateRepresentativeDocumentRequest,
    ValidateRepresentativeDocumentResponse,
)

GENERIC_REPRESENTATIVE_NAMES = frozenset({
    "representante",
    "representante legal",
    "otro representante",
    "representante 2",
    "representante 3",
    "representante 4",
    "socio 1",
    "socio 2",
    "socio 3",
    "firmante adicional",
    "firmante extra",
    "sin representante",
    "sin representante asignado",
    "n/a",
    "na",
    "pendiente",
    "por definir",
    "tbd",
    "nombre completo",
})

_GENERIC_NAME_RE = re.compile(
    r"^(representante|socio|firmante|otro|adicional)(\s+\d+)?(\s+(adicional|extra))?$",
    re.IGNORECASE,
)


def is_registered_representative_name(name: str | None) -> bool:
    """Nombre real de persona — rechaza placeholders y genéricos."""
    cleaned = " ".join((name or "").split())
    if len(cleaned) < 4:
        return False
    lower = cleaned.lower()
    if lower in GENERIC_REPRESENTATIVE_NAMES:
        return False
    if _GENERIC_NAME_RE.match(lower):
        return False
    return True


def is_registered_representative(row: CompanyRepresentative) -> bool:
    return bool(row.is_active) and is_registered_representative_name(row.full_name)

RELATION_LABELS = {
    "representante_legal": "Representante legal",
    "gerente_general": "Gerente general",
    "presidente": "Presidente",
    "socio_administrador": "Socio administrador",
    "accionista": "Accionista",
    "apoderado": "Apoderado",
    "firmante_autorizado": "Firmante autorizado",
    "miembro_consejo": "Miembro del consejo",
    "contacto_administrativo": "Contacto administrativo",
}

DOCUMENT_TYPES = {
    "cedula": "Cédula",
    "pasaporte": "Pasaporte",
    "poder_notarial": "Poder notarial",
    "acta_designacion": "Acta de designación",
    "certificacion": "Certificación",
    "otros": "Otros",
}

REQUIRED_DOCS_BY_RELATION: dict[str, tuple[str, ...]] = {
    "representante_legal": ("cedula", "poder_notarial"),
    "responsable_legal": ("cedula",),
    "responsable_financiero": (),
    "responsable_licitaciones": (),
    "gerente_general": ("cedula",),
    "presidente": ("cedula",),
    "socio_administrador": ("cedula",),
    "apoderado": ("cedula", "poder_notarial"),
    "firmante_autorizado": ("cedula", "poder_notarial"),
    "accionista": ("cedula",),
    "miembro_consejo": ("cedula",),
    "contacto_administrativo": (),
}

VALIDATION_BADGES = {
    "pending": "Pendiente de validar",
    "validated": "Cédula validada",
    "rejected": "Rechazada",
    "needs_correction": "Requiere corrección",
}

FIELD_TO_DOC_TYPE = {
    "cedula_representante": "cedula",
    "poderes": "poder_notarial",
    "acta_asamblea": "acta_designacion",
}

PROFILE_FIELD_TO_ROLE = {
    "representante_legal": "representante_legal",
    "responsable_legal": "responsable_legal",
    "responsable_financiero": "responsable_financiero",
    "responsable_licitaciones": "contacto_administrativo",
}

ROLE_TYPE_LABELS = {
    **RELATION_LABELS,
    "responsable_legal": "Responsable legal",
    "responsable_financiero": "Responsable financiero",
    "responsable_licitaciones": "Responsable de licitaciones",
}


def normalize_person_name(name: str | None) -> str:
    return " ".join((name or "").lower().split())


class CompanyRepresentativeService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def list_representatives(self, company_id: uuid.UUID) -> RepresentativesSummaryResponse:
        profile = await self._get_profile(company_id)
        await self._deactivate_placeholder_representatives(profile.id)
        await self._ensure_legacy_migrated(profile)
        reps = await self._load_representatives(profile.id)
        validator_names = await self._validator_names(reps)
        roles_map = await self._load_roles_for_people([r.id for r in reps])
        items: list[RepresentativeResponse] = []
        pending = 0
        missing = 0
        for rep in reps:
            docs = await self._load_documents(rep.id)
            resp = self._rep_response(rep, docs, validator_names, roles=roles_map.get(rep.id))
            items.append(resp)
            pending += resp.documents_pending_validation
            missing += resp.documents_missing
        return RepresentativesSummaryResponse(
            company_id=str(profile.id),
            company_key=profile.company_key,
            representatives=items,
            total_representatives=len(items),
            validation_pending_count=pending,
            documents_missing_count=missing,
            all_validated=len(items) > 0 and pending == 0 and missing == 0,
        )

    async def create_representative(
        self, company_id: uuid.UUID, payload: RepresentativeCreateRequest, *, force_new: bool = False
    ) -> RepresentativeResponse:
        profile = await self._get_profile(company_id)
        full_name = payload.full_name.strip()
        if not is_registered_representative_name(full_name):
            raise ValueError(
                "Indique el nombre completo del representante. "
                "No se permiten placeholders ni nombres genéricos."
            )
        id_num = (payload.identification_number or "").strip() or None
        if not force_new:
            existing = await self.find_matching_person(company_id, full_name, id_num)
            if existing:
                roles = await self._load_person_roles(existing.id)
                role_labels = [ROLE_TYPE_LABELS.get(r, r) for r in roles]
                if payload.relation_type not in roles:
                    raise ValueError(
                        f"{existing.full_name} ya existe como persona relacionada"
                        f" ({', '.join(role_labels) or existing.relation_type}). "
                        f"Use assign_role para agregar «{ROLE_TYPE_LABELS.get(payload.relation_type, payload.relation_type)}» "
                        f"sin duplicar el registro, o confirme force_new=true."
                    )
        row = CompanyRepresentative(
            tenant_id=self.tenant_id,
            company_profile_id=profile.id,
            full_name=full_name,
            identification_type=payload.identification_type,
            identification_number=(payload.identification_number or "").strip() or None,
            position=payload.position,
            relation_type=payload.relation_type,
            email=payload.email,
            phone=payload.phone,
            can_sign=payload.can_sign,
            is_legal_representative=payload.is_legal_representative,
            can_participate_in_bids=payload.can_participate_in_bids,
            ownership_percentage=payload.ownership_percentage,
            start_date=payload.start_date,
            end_date=payload.end_date,
            is_active=payload.is_active,
        )
        self.db.add(row)
        await self.db.flush()
        await self._ensure_role_row(profile.id, row.id, payload.relation_type, payload)
        await self.db.commit()
        await self.db.refresh(row)
        return self._rep_response(row, [])

    async def find_matching_person(
        self,
        company_id: uuid.UUID,
        full_name: str,
        identification_number: str | None = None,
    ) -> CompanyRepresentative | None:
        profile = await self._get_profile(company_id)
        id_num = (identification_number or "").strip()
        if id_num:
            row = (
                await self.db.execute(
                    select(CompanyRepresentative).where(
                        CompanyRepresentative.company_profile_id == profile.id,
                        CompanyRepresentative.tenant_id == self.tenant_id,
                        CompanyRepresentative.identification_number == id_num,
                        CompanyRepresentative.is_active.is_(True),
                    )
                )
            ).scalar_one_or_none()
            if row and is_registered_representative(row):
                return row
        norm = normalize_person_name(full_name)
        if len(norm) < 4:
            return None
        rows = (
            await self.db.execute(
                select(CompanyRepresentative).where(
                    CompanyRepresentative.company_profile_id == profile.id,
                    CompanyRepresentative.tenant_id == self.tenant_id,
                    CompanyRepresentative.is_active.is_(True),
                )
            )
        ).scalars().all()
        for row in rows:
            if is_registered_representative(row) and normalize_person_name(row.full_name) == norm:
                return row
        return None

    async def assign_role(
        self,
        company_id: uuid.UUID,
        person_id: uuid.UUID,
        role_type: str,
        *,
        can_sign: bool | None = None,
        can_participate_in_bids: bool | None = None,
    ) -> RepresentativeResponse:
        profile = await self._get_profile(company_id)
        person = await self._get_representative(profile.id, person_id)
        if not is_registered_representative(person):
            raise ValueError("La persona seleccionada no es válida.")
        await self._ensure_role_row(
            profile.id,
            person.id,
            role_type,
            RepresentativeCreateRequest(
                full_name=person.full_name,
                relation_type=role_type,
                can_sign=can_sign if can_sign is not None else person.can_sign,
                can_participate_in_bids=(
                    can_participate_in_bids
                    if can_participate_in_bids is not None
                    else person.can_participate_in_bids
                ),
            ),
        )
        if role_type == "representante_legal":
            person.is_legal_representative = True
        if can_sign:
            person.can_sign = True
        await self.db.commit()
        docs = await self._load_documents(person.id)
        names = await self._validator_names([person])
        return self._rep_response(person, docs, names)

    async def link_profile_field_to_person(
        self, company_id: uuid.UUID, field_key: str, person_id: uuid.UUID
    ) -> dict:
        """Asigna un campo de perfil (ej. responsable_legal) a una persona existente."""
        profile = await self._get_profile(company_id)
        person = await self._get_representative(profile.id, person_id)
        role_type = PROFILE_FIELD_TO_ROLE.get(field_key)
        if not role_type:
            raise ValueError(f"Campo {field_key} no admite selección de persona")
        setattr(profile, field_key, person.full_name)
        role_type = PROFILE_FIELD_TO_ROLE[field_key]
        await self._ensure_role_row(
            profile.id,
            person.id,
            role_type,
            RepresentativeCreateRequest(full_name=person.full_name, relation_type=role_type),
        )
        await self.db.commit()
        return {
            "ok": True,
            "field_key": field_key,
            "person_id": str(person.id),
            "person_name": person.full_name,
            "message": f"{person.full_name} asignado como {ROLE_TYPE_LABELS.get(role_type, role_type)}.",
        }

    async def update_representative(
        self, company_id: uuid.UUID, representative_id: uuid.UUID, payload: RepresentativeUpdateRequest
    ) -> RepresentativeResponse:
        profile = await self._get_profile(company_id)
        row = await self._get_representative(profile.id, representative_id)
        for key, value in payload.model_dump(exclude_unset=True).items():
            if key == "full_name" and value:
                value = str(value).strip()
                if not is_registered_representative_name(value):
                    raise ValueError(
                        "Indique el nombre completo del representante. "
                        "No se permiten placeholders ni nombres genéricos."
                    )
            if key == "identification_number" and value is not None:
                value = str(value).strip() or None
            setattr(row, key, value)
        await self.db.commit()
        await self.db.refresh(row)
        docs = await self._load_documents(row.id)
        names = await self._validator_names([row])
        return self._rep_response(row, docs, names)

    async def deactivate_representative(
        self, company_id: uuid.UUID, representative_id: uuid.UUID
    ) -> RepresentativeResponse:
        return await self.update_representative(
            company_id, representative_id, RepresentativeUpdateRequest(is_active=False)
        )

    async def delete_representative(
        self, company_id: uuid.UUID, representative_id: uuid.UUID
    ) -> dict:
        profile = await self._get_profile(company_id)
        rep = await self._get_representative(profile.id, representative_id)
        docs = await self._load_documents(rep.id)
        if any(d.status == "loaded" for d in docs):
            raise ValueError(
                "No se puede eliminar: el representante tiene documentos vinculados. "
                "Use «Desactivar» en su lugar."
            )
        await self.db.delete(rep)
        await self.db.commit()
        return {"ok": True, "message": f"Representante {rep.full_name} eliminado."}

    async def upsert_from_form(
        self, company_id: uuid.UUID, item: dict
    ) -> RepresentativeResponse:
        """Crea o actualiza representante desde formulario externo (por id o cédula)."""
        profile = await self._get_profile(company_id)
        rep_id_raw = item.get("id")
        if rep_id_raw:
            try:
                rep_id = uuid.UUID(str(rep_id_raw))
                await self._get_representative(profile.id, rep_id)
                payload = RepresentativeUpdateRequest(
                    **{k: v for k, v in item.items() if k != "id" and v is not None}
                )
                return await self.update_representative(company_id, rep_id, payload)
            except (ValueError, TypeError):
                pass

        id_num = (item.get("identification_number") or "").strip()
        if id_num:
            existing = (
                await self.db.execute(
                    select(CompanyRepresentative).where(
                        CompanyRepresentative.company_profile_id == profile.id,
                        CompanyRepresentative.tenant_id == self.tenant_id,
                        CompanyRepresentative.identification_number == id_num,
                        CompanyRepresentative.is_active.is_(True),
                    )
                )
            ).scalar_one_or_none()
            if existing:
                payload = RepresentativeUpdateRequest(
                    **{k: v for k, v in item.items() if k not in ("id",) and v is not None}
                )
                return await self.update_representative(company_id, existing.id, payload)

        return await self.create_representative(
            company_id,
            RepresentativeCreateRequest(**{k: v for k, v in item.items() if k != "id"}),
        )

    def missing_documents_summary(
        self, summary: RepresentativesSummaryResponse
    ) -> list[dict]:
        """Documentos faltantes o pendientes de validación por representante."""
        items: list[dict] = []
        for rep in summary.representatives:
            for doc in rep.documents:
                if doc.status == "missing":
                    items.append(
                        {
                            "representative_id": rep.id,
                            "representative_name": rep.full_name,
                            "relation_label": rep.relation_label,
                            "document_type": doc.document_type,
                            "document_label": doc.document_label,
                            "status": "missing",
                            "validation_status": doc.validation_status,
                            "badge": "Pendiente",
                        }
                    )
                elif doc.status == "loaded" and doc.requires_validation and doc.validation_status == "pending":
                    items.append(
                        {
                            "representative_id": rep.id,
                            "representative_name": rep.full_name,
                            "relation_label": rep.relation_label,
                            "document_type": doc.document_type,
                            "document_label": doc.document_label,
                            "status": "validation_pending",
                            "validation_status": doc.validation_status,
                            "badge": "Pendiente de validar",
                        }
                    )
                elif doc.validation_status == "rejected":
                    items.append(
                        {
                            "representative_id": rep.id,
                            "representative_name": rep.full_name,
                            "relation_label": rep.relation_label,
                            "document_type": doc.document_type,
                            "document_label": doc.document_label,
                            "status": "rejected",
                            "validation_status": doc.validation_status,
                            "badge": "Rechazada",
                        }
                    )
        return items

    async def upsert_document(
        self,
        *,
        company_id: uuid.UUID,
        representative_id: uuid.UUID,
        document_type: str,
        filename: str,
        knowledge_asset_id: uuid.UUID | None = None,
        m365_drive_id: str | None = None,
        m365_item_id: str | None = None,
        m365_web_url: str | None = None,
        link_mode: str = "link",
        expiration_date: date | None = None,
    ) -> RepresentativeDocument:
        profile = await self._get_profile(company_id)
        rep = await self._get_representative(profile.id, representative_id)
        existing = (
            await self.db.execute(
                select(RepresentativeDocument).where(
                    RepresentativeDocument.representative_id == rep.id,
                    RepresentativeDocument.document_type == document_type,
                )
            )
        ).scalar_one_or_none()
        if not existing:
            existing = RepresentativeDocument(
                tenant_id=self.tenant_id,
                company_profile_id=profile.id,
                representative_id=rep.id,
                document_type=document_type,
            )
            self.db.add(existing)
        existing.filename = filename
        existing.knowledge_asset_id = knowledge_asset_id
        existing.m365_drive_id = m365_drive_id
        existing.m365_item_id = m365_item_id
        existing.m365_web_url = m365_web_url
        existing.link_mode = link_mode
        existing.status = "loaded"
        existing.validation_status = "pending"
        existing.validation_method = None
        existing.validated_at = None
        existing.validated_by_user_id = None
        existing.expiration_date = expiration_date
        await self.db.commit()
        await self.db.refresh(existing)
        return existing

    async def validate_document(
        self,
        company_id: uuid.UUID,
        representative_id: uuid.UUID,
        document_type: str,
        payload: ValidateRepresentativeDocumentRequest,
    ) -> ValidateRepresentativeDocumentResponse:
        profile = await self._get_profile(company_id)
        rep = await self._get_representative(profile.id, representative_id)
        doc = (
            await self.db.execute(
                select(RepresentativeDocument).where(
                    RepresentativeDocument.representative_id == rep.id,
                    RepresentativeDocument.document_type == document_type,
                )
            )
        ).scalar_one_or_none()
        if not doc or doc.status != "loaded":
            raise ValueError("No hay documento cargado para validar.")
        if document_type == "cedula" and not (rep.identification_number or "").strip():
            raise ValueError("El representante debe tener número de cédula antes de validar.")
        doc.validation_status = payload.validation_status
        doc.validation_method = payload.validation_method
        doc.validation_notes = payload.validation_notes
        doc.validated_by_user_id = self.user_id
        doc.validated_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(doc)
        names = await self._validator_names([rep])
        resp = self._doc_response(doc, names.get(str(doc.validated_by_user_id or "")))
        msg = (
            f"Cédula validada para {rep.full_name}."
            if payload.validation_status == "validated"
            else f"Documento marcado como {VALIDATION_BADGES.get(payload.validation_status, payload.validation_status)}."
        )
        return ValidateRepresentativeDocumentResponse(ok=True, message=msg, document=resp)

    async def resolve_representative_for_field(
        self, company_id: uuid.UUID, field_key: str, representative_id: uuid.UUID | None
    ) -> tuple[CompanyRepresentative, str]:
        profile = await self._get_profile(company_id)
        doc_type = FIELD_TO_DOC_TYPE.get(field_key, field_key)
        if representative_id:
            rep = await self._get_representative(profile.id, representative_id)
            if not is_registered_representative(rep):
                raise ValueError("El representante seleccionado no es válido.")
            return rep, doc_type
        reps = await self._load_representatives(profile.id)
        if not reps:
            raise ValueError(
                "Debe agregar un representante antes de asociar este documento. "
                "Use «Agregar representante» en la pestaña correspondiente."
            )
        legal = next((r for r in reps if r.is_legal_representative), None)
        if legal:
            return legal, doc_type
        if len(reps) == 1:
            return reps[0], doc_type
        raise ValueError(
            "Seleccione el representante al que corresponde este documento."
        )

    async def _ensure_legacy_migrated(self, profile: LicitadorCompanyProfile) -> None:
        existing = (
            await self.db.execute(
                select(CompanyRepresentative.id).where(
                    CompanyRepresentative.tenant_id == self.tenant_id,
                    CompanyRepresentative.company_profile_id == profile.id,
                    CompanyRepresentative.is_active.is_(True),
                ).limit(1)
            )
        ).scalar_one_or_none()
        if existing:
            return
        legal_name = (profile.representante_legal or "").strip()
        if not is_registered_representative_name(legal_name):
            return
        rep = CompanyRepresentative(
            tenant_id=self.tenant_id,
            company_profile_id=profile.id,
            full_name=legal_name,
            identification_type="cedula",
            identification_number=profile.cedula_representante,
            position=profile.cargo_representante,
            relation_type="representante_legal",
            is_legal_representative=True,
            can_sign=True,
            can_participate_in_bids=True,
        )
        self.db.add(rep)
        await self.db.flush()
        asset = (
            await self.db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == self.tenant_id,
                    KnowledgeAsset.company_key == profile.company_key,
                    KnowledgeAsset.document_type == "cedula_representante",
                    KnowledgeAsset.is_active.is_(True),
                )
            )
        ).scalar_one_or_none()
        if asset:
            meta = asset.metadata_ or {}
            self.db.add(
                RepresentativeDocument(
                    tenant_id=self.tenant_id,
                    company_profile_id=profile.id,
                    representative_id=rep.id,
                    document_type="cedula",
                    knowledge_asset_id=asset.id,
                    filename=asset.filename,
                    m365_item_id=meta.get("graph_item_id"),
                    m365_web_url=meta.get("web_url"),
                    link_mode=meta.get("link_mode", "link"),
                    status="loaded",
                    validation_status="pending",
                )
            )
        await self.db.commit()

    async def _load_roles_for_people(self, person_ids: list[uuid.UUID]) -> dict[uuid.UUID, list[str]]:
        if not person_ids:
            return {}
        rows = (
            await self.db.execute(
                select(CompanyPersonRole).where(
                    CompanyPersonRole.person_id.in_(person_ids),
                    CompanyPersonRole.tenant_id == self.tenant_id,
                    CompanyPersonRole.is_active.is_(True),
                )
            )
        ).scalars().all()
        result: dict[uuid.UUID, list[str]] = {pid: [] for pid in person_ids}
        for row in rows:
            result.setdefault(row.person_id, []).append(row.role_type)
        reps = (
            await self.db.execute(
                select(CompanyRepresentative).where(CompanyRepresentative.id.in_(person_ids))
            )
        ).scalars().all()
        for rep in reps:
            if rep.relation_type and rep.relation_type not in result.get(rep.id, []):
                result.setdefault(rep.id, []).append(rep.relation_type)
        return result

    async def _load_person_roles(self, person_id: uuid.UUID) -> list[str]:
        batch = await self._load_roles_for_people([person_id])
        return batch.get(person_id, [])

    async def _ensure_role_row(
        self,
        company_profile_id: uuid.UUID,
        person_id: uuid.UUID,
        role_type: str,
        payload: RepresentativeCreateRequest,
    ) -> None:
        existing = (
            await self.db.execute(
                select(CompanyPersonRole).where(
                    CompanyPersonRole.person_id == person_id,
                    CompanyPersonRole.role_type == role_type,
                    CompanyPersonRole.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if existing:
            existing.is_active = True
            if payload.can_sign:
                existing.can_sign = True
            return
        self.db.add(
            CompanyPersonRole(
                tenant_id=self.tenant_id,
                person_id=person_id,
                company_profile_id=company_profile_id,
                role_type=role_type,
                can_sign=payload.can_sign,
                can_participate_in_bids=payload.can_participate_in_bids,
                ownership_percentage=payload.ownership_percentage,
                start_date=payload.start_date,
                end_date=payload.end_date,
            )
        )

    async def _deactivate_placeholder_representatives(self, company_profile_id: uuid.UUID) -> None:
        rows = list(
            (
                await self.db.execute(
                    select(CompanyRepresentative).where(
                        CompanyRepresentative.company_profile_id == company_profile_id,
                        CompanyRepresentative.tenant_id == self.tenant_id,
                        CompanyRepresentative.is_active.is_(True),
                    )
                )
            ).scalars().all()
        )
        changed = False
        for row in rows:
            if not is_registered_representative(row):
                row.is_active = False
                changed = True
        if changed:
            await self.db.commit()

    async def _get_profile(self, company_id: uuid.UUID) -> LicitadorCompanyProfile:
        row = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == company_id,
                    LicitadorCompanyProfile.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not row:
            raise ValueError("Empresa no encontrada")
        return row

    async def _get_representative(
        self, company_profile_id: uuid.UUID, representative_id: uuid.UUID
    ) -> CompanyRepresentative:
        row = (
            await self.db.execute(
                select(CompanyRepresentative).where(
                    CompanyRepresentative.id == representative_id,
                    CompanyRepresentative.company_profile_id == company_profile_id,
                    CompanyRepresentative.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not row:
            raise ValueError("Representante no encontrado")
        return row

    async def _load_representatives(self, company_profile_id: uuid.UUID) -> list[CompanyRepresentative]:
        rows = list(
            (
                await self.db.execute(
                    select(CompanyRepresentative)
                    .where(
                        CompanyRepresentative.company_profile_id == company_profile_id,
                        CompanyRepresentative.tenant_id == self.tenant_id,
                        CompanyRepresentative.is_active.is_(True),
                    )
                    .order_by(
                        CompanyRepresentative.is_legal_representative.desc(),
                        CompanyRepresentative.full_name,
                    )
                )
            ).scalars().all()
        )
        return [r for r in rows if is_registered_representative(r)]

    async def _load_documents(self, representative_id: uuid.UUID) -> list[RepresentativeDocument]:
        return list(
            (
                await self.db.execute(
                    select(RepresentativeDocument).where(
                        RepresentativeDocument.representative_id == representative_id,
                        RepresentativeDocument.tenant_id == self.tenant_id,
                    )
                )
            ).scalars().all()
        )

    async def _validator_names(self, reps: list[CompanyRepresentative]) -> dict[str, str]:
        from app.models.user import User

        rep_ids = [r.id for r in reps]
        if not rep_ids:
            return {}
        doc_rows = list(
            (
                await self.db.execute(
                    select(RepresentativeDocument).where(
                        RepresentativeDocument.representative_id.in_(rep_ids),
                        RepresentativeDocument.tenant_id == self.tenant_id,
                    )
                )
            ).scalars().all()
        )
        user_ids = {d.validated_by_user_id for d in doc_rows if d.validated_by_user_id}
        if not user_ids:
            return {}
        users = (
            await self.db.execute(select(User).where(User.id.in_(user_ids)))
        ).scalars().all()
        return {str(u.id): (u.full_name or u.email or str(u.id)) for u in users}

    def _rep_response(
        self,
        rep: CompanyRepresentative,
        docs: list[RepresentativeDocument],
        validator_names: dict[str, str] | None = None,
        roles: list[str] | None = None,
    ) -> RepresentativeResponse:
        validator_names = validator_names or {}
        role_list = roles if roles is not None else ([rep.relation_type] if rep.relation_type else [])
        required_types: set[str] = set()
        for role in role_list:
            required_types.update(REQUIRED_DOCS_BY_RELATION.get(role, ("cedula",)))
        if not required_types:
            required_types.update(REQUIRED_DOCS_BY_RELATION.get(rep.relation_type, ("cedula",)))
        required = tuple(sorted(required_types))
        by_type = {d.document_type: d for d in docs}
        doc_responses: list[RepresentativeDocumentResponse] = []
        loaded = 0
        pending_val = 0
        missing = 0
        for doc_type in required:
            row = by_type.get(doc_type)
            if row and row.status == "loaded":
                dr = self._doc_response(row, validator_names.get(str(row.validated_by_user_id or "")))
                doc_responses.append(dr)
                loaded += 1
                if dr.validation_status == "pending" and dr.requires_validation:
                    pending_val += 1
            else:
                missing += 1
                doc_responses.append(
                    RepresentativeDocumentResponse(
                        id="",
                        document_type=doc_type,
                        document_label=DOCUMENT_TYPES.get(doc_type, doc_type),
                        status="missing",
                        badge="Pendiente",
                        validation_status="pending",
                        validation_badge="—",
                        requires_validation=doc_type == "cedula",
                    )
                )
        for doc_type, row in by_type.items():
            if doc_type in required:
                continue
            dr = self._doc_response(row, validator_names.get(str(row.validated_by_user_id or "")))
            doc_responses.append(dr)
            if row.status == "loaded":
                loaded += 1
        status_parts = []
        if missing:
            status_parts.append(f"{missing} doc. pendiente(s)")
        if pending_val:
            status_parts.append(f"{pending_val} por validar")
        if not missing and not pending_val and loaded:
            status_parts.append("Completo")
        return RepresentativeResponse(
            id=str(rep.id),
            full_name=rep.full_name,
            identification_type=rep.identification_type,
            identification_number=rep.identification_number,
            position=rep.position,
            relation_type=rep.relation_type,
            relation_label=RELATION_LABELS.get(rep.relation_type, rep.relation_type),
            roles=role_list,
            role_labels=[ROLE_TYPE_LABELS.get(r, r) for r in role_list],
            email=rep.email,
            phone=rep.phone,
            can_sign=rep.can_sign,
            is_legal_representative=rep.is_legal_representative,
            can_participate_in_bids=rep.can_participate_in_bids,
            ownership_percentage=rep.ownership_percentage,
            start_date=rep.start_date,
            end_date=rep.end_date,
            is_active=rep.is_active,
            documents=doc_responses,
            documents_loaded=loaded,
            documents_pending_validation=pending_val,
            documents_missing=missing,
            status_summary=" · ".join(status_parts) if status_parts else "Sin documentos",
        )

    @staticmethod
    def _doc_response(
        row: RepresentativeDocument,
        validated_by_name: str | None = None,
    ) -> RepresentativeDocumentResponse:
        requires = row.document_type == "cedula"
        vstatus = row.validation_status
        if row.status != "loaded":
            badge, vbadge = "Falta", "—"
            status = "missing"
        else:
            status = "loaded"
            badge = "Documento cargado"
            vbadge = VALIDATION_BADGES.get(vstatus, vstatus)
        return RepresentativeDocumentResponse(
            id=str(row.id),
            document_type=row.document_type,
            document_label=DOCUMENT_TYPES.get(row.document_type, row.document_type),
            filename=row.filename,
            status=status,
            badge=badge,
            validation_status=vstatus,
            validation_badge=vbadge,
            validation_method=row.validation_method,
            validation_notes=row.validation_notes,
            validated_at=row.validated_at,
            validated_by_name=validated_by_name,
            expiration_date=row.expiration_date,
            knowledge_asset_id=str(row.knowledge_asset_id) if row.knowledge_asset_id else None,
            m365_web_url=row.m365_web_url,
            m365_item_id=row.m365_item_id,
            link_mode=row.link_mode,
            requires_validation=requires,
        )
