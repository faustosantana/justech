"""Control de acceso del Copiloto — JAIOS decide, no Hermes."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.copilot_scopes import (
    DATA_CLASS_LABELS,
    INTENT_SCOPES,
    SCOPE_LABELS,
    TOOL_ACCESS,
    denial_message,
    role_has_any_scope,
    scopes_for_role,
)
from app.core.admin_permissions import normalize_role
from app.core.tenant import get_current_role
from app.models.integration_settings import TenantIntegrationSetting
from app.models.tenant import TenantMembership


@dataclass
class AccessDecision:
    allowed: bool
    reason: str = ""
    missing_scope: str = ""
    classification: str = ""
    resource: str = ""
    intent: str = ""
    tool: str = ""
    scopes: list[str] = field(default_factory=list)


class CopilotAccessService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._role: str | None = None
        self._extra_scopes: frozenset[str] | None = None
        self._assigned_customers: list[str] | None = None

    async def _load_membership(self) -> TenantMembership | None:
        result = await self.db.execute(
            select(TenantMembership).where(
                TenantMembership.tenant_id == self.tenant_id,
                TenantMembership.user_id == self.user_id,
            )
        )
        return result.scalar_one_or_none()

    async def role(self) -> str:
        if self._role is None:
            self._role = normalize_role(get_current_role())
            membership = await self._load_membership()
            if membership and membership.role:
                self._role = normalize_role(membership.role)
        return self._role

    async def extra_scopes(self) -> frozenset[str]:
        if self._extra_scopes is not None:
            return self._extra_scopes
        cfg = await self._security_config()
        overrides = (cfg.get("user_scope_overrides") or {}).get(str(self.user_id), {})
        role_overrides = (cfg.get("role_scope_overrides") or {}).get(await self.role(), [])
        extra = set(overrides.get("add_scopes") or []) | set(role_overrides)
        remove = set(overrides.get("remove_scopes") or [])
        base = scopes_for_role(await self.role())
        self._extra_scopes = frozenset((base | extra) - remove)
        return self._extra_scopes

    async def assigned_customers(self) -> list[str]:
        if self._assigned_customers is not None:
            return self._assigned_customers
        cfg = await self._security_config()
        user_cfg = (cfg.get("user_assignments") or {}).get(str(self.user_id), {})
        self._assigned_customers = list(user_cfg.get("customers") or [])
        return self._assigned_customers

    async def _security_config(self) -> dict[str, Any]:
        result = await self.db.execute(
            select(TenantIntegrationSetting).where(
                TenantIntegrationSetting.tenant_id == self.tenant_id,
                TenantIntegrationSetting.provider == "hermes",
            )
        )
        row = result.scalar_one_or_none()
        return (row.config or {}).get("copilot_security", {}) if row else {}

    async def user_scopes(self) -> list[str]:
        return sorted(await self.extra_scopes())

    async def permissions_summary(self) -> str:
        scopes = await self.user_scopes()
        labels = [SCOPE_LABELS.get(s, s) for s in scopes[:12]]
        role = await self.role()
        extra = f" (+{len(scopes) - 12} más)" if len(scopes) > 12 else ""
        return f"Rol: {role}. Permisos IA: {', '.join(labels)}{extra}"

    async def check_tool(
        self,
        tool_name: str,
        *,
        intent: str | None = None,
        parameters: dict[str, Any] | None = None,
    ) -> AccessDecision:
        normalized = (tool_name or "").strip().lower().replace("-", "_")
        if normalized in ("odoo_sales",):
            normalized = "odoo_sales"
        meta = TOOL_ACCESS.get(normalized)
        if not meta:
            return AccessDecision(allowed=True, tool=normalized, reason="tool_unrestricted")

        scopes = await self.extra_scopes()
        required = meta["scopes_any"]
        allowed = bool(scopes & required)

        # Intención más restrictiva
        if intent and intent in INTENT_SCOPES:
            intent_required = INTENT_SCOPES[intent]
            if not (scopes & intent_required):
                allowed = False
                missing = next(iter(intent_required - scopes), "")
                return AccessDecision(
                    allowed=False,
                    reason=denial_message(missing),
                    missing_scope=missing,
                    classification=meta["classification"],
                    resource=meta["resource"],
                    intent=intent,
                    tool=normalized,
                    scopes=sorted(scopes),
                )

        if not allowed:
            missing = next(iter(required - scopes), "")
            return AccessDecision(
                allowed=False,
                reason=denial_message(missing),
                missing_scope=missing,
                classification=meta["classification"],
                resource=meta["resource"],
                intent=intent or "",
                tool=normalized,
                scopes=sorted(scopes),
            )

        # Cliente asignado — ventas por cliente específico
        if normalized in ("odoo_sales", "odoo") and parameters:
            customer = (
                parameters.get("customer")
                or parameters.get("cliente")
                or parameters.get("query", "")
            )
            if customer and "sales.read.all" not in scopes:
                assigned = await self.assigned_customers()
                if assigned and not any(a.lower() in str(customer).lower() for a in assigned):
                    return AccessDecision(
                        allowed=False,
                        reason=(
                            "No tienes permisos para consultar ventas de ese cliente. "
                            "Solo puedes ver clientes asignados a tu cuenta."
                        ),
                        missing_scope="customers.read.assigned",
                        classification=meta["classification"],
                        resource=meta["resource"],
                        intent=intent or "",
                        tool=normalized,
                        scopes=sorted(scopes),
                    )

        return AccessDecision(
            allowed=True,
            classification=meta["classification"],
            resource=meta["resource"],
            intent=intent or "",
            tool=normalized,
            scopes=sorted(scopes),
        )

    async def check_intent_before_tools(
        self,
        intent: str,
        tools: list[dict[str, Any]],
    ) -> AccessDecision | None:
        """Pre-validación antes de ejecutar herramientas."""
        for tool in tools:
            name = tool.get("name") or tool.get("tool") or ""
            params = tool.get("parameters") or {}
            decision = await self.check_tool(name, intent=intent, parameters=params)
            if not decision.allowed:
                return decision
        return None

    @staticmethod
    def get_role_matrix() -> dict[str, Any]:
        from app.core.copilot_scopes import ROLE_SCOPES, ALL_SCOPES

        return {
            "scopes": sorted(ALL_SCOPES),
            "scope_labels": SCOPE_LABELS,
            "data_classifications": DATA_CLASS_LABELS,
            "roles": {
                role: sorted(scopes)
                for role, scopes in ROLE_SCOPES.items()
                if role != "member"
            },
        }
