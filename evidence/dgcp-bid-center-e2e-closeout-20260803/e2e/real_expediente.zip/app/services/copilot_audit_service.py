"""Auditoría de consultas sensibles del Copiloto."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import Request
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit_log import AuditLog
from app.services.audit_service import AuditService
from app.services.copilot_access_service import AccessDecision


class CopilotAuditService:
    ACTION = "copilot.query"

    def __init__(self, db: AsyncSession):
        self.db = db
        self.audit = AuditService(db)

    async def log_query(
        self,
        *,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        question: str,
        intent: str | None = None,
        tool: str | None = None,
        resource: str | None = None,
        classification: str | None = None,
        customer: str | None = None,
        provider: str | None = None,
        allowed: bool = True,
        data_returned: bool = False,
        model: str | None = None,
        decision: AccessDecision | None = None,
        request: Request | None = None,
    ) -> AuditLog:
        details: dict[str, Any] = {
            "question": question[:500],
            "intent": intent or (decision.intent if decision else None),
            "tool": tool or (decision.tool if decision else None),
            "resource": resource or (decision.resource if decision else None),
            "data_classification": classification or (decision.classification if decision else None),
            "customer": customer,
            "provider": provider,
            "permission_granted": allowed,
            "data_returned": data_returned,
            "model": model,
            "missing_scope": decision.missing_scope if decision else None,
            "denial_reason": decision.reason if decision and not allowed else None,
        }
        return await self.audit.log(
            action=self.ACTION,
            tenant_id=tenant_id,
            user_id=user_id,
            resource_type="copilot",
            details=details,
            request=request,
        )

    async def list_recent(
        self,
        tenant_id: uuid.UUID,
        *,
        limit: int = 50,
        denied_only: bool = False,
    ) -> list[dict[str, Any]]:
        q = (
            select(AuditLog)
            .where(AuditLog.tenant_id == tenant_id, AuditLog.action == self.ACTION)
            .order_by(desc(AuditLog.created_at))
            .limit(limit)
        )
        result = await self.db.execute(q)
        rows = result.scalars().all()
        out = []
        for row in rows:
            d = row.details or {}
            if denied_only and d.get("permission_granted"):
                continue
            out.append({
                "id": str(row.id),
                "user_id": str(row.user_id) if row.user_id else None,
                "question": d.get("question"),
                "intent": d.get("intent"),
                "tool": d.get("tool"),
                "resource": d.get("resource"),
                "data_classification": d.get("data_classification"),
                "customer": d.get("customer"),
                "permission_granted": d.get("permission_granted"),
                "data_returned": d.get("data_returned"),
                "model": d.get("model"),
                "denial_reason": d.get("denial_reason"),
                "ip_address": str(row.ip_address) if row.ip_address else None,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            })
        return out
