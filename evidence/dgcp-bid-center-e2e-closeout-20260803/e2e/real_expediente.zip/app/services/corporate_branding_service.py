"""Activos de branding corporativo — logo, firma, sello por empresa (sin hardcode)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.services.company_normalization_service import canonical_label, normalize_company_key
from app.services.corporate_identity_service import CorporateIdentityService
from app.services.corporate_knowledge_engine import CorporateKnowledgeEngine
from app.services.corporate_repository_unified_service import CorporateRepositoryUnifiedService
from app.services.knowledge_source_provider import get_knowledge_source_provider


@dataclass
class BrandingAssetStatus:
    asset_type: str
    status: str  # detectado | falta | requiere_actualizacion
    label: str | None = None
    source: str | None = None
    view_url: str | None = None
    local_path: Path | None = None
    filename: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "asset_type": self.asset_type,
            "status": self.status,
            "label": self.label,
            "source": self.source,
            "view_url": self.view_url,
            "filename": self.filename,
        }


@dataclass
class CorporateBrandingContext:
    company_key: str
    company_name: str
    rnc: str | None = None
    address: str | None = None
    phone: str | None = None
    email: str | None = None
    representative_name: str | None = None
    representative_role: str | None = None
    logo: BrandingAssetStatus = field(default_factory=lambda: BrandingAssetStatus("logo", "falta"))
    signature: BrandingAssetStatus = field(default_factory=lambda: BrandingAssetStatus("signature", "falta"))
    stamp: BrandingAssetStatus = field(default_factory=lambda: BrandingAssetStatus("stamp", "falta"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "company_key": self.company_key,
            "company_name": self.company_name,
            "rnc": self.rnc,
            "address": self.address,
            "phone": self.phone,
            "email": self.email,
            "representative_name": self.representative_name,
            "representative_role": self.representative_role,
            "logo": self.logo.to_dict(),
            "signature": self.signature.to_dict(),
            "stamp": self.stamp.to_dict(),
        }


class CorporateBrandingService:
    """Resuelve branding desde Perfil Empresarial + Repositorio + Identidad corporativa."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, *, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.identity = CorporateIdentityService(db, tenant_id, user_id=user_id)
        self.source = get_knowledge_source_provider()

    async def resolve(self, company_key: str) -> CorporateBrandingContext:
        key = normalize_company_key(company_key) or company_key
        profile_text = await self._profile_text(key)
        ctx = CorporateBrandingContext(
            company_key=key,
            company_name=profile_text.get("razon_social") or canonical_label(key),
            rnc=profile_text.get("rnc"),
            address=profile_text.get("direccion"),
            phone=profile_text.get("telefono"),
            email=profile_text.get("correo"),
            representative_name=profile_text.get("representante_legal") or profile_text.get("responsable_legal"),
            representative_role=profile_text.get("cargo_representante") or "Representante autorizado",
        )
        ctx.logo = await self._resolve_logo(key)
        sig_path, sig_name, sig_status = await self.identity.resolve_signature_path()
        ctx.signature = BrandingAssetStatus(
            asset_type="signature",
            status="detectado" if sig_path else ("requiere_actualizacion" if sig_status == "requiere_revision" else "falta"),
            label="Firma corporativa",
            source="corporate_identity",
            filename=sig_name or self.identity.default_signature_filename(),
            local_path=sig_path,
        )
        expected_stamp = self.identity.stamp_filename_for_company(key)
        stamp_path, stamp_name, stamp_status = await self.identity.resolve_stamp_path(key)
        ctx.stamp = BrandingAssetStatus(
            asset_type="stamp",
            status="detectado" if stamp_path else ("requiere_actualizacion" if stamp_status == "requiere_revision" else "falta"),
            label=f"Sello {ctx.company_name}",
            source="corporate_identity",
            filename=stamp_name or expected_stamp or None,
            local_path=stamp_path,
        )
        return ctx

    async def _profile_text(self, company_key: str) -> dict[str, str]:
        merged: dict[str, str] = {}
        result = await self.db.execute(
            select(LicitadorCompanyProfile).where(
                LicitadorCompanyProfile.tenant_id == self.tenant_id,
                LicitadorCompanyProfile.company_key == company_key,
            )
        )
        profile = result.scalar_one_or_none()
        if profile:
            repo = CorporateRepositoryUnifiedService(self.db, self.tenant_id, company_key=company_key)
            merged = {k: str(v) for k, v in repo.merge_profile_text(profile).items() if v}
        static = CorporateRepositoryUnifiedService.static_profile(company_key)
        for k, v in static.items():
            merged.setdefault(k, v)
        knowledge = CorporateKnowledgeEngine(self.db, self.tenant_id).get_company_profile(company_key)
        for k, v in knowledge.items():
            merged.setdefault(k, str(v))
        return merged

    async def _resolve_logo(self, company_key: str) -> BrandingAssetStatus:
        result = await self.db.execute(
            select(KnowledgeAsset)
            .where(
                KnowledgeAsset.tenant_id == self.tenant_id,
                KnowledgeAsset.company_key == company_key,
                KnowledgeAsset.is_active.is_(True),
                KnowledgeAsset.document_type == "logo",
            )
            .order_by(KnowledgeAsset.synced_at.desc().nullslast())
            .limit(1)
        )
        asset = result.scalar_one_or_none()
        if not asset:
            result = await self.db.execute(
                select(KnowledgeAsset)
                .where(
                    KnowledgeAsset.tenant_id == self.tenant_id,
                    KnowledgeAsset.is_active.is_(True),
                    KnowledgeAsset.folder_category == "identity",
                    KnowledgeAsset.company_key == company_key,
                )
                .order_by(KnowledgeAsset.synced_at.desc().nullslast())
                .limit(5)
            )
            for row in result.scalars():
                if "logo" in (row.filename or "").lower() or row.document_type == "logo":
                    asset = row
                    break
        if not asset:
            fallback = self._scan_logo_files(company_key)
            if fallback:
                return fallback
            return BrandingAssetStatus(
                asset_type="logo",
                status="falta",
                label="Logo corporativo",
                source="repository",
                filename="logo_justech.png (IDENTIDAD_CORPORATIVA/JUSTECH · document_type=logo)",
            )
        local_path = None
        try:
            root = Path(self.source.root_path())
            candidate = root / asset.relative_path
            if candidate.is_file():
                local_path = candidate
        except Exception:
            local_path = None
        status = "detectado" if local_path and local_path.is_file() else "requiere_actualizacion"
        meta = asset.metadata_ or {}
        return BrandingAssetStatus(
            asset_type="logo",
            status=status,
            label=asset.title or asset.filename,
            source="repository",
            view_url=meta.get("web_url"),
            local_path=local_path if local_path and local_path.is_file() else None,
            filename=asset.filename,
        )

    def _scan_logo_files(self, company_key: str) -> BrandingAssetStatus | None:
        """Fallback: buscar logo en repositorio de conocimiento e identidad corporativa."""
        from app.config import settings

        patterns = ("logo", company_key.replace("_", ""), company_key)
        search_roots: list[Path] = []
        try:
            search_roots.append(Path(self.source.root_path()))
        except Exception:
            pass
        search_roots.append(Path(settings.knowledge_source_path))
        search_roots.append(
            Path(settings.expediente_storage_path) / str(self.tenant_id) / "corporate_identity"
        )
        image_ext = {".png", ".jpg", ".jpeg", ".webp", ".svg"}
        candidates: list[Path] = []
        for root in search_roots:
            if not root.is_dir():
                continue
            for path in root.rglob("*"):
                if not path.is_file() or path.suffix.lower() not in image_ext:
                    continue
                name = path.name.lower()
                if "logo" in name or any(p in name for p in patterns if p):
                    candidates.append(path)
        if not candidates:
            return None
        candidates.sort(key=lambda p: (
            0 if "logo" in p.name.lower() else 1,
            -p.stat().st_mtime,
        ))
        best = candidates[0]
        return BrandingAssetStatus(
            asset_type="logo",
            status="detectado",
            label=best.name,
            source="repository_scan",
            local_path=best,
            filename=best.name,
        )

    @staticmethod
    def read_image_bytes(asset: BrandingAssetStatus) -> bytes | None:
        if asset.local_path and asset.local_path.is_file():
            try:
                return asset.local_path.read_bytes()
            except OSError:
                return None
        return None
