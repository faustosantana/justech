"""Fuente única de verdad — perfil empresarial + documentos legales corporativos.

Alinea Perfil Empresarial (Documents Hub) con el mismo repositorio que usa
DGCPSmartMatchingEngine para checklist, Hermes y autollenado.
"""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document import Document
from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.services.company_normalization_service import canonical_label, normalize_company_key
from app.services.company_profile_sync_service import CompanyProfileSyncService
from app.services.dgcp_compliance_engine import OFFICIAL_KNOWLEDGE_FOLDERS
from app.services.dgcp_document_matcher import DOC_TYPE_ALIASES
from app.services.document_requirement_validator import (
    TYPE_ALIASES,
    rank_knowledge_asset_for_requirement,
    type_matches_requirement,
    validate_asset_for_requirement,
)
from app.services.document_validity_analyzer import DocumentValidityAnalyzer

RPE_NUMBER_PENDING_LABEL = "Documento detectado, número pendiente"

_RPE_NUMBER_PATTERNS = (
    re.compile(r"\bRPE[\s:.\-]*(\d{4,})\b", re.I),
    re.compile(r"(?:registro\s+)?proveedor\s+(?:del\s+)?estado[\s:.\-]*(\d{4,})", re.I),
    re.compile(r"(?:n[°º]|no\.?|numero|número)\s*[:.\-]?\s*(\d{4,})", re.I),
)

# Campo de perfil → clave de requisito DGCP (misma que smart matcher)
FIELD_TO_REQUIREMENT: dict[str, str] = {
    "dgii": "certificacion_dgii",
    "tss": "certificacion_tss",
    "mipyme": "certificacion_mipyme",
    "registro_mercantil": "registro_mercantil",
    "proveedor_estado": "rpe",
    "certificacion_bancaria": "certificacion_bancaria",
    "poderes": "poderes",
    "acta_asamblea": "acta_asamblea",
    "estatutos": "estatutos",
    "cedula_representante": "cedula_representante",
}

# document_type crudo → field_key canónico del perfil
_RAW_TYPE_TO_FIELD: dict[str, str] = {}
for field_key, req_key in FIELD_TO_REQUIREMENT.items():
    _RAW_TYPE_TO_FIELD[field_key] = field_key
    _RAW_TYPE_TO_FIELD[req_key] = field_key
for aliases in TYPE_ALIASES.values():
    canonical = None
    for alias in aliases:
        if alias in FIELD_TO_REQUIREMENT:
            canonical = alias
            break
        if alias in _RAW_TYPE_TO_FIELD:
            canonical = _RAW_TYPE_TO_FIELD[alias]
            break
    if canonical:
        for alias in aliases:
            _RAW_TYPE_TO_FIELD[alias] = canonical
for req_key, aliases in DOC_TYPE_ALIASES.items():
    field = FIELD_TO_REQUIREMENT.get(req_key, req_key)
    _RAW_TYPE_TO_FIELD[req_key] = field
    for alias in aliases:
        _RAW_TYPE_TO_FIELD[alias.replace(" ", "_")] = field


@dataclass
class ResolvedCorporateDocument:
    field_key: str
    document_name: str | None
    knowledge_asset_id: str | None
    document_id: str | None
    match_source: str | None
    unified_status: str  # missing | detected | validated | expired | pending_analysis
    badge: str
    vigency_status: str | None
    relative_path: str | None
    web_url: str | None


class CorporateRepositoryUnifiedService:
    """Resuelve perfil y documentos corporativos con las mismas reglas que DGCP analyze."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, *, company_key: str):
        self.db = db
        self.tenant_id = tenant_id
        self.company_key = normalize_company_key(company_key) or company_key
        self.validity_analyzer = DocumentValidityAnalyzer()

    @staticmethod
    def static_profile(company_key: str) -> dict[str, str]:
        path = Path(__file__).resolve().parent.parent / "data" / "company_profiles.json"
        if not path.is_file():
            return {}
        data = json.loads(path.read_text(encoding="utf-8"))
        key = normalize_company_key(company_key) or company_key.lower().replace(" ", "_")
        prof = dict(data.get(key) or {})
        if not prof.get("razon_social"):
            prof["razon_social"] = canonical_label(key)
        return {k: str(v) for k, v in prof.items() if v}

    def merge_profile_text(self, profile: LicitadorCompanyProfile) -> dict[str, Any]:
        """DB → raw_json normalizado → company_profiles.json (misma cascada que autollenado)."""
        normalized = CompanyProfileSyncService._normalize_json(profile.raw_json or {})
        for col in (
            "razon_social",
            "nombre_comercial",
            "rnc",
            "direccion",
            "telefono",
            "correo",
            "representante_legal",
            "cedula_representante",
            "cargo_representante",
            "responsable_legal",
            "responsable_financiero",
            "responsable_licitaciones",
        ):
            val = getattr(profile, col, None)
            if val and str(val).strip():
                normalized[col] = str(val).strip()

        static = self.static_profile(profile.company_key)
        for key, val in static.items():
            if not normalized.get(key) or not str(normalized.get(key)).strip():
                normalized[key] = val

        if not normalized.get("razon_social"):
            normalized["razon_social"] = canonical_label(profile.company_key)

        # RPE puede vivir en raw_json o static
        if not normalized.get("proveedor_estado") and not normalized.get("rpe"):
            rpe = (profile.raw_json or {}).get("rpe") or (profile.raw_json or {}).get("proveedor_estado")
            if rpe:
                normalized["proveedor_estado"] = str(rpe)
                normalized["rpe"] = str(rpe)

        return normalized

    @staticmethod
    def extract_rpe_number(text: str | None) -> str | None:
        if not text or not str(text).strip():
            return None
        for pattern in _RPE_NUMBER_PATTERNS:
            match = pattern.search(str(text))
            if match:
                return match.group(1).strip()
        return None

    @staticmethod
    def display_document_name(asset: KnowledgeAsset) -> str:
        return (asset.filename or asset.title or "").strip()

    async def enrich_profile_from_documents(
        self,
        profile: LicitadorCompanyProfile,
        *,
        legal_docs: dict[str, ResolvedCorporateDocument] | None = None,
    ) -> dict[str, Any]:
        """Fusiona texto de perfil + número RPE desde documento detectado."""
        normalized = self.merge_profile_text(profile)
        docs = legal_docs or await self.resolve_legal_documents()
        rpe_doc = docs.get("proveedor_estado")
        if normalized.get("proveedor_estado") or normalized.get("rpe"):
            return normalized
        if not rpe_doc or rpe_doc.unified_status == "missing":
            return normalized

        normalized["rpe_document_detected"] = True
        if rpe_doc.knowledge_asset_id:
            asset = (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.id == uuid.UUID(rpe_doc.knowledge_asset_id),
                        KnowledgeAsset.tenant_id == self.tenant_id,
                    )
                )
            ).scalar_one_or_none()
            if asset:
                number = self.extract_rpe_number(asset.extracted_text)
                if number:
                    normalized["proveedor_estado"] = number
                    normalized["rpe"] = number
                    return normalized
        normalized["rpe_display"] = RPE_NUMBER_PENDING_LABEL
        return normalized

    @staticmethod
    def resolve_rpe_display(normalized: dict[str, Any]) -> str | None:
        return (
            normalized.get("proveedor_estado")
            or normalized.get("rpe")
            or normalized.get("rpe_display")
        )

    @staticmethod
    def canonical_field_for_type(document_type: str | None) -> str | None:
        if not document_type:
            return None
        key = document_type.lower().strip().replace(" ", "_")
        return _RAW_TYPE_TO_FIELD.get(key)

    async def load_knowledge_assets(self) -> list[KnowledgeAsset]:
        result = await self.db.execute(
            select(KnowledgeAsset).where(
                KnowledgeAsset.tenant_id == self.tenant_id,
                KnowledgeAsset.is_active.is_(True),
                KnowledgeAsset.folder_category.in_(tuple(OFFICIAL_KNOWLEDGE_FOLDERS)),
            )
        )
        assets = list(result.scalars().all())
        label = canonical_label(self.company_key).upper()
        scoped: list[KnowledgeAsset] = []
        for asset in assets:
            ck = (asset.company_key or "").lower().replace(" ", "_")
            path = (asset.relative_path or "").upper()
            if ck == self.company_key or label in path or self.company_key.upper() in path:
                scoped.append(asset)
        return scoped if scoped else assets

    async def load_documents(self) -> list[Document]:
        result = await self.db.execute(
            select(Document).where(
                Document.tenant_id == self.tenant_id,
                Document.is_active.is_(True),
                ~Document.title.contains(" — "),
            )
        )
        return list(result.scalars().all())

    def _score_asset_for_field(self, field_key: str, asset: KnowledgeAsset) -> float:
        req_key = FIELD_TO_REQUIREMENT.get(field_key, field_key)
        score = 0.0
        fn = (asset.filename or "").lower().replace("_", " ")
        tit = (asset.title or "").lower().replace("_", " ")
        req_phrase = req_key.replace("_", " ")

        if req_phrase in fn:
            score += 100.0
        if req_phrase in tit:
            score += 40.0
        if type_matches_requirement(req_key, asset.document_type):
            score += 30.0
        if (asset.company_key or "").lower().replace(" ", "_") == self.company_key:
            score += 20.0
        if field_key == "registro_mercantil" and any(k in tit for k in ("rpe", "proveedor del estado", "proveedor estado")):
            score -= 80.0
        if field_key == "proveedor_estado" and "registro mercantil" in fn and "rpe" not in fn:
            score -= 80.0
        return score

    def _best_asset_for_field(
        self,
        field_key: str,
        assets: list[KnowledgeAsset],
    ) -> KnowledgeAsset | None:
        req_key = FIELD_TO_REQUIREMENT.get(field_key, field_key)
        candidates: list[KnowledgeAsset] = []
        for asset in assets:
            vr = validate_asset_for_requirement(
                req_key,
                filename=asset.filename,
                title=asset.title,
                document_type=asset.document_type,
                asset=asset,
                check_vigency=self.validity_analyzer.requires_vigency_check(req_key),
            )
            if vr.ok:
                candidates.append(asset)

        if not candidates:
            return None

        company_matches = [
            a for a in candidates if (a.company_key or "").lower().replace(" ", "_") == self.company_key
        ]
        if company_matches:
            candidates = company_matches

        if self.validity_analyzer.requires_vigency_check(req_key):
            candidates.sort(
                key=lambda a: rank_knowledge_asset_for_requirement(req_key, a),
                reverse=True,
            )
        else:
            candidates.sort(key=lambda a: (a.filename or "", str(a.id)))
        return candidates[0]

    def _best_document_for_field(
        self,
        field_key: str,
        documents: list[Document],
    ) -> Document | None:
        req_key = FIELD_TO_REQUIREMENT.get(field_key, field_key)
        best: Document | None = None
        best_score = 0.0
        for doc in documents:
            vr = validate_asset_for_requirement(
                req_key,
                filename=doc.filename,
                title=doc.title,
                document_type=(doc.category or "").lower() or None,
                check_vigency=False,
            )
            if not vr.ok:
                continue
            score = 90.0 if req_key in (doc.category or "").lower() else 80.0
            if score > best_score:
                best_score = score
                best = doc
        return best

    def _unified_status_from_asset(
        self,
        field_key: str,
        asset: KnowledgeAsset | None,
        *,
        document: Document | None = None,
    ) -> tuple[str, str, str | None]:
        """Returns (unified_status, badge, vigency_status)."""
        if not asset and not document:
            return "missing", "Falta", None

        req_key = FIELD_TO_REQUIREMENT.get(field_key, field_key)
        vigency = None
        if asset:
            vigency = asset.vigency_status
            name = asset.title or asset.filename
            has_text = bool((asset.extracted_text or "").strip())
            analyzed = bool(asset.analyzed_at)
        else:
            vigency = None
            name = document.title if document else None
            has_text = bool((document.extracted_text or "").strip()) if document else False
            analyzed = bool(document and document.extracted_text)

        if vigency in ("vencido",):
            return "expired", "Documento vencido", vigency

        if vigency in ("vigente", "validado"):
            return "validated", "Documento validado", vigency

        if has_text and analyzed and vigency not in ("vencido", "proximo_a_vencer"):
            return "validated", "Documento validado", vigency or "vigente"

        if not has_text and self.validity_analyzer.requires_vigency_check(req_key):
            return "pending_analysis", "Pendiente análisis", vigency or "sin_fecha"

        if vigency in ("sin_fecha", "proximo_a_vencer", None) and (asset or document):
            return "detected", "Documento detectado", vigency

        return "detected", "Documento detectado", vigency

    async def resolve_legal_documents(self) -> dict[str, ResolvedCorporateDocument]:
        assets = await self.load_knowledge_assets()
        documents = await self.load_documents()
        resolved: dict[str, ResolvedCorporateDocument] = {}

        legal_fields = (
            "registro_mercantil",
            "dgii",
            "tss",
            "mipyme",
            "certificacion_bancaria",
            "poderes",
            "acta_asamblea",
            "estatutos",
            "proveedor_estado",
            "cedula_representante",
        )

        used_asset_ids: set[str] = set()
        available_assets = list(assets)

        for field_key in legal_fields:
            pool = [a for a in available_assets if str(a.id) not in used_asset_ids]
            asset = self._best_asset_for_field(field_key, pool)
            doc = None if asset else self._best_document_for_field(field_key, documents)

            unified_status, badge, vigency = self._unified_status_from_asset(
                field_key, asset, document=doc
            )

            if asset:
                used_asset_ids.add(str(asset.id))
                meta = asset.metadata_ or {}
                resolved[field_key] = ResolvedCorporateDocument(
                    field_key=field_key,
                    document_name=self.display_document_name(asset),
                    knowledge_asset_id=str(asset.id),
                    document_id=None,
                    match_source="knowledge_repository",
                    unified_status=unified_status,
                    badge=badge,
                    vigency_status=vigency,
                    relative_path=asset.relative_path,
                    web_url=meta.get("web_url"),
                )
            elif doc:
                resolved[field_key] = ResolvedCorporateDocument(
                    field_key=field_key,
                    document_name=doc.title,
                    knowledge_asset_id=None,
                    document_id=str(doc.id),
                    match_source="document_repository",
                    unified_status=unified_status,
                    badge=badge,
                    vigency_status=vigency,
                    relative_path=None,
                    web_url=None,
                )
            else:
                resolved[field_key] = ResolvedCorporateDocument(
                    field_key=field_key,
                    document_name=None,
                    knowledge_asset_id=None,
                    document_id=None,
                    match_source=None,
                    unified_status="missing",
                    badge="Falta",
                    vigency_status=None,
                    relative_path=None,
                    web_url=None,
                )

        return resolved

    def completeness_from_fields(
        self,
        text_fields: dict[str, Any],
        documents: dict[str, ResolvedCorporateDocument],
        *,
        profile_field_keys: list[str],
        document_field_keys: list[str],
    ) -> tuple[int, int, int]:
        """Returns (score_pct, complete_count, total_count)."""
        total = len(profile_field_keys) + len(document_field_keys)
        if total == 0:
            return 0, 0, 0
        complete = 0

        for key in profile_field_keys:
            val = text_fields.get(key)
            if val and str(val).strip():
                complete += 1

        for key in document_field_keys:
            doc = documents.get(key)
            if doc and doc.unified_status in ("detected", "validated", "pending_analysis"):
                complete += 1

        score = round(100 * complete / total)
        return score, complete, total
