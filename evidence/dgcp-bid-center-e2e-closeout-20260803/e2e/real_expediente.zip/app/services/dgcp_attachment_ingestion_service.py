"""Ingesta de adjuntos y documentos del proceso DGCP (Fase 7.3)."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.dgcp_process_document import DGCPProcessDocument
from app.services.dgcp_portal_document_service import DGCPPortalDocumentService, PortalDocumentRef
from app.services.dgcp_process_document_classifier import classify_process_document
from app.services.dgcp_process_storage_service import DGCPProcessStorageService

logger = logging.getLogger(__name__)

# Tipos de fuente del repositorio de proceso (nunca documentos corporativos indexados).
PROCESS_SOURCE_TYPES = frozenset({"portal", "dgcp_api", "portal_text", "process_file", "reference"})
REAL_DOCUMENT_SOURCE_TYPES = frozenset({"dgcp_api", "portal_text", "process_file", "reference"})


class DGCPAttachmentIngestionService:
    SUPPORTED_FORMATS = {".pdf", ".docx", ".doc", ".xlsx", ".xls", ".csv", ".txt"}

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.storage = DGCPProcessStorageService(tenant_id)
        self.portal = DGCPPortalDocumentService()

    async def ingest(self, opportunity: DGCPOpportunity) -> list[dict]:
        if not settings.dgcp_attachment_ingestion_enabled:
            return []

        existing = await self.load_process_documents(opportunity.id)
        preserved = [
            d for d in existing
            if (d.metadata_ or {}).get("preserve_on_ingest") or (d.metadata_ or {}).get("manual_upload")
        ]
        preserved_ids = [d.id for d in preserved]

        delete_stmt = delete(DGCPProcessDocument).where(
            DGCPProcessDocument.tenant_id == self.tenant_id,
            DGCPProcessDocument.opportunity_id == opportunity.id,
        )
        if preserved_ids:
            delete_stmt = delete_stmt.where(DGCPProcessDocument.id.notin_(preserved_ids))
        await self.db.execute(delete_stmt)
        await self.db.flush()

        discovered: list[dict] = [self._summary(d) for d in preserved]
        seen_keys = {self._dedupe_key_from_summary(d) for d in discovered}

        await self._ensure_portal_link(opportunity, seen_keys)
        portal_stats = await self._ingest_portal_documents(opportunity, seen_keys)
        logger.info(
            "DGCP portal ingest %s: discovered=%s downloaded=%s",
            opportunity.code,
            portal_stats.get("discovered", 0),
            portal_stats.get("downloaded", 0),
        )

        for item in self._discover_from_payload(opportunity):
            key = self._dedupe_key_from_item(item)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            doc = await self._register_reference(opportunity, item)
            discovered.append(self._summary(doc))

        await self.db.commit()
        all_docs = await self.load_process_documents(opportunity.id)
        return [self._summary(d) for d in all_docs if d.source_type in REAL_DOCUMENT_SOURCE_TYPES] + [
            self._summary(d) for d in all_docs if d.source_type == "portal"
        ]

    async def refresh_portal_documents(self, opportunity: DGCPOpportunity) -> dict[str, Any]:
        """Re-busca y descarga documentos publicados en el portal DGCP."""
        if not settings.dgcp_attachment_ingestion_enabled:
            return {"discovered": 0, "downloaded": 0, "items": []}

        existing = await self.load_process_documents(opportunity.id)
        for doc in existing:
            meta = doc.metadata_ or {}
            if meta.get("manual_upload") or meta.get("preserve_on_ingest"):
                continue
            if doc.source_type in ("process_file", "dgcp_api") and meta.get("portal_document_id"):
                await self.db.delete(doc)
        await self.db.flush()

        seen_keys = {self._dedupe_key_from_doc(d) for d in await self.load_process_documents(opportunity.id)}
        await self._ensure_portal_link(opportunity, seen_keys)
        stats = await self._ingest_portal_documents(opportunity, seen_keys, skip_existing=False)
        await self.db.commit()
        docs = await self.load_process_documents(opportunity.id)
        stats["items"] = self.build_documents_response(docs)
        return stats

    async def upload_process_document(
        self,
        opportunity: DGCPOpportunity,
        *,
        filename: str,
        content: bytes,
        mime_type: str | None = None,
        doc_role: str | None = None,
    ) -> DGCPProcessDocument:
        """Registra un documento del proceso (p. ej. pliego PDF) con extracción de texto."""
        from app.services.document_extraction_service import DocumentExtractionService

        role, priority = classify_process_document(filename, source_url=None)
        if doc_role:
            role = doc_role
        if role == "general" and "pliego" in filename.lower():
            role = "pliego"
        if role in ("pliego", "tdr", "bases", "especificaciones"):
            priority = "alta"

        ext = Path(filename).suffix.lower() or ".pdf"
        stem = self.storage.slugify(Path(filename).stem)
        safe_name = f"{role}_{stem}{ext}" if not stem.startswith(role) else f"{stem}{ext}"

        self.storage.write_bytes(opportunity.code, safe_name, content)

        extracted, read_error = self._extract_text(content, filename=filename, mime_type=mime_type)

        metadata: dict[str, Any] = {
            "storage_filename": safe_name,
            "storage_uri": self.storage.relative_uri(opportunity.code, safe_name),
            "file_size_bytes": len(content),
            "manual_upload": True,
            "preserve_on_ingest": True,
            "scope": "dgcp_process",
            "original_filename": filename,
            "source_label": "Upload manual",
        }
        if read_error:
            metadata["read_error"] = read_error

        doc = DGCPProcessDocument(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            title=Path(filename).stem.replace("_", " ").strip() or "Documento del proceso",
            source_type="process_file",
            doc_role=role,
            priority=priority,
            format=ext.lstrip(".") or "pdf",
            ingestion_status="analyzed" if extracted else "error",
            extracted_text=extracted,
            metadata_=metadata,
            analyzed_at=datetime.now(timezone.utc) if extracted else None,
        )
        self.db.add(doc)
        await self.db.flush()
        return doc

    async def reingest_process_document(
        self,
        opportunity: DGCPOpportunity,
        process_document: DGCPProcessDocument,
    ) -> DGCPProcessDocument:
        meta = process_document.metadata_ or {}
        filename = meta.get("storage_filename") or meta.get("original_filename")
        if not filename:
            raise ValueError("Documento sin archivo almacenado para reingestar")
        content = self.storage.read_bytes(opportunity.code, filename)
        original = meta.get("original_filename") or filename
        extracted, read_error = self._extract_text(content, filename=original)
        new_meta = dict(meta)
        if read_error:
            new_meta["read_error"] = read_error
        else:
            new_meta.pop("read_error", None)
        process_document.extracted_text = extracted
        process_document.ingestion_status = "analyzed" if extracted else "error"
        process_document.analyzed_at = datetime.now(timezone.utc) if extracted else None
        process_document.metadata_ = new_meta
        await self.db.flush()
        return process_document

    async def update_document_role(
        self,
        process_document: DGCPProcessDocument,
        doc_role: str,
    ) -> DGCPProcessDocument:
        allowed = {
            "pliego", "tdr", "formulario", "anexo", "enmienda", "circular", "adenda",
            "general", "ficha_tecnica", "especificaciones", "invitacion",
        }
        role = doc_role.strip().lower()
        if role not in allowed:
            raise ValueError(f"Rol de documento no válido: {doc_role}")
        process_document.doc_role = role
        process_document.priority = "alta" if role in ("pliego", "tdr", "especificaciones") else process_document.priority
        meta = dict(process_document.metadata_ or {})
        meta["role_overridden"] = True
        process_document.metadata_ = meta
        await self.db.flush()
        return process_document

    async def _ingest_portal_documents(
        self,
        opportunity: DGCPOpportunity,
        seen_keys: set[str],
        *,
        skip_existing: bool = False,
    ) -> dict[str, int]:
        stats = {"discovered": 0, "downloaded": 0}
        if not settings.dgcp_portal_document_fetch_enabled or not opportunity.source_url:
            return stats

        refs = await self.portal.discover_from_portal(opportunity.source_url, process_code=opportunity.code)
        stats["discovered"] = len(refs)
        existing_portal_ids = set()
        if skip_existing:
            for doc in await self.load_process_documents(opportunity.id):
                pid = (doc.metadata_ or {}).get("portal_document_id")
                if pid:
                    existing_portal_ids.add(str(pid))

        for ref in refs:
            if skip_existing and ref.portal_document_id in existing_portal_ids:
                continue
            key = f"portal:{ref.portal_document_id}"
            if key in seen_keys:
                continue
            seen_keys.add(key)
            downloaded = await self.portal.download(ref)
            if downloaded:
                content, mime = downloaded
                doc = await self._register_portal_file(opportunity, ref, content, mime_type=mime)
                stats["downloaded"] += 1
            else:
                doc = await self._register_portal_reference(opportunity, ref)
            seen_keys.add(self._dedupe_key_from_doc(doc))
        return stats

    async def _ensure_portal_link(self, opportunity: DGCPOpportunity, seen_keys: set[str]) -> None:
        if not opportunity.source_url:
            return
        key = f"portal-link:{opportunity.code}"
        if key in seen_keys:
            return
        portal_url = self.portal.normalize_portal_url(opportunity.source_url) or opportunity.source_url
        result = await self.db.execute(
            select(DGCPProcessDocument).where(
                DGCPProcessDocument.tenant_id == self.tenant_id,
                DGCPProcessDocument.opportunity_id == opportunity.id,
                DGCPProcessDocument.source_type == "portal",
            )
        )
        existing = result.scalar_one_or_none()
        if existing:
            existing.source_url = portal_url
            existing.title = f"Portal DGCP — {opportunity.code}"
            await self.db.flush()
            seen_keys.add(key)
            return
        doc = DGCPProcessDocument(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            title=f"Portal DGCP — {opportunity.code}",
            source_url=portal_url,
            source_type="portal",
            doc_role="portal",
            priority="baja",
            format="link",
            ingestion_status="registered",
            metadata_={"is_portal_link": True, "scope": "dgcp_process"},
        )
        self.db.add(doc)
        await self.db.flush()
        seen_keys.add(key)

    async def _register_portal_file(
        self,
        opportunity: DGCPOpportunity,
        ref: PortalDocumentRef,
        content: bytes,
        *,
        mime_type: str | None = None,
    ) -> DGCPProcessDocument:
        ext = f".{ref.format}" if ref.format else ".pdf"
        stem = self.storage.slugify(Path(ref.filename).stem)
        safe_name = f"{ref.doc_role}_{stem}{ext}"
        self.storage.write_bytes(opportunity.code, safe_name, content)
        extracted, read_error = self._extract_text(content, filename=ref.filename, mime_type=mime_type)
        metadata = {
            **DGCPPortalDocumentService.discovery_meta(ref),
            "storage_filename": safe_name,
            "storage_uri": self.storage.relative_uri(opportunity.code, safe_name),
            "file_size_bytes": len(content),
            "source_label": "DGCP Portal",
            "scope": "dgcp_process",
        }
        if read_error:
            metadata["read_error"] = read_error
        doc = DGCPProcessDocument(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            title=ref.title,
            source_url=ref.retrieve_url,
            source_type="process_file",
            doc_role=ref.doc_role,
            priority=ref.priority,
            format=ref.format or "pdf",
            ingestion_status="analyzed" if extracted else "error",
            extracted_text=extracted,
            metadata_=metadata,
            analyzed_at=datetime.now(timezone.utc) if extracted else None,
        )
        self.db.add(doc)
        await self.db.flush()
        return doc

    async def _register_portal_reference(
        self,
        opportunity: DGCPOpportunity,
        ref: PortalDocumentRef,
    ) -> DGCPProcessDocument:
        metadata = {
            **DGCPPortalDocumentService.discovery_meta(ref),
            "source_label": "DGCP Portal (referencia)",
            "scope": "dgcp_process",
        }
        doc = DGCPProcessDocument(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            title=ref.title,
            source_url=ref.retrieve_url,
            source_type="dgcp_api",
            doc_role=ref.doc_role,
            priority=ref.priority,
            format=ref.format or "pdf",
            ingestion_status="registered",
            metadata_=metadata,
        )
        self.db.add(doc)
        await self.db.flush()
        return doc

    def _discover_from_payload(self, opportunity: DGCPOpportunity) -> list[dict[str, Any]]:
        items: list[dict[str, Any]] = []
        payload = opportunity.raw_payload or opportunity.full_info or {}
        if not isinstance(payload, dict):
            return items

        for key in ("documentos", "pliego", "anexos", "adjuntos", "archivos", "requisitos"):
            val = payload.get(key) or (payload.get("extra") or {}).get(key)
            if isinstance(val, list):
                for entry in val:
                    if isinstance(entry, dict):
                        title = str(entry.get("nombre") or entry.get("title") or entry.get("descripcion") or "Documento")
                        url = entry.get("url") or entry.get("link")
                        role, priority = classify_process_document(title, source_url=str(url) if url else None)
                        items.append({
                            "title": title,
                            "source_url": url,
                            "source_type": "dgcp_api",
                            "doc_role": role,
                            "priority": priority,
                            "format": "link",
                        })
                    elif isinstance(entry, str):
                        role, priority = classify_process_document(entry)
                        items.append({
                            "title": entry,
                            "source_type": "dgcp_api",
                            "doc_role": role,
                            "priority": priority,
                            "format": "reference",
                        })
            elif isinstance(val, str) and val.strip():
                role, priority = classify_process_document(val)
                items.append({
                    "title": val[:200],
                    "source_type": "dgcp_api",
                    "doc_role": role,
                    "priority": priority,
                    "format": "text",
                    "extracted_text": val,
                })

        desc = opportunity.description or ""
        if desc.strip() and len(desc) > 120:
            items.append({
                "title": f"Descripción del proceso — {opportunity.code}",
                "source_type": "portal_text",
                "doc_role": "invitacion",
                "priority": "media",
                "format": "text",
                "extracted_text": desc,
            })

        return items

    async def _register_reference(self, opportunity: DGCPOpportunity, item: dict[str, Any]) -> DGCPProcessDocument:
        role = item.get("doc_role", "general")
        priority = item.get("priority", "media")
        extracted_text = item.get("extracted_text")
        storage_filename = None
        source_type = item.get("source_type", "reference")

        if extracted_text:
            slug = self.storage.slugify(item["title"])
            storage_filename = self.storage.write_text(
                opportunity.code,
                f"{slug}.txt",
                extracted_text[:500_000],
            )
            source_type = "process_file"

        metadata: dict[str, Any] = {
            "discovery": item.get("source_type"),
            "source_label": "API DGCP",
            "scope": "dgcp_process",
        }
        if storage_filename:
            metadata["storage_filename"] = storage_filename
            metadata["storage_uri"] = self.storage.relative_uri(opportunity.code, storage_filename)

        doc = DGCPProcessDocument(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            title=item["title"],
            source_url=item.get("source_url"),
            source_type=source_type,
            doc_role=role,
            priority=priority,
            format=item.get("format", "reference"),
            ingestion_status="analyzed" if extracted_text else "registered",
            extracted_text=extracted_text[:100000] if extracted_text else None,
            metadata_=metadata,
            analyzed_at=datetime.now(timezone.utc) if extracted_text else None,
        )
        self.db.add(doc)
        await self.db.flush()
        return doc

    async def load_process_documents(self, opportunity_id: uuid.UUID) -> list[DGCPProcessDocument]:
        result = await self.db.execute(
            select(DGCPProcessDocument).where(
                DGCPProcessDocument.tenant_id == self.tenant_id,
                DGCPProcessDocument.opportunity_id == opportunity_id,
            ).order_by(DGCPProcessDocument.priority, DGCPProcessDocument.created_at)
        )
        return list(result.scalars().all())

    def build_documents_response(self, docs: list[DGCPProcessDocument]) -> dict[str, Any]:
        portal_doc = next((d for d in docs if d.source_type == "portal"), None)
        real_docs = [d for d in docs if d.source_type in REAL_DOCUMENT_SOURCE_TYPES]
        unique: list[DGCPProcessDocument] = []
        seen: set[str] = set()
        for doc in real_docs:
            key = self._dedupe_key_from_doc(doc)
            if key in seen:
                continue
            seen.add(key)
            unique.append(doc)
        return {
            "items": [self._summary(d) for d in unique],
            "total": len(unique),
            "portal": self._summary(portal_doc) if portal_doc else None,
        }

    async def build_extraction_corpus(self, opportunity_id: uuid.UUID) -> tuple[str, list[DGCPProcessDocument]]:
        docs = await self.load_process_documents(opportunity_id)
        priority_order = {"alta": 0, "media": 1, "baja": 2}
        usable = [
            d for d in docs
            if d.extracted_text and d.priority in ("alta", "media") and d.doc_role not in ("imagen", "portal")
        ]
        usable.sort(key=lambda d: (priority_order.get(d.priority, 9), d.title))
        if not usable:
            usable = [d for d in docs if d.extracted_text and d.doc_role != "portal"]
        parts = [f"=== {d.title} ({d.doc_role}) ===\n{d.extracted_text}" for d in usable]
        return "\n\n".join(parts), usable

    async def read_process_file(
        self,
        opportunity: DGCPOpportunity,
        process_document: DGCPProcessDocument,
    ) -> tuple[bytes, str]:
        meta = process_document.metadata_ or {}
        filename = meta.get("storage_filename")
        if not filename:
            raise FileNotFoundError("Documento de proceso sin archivo almacenado")
        content = self.storage.read_bytes(opportunity.code, filename)
        ext = Path(str(filename)).suffix.lower()
        mime_map = {".pdf": "application/pdf", ".txt": "text/plain", ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"}
        mime = mime_map.get(ext, "application/octet-stream")
        return content, mime

    @staticmethod
    def _extract_text(content: bytes, *, filename: str, mime_type: str | None = None) -> tuple[str | None, str | None]:
        from app.services.document_extraction_service import DocumentExtractionService

        try:
            result = DocumentExtractionService().extract(content, filename=filename, mime_type=mime_type)
            if result.text.strip():
                return result.text.strip()[:100_000], None
            return None, "No se extrajo texto del archivo"
        except Exception as exc:
            return None, str(exc)[:500]

    @staticmethod
    def _dedupe_key_from_doc(doc: DGCPProcessDocument) -> str:
        meta = doc.metadata_ or {}
        if meta.get("portal_document_id"):
            return f"portal:{meta['portal_document_id']}"
        if meta.get("storage_uri"):
            return f"uri:{meta['storage_uri']}"
        return f"{doc.doc_role}:{doc.title}:{doc.format}".lower()

    @staticmethod
    def _dedupe_key_from_summary(item: dict[str, Any]) -> str:
        if item.get("portal_document_id"):
            return f"portal:{item['portal_document_id']}"
        if item.get("storage_uri"):
            return f"uri:{item['storage_uri']}"
        return f"{item.get('doc_role')}:{item.get('title')}:{item.get('format')}".lower()

    @staticmethod
    def _dedupe_key_from_item(item: dict[str, Any]) -> str:
        return f"{item.get('doc_role')}:{item.get('title')}:{item.get('format')}".lower()

    @staticmethod
    def _summary(doc: DGCPProcessDocument) -> dict:
        display = DGCPAttachmentIngestionService._display_status(doc)
        meta = doc.metadata_ or {}
        is_portal_link = doc.source_type == "portal" or meta.get("is_portal_link")
        return {
            "id": str(doc.id),
            "title": doc.title,
            "doc_role": doc.doc_role,
            "priority": doc.priority,
            "format": doc.format,
            "source_type": doc.source_type,
            "source_url": doc.source_url,
            "source_label": meta.get("source_label") or DGCPAttachmentIngestionService._source_label(doc),
            "ingestion_status": doc.ingestion_status,
            "display_status": display,
            "text_extraction_status": display,
            "has_text": bool(doc.extracted_text),
            "is_portal_link": is_portal_link,
            "is_downloadable": bool(meta.get("storage_filename")),
            "document_id": str(doc.document_id) if doc.document_id else None,
            "storage_uri": meta.get("storage_uri"),
            "file_size_bytes": meta.get("file_size_bytes"),
            "portal_document_id": meta.get("portal_document_id"),
            "published_at": doc.created_at.isoformat() if doc.created_at else None,
            "original_filename": meta.get("original_filename"),
        }

    @staticmethod
    def _source_label(doc: DGCPProcessDocument) -> str:
        if doc.source_type == "portal":
            return "Portal DGCP"
        if doc.source_type == "process_file" and (doc.metadata_ or {}).get("manual_upload"):
            return "Upload manual"
        if doc.source_type == "process_file":
            return "DGCP Portal"
        if doc.source_type == "dgcp_api":
            return "API DGCP"
        if doc.source_type == "portal_text":
            return "Descripción portal"
        return "Referencia"

    @staticmethod
    def _display_status(doc: DGCPProcessDocument) -> str:
        meta = doc.metadata_ or {}
        if doc.source_type == "portal":
            return "Enlace externo"
        if meta.get("read_error"):
            return "Error de lectura"
        if doc.ingestion_status == "error":
            return "Error de lectura"
        if doc.extracted_text and doc.doc_role in ("pliego", "tdr", "ficha_tecnica", "especificaciones"):
            return "Requisitos extraídos"
        if doc.extracted_text and doc.ingestion_status == "analyzed":
            return "Texto extraído"
        if doc.source_type == "process_file" and not doc.extracted_text:
            return "Sin texto extraído"
        if doc.source_type == "process_file":
            return "Archivo del proceso"
        if doc.ingestion_status == "registered":
            return "Detectado — pendiente descarga"
        if doc.source_type in ("dgcp_api", "reference") and not doc.extracted_text:
            return "Detectado — pendiente descarga"
        return "Sin contenido relevante"
