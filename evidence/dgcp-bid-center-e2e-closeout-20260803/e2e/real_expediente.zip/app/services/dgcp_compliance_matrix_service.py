"""Matriz de cumplimiento técnico — Fase 6.2C (evidencia obligatoria)."""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from app.config import settings
from app.services.hermes_client import HermesClient

logger = logging.getLogger(__name__)


class DGCPComplianceMatrixService:
    """
    Compara requisito del pliego vs especificaciones del producto.
    Sin evidencia técnica verificable → requiere_revision (nunca cumple).
    """

    def __init__(self, *, client: HermesClient | None = None):
        self.client = client or HermesClient()

    async def build_matrix(
        self,
        requirement: dict[str, Any],
        candidate: dict[str, Any],
        *,
        datasheet_excerpt: str = "",
    ) -> tuple[list[dict[str, Any]], float]:
        specs = list(requirement.get("technical_requirements") or [])
        specs.extend(requirement.get("functional_requirements") or [])
        if not specs:
            specs = [{"text": requirement.get("nombre") or "Requisito general", "confidence": 0.5}]

        if candidate.get("is_technical_source") and settings.dgcp_product_intelligence_hermes_enrich:
            matrix = await self._matrix_via_hermes(requirement, candidate, specs, datasheet_excerpt)
        else:
            matrix = self._matrix_conservative(requirement, candidate, specs)

        pct = self._compliance_pct(matrix)
        return matrix, pct

    async def _matrix_via_hermes(
        self,
        requirement: dict[str, Any],
        candidate: dict[str, Any],
        specs: list[dict],
        datasheet_excerpt: str,
    ) -> list[dict[str, Any]]:
        if not self.client.is_available():
            return self._matrix_conservative(requirement, candidate, specs)
        system_prompt = (
            "Eres un ingeniero de preventa. Compara requisitos del pliego vs especificaciones del producto. "
            "REGLAS ESTRICTAS: "
            "1) Marca 'cumple' SOLO con evidencia de datasheet oficial, página fabricante o documento técnico. "
            "2) Nunca uses Odoo, ventas ni proveedor para cumplimiento. "
            "3) Sin evidencia → 'requiere_revision'. "
            "4) Incluye fragmento, fuente, página cuando exista. "
            "5) Responde SOLO JSON."
        )
        question = json.dumps({
            "task": "compliance_matrix",
            "requirement": {
                "nombre": requirement.get("nombre"),
                "specs": [s.get("text") for s in specs],
            },
            "candidate": {
                "manufacturer": candidate.get("manufacturer"),
                "model": candidate.get("model"),
                "name": candidate.get("name"),
                "datasheet_url": candidate.get("datasheet_url"),
                "datasheet_path": candidate.get("datasheet_path"),
            },
            "datasheet_excerpt": datasheet_excerpt[:6000],
            "output_schema": {
                "compliance_matrix": [{
                    "requisito": "",
                    "valor_requerido": "",
                    "valor_producto": "",
                    "cumple": "requiere_revision",
                    "evidencia": "",
                    "fuente": "",
                    "pagina": "",
                    "fragmento": "",
                    "observacion": "",
                    "confianza": 0.0,
                }],
            },
        }, ensure_ascii=False)
        try:
            raw = await self.client.copilot_turn(system_prompt=system_prompt, question=question)
            if not raw:
                return self._matrix_conservative(requirement, candidate, specs)
            content = raw.get("content") or raw.get("answer") or ""
            parsed = _parse_json(content)
            rows = (parsed or {}).get("compliance_matrix") or []
            if not rows:
                return self._matrix_conservative(requirement, candidate, specs)
            return [self._normalize_row(r, candidate) for r in rows if isinstance(r, dict)]
        except Exception:
            logger.exception("Hermes compliance matrix failed")
            return self._matrix_conservative(requirement, candidate, specs)

    def _matrix_conservative(
        self,
        requirement: dict[str, Any],
        candidate: dict[str, Any],
        specs: list[dict],
    ) -> list[dict[str, Any]]:
        """Sin evidencia técnica: todo requiere_revision salvo match literal en datasheet path."""
        product_label = candidate.get("model") or candidate.get("name") or "Producto"
        is_commercial = candidate.get("source") == "comercial" or not candidate.get("is_technical_source")
        rows: list[dict[str, Any]] = []
        for spec in specs:
            req_text = spec.get("text") or ""
            row = {
                "requisito": req_text,
                "valor_requerido": req_text,
                "valor_producto": product_label if not is_commercial else None,
                "cumple": "requiere_revision",
                "evidencia": None,
                "fuente": candidate.get("datasheet_path") or candidate.get("datasheet_url"),
                "pagina": spec.get("page"),
                "fragmento": spec.get("evidence"),
                "observacion": self._observation(is_commercial, candidate),
                "confianza": 0.0 if is_commercial else float(spec.get("confidence") or 0.3),
            }
            if not is_commercial and candidate.get("datasheet_path"):
                row["observacion"] = "Datasheet en repositorio — validar manualmente contra requisito"
                row["confianza"] = 0.4
            rows.append(row)
        return rows

    @staticmethod
    def _observation(is_commercial: bool, candidate: dict) -> str:
        if is_commercial:
            return "Fuente comercial — no válida para cumplimiento técnico"
        if not candidate.get("datasheet_url") and not candidate.get("datasheet_path"):
            return "Sin datasheet oficial indexado — buscar documentación del fabricante"
        return "Validar evidencia en datasheet oficial"

    @staticmethod
    def _normalize_row(raw: dict, candidate: dict) -> dict[str, Any]:
        status = (raw.get("cumple") or "requiere_revision").lower().replace(" ", "_")
        if status not in ("cumple", "cumple_parcial", "no_cumple", "requiere_revision"):
            status = "requiere_revision"
        if candidate.get("source") == "comercial":
            status = "requiere_revision"
        if status == "cumple" and not (raw.get("evidencia") or raw.get("fragmento") or raw.get("fuente")):
            status = "requiere_revision"
        return {
            "requisito": raw.get("requisito") or "",
            "valor_requerido": raw.get("valor_requerido"),
            "valor_producto": raw.get("valor_producto"),
            "cumple": status,
            "evidencia": raw.get("evidencia"),
            "fuente": raw.get("fuente") or candidate.get("datasheet_url") or candidate.get("datasheet_path"),
            "pagina": raw.get("pagina"),
            "fragmento": raw.get("fragmento"),
            "observacion": raw.get("observacion"),
            "confianza": float(raw.get("confianza") or 0.0),
        }

    @staticmethod
    def _compliance_pct(matrix: list[dict[str, Any]]) -> float:
        if not matrix:
            return 0.0
        weights = {"cumple": 1.0, "cumple_parcial": 0.5, "no_cumple": 0.0, "requiere_revision": 0.0}
        total = sum(weights.get(r.get("cumple", "requiere_revision"), 0.0) for r in matrix)
        return round(100.0 * total / len(matrix), 1)


def _parse_json(text: str) -> dict | None:
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
    return None
