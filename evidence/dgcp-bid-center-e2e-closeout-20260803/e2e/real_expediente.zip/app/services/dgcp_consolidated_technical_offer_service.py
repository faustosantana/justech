"""Oferta técnica consolidada — borrador estructurado (Fase 6.3, expediente)."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity


SECTION_ORDER = [
    "Portada",
    "Resumen ejecutivo",
    "Información de la empresa",
    "Experiencia relevante",
    "Formularios requeridos",
    "Matriz de cumplimiento",
    "Fichas técnicas",
    "Certificaciones",
    "Documentación legal",
    "Anexos",
]


class DGCPConsolidatedTechnicalOfferService:
    """Ensambla un único documento técnico en estado BORRADOR — sin aprobación automática."""

    MANIFEST_KEY = "consolidated_technical_offer"

    def build(
        self,
        opportunity: DGCPOpportunity,
        pkg: DGCPBidPackage,
        *,
        company_name: str,
    ) -> tuple[str, list[str], dict[str, Any]]:
        manifest = pkg.manifest or {}
        hermes = manifest.get("hermes_document_analysis") or {}
        requirements = pkg.requirements or {}
        checklist = list(pkg.checklist or [])
        tech_sheets = (manifest.get("technical_sheets") or {}).get("items") or []
        tech_intel = (manifest.get("product_intelligence") or {}).get("items") or []
        generated_forms = list(pkg.generated_forms or [])

        lines: list[str] = []
        sections_present: list[str] = []

        def section(title: str, body_lines: list[str]) -> None:
            if not body_lines:
                return
            sections_present.append(title)
            lines.append(f"\n# {title}\n")
            lines.extend(body_lines)
            lines.append("")

        section("Portada", [
            f"**Proceso:** {opportunity.code}",
            f"**Institución:** {opportunity.institution}",
            f"**Objeto:** {opportunity.title}",
            f"**Empresa:** {company_name}",
            f"**Estado:** BORRADOR — requiere revisión y aprobación humana",
            f"**Generado:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        ])

        summary = hermes.get("summary") or opportunity.description or ""
        section("Resumen ejecutivo", [
            summary[:4000] if summary else "_Pendiente — ejecute análisis documental Hermes._",
        ])

        section("Información de la empresa", [
            f"Participante: **{company_name}**",
            "_Completar desde Perfil Empresarial: RNC, domicilio, representante legal._",
        ])

        hist = opportunity.similar_history or []
        if hist:
            section("Experiencia relevante", [
                f"- {h}" if isinstance(h, str) else f"- {h.get('title', h)}"
                for h in hist[:8]
            ])
        else:
            section("Experiencia relevante", ["_Sin historial similar indexado._"])

        form_lines = []
        for form in generated_forms:
            label = form.get("form_type") or form.get("filename") or "Formulario"
            status = form.get("status") or "borrador"
            form_lines.append(f"- {label} ({status})")
        for item in checklist:
            req = (item.get("requirement") or "").lower()
            if "sncc" in req or "f.0" in req:
                st = item.get("status") or "pendiente"
                form_lines.append(f"- {item.get('requirement')} — {st}")
        section("Formularios requeridos", form_lines or ["_Sin formularios generados._"])

        matrix_lines = []
        for ti in tech_intel:
            req = (ti.get("requirement") or {}).get("nombre") or "Requisito"
            for row in ti.get("compliance_matrix") or []:
                matrix_lines.append(
                    f"- **{req}** / {row.get('requisito')}: {row.get('cumple')} "
                    f"({row.get('observacion') or row.get('evidencia') or 'sin evidencia'})"
                )
        for sheet in tech_sheets:
            draft = sheet.get("draft") or {}
            for row in draft.get("compliance_matrix") or []:
                matrix_lines.append(
                    f"- **{sheet.get('required_product_name')}** / "
                    f"{row.get('pliego_requirement')}: {row.get('complies')}"
                )
        section("Matriz de cumplimiento", matrix_lines or ["_Matriz pendiente — complete Oferta técnica en expediente._"])

        sheet_lines = []
        for sheet in tech_sheets:
            name = sheet.get("required_product_name") or "Producto"
            status = sheet.get("status") or "detectada"
            offered = sheet.get("offered_product") or {}
            model = offered.get("model") or offered.get("description") or "—"
            sheet_lines.append(f"- {name}: {model} ({status})")
        section("Fichas técnicas", sheet_lines or ["_Sin fichas técnicas generadas._"])

        cert_lines = [
            f"- {item.get('label') or item.get('key') if isinstance(item, dict) else str(item)}"
            for item in (requirements.get("certifications") or [])
        ]
        section("Certificaciones", cert_lines or ["_Ver checklist de certificaciones._"])

        legal_lines = []
        for bucket in ("legal", "administrative", "mandatory_documents"):
            for item in requirements.get(bucket) or []:
                label = item.get("label") if isinstance(item, dict) else str(item)
                legal_lines.append(f"- {label}")
        section("Documentación legal", legal_lines[:30] or ["_Ver checklist documental._"])

        annex_lines = [
            f"- {doc.get('title') or doc.get('filename')}"
            for doc in (pkg.process_documents_summary or [])[:20]
            if isinstance(doc, dict)
        ]
        section("Anexos", annex_lines or ["_Anexos según pliego y expediente preparado._"])

        content = "\n".join(lines).strip()
        meta = {
            "status": "borrador",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "filename": f"oferta_tecnica_consolidada_{opportunity.code.replace('/', '-')}.md",
            "sections": sections_present,
            "preview_excerpt": content[:1500],
        }
        return content, sections_present, meta
