"""Event bus expediente — sincronización en cascada + timeline."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from app.config import settings
from app.services.dgcp_expediente_sync_service import DGCPExpedienteSyncService


EVENT_LABELS: dict[str, str] = {
    "document_added": "Documento agregado",
    "document_removed": "Documento eliminado",
    "document_approved": "Documento aprobado",
    "document_rejected": "Documento rechazado",
    "status_changed": "Cambio de estado",
    "assignee_changed": "Cambio de responsable",
    "comment_added": "Comentario interno",
    "manual_validation": "Validación manual",
    "analysis_completed": "Análisis completado",
    "expediente_prepared": "Expediente preparado",
    "expediente_validated": "Validación final del expediente",
}


class DGCPExpedienteEventService:
    """Registra eventos y recalcula estado unificado del expediente."""

    MAX_HISTORY = 200

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_expediente_event_bus)

    @classmethod
    def label_for(cls, event_type: str) -> str:
        return EVENT_LABELS.get(event_type, event_type.replace("_", " ").capitalize())

    @classmethod
    def timeline(cls, pkg: Any, *, limit: int = 50) -> list[dict[str, Any]]:
        manifest = dict(getattr(pkg, "manifest", None) or {})
        history = list(manifest.get("event_history") or [])
        out: list[dict[str, Any]] = []
        for entry in reversed(history[-limit:]):
            et = str(entry.get("event_type") or "")
            detail = entry.get("detail") or {}
            out.append(
                {
                    **entry,
                    "label": entry.get("label") or cls.label_for(et),
                    "summary": detail.get("summary")
                    or detail.get("note")
                    or detail.get("requirement_label")
                    or detail.get("requirement_key")
                    or cls.label_for(et),
                }
            )
        return out

    @classmethod
    async def publish(
        cls,
        pkg: Any,
        *,
        event_type: str,
        actor_id: uuid.UUID | None = None,
        detail: dict[str, Any] | None = None,
        checklist: list[dict[str, Any]] | None = None,
        preparation_pct: float | None = None,
    ) -> dict[str, Any]:
        if not cls.enabled() or pkg is None:
            return {"published": False}

        manifest = dict(getattr(pkg, "manifest", None) or {})
        history: list[dict[str, Any]] = list(manifest.get("event_history") or [])
        entry = {
            "event_type": event_type,
            "label": cls.label_for(event_type),
            "at": datetime.now(timezone.utc).isoformat(),
            "actor_id": str(actor_id) if actor_id else None,
            "detail": detail or {},
        }
        history.append(entry)
        manifest["event_history"] = history[-cls.MAX_HISTORY :]
        manifest["last_event"] = entry
        pkg.manifest = manifest

        active_checklist = checklist if checklist is not None else list(getattr(pkg, "checklist", None) or [])
        prep = preparation_pct
        if prep is None:
            bid = getattr(pkg, "bid_package", None) or {}
            prep = float(bid.get("preparation_pct") or 0)

        sync = DGCPExpedienteSyncService.sync_package(pkg, checklist=active_checklist, preparation_pct=prep)
        return {"published": True, "event": entry, "sync": sync}

    @classmethod
    def enrich_checklist_notes_from_hermes(
        cls,
        checklist: list[dict[str, Any]],
        hermes_meta: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        if not hermes_meta or hermes_meta.get("status") != "completed":
            return checklist
        summary = (hermes_meta.get("summary") or "").strip()
        if not summary:
            return checklist
        for item in checklist:
            if item.get("ia_observations"):
                continue
            if item.get("evidence_source") == "hermes_llm":
                item["ia_observations"] = summary[:500]
                item["notes"] = item.get("notes") or summary[:500]
        return checklist
