"""Sincronización expediente único — checklist, estado, historial (Fase 4)."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from app.config import settings
from app.services.dgcp_compliance_engine import DGCPComplianceEngine


class DGCPExpedienteSyncService:
    """Deriva estado unificado del expediente desde checklist y preparación."""

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_unified_expediente)

    @classmethod
    def enrich_checklist_item(cls, item: dict[str, Any]) -> dict[str, Any]:
        if not cls.enabled():
            return item
        raw = item.get("status") or "pendiente"
        item = dict(item)
        item["unified_status"] = DGCPComplianceEngine.unified_status(raw)
        item.setdefault("category", item.get("tipo"))
        if not item.get("priority"):
            item["priority"] = "alta" if item.get("mandatory") else "media"
        return item

    @classmethod
    def sync_package(
        cls,
        pkg: Any,
        *,
        checklist: list[dict[str, Any]],
        preparation_pct: float,
        expediente_status: str | None = None,
    ) -> dict[str, Any]:
        """Actualiza metadatos unificados en bid_package sin romper flujo legacy."""
        if not cls.enabled():
            return {"synced": False}

        enriched = [cls.enrich_checklist_item(dict(i)) for i in checklist]
        counts: dict[str, int] = {}
        for row in enriched:
            us = row.get("unified_status") or "detectado"
            counts[us] = counts.get(us, 0) + 1

        total = len(enriched)
        summary = {
            "estado_general": expediente_status or getattr(pkg, "expediente_status", None) or "sin_preparar",
            "preparation_pct": preparation_pct,
            "total_requisitos": total,
            "requisitos_completados": counts.get("completado", 0),
            "requisitos_pendientes": counts.get("pendiente", 0),
            "requisitos_vencidos": counts.get("vencido", 0),
            "requisitos_requiere_revision": counts.get("requiere_revision", 0),
            "requisitos_rechazados": counts.get("rechazado", 0),
            "requisitos_no_aplica": counts.get("no_aplica", 0),
            "requisitos_detectados": counts.get("detectado", 0),
            "total": total,
            "by_status": counts,
            "synced_at": datetime.now(UTC).isoformat(),
        }
        meta = dict(getattr(pkg, "manifest", None) or {})
        meta["expediente_unified"] = summary
        if hasattr(pkg, "manifest"):
            pkg.manifest = meta
        if hasattr(pkg, "checklist"):
            pkg.checklist = enriched

        return {"synced": True, "summary": summary, "checklist": enriched}
