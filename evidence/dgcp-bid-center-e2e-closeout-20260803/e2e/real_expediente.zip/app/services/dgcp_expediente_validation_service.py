"""Motor de validación consolidado para expedientes DGCP."""

from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.services.company_profile_sync_service import CompanyProfileSyncService
from app.services.corporate_identity_service import CorporateIdentityService
from app.services.real_dgcp_expediente_builder import RealDGCPExpedienteBuilder

REQUIRED_EXPEDIENTE_DOCS = (
    "registro_mercantil",
    "dgii",
    "tss",
    "proveedor_estado",
    "mipyme",
    "cedula_representante",
    "certificacion_bancaria",
)

IDENTITY_REQUIRED = ("Firma autorizada", "Sello")


class DGCPExpedienteValidationService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.builder = RealDGCPExpedienteBuilder(db, tenant_id, user_id=user_id)

    async def validate(
        self,
        opportunity_id: uuid.UUID,
        *,
        company_key: str | None = None,
    ) -> dict:
        base = await self.builder.validate_package(opportunity_id)
        company_risks: list[str] = []
        missing_docs: list[str] = []
        expired_docs: list[str] = []
        missing_data: list[str] = []

        if company_key:
            profile_svc = CompanyProfileSyncService(self.db, self.tenant_id)
            profiles = await profile_svc.list_profiles()
            profile = next((p for p in profiles if p["company_key"] == company_key), None)
            if not profile:
                company_risks.append(f"Perfil de empresa '{company_key}' no sincronizado desde OneDrive")
            elif profile.get("missing_fields"):
                missing_data.extend(profile["missing_fields"])
                company_risks.append(
                    f"Perfil incompleto ({profile.get('completeness_score', 0)}%): "
                    + ", ".join(profile["missing_fields"][:5])
                )

            legal = await self._legal_status(company_key)
            missing_docs.extend(legal["missing"])
            expired_docs.extend(legal["expired"])

            try:
                identity = await CorporateIdentityService(
                    self.db, self.tenant_id, user_id=self.user_id
                ).get_company_assets(company_key)
                for label in IDENTITY_REQUIRED:
                    if label in (identity.missing or []):
                        missing_docs.append(label.lower().replace(" ", "_"))
                        company_risks.append(f"Identidad corporativa: falta {label}")
            except Exception:
                company_risks.append("No se pudo verificar identidad corporativa")

        ready = (
            base.can_prepare_package
            and not company_risks
            and not missing_docs
            and not expired_docs
            and not missing_data
        )
        status = "listo_para_presentar" if ready else "incompleto"

        return {
            "status": status,
            "ready_to_submit": ready,
            "blocked": not ready,
            "package_validation": base.model_dump(mode="json"),
            "company_key": company_key,
            "missing_documents": list(dict.fromkeys(missing_docs)),
            "expired_documents": expired_docs,
            "missing_data": list(dict.fromkeys(missing_data)),
            "risks": company_risks + list(base.critical_errors or []),
            "warnings": list(base.warnings or []),
            "message": (
                "Faltan documentos para completar esta licitación."
                if not ready
                else "Perfil documental listo para expediente."
            ),
        }

    async def _legal_status(self, company_key: str) -> dict:
        expected = REQUIRED_EXPEDIENTE_DOCS + ("rnc", "estatutos", "poderes")
        assets = (
            await self.db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == self.tenant_id,
                    KnowledgeAsset.is_active.is_(True),
                    KnowledgeAsset.folder_category == "legal_documents",
                    KnowledgeAsset.company_key == company_key,
                )
            )
        ).scalars().all()

        m365_legal = (
            await self.db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == self.tenant_id,
                    KnowledgeAsset.is_active.is_(True),
                    KnowledgeAsset.relative_path.ilike(f"%01_DOCUMENTOS_LEGALES%/{company_key.upper()}%"),
                )
            )
        ).scalars().all()
        all_assets = list(assets) + [a for a in m365_legal if a not in assets]

        found_types = {a.document_type.lower() for a in all_assets}
        missing = [t for t in expected if t not in found_types and not any(t in (a.filename or "").lower() for a in all_assets)]
        expired = [a.filename for a in all_assets if a.vigency_status in ("vencido", "expired")]

        return {"missing": missing, "expired": expired, "found": len(all_assets)}
