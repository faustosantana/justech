"""Autollenado y generación controlada de formularios DGCP — plantillas reales."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.user import User
from app.schemas.dgcp_bid import (
    DGCPAliasFieldSummary,
    DGCPAliasMappingField,
    DGCPAliasMappingSaveRequest,
    DGCPFormAutofillPreviewResponse,
    DGCPFormGenerateResponse,
    DGCPFormPreviewField,
)
from app.services.document_autofill.alias_mapping_store import AliasMappingStore
from app.services.document_autofill.field_alias_registry import CANONICAL_FIELDS
from app.services.document_autofill.document_autofill_service import DocumentAutofillService


class DGCPFormAutofillService:
    """Facade — mantiene API existente y delega generación documental."""

    FORM_LABELS = {
        "SNCC.F033": "SNCC F.033",
        "SNCC.F042": "SNCC F.042",
        "SNCC.F047": "SNCC F.047",
        "OFERTA.ECONOMICA": "Oferta económica",
        "CARTA.PRESENTACION": "Carta de presentación",
    }

    FIELD_SOURCES = {
        "razon_social": "Repositorio corporativo",
        "rnc": "Repositorio corporativo",
        "direccion": "Repositorio corporativo",
        "representante_legal": "Repositorio corporativo",
        "telefono": "Repositorio corporativo",
        "correo": "Repositorio corporativo",
        "cuenta_bancaria": "Repositorio corporativo",
        "proceso_dgcp": "DGCP",
        "entidad_contratante": "DGCP",
        "objeto_proceso": "DGCP",
        "monto": "DGCP / usuario",
        "fabricante": "Usuario / Assistant",
        "plazo_entrega": "Usuario / Assistant",
        "garantia": "Usuario / Assistant",
        "productos": "Usuario / expediente",
        "condiciones": "Usuario / expediente",
        "fecha": "Sistema",
    }

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.documents = DocumentAutofillService(db, tenant_id, user_id=user_id)

    async def _user_email(self) -> str | None:
        if not self.user_id:
            return None
        user = await self.db.get(User, self.user_id)
        return user.email if user else None

    async def autofill_preview(
        self,
        opportunity: DGCPOpportunity,
        *,
        form_type: str = "SNCC.F042",
        company: str = "justech",
        user_input: dict | None = None,
        field_overrides: dict | None = None,
    ) -> DGCPFormAutofillPreviewResponse:
        result = await self.documents.build_document(
            opportunity,
            form_type=form_type,
            company=company,
            user_input=user_input,
            overrides=field_overrides,
            persist=False,
            user_email=await self._user_email(),
        )
        fields = [
            DGCPFormPreviewField(
                label=f.label,
                value=f.value,
                status=f.status,
                confidence=f.confidence,
                source=f.source,
                key=f.key,
            )
            for f in result.fields
        ]
        overall = (
            sum(f.confidence for f in fields if f.value) / max(len([f for f in fields if f.value]), 1)
            if fields
            else 0.0
        )
        return DGCPFormAutofillPreviewResponse(
            opportunity_id=opportunity.id,
            form_type=result.form_type,
            company=company,
            fields=fields,
            missing=result.missing,
            warnings=self._build_warnings(result),
            overall_confidence=round(overall, 2),
            generate_enabled=result.generate_allowed,
            draft_enabled=result.draft_allowed,
            note=(
                "Vista previa PDF real — plantilla "
                + ("M365" if result.template_source_type == "m365" else "local")
                + f" · motor {result.pdf_engine}"
                + f" · {result.completion_status}"
            ),
            document_preview_available=bool(result.pdf_bytes),
            template_source=result.template_path,
            template_source_type=result.template_source_type,
            pdf_engine=result.pdf_engine,
            template_m365=result.m365_template,
            alias_fields=[DGCPAliasMappingField(**a) for a in result.alias_fields],
            alias_summary=DGCPAliasFieldSummary(**result.alias_summary) if result.alias_summary else None,
            can_pass=result.can_pass,
            ready_for_signature=result.ready_for_signature,
            completion_status=result.completion_status,
            aliases_detected=result.audit_record.get("aliases_detected", len(result.alias_fields)),
            aliases_mapped=result.alias_summary.get("completed", 0) if result.alias_summary else 0,
            critical_pending_aliases=result.audit_record.get("critical_pending", []),
            non_critical_pending_aliases=result.audit_record.get("non_critical_pending", []),
        )

    @staticmethod
    def _build_warnings(result) -> list[str]:
        warnings: list[str] = []
        summary = result.alias_summary or {}
        if summary.get("critical_pending"):
            warnings.append(
                f"Pendientes críticos ({summary['critical_pending']}): impiden firma/sello."
            )
        if summary.get("non_critical_pending"):
            warnings.append(
                f"Pendientes no críticos ({summary['non_critical_pending']}): puede generar PDF con advertencia."
            )
        for m in result.missing[:8]:
            warnings.append(f"Campo pendiente: {m}")
        return warnings

    def save_alias_mapping(
        self,
        data: DGCPAliasMappingSaveRequest,
        *,
        user_email: str | None = None,
    ) -> dict:
        store = AliasMappingStore(self.tenant_id)
        store.save_mapping(
            data.alias_normalized,
            canonical=data.canonical,
            scope=data.scope,
            template_key=data.template_key,
            opportunity_id=data.opportunity_id,
            status=data.status,
            confidence=data.confidence,
            user_email=user_email,
            alias_original=data.alias_original,
            value=data.value,
        )
        return {"ok": True}

    @staticmethod
    def list_canonical_fields() -> list[dict]:
        return [{"key": k, "label": v} for k, v in CANONICAL_FIELDS.items()]

    async def generate_controlled_copy(
        self,
        opportunity: DGCPOpportunity,
        *,
        form_type: str = "SNCC.F042",
        company: str = "justech",
        user_input: dict | None = None,
        field_overrides: dict | None = None,
        expediente_path=None,
        draft: bool = False,
    ) -> DGCPFormGenerateResponse:
        preview = await self.documents.build_document(
            opportunity,
            form_type=form_type,
            company=company,
            user_input=user_input,
            overrides=field_overrides,
            persist=False,
            user_email=await self._user_email(),
        )
        if not draft and not preview.ready_for_signature:
            raise ValueError(
                "Hay pendientes críticos. Complete los campos o guarde como borrador (draft=true)."
            )

        result = await self.documents.build_document(
            opportunity,
            form_type=form_type,
            company=company,
            user_input=user_input,
            overrides=field_overrides,
            persist=True,
            expediente_path=expediente_path,
            user_email=await self._user_email(),
        )
        is_draft = draft or not result.ready_for_signature
        return DGCPFormGenerateResponse(
            opportunity_id=opportunity.id,
            form_type=result.form_type,
            output_path=result.pdf_path or result.docx_path or "",
            filename=result.pdf_filename or result.docx_filename or "",
            fields_completed=sum(1 for f in result.fields if f.value),
            fields_pending=len(result.missing),
            overall_confidence=round(
                sum(f.confidence for f in result.fields if f.value)
                / max(len([f for f in result.fields if f.value]), 1),
                2,
            ),
            docx_path=result.docx_path,
            pdf_path=result.pdf_path,
            audit_path=str(result.pdf_path).replace(".pdf", "_audit.json") if result.pdf_path else None,
            template_hash=result.template_hash,
            generated_at=datetime.now(timezone.utc).isoformat(),
            template_source_type=result.template_source_type,
            pdf_engine=result.pdf_engine,
            template_m365=result.m365_template,
            ready_for_signature=result.ready_for_signature and not is_draft,
            completion_status=result.completion_status,
            is_draft=is_draft,
        )

    async def document_preview_pdf(
        self,
        opportunity: DGCPOpportunity,
        *,
        form_type: str,
        company: str = "justech",
        user_input: dict | None = None,
        field_overrides: dict | None = None,
    ) -> bytes:
        result = await self.documents.build_document(
            opportunity,
            form_type=form_type,
            company=company,
            user_input=user_input,
            overrides=field_overrides,
            persist=False,
            user_email=await self._user_email(),
        )
        return result.pdf_bytes
