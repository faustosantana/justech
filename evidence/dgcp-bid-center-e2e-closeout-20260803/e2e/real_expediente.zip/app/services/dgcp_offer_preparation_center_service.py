"""Centro de preparación de oferta — agregador del expediente (Fase 6.3).

No duplica lógica de checklist, Hermes, fichas ni matrices; las consolida
para responder «¿qué tan preparada está la oferta?» dentro del expediente.
"""

from __future__ import annotations

import copy
import re
import uuid
from datetime import date
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from app.config import settings
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.dgcp_offer_preparation import (
    DGCPOfferPreparationArea,
    DGCPOfferPreparationAutoAction,
    DGCPOfferPreparationBrandingAsset,
    DGCPOfferPreparationCenterResponse,
    DGCPOfferPreparationConsolidatedGenerateResponse,
    DGCPOfferPreparationConsolidatedOffer,
    DGCPOfferPreparationExecutiveSummary,
    DGCPOfferPreparationHumanDecision,
    DGCPOfferPreparationPendingItem,
    DGCPOfferPreparationRisk,
)
from app.services.company_normalization_service import canonical_label
from app.services.corporate_branding_service import CorporateBrandingService
from app.services.dgcp_compliance_engine import (
    ACTION_BY_STATUS,
    COMPLIANT_STATUSES,
    COMPLETE_STATUSES,
    DGCPComplianceEngine,
    FALTANTE_STATUSES,
    REVIEW_STATUSES,
    SNCC_KEY_BY_FORM,
    UNANALYZED_STATUSES,
    VENCIDO_STATUSES,
)
from app.services.dgcp_consolidated_technical_offer_service import DGCPConsolidatedTechnicalOfferService

INTEREST_LABELS = {
    "detected": "Detectada",
    "interested": "Interesada",
    "to_bid": "En licitación",
    "review": "En revisión",
    "discarded": "Descartada",
    "won": "Ganada",
    "lost": "Perdida",
}

CRITICAL_KEYWORDS = (
    "garantía", "garantia", "seriedad", "rpe", "sncc", "f.033", "f.034", "f.042", "f.047",
    "oferta técnica", "oferta tecnica", "ficha técnica", "ficha tecnica", "matriz",
    "carta de", "registro", "dgii", "tss", "certificación", "certificacion",
)

MINOR_KEYWORDS = (
    "logo", "firma", "sello", "representante", "cargo", "branding", "identidad", "imagen producto",
    "datasheet",
)

BLOCKING_STATUSES = FALTANTE_STATUSES | VENCIDO_STATUSES | COMPLETE_STATUSES

NON_BLOCKING_REQUIREMENT_KEYS = frozenset({
    "tiempo_entrega",
    "descalificacion",
    "vigencia_oferta",
    "criterios_evaluacion",
    "condiciones_pago",
    "especificaciones_tecnicas",
    "experiencia",
    "visita_tecnica",
})

TASK_RECOMMENDATION_PREFIXES = (
    "verificar ",
    "solicitar ",
    "preparar ",
    "revisar ",
    "evaluar ",
    "presentar ",
    "completar la ",
    "analizar ",
    "confirmar ",
)

EVIDENCIA_NO_DISPONIBLE = "Evidencia no disponible"

BRANDING_LABELS = {
    "logo": "Logo corporativo",
    "signature": "Firma digital",
    "stamp": "Sello corporativo",
}

AREA_DEFS = (
    ("documentacion", "Documentación"),
    ("formularios", "Formularios"),
    ("legal", "Requisitos legales"),
    ("tecnico", "Requisitos técnicos"),
    ("evidencias", "Evidencias"),
    ("fichas_tecnicas", "Fichas técnicas"),
    ("matriz_cumplimiento", "Matriz de cumplimiento"),
    ("oferta_tecnica", "Oferta técnica"),
)


class DGCPOfferPreparationCenterService:
    MANIFEST_KEY = "offer_preparation_center"

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.compliance = DGCPComplianceEngine()
        self.consolidated = DGCPConsolidatedTechnicalOfferService()

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_offer_preparation_center)

    async def get_center(self, opportunity_id: uuid.UUID) -> DGCPOfferPreparationCenterResponse:
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._get_package(opportunity_id)
        analyzed = pkg is not None and bool(pkg.analyzed_at)
        if not analyzed or not pkg:
            return DGCPOfferPreparationCenterResponse(
                opportunity_id=opportunity_id,
                enabled=self.enabled(),
                analyzed=False,
                executive_summary=self._executive_summary(opportunity, pkg, 0.0),
                areas=[],
                critical_pending=[DGCPOfferPreparationPendingItem(
                    id="analyze",
                    label="Análisis de requisitos pendiente",
                    area="documentacion",
                    severity="critico",
                    reason="Ejecute «Analizar requisitos» para activar el centro de preparación.",
                    action_hint="Analizar requisitos",
                )],
            )

        bid = pkg.bid_package or {}
        manifest = pkg.manifest or {}
        checklist = list(pkg.checklist or [])

        areas = self._compute_areas(pkg, checklist, manifest)
        derived_pct = self._overall_pct_from_areas(areas)
        stored_area = bid.get("area_preparation_pct")
        if stored_area is None and bid.get("preparation_pct") is not None:
            # Compatibilidad: versiones previas guardaban avance por áreas en preparation_pct
            legacy = float(bid.get("preparation_pct") or 0)
            if legacy > 0 and derived_pct > 0 and abs(legacy - derived_pct) < 5:
                stored_area = legacy
        prep_pct = derived_pct
        if stored_area is not None:
            prep_pct = float(stored_area)
            if prep_pct <= 0 and derived_pct > 0:
                prep_pct = derived_pct

        if bid.get("area_preparation_pct") != prep_pct:
            bid = {**bid, "area_preparation_pct": prep_pct}
            pkg.bid_package = bid
            flag_modified(pkg, "bid_package")

        critical, minor = self._pending_items(checklist, pkg, manifest, opportunity)
        auto_actions = self._auto_actions(pkg, manifest, checklist)
        human = self._human_decisions(pkg, manifest)
        risks = self._consolidate_risks(opportunity, pkg, manifest)
        consolidated = self._consolidated_state(manifest)

        branding_status: list[DGCPOfferPreparationBrandingAsset] = []
        company_key = self._company_key(opportunity)
        try:
            branding = await CorporateBrandingService(self.db, self.tenant_id, user_id=self.user_id).resolve(company_key)
            branding_status, branding_minor = self._branding_pending(branding)
            minor.extend(branding_minor)
        except Exception:
            pass

        critical = self._dedupe_pending(critical)
        minor = self._dedupe_pending(minor)

        response = DGCPOfferPreparationCenterResponse(
            opportunity_id=opportunity_id,
            enabled=self.enabled(),
            analyzed=True,
            executive_summary=self._executive_summary(opportunity, pkg, prep_pct),
            areas=areas,
            critical_pending=critical[:25],
            minor_pending=minor[:25],
            auto_actions=auto_actions,
            human_decisions=human,
            risks=risks,
            branding_status=branding_status,
            consolidated_offer=consolidated,
        )
        await self._cache_summary(pkg, response)
        return response

    async def generate_consolidated_offer(
        self,
        opportunity_id: uuid.UUID,
    ) -> DGCPOfferPreparationConsolidatedGenerateResponse:
        if not self.enabled():
            raise ValueError("Centro de preparación deshabilitado (DGCP_OFFER_PREPARATION_CENTER=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._require_package(opportunity_id)
        company = canonical_label(self._company_key(opportunity))
        content, sections, meta = self.consolidated.build(opportunity, pkg, company_name=company)

        manifest = copy.deepcopy(pkg.manifest or {})
        manifest[self.consolidated.MANIFEST_KEY] = {**meta, "content": content}
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.commit()
        await self.db.refresh(pkg)

        return DGCPOfferPreparationConsolidatedGenerateResponse(
            opportunity_id=opportunity_id,
            status="borrador",
            filename=meta["filename"],
            content=content,
            sections=sections,
            message="Oferta técnica consolidada generada en estado BORRADOR — requiere aprobación humana.",
        )

    def _executive_summary(
        self,
        opportunity: DGCPOpportunity,
        pkg: DGCPBidPackage | None,
        prep_pct: float,
    ) -> DGCPOfferPreparationExecutiveSummary:
        requirements = (pkg.requirements if pkg else None) or {}
        guarantees = requirements.get("guarantees") or []
        guarantee_text = None
        if guarantees:
            guarantee_text = guarantees[0] if isinstance(guarantees[0], str) else str(guarantees[0])
        company_key = self._company_key(opportunity)
        return DGCPOfferPreparationExecutiveSummary(
            institution=opportunity.institution,
            process_code=opportunity.code,
            title=opportunity.title,
            modalidad=opportunity.modalidad,
            deadline=opportunity.deadline.isoformat() if isinstance(opportunity.deadline, date) else None,
            estimated_amount=float(opportunity.amount) if opportunity.amount else None,
            currency=opportunity.currency or "DOP",
            guarantee_amount=guarantee_text,
            participating_company=canonical_label(company_key),
            interest_status=opportunity.status,
            interest_status_label=INTEREST_LABELS.get(opportunity.status, opportunity.status),
            overall_preparation_pct=prep_pct,
            expediente_status=pkg.expediente_status if pkg else "sin_preparar",
        )

    def _compute_areas(
        self,
        pkg: DGCPBidPackage,
        checklist: list[dict],
        manifest: dict,
    ) -> list[DGCPOfferPreparationArea]:
        buckets: dict[str, list[dict]] = {k: [] for k, _ in AREA_DEFS}
        for item in checklist:
            area = self._classify_item(item)
            buckets.setdefault(area, []).append(item)

        areas: list[DGCPOfferPreparationArea] = []
        for key, label in AREA_DEFS:
            if key == "fichas_tecnicas":
                pct, detail = self._tech_sheets_pct(manifest)
            elif key == "matriz_cumplimiento":
                pct, detail = self._matrix_pct(manifest)
            elif key == "oferta_tecnica":
                pct, detail = self._oferta_tecnica_pct(manifest, buckets.get("oferta_tecnica", []))
            elif key == "evidencias":
                pct, detail = self._evidence_pct(pkg)
            elif key == "tecnico":
                pct, detail = self._pct_from_items(buckets.get("tecnico", []) + buckets.get("documentacion", []))
            else:
                pct, detail = self._pct_from_items(buckets.get(key, []))
            areas.append(DGCPOfferPreparationArea(
                key=key,
                label=label,
                preparation_pct=pct,
                status=self._area_status(pct),
                detail=detail,
            ))
        return areas

    @staticmethod
    def _overall_pct_from_areas(areas: list[DGCPOfferPreparationArea]) -> float:
        values = [a.preparation_pct for a in areas if a.preparation_pct is not None]
        if not values:
            return 0.0
        return round(sum(values) / len(values), 1)

    @classmethod
    def compute_area_preparation_pct(cls, pkg: DGCPBidPackage) -> float:
        """Avance por áreas — lectura sin persistir (para bid-package en primer render)."""
        manifest = pkg.manifest or {}
        cached = (manifest.get(cls.MANIFEST_KEY) or {}).get("overall_preparation_pct")
        if cached is not None:
            return float(cached)
        bid = pkg.bid_package or {}
        if bid.get("area_preparation_pct") is not None:
            return float(bid["area_preparation_pct"])
        if not pkg.checklist:
            return 0.0
        svc = cls.__new__(cls)
        areas = svc._compute_areas(pkg, list(pkg.checklist or []), manifest)
        return svc._overall_pct_from_areas(areas)

    @staticmethod
    def _pct_from_items(items: list[dict]) -> tuple[float | None, str | None]:
        if not items:
            return None, "Sin ítems en checklist"
        compliant = sum(1 for i in items if (i.get("status") or "") in COMPLIANT_STATUSES)
        pct = round(100.0 * compliant / len(items), 1)
        return pct, f"{compliant}/{len(items)} ítems cumplidos"

    @staticmethod
    def _tech_sheets_pct(manifest: dict) -> tuple[float | None, str | None]:
        block = manifest.get("technical_sheets") or {}
        items = block.get("items") or []
        if not items:
            summary = manifest.get("technical_sheets_summary") or {}
            if summary.get("requires_technical_sheets"):
                return 0.0, "Fichas requeridas — pendientes de detectar"
            return None, "No requiere fichas técnicas"
        approved = sum(1 for i in items if i.get("status") == "aprobada")
        draft = sum(1 for i in items if i.get("status") in ("borrador_generado", "requiere_revision", "lista_para_generar"))
        pct = round(100.0 * approved / len(items), 1)
        return pct, f"{approved} aprobadas · {draft} en borrador/revisión · {len(items)} total"

    @staticmethod
    def _matrix_pct(manifest: dict) -> tuple[float | None, str | None]:
        block = manifest.get("product_intelligence") or {}
        items = block.get("items") or []
        if not items:
            return None, "Ejecute análisis técnico del pliego (Oferta técnica)"
        pcts = [float(i.get("compliance_pct") or 0) for i in items if i.get("compliance_pct") is not None]
        if not pcts:
            return 0.0, f"{len(items)} bienes — matriz pendiente"
        avg = round(sum(pcts) / len(pcts), 1)
        return avg, f"Promedio cumplimiento {avg}% en {len(items)} bien(es)"

    @staticmethod
    def _oferta_tecnica_pct(manifest: dict, checklist_items: list[dict]) -> tuple[float | None, str | None]:
        parts: list[float] = []
        ts_pct, _ = DGCPOfferPreparationCenterService._tech_sheets_pct(manifest)
        mx_pct, _ = DGCPOfferPreparationCenterService._matrix_pct(manifest)
        if ts_pct is not None:
            parts.append(ts_pct)
        if mx_pct is not None:
            parts.append(mx_pct)
        cl_pct, _ = DGCPOfferPreparationCenterService._pct_from_items(checklist_items)
        if cl_pct is not None:
            parts.append(cl_pct)
        consolidated = manifest.get("consolidated_technical_offer") or {}
        if consolidated.get("status") == "borrador":
            parts.append(50.0)
        elif consolidated.get("status") == "aprobado":
            parts.append(100.0)
        if not parts:
            return 0.0, "Oferta técnica no iniciada"
        return round(sum(parts) / len(parts), 1), "Promedio fichas + matriz + consolidado"

    @staticmethod
    def _evidence_pct(pkg: DGCPBidPackage) -> tuple[float | None, str | None]:
        evidence = list(pkg.requirement_evidence or [])
        checklist = list(pkg.checklist or [])
        if not checklist:
            return None, None
        with_evidence = sum(
            1 for i in checklist
            if i.get("evidence_source") or i.get("document_id") or i.get("knowledge_asset_id")
        )
        pct = round(100.0 * with_evidence / len(checklist), 1) if checklist else 0.0
        return pct, f"{with_evidence} ítems con evidencia · {len(evidence)} registros"

    @staticmethod
    def _area_status(pct: float | None) -> str:
        if pct is None:
            return "pendiente"
        if pct >= 100:
            return "listo"
        if pct >= 60:
            return "parcial"
        if pct <= 0:
            return "bloqueado"
        return "parcial"

    @staticmethod
    def _classify_item(item: dict) -> str:
        text = " ".join(filter(None, [
            item.get("requirement"),
            item.get("key"),
            item.get("requirement_key"),
            item.get("tipo"),
        ])).lower()
        if any(k in text for k in ("sncc", "f.0", "formulario", "plantilla")):
            return "formularios"
        if ("ficha" in text and "técnica" in text) or ("ficha" in text and "tecnica" in text):
            return "fichas_tecnicas"
        if "oferta" in text and ("técnica" in text or "tecnica" in text):
            return "oferta_tecnica"
        if any(k in text for k in ("rpe", "dgii", "tss", "legal", "garantía", "garantia", "seriedad", "registro")):
            return "legal"
        if any(k in text for k in ("técnico", "tecnico", "especific", "equipo", "switch", "router")):
            return "tecnico"
        return "documentacion"

    def _pending_items(
        self,
        checklist: list[dict],
        pkg: DGCPBidPackage,
        manifest: dict,
        opportunity: DGCPOpportunity,
    ) -> tuple[list[DGCPOfferPreparationPendingItem], list[DGCPOfferPreparationPendingItem]]:
        critical: list[DGCPOfferPreparationPendingItem] = []
        minor: list[DGCPOfferPreparationPendingItem] = []
        has_sheet_items = bool((manifest.get("technical_sheets") or {}).get("items"))

        for item in checklist:
            if has_sheet_items and (item.get("requirement_key") or "").lower() == "ficha_tecnica":
                continue
            severity = self._classify_checklist_pending(item)
            if severity is None:
                continue
            req = item.get("requirement") or item.get("key") or "Requisito"
            status = item.get("status") or "pendiente"
            pending = DGCPOfferPreparationPendingItem(
                id=str(item.get("id") or req),
                label=req,
                area=self._classify_item(item),
                severity=severity,
                reason=ACTION_BY_STATUS.get(status),
                checklist_item_id=str(item.get("id")) if item.get("id") else None,
                action_hint=ACTION_BY_STATUS.get(status),
            )
            (critical if severity == "critico" else minor).append(pending)

        critical.extend(self._technical_sheet_pending(manifest, critical_only=True))
        minor.extend(self._technical_sheet_pending(manifest, critical_only=False))
        critical.extend(self._matrix_pending(manifest))

        return critical, minor

    @staticmethod
    def _classify_checklist_pending(item: dict) -> str | None:
        status = item.get("status") or "pendiente"
        if status in COMPLIANT_STATUSES or status == "no_aplica" or item.get("no_aplica"):
            return None

        req_key = (item.get("requirement_key") or "").lower()
        label = (item.get("requirement") or item.get("key") or "").strip()
        label_lower = label.lower()
        mandatory = bool(item.get("mandatory", True))

        if any(k in label_lower for k in MINOR_KEYWORDS):
            return "menor"

        if DGCPOfferPreparationCenterService._is_task_recommendation(item):
            return None

        if req_key in NON_BLOCKING_REQUIREMENT_KEYS:
            return "menor" if status not in COMPLIANT_STATUSES else None

        if status in REVIEW_STATUSES | UNANALYZED_STATUSES:
            return "menor"

        if mandatory and status in BLOCKING_STATUSES:
            return "critico"

        if not mandatory:
            return "menor"

        return None

    @staticmethod
    def _is_task_recommendation(item: dict) -> bool:
        req_key = (item.get("requirement_key") or "").lower()
        label = (item.get("requirement") or item.get("key") or "").lower().strip()
        source = (item.get("evidence_source") or item.get("source") or "").lower()

        if req_key.startswith("hermes_"):
            return True
        if source == "hermes_llm" and len(label) > 60:
            return True
        return any(label.startswith(prefix) for prefix in TASK_RECOMMENDATION_PREFIXES)

    @staticmethod
    def _coalesce_technical_sheets(manifest: dict) -> list[dict]:
        raw = (manifest.get("technical_sheets") or {}).get("items") or []
        by_name: dict[str, list[dict]] = {}
        for sheet in raw:
            name = sheet.get("required_product_name") or "Producto"
            by_name.setdefault(name, []).append(sheet)

        coalesced: list[dict] = []
        minor_statuses = {"borrador_generado", "requiere_revision"}
        for _name, group in by_name.items():
            statuses = {g.get("status") or "detectada" for g in group}
            if statuses <= {"aprobada", "no_aplica"}:
                continue
            if statuses & minor_statuses:
                sheet = next(g for g in group if (g.get("status") or "") in minor_statuses)
            else:
                sheet = group[0]
            coalesced.append(sheet)
        return coalesced

    @staticmethod
    def _technical_sheet_pending(manifest: dict, *, critical_only: bool) -> list[DGCPOfferPreparationPendingItem]:
        items: list[DGCPOfferPreparationPendingItem] = []
        for sheet in DGCPOfferPreparationCenterService._coalesce_technical_sheets(manifest):
            st = sheet.get("status") or "detectada"
            if st in ("aprobada", "no_aplica"):
                continue
            name = sheet.get("required_product_name") or "Producto"
            sheet_id = sheet.get("id") or name
            is_critical = st in ("detectada", "pendiente_producto", "lista_para_generar")
            if critical_only and not is_critical:
                continue
            if not critical_only and is_critical:
                continue
            severity = "critico" if is_critical else "menor"
            reason = {
                "detectada": "Ficha requerida — producto detectado, pendiente generar",
                "pendiente_producto": "Producto no seleccionado — requiere decisión humana",
                "lista_para_generar": "Ficha requerida — pendiente de generar",
                "borrador_generado": "Borrador generado — requiere revisión",
                "requiere_revision": "Ficha existente — requiere revisión humana",
            }.get(st, f"Estado: {st}")
            items.append(DGCPOfferPreparationPendingItem(
                id=f"sheet-{sheet_id}",
                label=f"Ficha técnica: {name}",
                area="fichas_tecnicas",
                severity=severity,
                reason=reason,
                action_hint="Fichas Técnicas o Oferta técnica",
            ))
        return items

    @staticmethod
    def _matrix_pending(manifest: dict) -> list[DGCPOfferPreparationPendingItem]:
        items: list[DGCPOfferPreparationPendingItem] = []
        seen: set[str] = set()
        for ti in (manifest.get("product_intelligence") or {}).get("items") or []:
            if ti.get("compliance_matrix"):
                continue
            req = ti.get("requirement") or {}
            rid = str(req.get("id") or req.get("nombre") or "")
            if not rid or rid in seen:
                continue
            seen.add(rid)
            items.append(DGCPOfferPreparationPendingItem(
                id=f"matrix-{rid}",
                label=f"Matriz de cumplimiento: {req.get('nombre') or 'Requisito técnico'}",
                area="matriz_cumplimiento",
                severity="critico",
                reason="Matriz obligatoria no generada",
                action_hint="Expediente → Oferta técnica",
            ))
        return items

    @staticmethod
    def _normalize_dedupe_key(item: DGCPOfferPreparationPendingItem) -> str:
        label = item.label.lower().strip()
        label = re.sub(r"\s+", " ", label)
        if item.id.startswith("sheet-"):
            return f"sheet:{label}"
        if item.id.startswith("matrix-"):
            return f"matrix:{item.id}"
        if item.id.startswith("branding-"):
            return item.id
        if "garantía" in label or "garantia" in label:
            if "seriedad" in label:
                return "garantia:seriedad"
            if "cumplimiento" in label:
                return "garantia:cumplimiento"
            return "garantia"
        if "sncc" in label or "f.0" in label:
            for code in ("033", "034", "042", "047"):
                if code in label:
                    return f"sncc:{code}"
        return label[:100]

    @classmethod
    def _dedupe_pending(cls, items: list[DGCPOfferPreparationPendingItem]) -> list[DGCPOfferPreparationPendingItem]:
        seen: set[str] = set()
        deduped: list[DGCPOfferPreparationPendingItem] = []
        for item in items:
            key = cls._normalize_dedupe_key(item)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(item)
        return deduped

    @staticmethod
    def _branding_pending(
        branding: Any,
    ) -> tuple[list[DGCPOfferPreparationBrandingAsset], list[DGCPOfferPreparationPendingItem]]:
        status_rows: list[DGCPOfferPreparationBrandingAsset] = []
        minor: list[DGCPOfferPreparationPendingItem] = []

        for attr, default_label in BRANDING_LABELS.items():
            asset = getattr(branding, attr)
            label = asset.label or default_label
            status_rows.append(DGCPOfferPreparationBrandingAsset(
                asset_type=asset.asset_type,
                label=label,
                status=asset.status,
                source=asset.source,
            ))
            if asset.status == "falta":
                minor.append(DGCPOfferPreparationPendingItem(
                    id=f"branding-{asset.asset_type}",
                    label=label,
                    area="documentacion",
                    severity="menor",
                    reason="Activo corporativo pendiente para PDF y oferta.",
                    action_hint="Perfil empresarial / Identidad corporativa",
                ))
            elif asset.status == "requiere_actualizacion":
                minor.append(DGCPOfferPreparationPendingItem(
                    id=f"branding-{asset.asset_type}",
                    label=label,
                    area="documentacion",
                    severity="menor",
                    reason="Activo detectado — requiere actualización.",
                    action_hint="Perfil empresarial / Identidad corporativa",
                ))

        if not (branding.representative_role or "").strip():
            minor.append(DGCPOfferPreparationPendingItem(
                id="branding-representative_role",
                label="Cargo del representante legal",
                area="documentacion",
                severity="menor",
                reason="Dato incompleto — no bloquea participación.",
                action_hint="Perfil empresarial",
            ))

        return status_rows, minor

    def _auto_actions(
        self,
        pkg: DGCPBidPackage,
        manifest: dict,
        checklist: list[dict],
    ) -> list[DGCPOfferPreparationAutoAction]:
        actions: list[DGCPOfferPreparationAutoAction] = []

        for item in checklist:
            req = (item.get("requirement") or "").lower()
            status = item.get("status") or ""
            if "sncc" in req or "f.0" in req:
                form_type = None
                for code, key in SNCC_KEY_BY_FORM.items():
                    if code in req or key in req:
                        form_type = code
                        break
                if status not in COMPLIANT_STATUSES:
                    actions.append(DGCPOfferPreparationAutoAction(
                        id=f"autofill-{form_type or req[:20]}",
                        label=f"Generar {item.get('requirement')}",
                        action_type="generate_form",
                        area="formularios",
                        payload={"form_type": form_type, "checklist_item_id": item.get("id")},
                    ))

        for sheet in (manifest.get("technical_sheets") or {}).get("items") or []:
            if sheet.get("status") in ("lista_para_generar", "detectada", "pendiente_producto"):
                actions.append(DGCPOfferPreparationAutoAction(
                    id=f"gen-sheet-{sheet.get('id')}",
                    label=f"Generar ficha: {sheet.get('required_product_name')}",
                    action_type="generate_technical_sheet",
                    area="fichas_tecnicas",
                    payload={"sheet_id": sheet.get("id")},
                ))

        for ti in (manifest.get("product_intelligence") or {}).get("items") or []:
            rid = (ti.get("requirement") or {}).get("id")
            if rid and not ti.get("compliance_matrix"):
                actions.append(DGCPOfferPreparationAutoAction(
                    id=f"run-matrix-{rid}",
                    label=f"Generar matriz: {(ti.get('requirement') or {}).get('nombre')}",
                    action_type="run_compliance_matrix",
                    area="matriz_cumplimiento",
                    payload={"requirement_id": rid},
                ))

        if settings.dgcp_product_intelligence:
            actions.append(DGCPOfferPreparationAutoAction(
                id="run-tech-intel",
                label="Analizar pliego técnico",
                action_type="run_technical_intelligence",
                area="oferta_tecnica",
            ))

        actions.append(DGCPOfferPreparationAutoAction(
            id="gen-consolidated",
            label="Generar borrador oferta técnica consolidada",
            action_type="generate_consolidated_offer",
            area="oferta_tecnica",
        ))
        actions.append(DGCPOfferPreparationAutoAction(
            id="refresh-expediente",
            label="Actualizar expediente",
            action_type="prepare_expediente",
            area="documentacion",
        ))

        return actions[:20]

    def _human_decisions(self, pkg: DGCPBidPackage, manifest: dict) -> list[DGCPOfferPreparationHumanDecision]:
        decisions: list[DGCPOfferPreparationHumanDecision] = []

        for ti in (manifest.get("product_intelligence") or {}).get("items") or []:
            if ti.get("status") != "aprobado":
                decisions.append(DGCPOfferPreparationHumanDecision(
                    id=f"approve-product-{ti.get('requirement', {}).get('id')}",
                    label=f"Seleccionar modelo final: {(ti.get('requirement') or {}).get('nombre')}",
                    area="oferta_tecnica",
                    reason="Requiere validación humana del bien ofertado",
                ))
            for row in ti.get("compliance_matrix") or []:
                if row.get("cumple") == "requiere_revision":
                    decisions.append(DGCPOfferPreparationHumanDecision(
                        id=f"validate-row-{hash(row.get('requisito', '')) % 100000}",
                        label=f"Validar cumplimiento: {row.get('requisito')}",
                        area="matriz_cumplimiento",
                        reason=row.get("observacion"),
                    ))

        for sheet in DGCPOfferPreparationCenterService._coalesce_technical_sheets(manifest):
            st = sheet.get("status") or ""
            if st in ("borrador_generado", "requiere_revision"):
                decisions.append(DGCPOfferPreparationHumanDecision(
                    id=f"approve-sheet-{sheet.get('id')}",
                    label=f"Aprobar ficha: {sheet.get('required_product_name')}",
                    area="fichas_tecnicas",
                    reason="Borrador generado — pendiente aprobación",
                    payload={"sheet_id": sheet.get("id")},
                ))
            elif st in ("pendiente_producto", "detectada", "lista_para_generar"):
                decisions.append(DGCPOfferPreparationHumanDecision(
                    id=f"select-product-{sheet.get('id')}",
                    label=f"Seleccionar modelo final: {sheet.get('required_product_name')}",
                    area="fichas_tecnicas",
                    reason="Requiere validación humana del bien ofertado",
                    payload={"sheet_id": sheet.get("id")},
                ))

        consolidated = manifest.get("consolidated_technical_offer") or {}
        if consolidated.get("status") == "borrador":
            decisions.append(DGCPOfferPreparationHumanDecision(
                id="approve-consolidated",
                label="Aprobar oferta técnica consolidada",
                area="oferta_tecnica",
                reason="Documento en BORRADOR hasta aprobación explícita",
            ))

        return decisions[:20]

    def _consolidate_risks(
        self,
        opportunity: DGCPOpportunity,
        pkg: DGCPBidPackage,
        manifest: dict,
    ) -> list[DGCPOfferPreparationRisk]:
        risks: list[DGCPOfferPreparationRisk] = []
        seen: set[str] = set()

        def add(
            nivel: str,
            desc: str,
            fuente: str | None = None,
            evidencia: str | None = None,
            documento_origen: str | None = None,
        ) -> None:
            desc = (desc or "").strip()
            if not desc:
                return
            key = desc[:120].lower()
            if key in seen:
                return
            seen.add(key)
            risks.append(DGCPOfferPreparationRisk(
                nivel=nivel,
                descripcion=desc,
                fuente=fuente,
                evidencia=self._risk_evidencia(evidencia),
                documento_origen=documento_origen,
            ))

        hermes = manifest.get("hermes_document_analysis") or {}
        for hr in hermes.get("risks") or []:
            if isinstance(hr, dict):
                add(
                    (hr.get("nivel") or "medio").lower(),
                    hr.get("descripcion") or "",
                    "Hermes",
                    hr.get("evidencia") or hr.get("fragmento") or hr.get("source_text"),
                    hr.get("documento_origen") or hr.get("source_document") or hr.get("documento"),
                )
            elif isinstance(hr, str):
                add("medio", hr, "Hermes")

        blocking_keys = {
            (item.get("requirement") or "").lower()
            for item in (pkg.checklist or [])
            if item.get("mandatory", True)
            and (item.get("status") or "") in BLOCKING_STATUSES
            and not self._is_task_recommendation(item)
        }
        for r in pkg.requirement_risks or []:
            if not isinstance(r, dict):
                continue
            desc = r.get("descripcion") or ""
            if any(desc.lower().startswith(prefix) for prefix in TASK_RECOMMENDATION_PREFIXES):
                continue
            if ": Documento encontrado" in desc and "pendiente de lectura" in desc:
                continue
            if ": Documento encontrado" in desc and "vigencia" in desc.lower():
                continue
            req_name = desc.split(":", 1)[0].strip().lower()
            if req_name and req_name not in blocking_keys and "Expediente incompleto" not in desc:
                if r.get("nivel", "medio") in ("alto", "high") and "sin documento" not in desc.lower():
                    continue
            add(
                r.get("nivel", "medio"),
                desc,
                r.get("fuente", "Análisis"),
                r.get("evidencia") or r.get("fragmento"),
                r.get("documento_origen"),
            )

        for r in opportunity.risks or []:
            if isinstance(r, dict):
                add(
                    r.get("nivel", "medio"),
                    r.get("descripcion", r.get("text", "")),
                    "Licitación",
                    r.get("evidencia") or r.get("fragmento"),
                    r.get("documento_origen"),
                )
            elif isinstance(r, str):
                add("medio", r, "Licitación")

        for alert in pkg.alerts or []:
            if isinstance(alert, dict):
                sev = alert.get("severity") or alert.get("nivel") or "medio"
                add(
                    sev,
                    alert.get("message") or alert.get("title") or "",
                    "Alertas expediente",
                    alert.get("evidencia") or alert.get("detail"),
                    alert.get("documento_origen") or alert.get("source_document"),
                )

        order = {"alto": 0, "high": 0, "medio": 1, "medium": 1, "bajo": 2, "low": 2}
        risks.sort(key=lambda x: order.get(x.nivel.lower(), 3))
        return risks[:30]

    @staticmethod
    def _risk_evidencia(raw: str | None) -> str:
        text = (raw or "").strip()
        return text if text else EVIDENCIA_NO_DISPONIBLE

    @staticmethod
    def _consolidated_state(manifest: dict) -> DGCPOfferPreparationConsolidatedOffer:
        block = manifest.get("consolidated_technical_offer") or {}
        return DGCPOfferPreparationConsolidatedOffer(
            status=block.get("status") or "sin_generar",
            generated_at=block.get("generated_at"),
            filename=block.get("filename"),
            sections=block.get("sections") or [],
            preview_excerpt=block.get("preview_excerpt"),
        )

    async def _cache_summary(self, pkg: DGCPBidPackage, response: DGCPOfferPreparationCenterResponse) -> None:
        from datetime import datetime, timezone

        try:
            manifest = copy.deepcopy(pkg.manifest or {})
            manifest[self.MANIFEST_KEY] = {
                "overall_preparation_pct": response.executive_summary.overall_preparation_pct,
                "critical_count": len(response.critical_pending),
                "minor_count": len(response.minor_pending),
                "areas": [a.model_dump() for a in response.areas],
                "cached_at": datetime.now(timezone.utc).isoformat(),
            }
            pkg.manifest = manifest
            flag_modified(pkg, "manifest")
            await self.db.commit()
        except Exception:
            await self.db.rollback()

    @staticmethod
    def _company_key(opportunity: DGCPOpportunity) -> str:
        key = (opportunity.company or "justech").strip()
        return key if key and key != "unclassified" else "justech"

    async def _get_opportunity(self, opportunity_id: uuid.UUID) -> DGCPOpportunity | None:
        result = await self.db.execute(
            select(DGCPOpportunity).where(
                DGCPOpportunity.id == opportunity_id,
                DGCPOpportunity.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _get_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage | None:
        result = await self.db.execute(
            select(DGCPBidPackage).where(
                DGCPBidPackage.opportunity_id == opportunity_id,
                DGCPBidPackage.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _require_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity_id)
        if not pkg:
            raise ValueError("Expediente no analizado — ejecute análisis de requisitos primero.")
        return pkg
