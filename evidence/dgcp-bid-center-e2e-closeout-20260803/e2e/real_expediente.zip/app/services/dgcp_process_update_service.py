"""Monitor de actualizaciones y enmiendas DGCP — Fase 6.4 (dentro del expediente)."""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import uuid
from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from app.config import settings
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.dgcp_process_document import DGCPProcessDocument
from app.schemas.dgcp_process_updates import (
    DGCPProcessDocumentSnapshot,
    DGCPProcessSnapshot,
    DGCPProcessUpdateDashboardItem,
    DGCPProcessUpdateDashboardResponse,
    DGCPProcessUpdateRecord,
    DGCPProcessUpdatesMeta,
    DGCPProcessUpdatesResponse,
)
from app.services.dgcp_bid_package_service import (
    EXPEDIENTE_TRACKING_STATUSES,
    OPERATIONAL_INTEREST_STATUSES,
)

logger = logging.getLogger(__name__)

MANIFEST_SNAPSHOT_KEY = "process_update_snapshot"
MANIFEST_UPDATES_KEY = "process_updates"
MANIFEST_META_KEY = "process_updates_meta"

TRACKED_STATUSES = OPERATIONAL_INTEREST_STATUSES | frozenset({
    "preparing",
    "pending_documents",
    "ready_to_submit",
    "to_review",
    "review",
    "analyzing",
    "qualified",
})

SIMULATE_SCENARIOS: dict[str, dict[str, Any]] = {
    "nuevo_documento": {
        "change_type": "documento_nuevo",
        "description": "[Simulación QA] Nuevo documento publicado: Circular aclaratoria N° 1",
        "impact": "requiere_revision",
        "affected_document": "Circular aclaratoria N° 1",
        "recommended_action": "Revisar documento y actualizar checklist si aplica.",
        "suggestions": ["update_checklist", "reanalyze_hermes"],
        "requires_reanalysis": True,
    },
    "fecha_cambiada": {
        "change_type": "fecha_cambiada",
        "description": "[Simulación QA] Fecha límite de recepción de ofertas extendida",
        "impact": "critico",
        "recommended_action": "Actualizar cronograma interno y validar preparación del expediente.",
        "suggestions": ["update_checklist"],
        "requires_reanalysis": False,
        "diff": {"deadline": {"before": "2026-07-03", "after": "2026-07-17"}},
    },
    "enmienda": {
        "change_type": "enmienda",
        "description": "[Simulación QA] Enmienda al pliego — especificaciones técnicas modificadas",
        "impact": "critico",
        "affected_document": "Pliego de condiciones (enmienda)",
        "recommended_action": "Revisar enmienda, reanalizar pliego y validar fichas técnicas.",
        "suggestions": ["reanalyze_hermes", "update_checklist", "review_technical_sheets", "review_compliance_matrix"],
        "requires_reanalysis": True,
    },
    "estado_cambiado": {
        "change_type": "estado_cambiado",
        "description": "[Simulación QA] Estado del proceso cambió en portal DGCP",
        "impact": "requiere_revision",
        "recommended_action": "Confirmar estado en portal y ajustar plan de participación.",
        "suggestions": ["update_checklist"],
        "requires_reanalysis": False,
        "diff": {"dgcp_status": {"before": "Proceso publicado", "after": "Proceso en evaluación"}},
    },
    "documento_reemplazado": {
        "change_type": "documento_reemplazado",
        "description": "[Simulación QA] Pliego reemplazado por nueva versión",
        "impact": "critico",
        "affected_document": "Pliego de condiciones",
        "recommended_action": "Comparar versiones; no modificar documentos aprobados sin revisión humana.",
        "suggestions": ["reanalyze_hermes", "review_technical_sheets", "review_compliance_matrix"],
        "requires_reanalysis": True,
    },
}


class DGCPProcessUpdateService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_process_updates)

    async def get_updates(self, opportunity_id: uuid.UUID) -> DGCPProcessUpdatesResponse:
        opp = await self._get_opportunity(opportunity_id)
        if not opp:
            raise ValueError("Licitación no encontrada")
        pkg = await self._get_package(opportunity_id)
        manifest = (pkg.manifest if pkg else None) or {}
        visible = self._visible_updates(manifest)
        return DGCPProcessUpdatesResponse(
            opportunity_id=opportunity_id,
            enabled=self.enabled(),
            snapshot=self._load_snapshot(manifest),
            updates=[DGCPProcessUpdateRecord.model_validate(u) for u in visible],
            meta=self._meta_for_visible(manifest, visible),
        )

    @staticmethod
    def _include_simulate_updates() -> bool:
        from app.config import settings

        return settings.app_debug or settings.app_env != "production"

    @classmethod
    def _visible_updates(cls, manifest: dict) -> list[dict]:
        updates = manifest.get(MANIFEST_UPDATES_KEY) or []
        if cls._include_simulate_updates():
            return updates
        return [u for u in updates if u.get("source") != "simulate"]

    @staticmethod
    def _meta_for_visible(manifest: dict, visible: list[dict]) -> "DGCPProcessUpdatesMeta":
        from app.schemas.dgcp_process_updates import DGCPProcessUpdatesMeta

        base = DGCPProcessUpdateService._load_meta(manifest)
        if DGCPProcessUpdateService._include_simulate_updates():
            return base
        pending = [u for u in visible if u.get("review_status", "pendiente") == "pendiente"]
        critical = [u for u in pending if u.get("impact") == "critico"]
        requires = any(
            u.get("requires_reanalysis") and u.get("review_status") == "pendiente" for u in visible
        )
        return DGCPProcessUpdatesMeta(
            pending_count=len(pending),
            critical_count=len(critical),
            requires_reanalysis=requires,
            last_checked_at=base.last_checked_at,
            last_change_at=base.last_change_at,
            notification_hook_ready=base.notification_hook_ready,
        )

    async def save_snapshot_on_analyze(self, opportunity_id: uuid.UUID) -> None:
        if not self.enabled():
            return
        opp = await self._get_opportunity(opportunity_id)
        if not opp:
            return
        docs = await self._load_process_documents(opportunity_id)
        summary = await self._process_docs_summary(opportunity_id)
        snapshot = self.build_snapshot(opp, docs, summary)
        pkg = await self._get_or_create_package(opportunity_id)
        manifest = copy.deepcopy(pkg.manifest or {})
        manifest[MANIFEST_SNAPSHOT_KEY] = snapshot.model_dump()
        meta = self._load_meta(manifest)
        meta.last_checked_at = datetime.now(timezone.utc).isoformat()
        manifest[MANIFEST_META_KEY] = meta.model_dump()
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.flush()

    async def check_after_portal_sync(
        self,
        opportunity: DGCPOpportunity,
        *,
        previous_payload: dict | None = None,
    ) -> list[DGCPProcessUpdateRecord]:
        if not self.enabled() or opportunity.status not in TRACKED_STATUSES:
            return []
        pkg = await self._get_package(opportunity.id)
        manifest = (pkg.manifest if pkg else None) or {}
        old_snapshot = self._load_snapshot(manifest)
        if not old_snapshot and previous_payload:
            old_snapshot = self.build_snapshot_from_payload(previous_payload, opportunity)

        docs = await self._load_process_documents(opportunity.id)
        summary = (pkg.process_documents_summary if pkg else None) or []
        new_snapshot = self.build_snapshot(opportunity, docs, summary)

        if not old_snapshot:
            if pkg:
                manifest[MANIFEST_SNAPSHOT_KEY] = new_snapshot.model_dump()
                pkg.manifest = manifest
                flag_modified(pkg, "manifest")
            return []

        updates = self.compare_snapshots(old_snapshot, new_snapshot)
        if not updates:
            return []

        return await self._record_updates(opportunity.id, updates, new_snapshot, source="portal_sync")

    async def check_now(self, opportunity_id: uuid.UUID) -> DGCPProcessUpdatesResponse:
        if not self.enabled():
            raise ValueError("Monitor de actualizaciones deshabilitado (DGCP_PROCESS_UPDATES=false)")
        opp = await self._get_opportunity(opportunity_id)
        if not opp:
            raise ValueError("Licitación no encontrada")
        pkg = await self._get_package(opportunity_id)
        manifest = (pkg.manifest if pkg else None) or {}
        old_snapshot = self._load_snapshot(manifest)
        docs = await self._load_process_documents(opportunity_id)
        summary = (pkg.process_documents_summary if pkg else None) or []
        new_snapshot = self.build_snapshot(opp, docs, summary)
        if old_snapshot:
            updates = self.compare_snapshots(old_snapshot, new_snapshot)
            if updates:
                await self._record_updates(opportunity_id, updates, new_snapshot, source="manual_check")
        elif pkg:
            manifest[MANIFEST_SNAPSHOT_KEY] = new_snapshot.model_dump()
            meta = self._load_meta(manifest)
            meta.last_checked_at = datetime.now(timezone.utc).isoformat()
            manifest[MANIFEST_META_KEY] = meta.model_dump()
            pkg.manifest = manifest
            flag_modified(pkg, "manifest")
            await self.db.flush()
        await self.db.commit()
        return await self.get_updates(opportunity_id)

    async def mark_reviewed(self, opportunity_id: uuid.UUID, update_id: str, note: str | None = None) -> DGCPProcessUpdateRecord:
        return await self._set_review_status(opportunity_id, update_id, "revisado", note)

    async def mark_applied(self, opportunity_id: uuid.UUID, update_id: str, note: str | None = None) -> DGCPProcessUpdateRecord:
        return await self._set_review_status(opportunity_id, update_id, "aplicado", note)

    async def simulate(self, opportunity_id: uuid.UUID, scenarios: list[str]) -> DGCPProcessUpdatesResponse:
        if not self.enabled():
            raise ValueError("Monitor de actualizaciones deshabilitado")
        if not scenarios:
            raise ValueError("Indique al menos un escenario de simulación")
        now = datetime.now(timezone.utc).isoformat()
        updates: list[DGCPProcessUpdateRecord] = []
        for key in scenarios:
            spec = SIMULATE_SCENARIOS.get(key)
            if not spec:
                continue
            updates.append(DGCPProcessUpdateRecord(
                id=str(uuid.uuid4()),
                detected_at=now,
                source="simulate",
                review_status="pendiente",
                **spec,
            ))
        if not updates:
            raise ValueError(f"Escenarios no reconocidos: {', '.join(scenarios)}")

        pkg = await self._get_or_create_package(opportunity_id)
        manifest = copy.deepcopy(pkg.manifest or {})
        history = list(manifest.get(MANIFEST_UPDATES_KEY) or [])
        history.extend(u.model_dump() for u in updates)
        manifest[MANIFEST_UPDATES_KEY] = history[-200:]
        self._refresh_meta(manifest, history)
        if self._load_meta(manifest).requires_reanalysis:
            pkg.expediente_status = "requiere_reanalisis"
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.commit()
        for u in updates:
            self._emit_notification_hook(opportunity_id, u)
        return await self.get_updates(opportunity_id)

    async def dashboard(self) -> DGCPProcessUpdateDashboardResponse:
        if not self.enabled():
            return DGCPProcessUpdateDashboardResponse(enabled=False, total_pending=0, total_critical=0)

        result = await self.db.execute(
            select(DGCPBidPackage, DGCPOpportunity)
            .join(DGCPOpportunity, DGCPOpportunity.id == DGCPBidPackage.opportunity_id)
            .where(
                DGCPBidPackage.tenant_id == self.tenant_id,
                DGCPOpportunity.status.in_(tuple(TRACKED_STATUSES)),
            )
        )
        items: list[DGCPProcessUpdateDashboardItem] = []
        total_pending = 0
        total_critical = 0
        for pkg, opp in result.all():
            meta = self._load_meta(pkg.manifest or {})
            if meta.pending_count <= 0:
                continue
            items.append(DGCPProcessUpdateDashboardItem(
                opportunity_id=opp.id,
                process_code=opp.code,
                title=opp.title,
                pending_count=meta.pending_count,
                critical_count=meta.critical_count,
                requires_reanalysis=meta.requires_reanalysis,
                last_change_at=meta.last_change_at,
            ))
            total_pending += meta.pending_count
            total_critical += meta.critical_count

        items.sort(key=lambda x: (x.critical_count, x.pending_count), reverse=True)
        return DGCPProcessUpdateDashboardResponse(
            enabled=True,
            total_pending=total_pending,
            total_critical=total_critical,
            items=items[:50],
        )

    def build_snapshot(
        self,
        opportunity: DGCPOpportunity,
        docs: list[DGCPProcessDocument],
        summary: list[dict] | None = None,
    ) -> DGCPProcessSnapshot:
        payload = opportunity.raw_payload or opportunity.full_info or {}
        dates = self._extract_dates(payload, opportunity)
        doc_snaps = self._document_snapshots(docs, summary)
        core = {
            "dgcp_status": opportunity.dgcp_status,
            "deadline": opportunity.deadline.isoformat() if isinstance(opportunity.deadline, date) else None,
            "monto_estimado": float(opportunity.amount or 0),
            "dates": dates,
            "description_hash": self._hash_text(opportunity.description or ""),
            "payload_hash": self._hash_json(payload),
        }
        return DGCPProcessSnapshot(
            snapshot_at=datetime.now(timezone.utc).isoformat(),
            snapshot_hash=self._hash_json({**core, "documents": [d.model_dump() for d in doc_snaps]}),
            **core,
            documents=doc_snaps,
        )

    @staticmethod
    def build_snapshot_from_payload(payload: dict, opportunity: DGCPOpportunity) -> DGCPProcessSnapshot:
        dates = DGCPProcessUpdateService._extract_dates(payload, opportunity)
        core = {
            "dgcp_status": payload.get("estado_proceso") or opportunity.dgcp_status,
            "deadline": opportunity.deadline.isoformat() if isinstance(opportunity.deadline, date) else None,
            "monto_estimado": float(payload.get("monto_estimado") or opportunity.amount or 0),
            "dates": dates,
            "description_hash": DGCPProcessUpdateService._hash_text(payload.get("descripcion") or opportunity.description or ""),
            "payload_hash": DGCPProcessUpdateService._hash_json(payload),
        }
        return DGCPProcessSnapshot(
            snapshot_at=datetime.now(timezone.utc).isoformat(),
            snapshot_hash=DGCPProcessUpdateService._hash_json({**core, "documents": []}),
            **core,
            documents=[],
        )

    def compare_snapshots(
        self,
        old: DGCPProcessSnapshot,
        new: DGCPProcessSnapshot,
    ) -> list[DGCPProcessUpdateRecord]:
        updates: list[DGCPProcessUpdateRecord] = []
        now = datetime.now(timezone.utc).isoformat()

        if old.dgcp_status != new.dgcp_status and new.dgcp_status:
            ctype, impact = self._classify_status_change(new.dgcp_status or "")
            updates.append(self._make_update(
                now,
                ctype,
                f"Estado del proceso: {old.dgcp_status or '—'} → {new.dgcp_status}",
                impact,
                diff={"dgcp_status": {"before": old.dgcp_status, "after": new.dgcp_status}},
            ))

        if old.deadline != new.deadline and new.deadline:
            impact = "critico" if self._is_deadline_extension(old.deadline, new.deadline) else "requiere_revision"
            ctype = "extension_plazo" if impact == "critico" else "fecha_cambiada"
            updates.append(self._make_update(
                now,
                ctype,
                f"Fecha límite: {old.deadline or '—'} → {new.deadline}",
                impact,
                recommended="Actualizar cronograma interno y validar preparación.",
                suggestions=["update_checklist"],
                diff={"deadline": {"before": old.deadline, "after": new.deadline}},
            ))

        if old.dates.get("fecha_enmienda") != new.dates.get("fecha_enmienda") and new.dates.get("fecha_enmienda"):
            updates.append(self._make_update(
                now,
                "enmienda",
                f"Nueva enmienda registrada ({new.dates.get('fecha_enmienda')})",
                "critico",
                affected="Pliego / anexos",
                recommended="Revisar enmienda y reanalizar requisitos técnicos.",
                suggestions=["reanalyze_hermes", "update_checklist", "review_technical_sheets", "review_compliance_matrix"],
                requires_reanalysis=True,
                diff={"fecha_enmienda": {"before": old.dates.get("fecha_enmienda"), "after": new.dates.get("fecha_enmienda")}},
            ))

        schedule_keys = (
            "fecha_fin_recepcion_ofertas",
            "fecha_apertura_ofertas",
            "fecha_estimada_adjudicacion",
            "fecha_habilitacion_oferente",
        )
        schedule_diff = {
            k: {"before": old.dates.get(k), "after": new.dates.get(k)}
            for k in schedule_keys
            if old.dates.get(k) != new.dates.get(k) and new.dates.get(k)
        }
        if schedule_diff:
            updates.append(self._make_update(
                now,
                "cronograma_cambiado",
                "Cronograma del proceso actualizado en portal DGCP",
                "requiere_revision",
                recommended="Revisar fechas del cronograma y ajustar plan interno.",
                suggestions=["update_checklist"],
                diff={"schedule": schedule_diff},
            ))

        if old.description_hash != new.description_hash and new.description_hash:
            updates.append(self._make_update(
                now,
                "pliego_modificado",
                "Descripción o objeto del proceso modificado en portal",
                "requiere_revision",
                recommended="Comparar texto publicado y validar si afecta requisitos.",
                suggestions=["reanalyze_hermes", "update_checklist"],
                requires_reanalysis=True,
            ))

        if old.monto_estimado != new.monto_estimado and new.monto_estimado is not None:
            updates.append(self._make_update(
                now,
                "otro",
                f"Monto estimado: {old.monto_estimado} → {new.monto_estimado}",
                "informativo",
                recommended="Verificar impacto en garantías y oferta económica.",
                suggestions=["update_checklist"],
            ))

        old_docs = {d.fingerprint: d for d in old.documents}
        new_docs = {d.fingerprint: d for d in new.documents}
        old_by_title = {(d.title.lower(), d.doc_role): d for d in old.documents}

        for fp, doc in new_docs.items():
            if fp not in old_docs:
                key = (doc.title.lower(), doc.doc_role)
                if key in old_by_title:
                    continue
                ctype = self._doc_change_type(doc.doc_role)
                impact = "critico" if doc.doc_role in ("pliego", "tdr", "enmienda", "especificaciones") else "requiere_revision"
                updates.append(self._make_update(
                    now,
                    ctype,
                    f"Nuevo documento detectado: {doc.title}",
                    impact,
                    affected=doc.title,
                    recommended="Revisar documento publicado; no alterar aprobados sin confirmación.",
                    suggestions=self._suggestions_for_doc(doc.doc_role, impact),
                    requires_reanalysis=impact != "informativo",
                ))

        for key, old_doc in old_by_title.items():
            matching = [d for d in new.documents if (d.title.lower(), d.doc_role) == key]
            if not matching:
                continue
            new_doc = matching[0]
            if old_doc.fingerprint != new_doc.fingerprint and new_doc.fingerprint in new_docs:
                updates.append(self._make_update(
                    now,
                    "documento_reemplazado",
                    f"Documento reemplazado o actualizado: {new_doc.title}",
                    "critico" if new_doc.doc_role in ("pliego", "tdr", "enmienda") else "requiere_revision",
                    affected=new_doc.title,
                    recommended="Comparar versiones; mantener documentos aprobados hasta revisión humana.",
                    suggestions=self._suggestions_for_doc(new_doc.doc_role, "critico"),
                    requires_reanalysis=True,
                    diff={"fingerprint": {"before": old_doc.fingerprint, "after": new_doc.fingerprint}},
                ))

        return updates

    async def _record_updates(
        self,
        opportunity_id: uuid.UUID,
        updates: list[DGCPProcessUpdateRecord],
        new_snapshot: DGCPProcessSnapshot,
        *,
        source: str,
    ) -> list[DGCPProcessUpdateRecord]:
        pkg = await self._get_or_create_package(opportunity_id)
        manifest = copy.deepcopy(pkg.manifest or {})
        history = list(manifest.get(MANIFEST_UPDATES_KEY) or [])
        for u in updates:
            u.source = source
            history.append(u.model_dump())
            self._emit_notification_hook(opportunity_id, u)
        manifest[MANIFEST_UPDATES_KEY] = history[-200:]
        manifest[MANIFEST_SNAPSHOT_KEY] = new_snapshot.model_dump()
        self._refresh_meta(manifest, history)

        if self._load_meta(manifest).requires_reanalysis:
            if pkg.expediente_status not in EXPEDIENTE_TRACKING_STATUSES:
                pkg.expediente_status = "requiere_reanalisis"

        from app.services.dgcp_expediente_event_service import DGCPExpedienteEventService

        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await DGCPExpedienteEventService.publish(
            pkg,
            event_type="portal_process_changed",
            actor_id=self.user_id,
            detail={"updates": [u.model_dump() for u in updates[-5:]]},
        )
        await self.db.flush()
        return updates

    async def _set_review_status(
        self,
        opportunity_id: uuid.UUID,
        update_id: str,
        status: str,
        note: str | None,
    ) -> DGCPProcessUpdateRecord:
        pkg = await self._get_package(opportunity_id)
        if not pkg:
            raise ValueError("Expediente no encontrado")
        manifest = copy.deepcopy(pkg.manifest or {})
        history = list(manifest.get(MANIFEST_UPDATES_KEY) or [])
        found: DGCPProcessUpdateRecord | None = None
        for item in history:
            if item.get("id") == update_id:
                item["review_status"] = status
                if note:
                    item["review_note"] = note
                found = DGCPProcessUpdateRecord.model_validate(item)
                break
        if not found:
            raise ValueError("Actualización no encontrada")
        manifest[MANIFEST_UPDATES_KEY] = history
        self._refresh_meta(manifest, history)
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.commit()
        return found

    @staticmethod
    def _make_update(
        detected_at: str,
        change_type: str,
        description: str,
        impact: str,
        *,
        affected: str | None = None,
        recommended: str | None = None,
        suggestions: list[str] | None = None,
        requires_reanalysis: bool = False,
        diff: dict | None = None,
    ) -> DGCPProcessUpdateRecord:
        return DGCPProcessUpdateRecord(
            id=str(uuid.uuid4()),
            detected_at=detected_at,
            change_type=change_type,  # type: ignore[arg-type]
            description=description,
            impact=impact,  # type: ignore[arg-type]
            affected_document=affected,
            recommended_action=recommended or DGCPProcessUpdateService._default_action(impact),
            suggestions=suggestions or [],
            requires_reanalysis=requires_reanalysis,
            diff=diff or {},
        )

    @staticmethod
    def _default_action(impact: str) -> str:
        return {
            "critico": "Revisar de inmediato y planificar reanálisis del expediente.",
            "requiere_revision": "Revisar cambio y confirmar impacto en preparación.",
            "informativo": "Registrar para seguimiento — sin acción urgente.",
        }.get(impact, "Revisar cambio publicado.")

    @staticmethod
    def _classify_status_change(status: str) -> tuple[str, str]:
        low = status.lower()
        if any(k in low for k in ("adjudic", "award")):
            return "adjudicacion", "critico"
        if any(k in low for k in ("cancel", "anul", "desierto")):
            return "cancelacion", "critico"
        if "suspend" in low:
            return "suspension", "critico"
        return "estado_cambiado", "requiere_revision"

    @staticmethod
    def _doc_change_type(doc_role: str) -> str:
        if doc_role == "enmienda":
            return "enmienda"
        if doc_role in ("circular", "aclaratoria"):
            return "circular"
        if doc_role in ("preguntas", "respuestas"):
            return "respuesta_preguntas"
        return "documento_nuevo"

    @staticmethod
    def _suggestions_for_doc(doc_role: str, impact: str) -> list[str]:
        base = ["update_checklist"]
        if impact == "critico" or doc_role in ("pliego", "tdr", "enmienda", "especificaciones"):
            base.extend(["reanalyze_hermes", "review_technical_sheets", "review_compliance_matrix"])
        return list(dict.fromkeys(base))

    @staticmethod
    def _is_deadline_extension(before: str | None, after: str | None) -> bool:
        if not before or not after:
            return False
        try:
            return date.fromisoformat(after) > date.fromisoformat(before)
        except ValueError:
            return False

    @staticmethod
    def _extract_dates(payload: dict, opportunity: DGCPOpportunity) -> dict[str, str | None]:
        def norm(val: Any) -> str | None:
            if val is None:
                return None
            if isinstance(val, datetime):
                return val.date().isoformat()
            if isinstance(val, date):
                return val.isoformat()
            return str(val)[:32]

        return {
            "fecha_enmienda": norm(payload.get("fecha_enmienda")),
            "fecha_fin_recepcion_ofertas": norm(payload.get("fecha_fin_recepcion_ofertas")),
            "fecha_apertura_ofertas": norm(payload.get("fecha_apertura_ofertas")),
            "fecha_estimada_adjudicacion": norm(payload.get("fecha_estimada_adjudicacion")),
            "fecha_habilitacion_oferente": norm(payload.get("fecha_habilitacion_oferente")),
            "fecha_publicacion": norm(payload.get("fecha_publicacion")),
            "deadline": opportunity.deadline.isoformat() if isinstance(opportunity.deadline, date) else None,
        }

    @staticmethod
    def _document_snapshots(
        docs: list[DGCPProcessDocument],
        summary: list[dict] | None,
    ) -> list[DGCPProcessDocumentSnapshot]:
        if docs:
            return [
                DGCPProcessDocumentSnapshot(
                    id=str(d.id),
                    title=d.title,
                    doc_role=d.doc_role,
                    source_url=d.source_url,
                    fingerprint=DGCPProcessUpdateService._doc_fingerprint(d.title, d.source_url, d.doc_role, d.extracted_text, d.ingestion_status),
                )
                for d in docs
            ]
        return [
            DGCPProcessDocumentSnapshot(
                id=str(item.get("id") or item.get("title")),
                title=str(item.get("title") or "Documento"),
                doc_role=str(item.get("doc_role") or "general"),
                source_url=item.get("source_url"),
                fingerprint=DGCPProcessUpdateService._doc_fingerprint(
                    str(item.get("title") or ""),
                    item.get("source_url"),
                    str(item.get("doc_role") or "general"),
                    "1" if item.get("has_text") else "",
                    str(item.get("ingestion_status") or ""),
                ),
            )
            for item in (summary or [])
        ]

    @staticmethod
    def _doc_fingerprint(title: str, url: str | None, role: str, text: str | None, status: str) -> str:
        raw = f"{title}|{url or ''}|{role}|{len(text or '')}|{status}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    @staticmethod
    def _hash_json(data: Any) -> str:
        normalized = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(normalized.encode()).hexdigest()

    @staticmethod
    def _hash_text(text: str) -> str:
        return hashlib.sha256(text.strip().encode()).hexdigest()[:16]

    @staticmethod
    def _load_snapshot(manifest: dict) -> DGCPProcessSnapshot | None:
        raw = manifest.get(MANIFEST_SNAPSHOT_KEY)
        if not raw:
            return None
        return DGCPProcessSnapshot.model_validate(raw)

    @staticmethod
    def _load_meta(manifest: dict) -> DGCPProcessUpdatesMeta:
        raw = manifest.get(MANIFEST_META_KEY) or {}
        return DGCPProcessUpdatesMeta.model_validate(raw)

    @staticmethod
    def _refresh_meta(manifest: dict, history: list[dict]) -> None:
        pending = [h for h in history if h.get("review_status", "pendiente") == "pendiente"]
        critical = [h for h in pending if h.get("impact") == "critico"]
        requires = any(h.get("requires_reanalysis") and h.get("review_status") == "pendiente" for h in history)
        last_change = history[-1].get("detected_at") if history else None
        manifest[MANIFEST_META_KEY] = DGCPProcessUpdatesMeta(
            pending_count=len(pending),
            critical_count=len(critical),
            requires_reanalysis=requires,
            last_checked_at=datetime.now(timezone.utc).isoformat(),
            last_change_at=last_change,
            notification_hook_ready=True,
        ).model_dump()

    @staticmethod
    def _emit_notification_hook(opportunity_id: uuid.UUID, update: DGCPProcessUpdateRecord) -> None:
        """Hook futuro para email/push — sin envío hasta infraestructura segura."""
        logger.info(
            "DGCP process update hook tenant_event opp=%s type=%s impact=%s",
            opportunity_id,
            update.change_type,
            update.impact,
        )

    async def _get_opportunity(self, opportunity_id: uuid.UUID) -> DGCPOpportunity | None:
        result = await self.db.execute(
            select(DGCPOpportunity).where(
                DGCPOpportunity.id == opportunity_id,
                DGCPOpportunity.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _get_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage | None:
        result = await self.db.execute(
            select(DGCPBidPackage).where(
                DGCPBidPackage.opportunity_id == opportunity_id,
                DGCPBidPackage.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _get_or_create_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity_id)
        if pkg:
            return pkg
        pkg = DGCPBidPackage(tenant_id=self.tenant_id, opportunity_id=opportunity_id)
        self.db.add(pkg)
        await self.db.flush()
        return pkg

    async def _load_process_documents(self, opportunity_id: uuid.UUID) -> list[DGCPProcessDocument]:
        result = await self.db.execute(
            select(DGCPProcessDocument).where(
                DGCPProcessDocument.opportunity_id == opportunity_id,
                DGCPProcessDocument.tenant_id == self.tenant_id,
            )
        )
        return list(result.scalars().all())

    async def _process_docs_summary(self, opportunity_id: uuid.UUID) -> list[dict]:
        pkg = await self._get_package(opportunity_id)
        return list(pkg.process_documents_summary or []) if pkg else []
