"""Búsqueda de productos candidatos — Fase 6.2B (Internet, repositorio, comercial)."""

from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.services.commercial_index_search_service import CommercialIndexSearchService
from app.services.hermes_client import HermesClient
from app.services.product_intelligence_repository_service import ProductIntelligenceRepositoryService

logger = logging.getLogger(__name__)

KNOWN_MODEL_HINTS: list[tuple[re.Pattern[str], str, str]] = [
    (re.compile(r"switch.*48.*poe", re.I), "Cisco", "CBS350-48P-4G"),
    (re.compile(r"switch.*48", re.I), "Cisco", "CBS350-48T-4G"),
    (re.compile(r"router.*empresarial", re.I), "Cisco", "ISR4331"),
    (re.compile(r"fortigate|firewall", re.I), "Fortinet", "FortiGate 200F"),
    (re.compile(r"2930f", re.I), "Aruba", "2930F 48G PoE+"),
    (re.compile(r"wifi\s*6|802\.11ax", re.I), "Ubiquiti", "U6-Pro"),
]


class DGCPProductCandidateSearchService:
    """Genera candidate_products[] — comercial nunca marca cumplimiento técnico."""

    def __init__(
        self,
        db: AsyncSession,
        tenant_id: Any,
        *,
        client: HermesClient | None = None,
        repo: ProductIntelligenceRepositoryService | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.client = client or HermesClient()
        self.repo = repo or ProductIntelligenceRepositoryService()

    async def search(
        self,
        requirement: dict[str, Any],
        *,
        include_internet: bool = True,
        include_repository: bool = True,
        include_commercial: bool = True,
    ) -> list[dict[str, Any]]:
        query = self._build_query(requirement)
        candidates: list[dict[str, Any]] = []
        seen: set[str] = set()

        if include_repository:
            for hit in self.repo.search_local(query, manufacturer=requirement.get("categoria")):
                key = (hit.get("filename") or "").lower()
                if key in seen:
                    continue
                seen.add(key)
                model = _model_from_filename(hit.get("filename") or "")
                candidates.append({
                    "id": str(uuid.uuid4()),
                    "manufacturer": hit.get("vendor"),
                    "model": model,
                    "sku": None,
                    "name": hit.get("filename") or model,
                    "datasheet_url": None,
                    "datasheet_path": hit.get("path"),
                    "source": "repositorio_tecnico",
                    "source_type": "repositorio_tecnico",
                    "confidence": hit.get("confidence", 0.7),
                    "is_technical_source": True,
                    "notes": "Documento técnico en repositorio interno",
                })

        if include_internet and settings.dgcp_product_intelligence_internet:
            for c in await self._search_internet(requirement, query):
                key = f"{c.get('manufacturer','')}-{c.get('model','')}".lower()
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(c)

        if include_commercial:
            for c in await self._search_commercial(query, requirement):
                key = f"{c.get('manufacturer','')}-{c.get('model','')}".lower()
                if key in seen:
                    continue
                seen.add(key)
                candidates.append(c)

        if not candidates:
            candidates.extend(self._heuristic_candidates(requirement, seen))

        candidates.sort(key=lambda x: (-float(x.get("confidence") or 0), x.get("name") or ""))
        return candidates[:15]

    async def _search_internet(self, requirement: dict[str, Any], query: str) -> list[dict[str, Any]]:
        if not settings.dgcp_product_intelligence_hermes_enrich:
            return self._internet_offline_hints(requirement)
        if not self.client.is_available():
            return self._internet_offline_hints(requirement)
        category = requirement.get("categoria") or ""
        specs = [s.get("text") for s in (requirement.get("technical_requirements") or []) if s.get("text")]
        system_prompt = (
            "Eres un ingeniero de preventa. Sugiere modelos reales de fabricantes oficiales "
            "que podrían cumplir requisitos de licitación. "
            "Incluye URL de datasheet oficial cuando la conozcas con certeza. "
            "NO uses datos de ERP, ventas ni proveedores. "
            "Si no estás seguro, baja la confianza. Responde SOLO JSON."
        )
        question = json.dumps({
            "task": "find_product_candidates",
            "product_requirement": requirement.get("nombre"),
            "category": category,
            "specs": specs[:12],
            "search_query": f"{category} {query} datasheet official",
            "output_schema": {
                "candidates": [{
                    "manufacturer": "",
                    "model": "",
                    "sku": "",
                    "name": "",
                    "datasheet_url": "",
                    "confidence": 0.0,
                    "notes": "",
                }],
            },
        }, ensure_ascii=False)
        try:
            raw = await self.client.copilot_turn(system_prompt=system_prompt, question=question)
            if not raw:
                return self._internet_offline_hints(requirement)
            content = raw.get("content") or raw.get("answer") or ""
            parsed = _parse_json(content)
            out: list[dict[str, Any]] = []
            for c in (parsed or {}).get("candidates") or []:
                if not isinstance(c, dict) or not (c.get("model") or c.get("name")):
                    continue
                conf = float(c.get("confidence") or 0.5)
                out.append({
                    "id": str(uuid.uuid4()),
                    "manufacturer": c.get("manufacturer"),
                    "model": c.get("model"),
                    "sku": c.get("sku"),
                    "name": c.get("name") or f"{c.get('manufacturer','')} {c.get('model','')}".strip(),
                    "datasheet_url": c.get("datasheet_url"),
                    "datasheet_path": None,
                    "source": "internet",
                    "source_type": "datasheet_oficial" if c.get("datasheet_url") else "hermes_inferencia",
                    "confidence": conf,
                    "is_technical_source": bool(c.get("datasheet_url")) or conf >= 0.75,
                    "notes": c.get("notes") or "Sugerencia Hermes — validar datasheet oficial",
                })
                if c.get("datasheet_url") and conf >= 0.6:
                    stored = await self.repo.store_datasheet(
                        url=c["datasheet_url"],
                        manufacturer=c.get("manufacturer") or "",
                        model=c.get("model") or c.get("name") or "product",
                    )
                    if stored:
                        out[-1]["datasheet_path"] = stored.get("path")
            return out or self._internet_offline_hints(requirement)
        except Exception:
            logger.exception("Internet candidate search failed")
            return self._internet_offline_hints(requirement)

    def _internet_offline_hints(self, requirement: dict[str, Any]) -> list[dict[str, Any]]:
        """Sin Hermes/internet: sugerencias de búsqueda, no productos verificados."""
        text = " ".join([
            requirement.get("nombre") or "",
            " ".join(s.get("text", "") for s in requirement.get("technical_requirements") or []),
        ])
        out: list[dict[str, Any]] = []
        for pat, mfr, model in KNOWN_MODEL_HINTS:
            if pat.search(text):
                out.append({
                    "id": str(uuid.uuid4()),
                    "manufacturer": mfr,
                    "model": model,
                    "sku": None,
                    "name": f"{mfr} {model}",
                    "datasheet_url": None,
                    "datasheet_path": None,
                    "source": "internet",
                    "source_type": "hermes_inferencia",
                    "confidence": 0.35,
                    "is_technical_source": False,
                    "notes": "Sugerencia offline — requiere datasheet oficial para cumplimiento",
                })
        return out

    async def _search_commercial(self, query: str, requirement: dict[str, Any]) -> list[dict[str, Any]]:
        svc = CommercialIndexSearchService(self.db, self.tenant_id)
        try:
            result = await svc.search(query, limit=8)
        except Exception:
            logger.exception("Commercial search failed for product candidates")
            return []
        out: list[dict[str, Any]] = []
        for item in result.items or []:
            name = item.product_name or item.description or ""
            if not name:
                continue
            out.append({
                "id": str(uuid.uuid4()),
                "manufacturer": item.brand,
                "model": item.model,
                "sku": item.sku,
                "name": name,
                "datasheet_url": None,
                "datasheet_path": None,
                "source": "comercial",
                "source_type": "odoo",
                "confidence": min(0.55, float(item.relevance_score or 0) / 100.0 + 0.3),
                "is_technical_source": False,
                "notes": "Solo referencia comercial — NO determina cumplimiento técnico",
                "odoo_product_id": item.product_id,
            })
        return out

    def _heuristic_candidates(self, requirement: dict[str, Any], seen: set[str]) -> list[dict[str, Any]]:
        return self._internet_offline_hints(requirement)

    @staticmethod
    def _build_query(requirement: dict[str, Any]) -> str:
        parts = [requirement.get("nombre") or "", requirement.get("categoria") or ""]
        for spec in requirement.get("technical_requirements") or []:
            parts.append(spec.get("text") or "")
        return " ".join(p for p in parts if p).strip()


def _model_from_filename(name: str) -> str:
    base = re.sub(r"_(datasheet|specs?|manual).*", "", name, flags=re.I)
    return re.sub(r"\.[^.]+$", "", base)


def _parse_json(text: str) -> dict | None:
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
    return None
