"""Enriquecimiento comercial — Fase 6.2F (Odoo/historial, NO cumplimiento técnico)."""

from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.commercial_index_search_service import CommercialIndexSearchService

logger = logging.getLogger(__name__)


class DGCPProductCommercialEnrichmentService:
    DISCLAIMER = "Datos comerciales — no determinan cumplimiento técnico."

    def __init__(self, db: AsyncSession, tenant_id: Any):
        self.db = db
        self.tenant_id = tenant_id

    async def enrich(
        self,
        candidate: dict[str, Any],
        *,
        requirement_name: str | None = None,
    ) -> dict[str, Any]:
        query = " ".join(
            filter(None, [
                candidate.get("manufacturer"),
                candidate.get("model"),
                candidate.get("name"),
                requirement_name,
            ])
        )
        odoo_id = candidate.get("odoo_product_id")
        svc = CommercialIndexSearchService(self.db, self.tenant_id)
        product_name = candidate.get("name")
        last_price = None
        units_sold = None
        last_sale_date = None
        avg_margin = None
        supplier = None

        try:
            if odoo_id:
                hist = await svc.product_history(product_id=int(odoo_id), limit=1)
            else:
                hist = await svc.product_history(query=query, limit=1)
            if hist.items:
                row = hist.items[0]
                product_name = row.product_name or product_name
                odoo_id = odoo_id or row.product_id
                last_price = float(row.avg_unit_price) if row.avg_unit_price else None
                units_sold = float(row.total_quantity) if row.total_quantity else None
                last_sale_date = row.last_sale_date.isoformat() if row.last_sale_date else None

            search = await svc.search(query, limit=3)
            for item in search.items or []:
                if item.supplier_name and not supplier:
                    supplier = item.supplier_name
                if item.unit_price and last_price is None:
                    last_price = float(item.unit_price)
        except Exception:
            logger.exception("Commercial enrichment failed query=%s", query[:80])

        return {
            "odoo_product_id": odoo_id,
            "product_name": product_name,
            "last_cost": None,
            "last_price": last_price,
            "avg_margin_pct": avg_margin,
            "supplier": supplier,
            "units_sold": units_sold,
            "last_sale_date": last_sale_date,
            "currency": "DOP",
            "source": "odoo",
            "disclaimer": self.DISCLAIMER,
        }
