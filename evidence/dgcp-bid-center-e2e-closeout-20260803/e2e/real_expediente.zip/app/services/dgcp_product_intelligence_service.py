"""Capa de inteligencia técnica de licitaciones — expediente (Fase 6.2).

Responde «¿qué bien cumple este requisito del pliego?» dentro del expediente.
No es un módulo de catálogo ni inventario de productos.
"""

from __future__ import annotations

import copy
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from app.config import settings
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.dgcp_product_intelligence import (
    DGCPProductIntelligenceActionResponse,
    DGCPProductIntelligenceApproveRequest,
    DGCPProductIntelligenceItem,
    DGCPProductIntelligenceResponse,
    DGCPProductIntelligenceRunResponse,
    DGCPProductIntelligenceSummary,
)
from app.schemas.dgcp_technical_sheet import DGCPTechSheetSelectProductRequest
from app.services.dgcp_compliance_matrix_service import DGCPComplianceMatrixService
from app.services.dgcp_expediente_event_service import DGCPExpedienteEventService
from app.services.dgcp_product_candidate_search_service import DGCPProductCandidateSearchService
from app.services.dgcp_product_commercial_enrichment_service import DGCPProductCommercialEnrichmentService
from app.services.dgcp_product_requirements_extractor_service import DGCPProductRequirementsExtractorService
from app.services.product_intelligence_repository_service import ProductIntelligenceRepositoryService

logger = logging.getLogger(__name__)


class DGCPProductIntelligenceService:
    MANIFEST_KEY = "product_intelligence"

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.extractor = DGCPProductRequirementsExtractorService()
        self.candidate_search = DGCPProductCandidateSearchService(db, tenant_id)
        self.compliance = DGCPComplianceMatrixService()
        self.commercial = DGCPProductCommercialEnrichmentService(db, tenant_id)
        self.repo = ProductIntelligenceRepositoryService()

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_product_intelligence)

    async def list_intelligence(self, opportunity_id: uuid.UUID) -> DGCPProductIntelligenceResponse:
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._get_package(opportunity_id)
        block = self._read_block(pkg)
        items = [self._to_item(i) for i in block.get("items") or []]
        summary = self._build_summary(items, block)
        return DGCPProductIntelligenceResponse(
            opportunity_id=opportunity_id,
            enabled=self.enabled(),
            summary=summary,
            items=items,
        )

    async def run_pipeline(
        self,
        opportunity_id: uuid.UUID,
        *,
        force: bool = False,
        process_corpus: str | None = None,
    ) -> DGCPProductIntelligenceRunResponse:
        if not self.enabled():
            raise ValueError("Inteligencia técnica deshabilitada (DGCP_PRODUCT_INTELLIGENCE=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._ensure_package(opportunity)

        corpus = process_corpus
        if corpus is None:
            corpus, _ = await self._build_corpus(opportunity_id, pkg)

        existing = {i["requirement"]["id"]: i for i in (self._read_block(pkg).get("items") or [])}
        if existing and not force:
            items = [self._to_item(i) for i in existing.values()]
            summary = self._build_summary(items, self._read_block(pkg))
            return DGCPProductIntelligenceRunResponse(
                opportunity_id=opportunity_id,
                requirements_count=len(items),
                candidates_count=summary.candidates_count,
                summary=summary,
                items=items,
                message="Pipeline ya ejecutado — use force=true para reanalizar.",
            )

        self.repo.ensure_structure()
        requirements, msg = self.extractor.extract(opportunity, pkg, process_corpus=corpus or "")
        if not requirements:
            block = {
                "items": [],
                "message": msg,
                "analyzed_at": datetime.now(timezone.utc).isoformat(),
                "version": 1,
            }
            await self._save_block(pkg, block)
            return DGCPProductIntelligenceRunResponse(
                opportunity_id=opportunity_id,
                requirements_count=0,
                candidates_count=0,
                summary=DGCPProductIntelligenceSummary(message=msg),
                items=[],
                message=msg,
            )

        requirements = await self.extractor.enrich_with_hermes(opportunity, requirements, corpus=corpus or "")
        merged_items: list[dict[str, Any]] = []

        for req in requirements:
            prev = existing.get(req["id"]) or {}
            if prev.get("status") == "aprobado" and not force:
                merged_items.append(prev)
                continue
            candidates = await self.candidate_search.search(req)
            selected_id = prev.get("selected_candidate_id")
            matrix: list[dict] = list(prev.get("compliance_matrix") or [])
            compliance_pct = prev.get("compliance_pct")
            commercial = prev.get("commercial")

            if candidates and not matrix:
                best = self._pick_best_candidate(candidates)
                matrix, compliance_pct = await self.compliance.build_matrix(req, best)
                selected_id = selected_id or best.get("id")
                commercial = await self.commercial.enrich(best, requirement_name=req.get("nombre"))

            merged_items.append({
                "requirement": req,
                "candidates": candidates,
                "selected_candidate_id": selected_id,
                "compliance_matrix": matrix,
                "compliance_pct": compliance_pct,
                "commercial": commercial,
                "recommended": prev.get("recommended", False),
                "technical_sheet_id": prev.get("technical_sheet_id"),
                "status": "matriz_generada" if matrix else ("candidatos_buscados" if candidates else "detectado"),
            })

        self._mark_recommended(merged_items)
        block = {
            "items": merged_items,
            "message": msg,
            "analyzed_at": datetime.now(timezone.utc).isoformat(),
            "version": 1,
        }
        await self._save_block(pkg, block)
        await self._publish_event(pkg, "product_intelligence_completed", {
            "requirements": len(merged_items),
            "candidates": sum(len(i.get("candidates") or []) for i in merged_items),
        })

        items = [self._to_item(i) for i in merged_items]
        summary = self._build_summary(items, block)
        return DGCPProductIntelligenceRunResponse(
            opportunity_id=opportunity_id,
            requirements_count=len(items),
            candidates_count=summary.candidates_count,
            summary=summary,
            items=items,
            message=msg,
        )

    async def run_after_analyze(
        self,
        opportunity_id: uuid.UUID,
        *,
        process_corpus: str = "",
    ) -> None:
        if not self.enabled():
            return
        try:
            await self.run_pipeline(opportunity_id, process_corpus=process_corpus)
        except Exception:
            logger.exception("Product intelligence post-analyze hook failed")

    async def search_candidates(
        self,
        opportunity_id: uuid.UUID,
        requirement_id: str,
        *,
        include_internet: bool = True,
        include_repository: bool = True,
        include_commercial: bool = True,
    ) -> DGCPProductIntelligenceActionResponse:
        pkg = await self._require_package(opportunity_id)
        item = self._get_item_or_raise(pkg, requirement_id)
        req = item["requirement"]
        candidates = await self.candidate_search.search(
            req,
            include_internet=include_internet,
            include_repository=include_repository,
            include_commercial=include_commercial,
        )
        item["candidates"] = candidates
        item["status"] = "candidatos_buscados"
        await self._update_item(pkg, item)
        return DGCPProductIntelligenceActionResponse(
            ok=True,
            item=self._to_item(item),
            message=f"{len(candidates)} candidato(s) encontrado(s).",
        )

    async def build_matrix(
        self,
        opportunity_id: uuid.UUID,
        requirement_id: str,
        candidate_id: str,
    ) -> DGCPProductIntelligenceActionResponse:
        pkg = await self._require_package(opportunity_id)
        item = self._get_item_or_raise(pkg, requirement_id)
        candidate = self._find_candidate(item, candidate_id)
        matrix, pct = await self.compliance.build_matrix(item["requirement"], candidate)
        commercial = await self.commercial.enrich(candidate, requirement_name=item["requirement"].get("nombre"))
        item["selected_candidate_id"] = candidate_id
        item["compliance_matrix"] = matrix
        item["compliance_pct"] = pct
        item["commercial"] = commercial
        item["status"] = "matriz_generada"
        await self._update_item(pkg, item)
        return DGCPProductIntelligenceActionResponse(
            ok=True,
            item=self._to_item(item),
            message=f"Matriz generada — cumplimiento {pct}%.",
        )

    async def approve_product(
        self,
        opportunity_id: uuid.UUID,
        requirement_id: str,
        data: DGCPProductIntelligenceApproveRequest,
    ) -> DGCPProductIntelligenceActionResponse:
        pkg = await self._require_package(opportunity_id)
        item = self._get_item_or_raise(pkg, requirement_id)
        candidate = self._find_candidate(item, data.candidate_id)
        if not item.get("compliance_matrix"):
            matrix, pct = await self.compliance.build_matrix(item["requirement"], candidate)
            item["compliance_matrix"] = matrix
            item["compliance_pct"] = pct
        item["selected_candidate_id"] = data.candidate_id
        item["status"] = "aprobado"
        item["recommended"] = True

        sheet_id = item.get("technical_sheet_id")
        if data.regenerate_sheet:
            sheet_id = await self._sync_technical_sheet(opportunity_id, item, candidate)
            item["technical_sheet_id"] = sheet_id

        await self._update_item(pkg, item)
        block = self._read_block(pkg)
        self._mark_recommended(block.get("items") or [])
        await self._save_block(pkg, block)
        await self._publish_event(pkg, "product_intelligence_approved", {
            "requirement_id": requirement_id,
            "candidate_id": data.candidate_id,
        })
        return DGCPProductIntelligenceActionResponse(
            ok=True,
            item=self._to_item(item),
            message="Producto aprobado para oferta técnica.",
        )

    async def reject_product(
        self,
        opportunity_id: uuid.UUID,
        requirement_id: str,
    ) -> DGCPProductIntelligenceActionResponse:
        pkg = await self._require_package(opportunity_id)
        item = self._get_item_or_raise(pkg, requirement_id)
        item["status"] = "rechazado"
        item["recommended"] = False
        await self._update_item(pkg, item)
        return DGCPProductIntelligenceActionResponse(
            ok=True,
            item=self._to_item(item),
            message="Producto rechazado.",
        )

    async def _sync_technical_sheet(
        self,
        opportunity_id: uuid.UUID,
        item: dict[str, Any],
        candidate: dict[str, Any],
    ) -> str | None:
        from app.services.dgcp_technical_sheet_service import DGCPTechnicalSheetService

        if not DGCPTechnicalSheetService.enabled():
            return item.get("technical_sheet_id")
        ts_svc = DGCPTechnicalSheetService(self.db, self.tenant_id, self.user_id)
        try:
            sheets = await ts_svc.list_sheets(opportunity_id)
            req_name = (item.get("requirement") or {}).get("nombre") or ""
            sheet_id = item.get("technical_sheet_id")
            for s in sheets.items:
                if sheet_id and s.id == sheet_id:
                    break
                if req_name.lower() in (s.required_product_name or "").lower():
                    sheet_id = s.id
                    break
            if not sheet_id:
                await ts_svc.detect(opportunity_id)
                sheets = await ts_svc.list_sheets(opportunity_id)
                for s in sheets.items:
                    if req_name.lower() in (s.required_product_name or "").lower():
                        sheet_id = s.id
                        break
            if not sheet_id:
                return None
            await ts_svc.select_product(
                opportunity_id,
                sheet_id,
                DGCPTechSheetSelectProductRequest(
                    brand=candidate.get("manufacturer"),
                    model=candidate.get("model"),
                    manufacturer=candidate.get("manufacturer"),
                    sku=candidate.get("sku"),
                    description=candidate.get("name"),
                    source="product_intelligence",
                    odoo_product_id=candidate.get("odoo_product_id"),
                ),
            )
            await ts_svc.generate_draft(opportunity_id, sheet_id)
            return sheet_id
        except Exception:
            logger.exception("Could not sync technical sheet for approved product")
            return item.get("technical_sheet_id")

    @staticmethod
    def _pick_best_candidate(candidates: list[dict[str, Any]]) -> dict[str, Any]:
        technical = [c for c in candidates if c.get("is_technical_source")]
        pool = technical or candidates
        return max(pool, key=lambda c: float(c.get("confidence") or 0))

    @staticmethod
    def _mark_recommended(items: list[dict[str, Any]]) -> None:
        best_id = None
        best_score = -1.0
        for item in items:
            if item.get("status") == "aprobado":
                item["recommended"] = True
                continue
            pct = float(item.get("compliance_pct") or 0)
            conf = max(
                (float(c.get("confidence") or 0) for c in (item.get("candidates") or [])),
                default=0.0,
            )
            score = pct * 0.7 + conf * 30
            if score > best_score and item.get("status") != "rechazado":
                best_score = score
                best_id = item["requirement"]["id"]
        for item in items:
            rid = item["requirement"]["id"]
            item["recommended"] = rid == best_id and item.get("status") != "rechazado"

    @staticmethod
    def _to_item(raw: dict[str, Any]) -> DGCPProductIntelligenceItem:
        return DGCPProductIntelligenceItem.model_validate(raw)

    @staticmethod
    def _build_summary(
        items: list[DGCPProductIntelligenceItem],
        block: dict[str, Any],
    ) -> DGCPProductIntelligenceSummary:
        pcts = [i.compliance_pct for i in items if i.compliance_pct is not None]
        approved = [i for i in items if i.status == "aprobado"]
        recommended = next((i for i in items if i.recommended), None)
        rec_label = None
        if recommended and recommended.selected_candidate_id:
            cand = next(
                (c for c in recommended.candidates if c.id == recommended.selected_candidate_id),
                None,
            )
            rec_label = cand.name if cand else recommended.requirement.nombre
        return DGCPProductIntelligenceSummary(
            requirements_count=len(items),
            candidates_count=sum(len(i.candidates) for i in items),
            approved_count=len(approved),
            fichas_generadas=sum(1 for i in items if i.technical_sheet_id),
            avg_compliance_pct=round(sum(pcts) / len(pcts), 1) if pcts else None,
            recommended_product=rec_label,
            message=block.get("message"),
        )

    def _find_candidate(self, item: dict, candidate_id: str) -> dict[str, Any]:
        for c in item.get("candidates") or []:
            if c.get("id") == candidate_id:
                return c
        raise ValueError("Candidato no encontrado")

    async def _get_opportunity(self, opportunity_id: uuid.UUID) -> DGCPOpportunity | None:
        result = await self.db.execute(
            select(DGCPOpportunity).where(
                DGCPOpportunity.id == opportunity_id,
                DGCPOpportunity.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _get_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage | None:
        result = await self.db.execute(
            select(DGCPBidPackage).where(
                DGCPBidPackage.opportunity_id == opportunity_id,
                DGCPBidPackage.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _ensure_package(self, opportunity: DGCPOpportunity) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity.id)
        if pkg:
            return pkg
        pkg = DGCPBidPackage(tenant_id=self.tenant_id, opportunity_id=opportunity.id, manifest={})
        self.db.add(pkg)
        await self.db.commit()
        await self.db.refresh(pkg)
        return pkg

    async def _require_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity_id)
        if not pkg:
            raise ValueError("Expediente no analizado — ejecute análisis de requisitos primero.")
        return pkg

    async def _build_corpus(self, opportunity_id: uuid.UUID, pkg: DGCPBidPackage) -> tuple[str, list]:
        from app.services.dgcp_attachment_ingestion_service import DGCPAttachmentIngestionService

        ingestion = DGCPAttachmentIngestionService(self.db, self.tenant_id, user_id=self.user_id)
        corpus, docs = await ingestion.build_extraction_corpus(opportunity_id)
        if not corpus.strip():
            hermes = (pkg.manifest or {}).get("hermes_document_analysis") or {}
            corpus = str(hermes.get("summary") or "")
        return corpus, docs

    @classmethod
    def _read_block(cls, pkg: DGCPBidPackage | None) -> dict[str, Any]:
        if not pkg or not pkg.manifest:
            return {}
        return copy.deepcopy((pkg.manifest or {}).get(cls.MANIFEST_KEY) or {})

    async def _save_block(self, pkg: DGCPBidPackage, block: dict[str, Any]) -> None:
        manifest = copy.deepcopy(pkg.manifest or {})
        manifest[self.MANIFEST_KEY] = copy.deepcopy(block)
        manifest["product_intelligence_summary"] = self._manifest_summary(manifest[self.MANIFEST_KEY])
        manifest["technical_intelligence_summary"] = manifest["product_intelligence_summary"]
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.commit()
        await self.db.refresh(pkg)

    async def _update_item(self, pkg: DGCPBidPackage, updated: dict[str, Any]) -> None:
        block = self._read_block(pkg)
        rid = updated["requirement"]["id"]
        items = []
        for item in block.get("items") or []:
            if item.get("requirement", {}).get("id") == rid:
                items.append(copy.deepcopy(updated))
            else:
                items.append(copy.deepcopy(item))
        block["items"] = items
        await self._save_block(pkg, block)

    @staticmethod
    def _get_item_or_raise(pkg: DGCPBidPackage, requirement_id: str) -> dict[str, Any]:
        for item in DGCPProductIntelligenceService._read_block(pkg).get("items") or []:
            if item.get("requirement", {}).get("id") == requirement_id:
                return item
        raise ValueError("Requisito de producto no encontrado")

    @staticmethod
    def _manifest_summary(block: dict[str, Any]) -> dict[str, Any]:
        items = block.get("items") or []
        pcts = [i.get("compliance_pct") for i in items if i.get("compliance_pct") is not None]
        return {
            "requirements_count": len(items),
            "approved_count": sum(1 for i in items if i.get("status") == "aprobado"),
            "avg_compliance_pct": round(sum(pcts) / len(pcts), 1) if pcts else None,
            "analyzed_at": block.get("analyzed_at"),
        }

    async def _publish_event(self, pkg: DGCPBidPackage, event_type: str, detail: dict[str, Any]) -> None:
        if not DGCPExpedienteEventService.enabled():
            return
        try:
            await DGCPExpedienteEventService.publish(
                pkg,
                event_type=event_type,
                actor_id=self.user_id,
                detail=detail,
            )
            await self.db.commit()
        except Exception:
            logger.exception("Product intelligence event publish failed")
