"""Extracción de requisitos técnicos por producto — Fase 6.2A."""

from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any

from app.config import settings
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_technical_product_detection_service import DGCPTechnicalProductDetectionService
from app.services.hermes_client import HermesClient

logger = logging.getLogger(__name__)

SPEC_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"(\d+)\s*(?:puertos?|ports?)\s*(?:gigabit|gb)?", re.I), "puertos"),
    (re.compile(r"poe\+?", re.I), "PoE"),
    (re.compile(r"(\d+)\s*w\b", re.I), "potencia"),
    (re.compile(r"(\d+)\s*sfp\+?", re.I), "SFP"),
    (re.compile(r"layer\s*3|l3\b", re.I), "Layer 3"),
    (re.compile(r"garant[ií]a\s*(?:de\s*)?(\d+)\s*a[nñ]os?", re.I), "garantía"),
    (re.compile(r"throughput\s*(?:m[ií]nimo)?\s*[:\-]?\s*(\d+\s*gbps?)", re.I), "throughput"),
    (re.compile(r"802\.11ax|wifi\s*6|wi-?fi\s*6", re.I), "WiFi 6"),
    (re.compile(r"(\d+)\s*va\b", re.I), "capacidad VA"),
    (re.compile(r"dual\s*wan", re.I), "Dual WAN"),
]


class DGCPProductRequirementsExtractorService:
    """Construye manifest.product_requirements[] desde pliego + Hermes."""

    def __init__(self, *, client: HermesClient | None = None):
        self.detector = DGCPTechnicalProductDetectionService()
        self.client = client or HermesClient()

    def extract(
        self,
        opportunity: DGCPOpportunity,
        pkg: DGCPBidPackage | None,
        *,
        process_corpus: str = "",
    ) -> tuple[list[dict[str, Any]], str]:
        manifest = (pkg.manifest if pkg else None) or {}
        hermes = manifest.get("hermes_document_analysis") or {}
        corpus = (process_corpus or "").strip() or str(hermes.get("summary") or "")

        detected, requires, det_msg = self.detector.detect(
            opportunity, pkg, process_corpus=corpus, force=requires_any(hermes, corpus)
        )
        if not detected:
            return [], det_msg or "No se detectaron productos con requisitos técnicos."

        items: list[dict[str, Any]] = []
        for raw in detected:
            name = raw.get("required_product_name") or "Producto"
            specs_text = " ".join(
                filter(None, [
                    raw.get("required_description"),
                    " ".join(raw.get("required_specs") or []),
                    raw.get("source_fragment"),
                ])
            )
            tech_reqs = self._parse_specs(specs_text, raw.get("evidence") or [])
            func_reqs = self._functional_from_label(name, specs_text)
            items.append({
                "id": raw.get("id") or str(uuid.uuid4()),
                "nombre": name,
                "categoria": raw.get("category") or self._guess_category(name),
                "cantidad": self._parse_qty(raw.get("quantity")),
                "unidad": "unidad",
                "technical_requirements": tech_reqs,
                "functional_requirements": func_reqs,
                "status": "detectado",
                "source_fragment": (raw.get("source_fragment") or specs_text)[:2000],
                "confidence": float(raw.get("confidence") or 0.6),
            })
        return items, f"Se extrajeron {len(items)} requisito(s) de producto."

    async def enrich_with_hermes(
        self,
        opportunity: DGCPOpportunity,
        items: list[dict[str, Any]],
        *,
        corpus: str = "",
    ) -> list[dict[str, Any]]:
        if not settings.dgcp_product_intelligence_hermes_enrich:
            return items
        if not self.client.is_available():
            return items
        system_prompt = (
            "Eres un ingeniero de preventa para licitaciones. "
            "Extrae requisitos técnicos y funcionales del pliego por producto. "
            "NO inventes requisitos no presentes en el texto. "
            "Incluye evidencia (fragmento) y confianza 0-1. "
            "Responde SOLO JSON válido."
        )
        question = json.dumps({
            "task": "extract_product_requirements",
            "process": {"code": opportunity.code, "title": opportunity.title},
            "products": [{"id": i["id"], "nombre": i["nombre"]} for i in items],
            "corpus_excerpt": corpus[:8000],
            "output_schema": {
                "items": [{
                    "id": "string",
                    "technical_requirements": [{"text": "", "evidence": "", "page": "", "confidence": 0.0}],
                    "functional_requirements": [{"text": "", "evidence": "", "confidence": 0.0}],
                }],
            },
        }, ensure_ascii=False)
        try:
            raw = await self.client.copilot_turn(system_prompt=system_prompt, question=question)
            if not raw:
                return items
            content = raw.get("content") or raw.get("answer") or ""
            parsed = _parse_json(content)
            if not parsed or not isinstance(parsed.get("items"), list):
                return items
            by_id = {str(x.get("id")): x for x in parsed["items"] if isinstance(x, dict)}
            enriched: list[dict[str, Any]] = []
            for item in items:
                extra = by_id.get(item["id"]) or {}
                merged = dict(item)
                if extra.get("technical_requirements"):
                    merged["technical_requirements"] = _merge_specs(
                        item.get("technical_requirements") or [],
                        extra["technical_requirements"],
                    )
                if extra.get("functional_requirements"):
                    merged["functional_requirements"] = _merge_specs(
                        item.get("functional_requirements") or [],
                        extra["functional_requirements"],
                    )
                merged["confidence"] = max(
                    float(item.get("confidence") or 0),
                    float(extra.get("confidence") or 0),
                )
                enriched.append(merged)
            return enriched
        except Exception:
            logger.exception("Hermes product requirements enrich failed")
            return items

    @staticmethod
    def _parse_specs(text: str, evidence: list[dict]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        seen: set[str] = set()
        frag = evidence[0].get("fragment") if evidence else None
        src_doc = evidence[0].get("document") if evidence else None
        page = evidence[0].get("page") if evidence else None
        for line in re.split(r"[\n;•]", text or ""):
            line = line.strip()
            if len(line) < 4:
                continue
            key = line.lower()[:80]
            if key in seen:
                continue
            seen.add(key)
            out.append({
                "text": line,
                "kind": "tecnico",
                "evidence": frag or line,
                "source_document": src_doc,
                "page": str(page) if page else None,
                "confidence": 0.7 if frag else 0.5,
            })
        for pat, label in SPEC_PATTERNS:
            m = pat.search(text or "")
            if m:
                spec_text = m.group(0).strip()
                key = spec_text.lower()
                if key not in seen:
                    seen.add(key)
                    out.append({
                        "text": f"{label}: {spec_text}",
                        "kind": "tecnico",
                        "evidence": spec_text,
                        "confidence": 0.65,
                    })
        return out

    @staticmethod
    def _functional_from_label(name: str, text: str) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        combined = f"{name} {text}".lower()
        hints = [
            ("administrable", "Equipo administrable / gestionable"),
            ("empresarial", "Grado empresarial"),
            ("rack", "Montaje en rack"),
            ("redundante", "Redundancia"),
        ]
        for token, label in hints:
            if token in combined:
                out.append({"text": label, "kind": "funcional", "confidence": 0.55})
        return out

    @staticmethod
    def _guess_category(name: str) -> str:
        lower = name.lower()
        for token, cat in (
            ("switch", "Switch"), ("router", "Router"), ("access point", "Access Point"),
            ("ups", "UPS"), ("firewall", "Firewall"), ("servidor", "Servidor"),
            ("laptop", "Laptop"), ("monitor", "Monitor"),
        ):
            if token in lower:
                return cat
        return "Equipo"

    @staticmethod
    def _parse_qty(raw: Any) -> float | None:
        if raw is None:
            return None
        m = re.search(r"(\d+(?:\.\d+)?)", str(raw))
        return float(m.group(1)) if m else None


def requires_any(hermes: dict, corpus: str) -> bool:
    text = (corpus + " " + str(hermes.get("summary") or "")).lower()
    return any(k in text for k in ("switch", "router", "equipo", "hardware", "ficha", "técnica", "tecnica"))


def _parse_json(text: str) -> dict | None:
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{[\s\S]*\}", text)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None
    return None


def _merge_specs(existing: list[dict], new: list[dict]) -> list[dict]:
    seen = {s.get("text", "").lower() for s in existing}
    merged = list(existing)
    for spec in new:
        if not isinstance(spec, dict):
            continue
        text = (spec.get("text") or "").strip()
        if not text or text.lower() in seen:
            continue
        seen.add(text.lower())
        merged.append({
            "text": text,
            "kind": spec.get("kind") or "tecnico",
            "evidence": spec.get("evidence"),
            "source_document": spec.get("source_document"),
            "page": spec.get("page"),
            "confidence": float(spec.get("confidence") or 0.6),
        })
    return merged
