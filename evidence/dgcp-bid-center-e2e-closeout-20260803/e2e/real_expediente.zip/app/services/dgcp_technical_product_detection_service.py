"""Detección de productos/ítems que requieren ficha técnica (Fase 6.1)."""

from __future__ import annotations

import re
import uuid
from datetime import datetime, timezone
from typing import Any

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity

# Indica que el pliego pide documentación técnica por producto
TECH_DOC_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"ficha\s+t[eé]cnica", re.I),
    re.compile(r"fichas\s+t[eé]cnicas", re.I),
    re.compile(r"datasheet", re.I),
    re.compile(r"brochure", re.I),
    re.compile(r"carta\s+del\s+fabricante", re.I),
    re.compile(r"autorizaci[oó]n\s+del\s+fabricante", re.I),
    re.compile(r"cat[aá]logo\s+del\s+producto", re.I),
    re.compile(r"especificaciones\s+t[eé]cnicas\s+por\s+producto", re.I),
    re.compile(r"oferta\s+t[eé]cnica", re.I),
]

# Productos/equipos típicos en pliegos TI/redes
PRODUCT_LINE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"switch(?:es)?\s*(?:\d+\s*)?(?:puertos?|port)?(?:\s*poe)?", re.I), "Switch"),
    (re.compile(r"router(?:es)?\s*(?:empresarial|enterprise)?", re.I), "Router"),
    (re.compile(r"access\s+point|punto\s+de\s+acceso|wifi\s*6|wi-?fi\s*6", re.I), "Access Point"),
    (re.compile(r"\bups\b|no\s+break|sistema\s+de\s+alimentaci[oó]n\s+ininterrumpida", re.I), "UPS"),
    (re.compile(r"laptop|port[aá]til|notebook", re.I), "Laptop"),
    (re.compile(r"servidor|server", re.I), "Servidor"),
    (re.compile(r"firewall|cortafuegos", re.I), "Firewall"),
    (re.compile(r"monitor(?:es)?", re.I), "Monitor"),
    (re.compile(r"impresora|printer", re.I), "Impresora"),
]

QTY_RE = re.compile(r"(\d+)\s*(?:unidad(?:es)?|u\.?|pcs?|piezas?)", re.I)
SPEC_LINE_RE = re.compile(
    r"(?:m[ií]nimo|debe|deber[aá]|requiere|con\s+al\s+menos|capacidad)\s*[:\-]?\s*(.{10,200})",
    re.I,
)


class DGCPTechnicalProductDetectionService:
    """Detecta ítems técnicos desde Hermes, checklist y corpus — sin modificar flujos existentes."""

    def detect(
        self,
        opportunity: DGCPOpportunity,
        pkg: DGCPBidPackage | None,
        *,
        process_corpus: str = "",
        force: bool = False,
    ) -> tuple[list[dict[str, Any]], bool, str]:
        """
        Returns (items, requires_technical_sheets, message).
        """
        manifest = (pkg.manifest if pkg else None) or {}
        hermes = manifest.get("hermes_document_analysis") or {}
        requirements = pkg.requirements if pkg else {}
        checklist = list(pkg.checklist or []) if pkg else []
        evidence = list(pkg.requirement_evidence or []) if pkg else []

        corpus = (process_corpus or "").strip()
        if not corpus and hermes.get("summary"):
            corpus = str(hermes.get("summary", ""))

        requires_docs = self._pliego_requires_tech_sheets(corpus, requirements, checklist, hermes)
        if not requires_docs and not force:
            return [], False, "No se detectaron fichas técnicas requeridas."

        seen: set[str] = set()
        items: list[dict[str, Any]] = []

        for raw in self._from_hermes_items(hermes, evidence):
            key = raw["required_product_name"].lower()
            if key in seen:
                continue
            seen.add(key)
            items.append(raw)

        title_corpus = " ".join(
            filter(None, [opportunity.title, str(hermes.get("summary") or ""), corpus])
        )
        for raw in self._from_corpus_products(title_corpus, evidence):
            key = raw["required_product_name"].lower()
            if key in seen:
                continue
            seen.add(key)
            items.append(raw)

        for raw in self._from_technical_requirements(requirements, checklist, evidence):
            key = raw["required_product_name"].lower()
            if key in seen:
                continue
            seen.add(key)
            items.append(raw)

        if not items:
            if requires_docs:
                return [], True, (
                    "El pliego solicita fichas técnicas pero no se identificaron productos "
                    "específicos. Revise el pliego o agregue manualmente."
                )
            return [], False, "No se detectaron fichas técnicas requeridas."

        items = self._dedupe_by_product_name(items)
        return items, True, f"Se detectaron {len(items)} ficha(s) técnica(s) requerida(s)."

    @staticmethod
    def _pliego_requires_tech_sheets(
        corpus: str,
        requirements: dict,
        checklist: list[dict],
        hermes: dict,
    ) -> bool:
        text = corpus.lower()
        for pat in TECH_DOC_PATTERNS:
            if pat.search(text):
                return True
        for bucket in ("technical", "mandatory_documents", "administrative"):
            for item in requirements.get(bucket) or []:
                label = (item.get("label") or "").lower()
                key = (item.get("key") or "").lower()
                if "ficha" in label or "ficha_tecnica" in key or "oferta_tecnica" in key:
                    return True
                if any(p.search(label) for p in TECH_DOC_PATTERNS):
                    return True
        for item in checklist:
            label = (item.get("requirement") or "").lower()
            if "ficha" in label or "técnica" in label or "tecnica" in label:
                return True
        for doc in hermes.get("required_documents") or []:
            if any(p.search(str(doc)) for p in TECH_DOC_PATTERNS):
                return True
        # Procesos de equipos TI con especificaciones en título/objeto
        title_hints = ("switch", "router", "equipo", "hardware", "red", "network", "ups", "wifi")
        combined = text + " " + str(hermes.get("summary") or "").lower()
        if any(h in combined for h in title_hints) and (
            "especific" in combined or "técnica" in combined or "tecnica" in combined
        ):
            return True
        return False

    def _from_hermes_items(self, hermes: dict, evidence: list[dict]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for item in hermes.get("items_detected") or []:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or item.get("label") or "").strip()
            if not name or len(name) < 3:
                continue
            if not self._looks_like_product(name):
                continue
            specs = []
            notes = str(item.get("notes") or "")
            if notes:
                specs.append(notes)
            qty = str(item.get("quantity") or "") if item.get("quantity") not in (None, "No especificada") else None
            out.append(self._new_item(
                name=name,
                description=notes or None,
                specs=specs,
                quantity=qty,
                detection_source="hermes",
                confidence=0.75,
                evidence=evidence,
            ))
        return out

    def _from_corpus_products(self, corpus: str, evidence: list[dict]) -> list[dict[str, Any]]:
        if not corpus.strip():
            return []
        out: list[dict[str, Any]] = []
        seen_local: set[str] = set()
        lines = [ln.strip() for ln in corpus.splitlines() if ln.strip()]
        if len(lines) <= 2 and len(corpus) > 20:
            lines.append(corpus.strip())
        for line in lines:
            for pattern, category in PRODUCT_LINE_PATTERNS:
                m = pattern.search(line)
                if not m:
                    continue
                name = self._normalize_product_name(line, category, m)
                key = name.lower()
                if key in seen_local:
                    continue
                seen_local.add(key)
                specs = self._extract_specs_near_line(line, lines)
                qty_m = QTY_RE.search(line)
                out.append(self._new_item(
                    name=name,
                    description=line[:500],
                    specs=specs,
                    quantity=qty_m.group(1) if qty_m else None,
                    detection_source="heuristic",
                    confidence=0.82,
                    evidence=evidence,
                    fragment=line[:300],
                ))
                break
        return out

    def _from_technical_requirements(
        self,
        requirements: dict,
        checklist: list[dict],
        evidence: list[dict],
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for bucket in ("technical",):
            for item in requirements.get(bucket) or []:
                label = item.get("label") or ""
                if "ficha" not in label.lower() and item.get("key") != "ficha_tecnica":
                    continue
                # Generic ficha técnica requirement — products come from corpus/hermes
                continue
        return out

    @staticmethod
    def _looks_like_product(name: str) -> bool:
        low = name.lower()
        if len(low) < 4:
            return False
        skip = ("documento", "certific", "garantía", "garantia", "formulario", "sncc", "pliego")
        if any(s in low for s in skip):
            return False
        product_hints = (
            "switch", "router", "ups", "laptop", "servidor", "access", "wifi",
            "monitor", "firewall", "equipo", "producto",
        )
        return any(h in low for h in product_hints)

    @staticmethod
    def _normalize_product_name(line: str, category: str, match: re.Match) -> str:
        fragment = match.group(0).strip()
        if category.lower() in fragment.lower() and len(fragment) <= 80:
            return fragment.title()
        return category if len(fragment) < 6 else f"{category} — {fragment[:60].strip()}".title()

    @staticmethod
    def _extract_specs_near_line(line: str, lines: list[str]) -> list[str]:
        specs: list[str] = []
        for spec_m in SPEC_LINE_RE.finditer(line):
            specs.append(spec_m.group(1).strip())
        idx = lines.index(line) if line in lines else -1
        if idx >= 0:
            for neighbor in lines[idx : idx + 3]:
                for spec_m in SPEC_LINE_RE.finditer(neighbor):
                    val = spec_m.group(1).strip()
                    if val not in specs:
                        specs.append(val)
        return specs[:8]

    def _new_item(
        self,
        *,
        name: str,
        description: str | None,
        specs: list[str],
        quantity: str | None,
        detection_source: str,
        confidence: float,
        evidence: list[dict],
        fragment: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()
        ev = evidence[0] if evidence else {}
        return {
            "id": str(uuid.uuid4()),
            "required_product_name": name,
            "required_description": description,
            "required_specs": specs,
            "quantity": quantity,
            "source_document_id": ev.get("process_document_id"),
            "source_fragment": fragment or ev.get("fragmento"),
            "source_page": ev.get("pagina"),
            "source_section": ev.get("seccion") or "Pliego/TDR",
            "detection_source": detection_source,
            "offered_product": None,
            "compliance_matrix": [],
            "missing_fields": self._default_missing(specs),
            "status": "detectada",
            "confidence": confidence,
            "responsible_user_id": None,
            "draft": None,
            "draft_document_id": None,
            "created_at": now,
            "updated_at": now,
        }

    @staticmethod
    def _dedupe_by_product_name(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Colapsa variantes (Switch/Switches) conservando mayor confianza."""
        buckets: dict[str, dict[str, Any]] = {}
        for item in items:
            base = re.sub(r"[^a-z0-9]+", "", item["required_product_name"].lower())
            base = base.rstrip("s") or base
            prev = buckets.get(base)
            if not prev or float(item.get("confidence") or 0) >= float(prev.get("confidence") or 0):
                buckets[base] = item
        return list(buckets.values())

    @staticmethod
    def _default_missing(specs: list[str]) -> list[str]:
        base = ["producto_ofertado", "marca", "modelo", "garantia", "datasheet"]
        if not specs:
            base.append("especificaciones_pliego")
        return base
