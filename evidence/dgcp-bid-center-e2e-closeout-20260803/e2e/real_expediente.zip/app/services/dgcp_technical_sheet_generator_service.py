"""Generación asistida de borradores de ficha técnica vía Hermes (Fase 6.1)."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from typing import Any

from app.config import settings
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.hermes_client import HermesClient

logger = logging.getLogger(__name__)


class DGCPTechnicalSheetGeneratorService:
    """Genera borradores — nunca inventa datos; marca incertidumbre."""

    def __init__(self, *, client: HermesClient | None = None):
        self.client = client or HermesClient()

    async def generate_draft(
        self,
        opportunity: DGCPOpportunity,
        sheet: dict[str, Any],
        *,
        company_name: str = "justech",
        odoo_context: list[dict[str, Any]] | None = None,
        extra_notes: str | None = None,
    ) -> tuple[dict[str, Any], float, list[str], list[str]]:
        """
        Returns (draft_dict, confidence, missing_fields, review_notes).
        """
        offered = sheet.get("offered_product") or {}
        required_specs = sheet.get("required_specs") or []
        corpus_fragment = sheet.get("source_fragment") or ""

        odoo_context = odoo_context or []
        system_prompt = (
            "Eres un asistente de licitaciones. Genera borradores de fichas técnicas en JSON. "
            "REGLAS ESTRICTAS: "
            "1) NO inventes datos técnicos no proporcionados. "
            "2) Usa 'Información pendiente' cuando falte un dato. "
            "3) Marca cumplimiento como 'requiere_revision' si no hay evidencia. "
            "4) Incluye review_notes para cada punto que requiera validación humana. "
            "5) Responde SOLO JSON válido sin markdown."
        )
        question = json.dumps({
            "task": "generate_technical_sheet_draft",
            "process": {
                "code": opportunity.code,
                "title": opportunity.title,
                "institution": opportunity.institution,
                "company": company_name,
            },
            "required_product": {
                "name": sheet.get("required_product_name"),
                "description": sheet.get("required_description"),
                "specs": required_specs,
                "quantity": sheet.get("quantity"),
                "pliego_fragment": corpus_fragment[:1500],
            },
            "offered_product": offered,
            "odoo_matches": odoo_context[:5],
            "extra_notes": extra_notes,
            "output_schema": {
                "header": ["process_code", "institution", "company", "date", "product_name"],
                "product": ["brand", "model", "manufacturer", "sku", "description"],
                "specifications": ["requirement", "offered", "complies", "evidence", "source", "confidence"],
                "compliance_matrix": ["pliego_requirement", "offered_product", "complies", "evidence", "observation"],
                "warranty_support": ["manufacturer_warranty", "offered_warranty", "delivery_time", "local_support", "certifications"],
                "observations": [],
                "review_notes": [],
                "missing_fields": [],
                "confidence": 0.0,
            },
        }, ensure_ascii=False)

        draft, confidence, missing, notes = self._fallback_draft(
            opportunity, sheet, company_name=company_name
        )

        if not self.client.is_available() or not settings.dgcp_tech_sheets_hermes_enrich:
            if settings.dgcp_tech_sheets_hermes_enrich:
                notes.append("Hermes no disponible — borrador heurístico sin enriquecimiento LLM.")
            draft["generated_at"] = datetime.now(timezone.utc).isoformat()
            draft["generation_confidence"] = confidence
            return draft, confidence, missing, notes

        try:
            import asyncio

            raw = await asyncio.wait_for(
                self.client.copilot_turn(
                    system_prompt=system_prompt,
                    question=question,
                    context={"module": "dgcp_technical_sheet", "opportunity_id": str(opportunity.id)},
                ),
                timeout=20.0,
            )
            if raw and raw.get("answer"):
                parsed = self._parse_llm_answer(raw["answer"])
                if parsed:
                    draft = self._merge_draft(draft, parsed)
                    confidence = float(parsed.get("confidence") or draft.get("generation_confidence") or 0.7)
                    missing = list(dict.fromkeys(missing + (parsed.get("missing_fields") or [])))
                    notes = list(dict.fromkeys(notes + (parsed.get("review_notes") or [])))
        except Exception:
            logger.exception("Hermes tech sheet draft generation failed")
            notes.append("Error al enriquecer con Hermes — borrador heurístico conservado.")

        draft["generated_at"] = datetime.now(timezone.utc).isoformat()
        draft["generation_confidence"] = confidence
        return draft, confidence, missing, notes

    def _fallback_draft(
        self,
        opportunity: DGCPOpportunity,
        sheet: dict[str, Any],
        *,
        company_name: str,
    ) -> tuple[dict[str, Any], float, list[str], list[str]]:
        offered = sheet.get("offered_product") or {}
        required_specs = sheet.get("required_specs") or []
        missing: list[str] = []
        notes: list[str] = ["Borrador inicial — requiere revisión humana antes de uso."]

        if not offered.get("model") and not offered.get("description"):
            missing.append("producto_ofertado")
            notes.append("Seleccione o indique el producto que se ofertará para esta partida.")

        brand = (offered.get("brand") or "").strip()
        model = (offered.get("model") or "").strip()
        product_desc = offered.get("description") or (f"{brand} {model}".strip() if brand and model else None)

        specs_rows = []
        matrix = []
        for spec in required_specs or ["Especificaciones según pliego"]:
            offered_val = model or product_desc or "Información pendiente"
            specs_rows.append({
                "requirement": spec,
                "offered": offered_val,
                "complies": "requiere_revision",
                "evidence": sheet.get("source_fragment"),
                "source": sheet.get("detection_source"),
                "confidence": 0.5,
            })
            matrix.append({
                "pliego_requirement": spec,
                "offered_product": offered_val,
                "complies": "requiere_revision",
                "evidence": sheet.get("source_fragment") or "—",
                "observation": "Validar contra datasheet oficial del fabricante",
            })

        if brand and model and len(specs_rows) <= 1:
            specs_rows.extend([
                {
                    "requirement": "Marca y modelo",
                    "offered": f"{brand} {model}",
                    "complies": "requiere_revision",
                    "evidence": "Producto ofertado en ficha",
                    "source": offered.get("source") or "manual",
                    "confidence": 0.85,
                },
                {
                    "requirement": "Documentación técnica (datasheet)",
                    "offered": "Información pendiente",
                    "complies": "pendiente",
                    "evidence": None,
                    "source": "pliego",
                    "confidence": 0.4,
                },
            ])

        if not offered.get("brand"):
            missing.append("marca")
        if not offered.get("model"):
            missing.append("modelo")
        missing.extend(["garantia", "datasheet"])

        draft = {
            "header": {
                "process_code": opportunity.code,
                "process_title": opportunity.title,
                "institution": opportunity.institution,
                "company": company_name,
                "date": datetime.now(timezone.utc).strftime("%d/%m/%Y"),
                "required_product": sheet.get("required_product_name"),
                "offered_product": offered.get("model") or offered.get("description") or "Información pendiente",
            },
            "product": {
                "brand": brand or "Información pendiente",
                "model": model or "Información pendiente",
                "manufacturer": offered.get("manufacturer") or (f"{brand} Systems, Inc." if brand.lower() == "cisco" else brand) or "Información pendiente",
                "sku": offered.get("sku"),
                "description": product_desc or "Información pendiente",
            },
            "specifications": specs_rows,
            "compliance_matrix": matrix,
            "warranty_support": {
                "manufacturer_warranty": "Información pendiente",
                "offered_warranty": "Información pendiente",
                "delivery_time": "Información pendiente",
                "local_support": "Información pendiente",
                "certifications": [],
            },
            "observations": [
                "Borrador generado por JAIOS — no enviar sin aprobación.",
            ],
            "review_notes": notes,
            "generation_confidence": 0.55 if offered else 0.35,
        }
        conf = float(draft["generation_confidence"])
        return draft, conf, missing, notes

    @staticmethod
    def _parse_llm_answer(answer: str) -> dict[str, Any] | None:
        text = answer.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text)
            text = re.sub(r"\s*```$", "", text)
        try:
            data = json.loads(text)
            return data if isinstance(data, dict) else None
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", text, re.S)
            if not m:
                return None
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                return None

    @staticmethod
    def _merge_draft(base: dict[str, Any], llm: dict[str, Any]) -> dict[str, Any]:
        merged = dict(base)
        for key in ("header", "product", "warranty_support"):
            if llm.get(key) and isinstance(llm[key], dict):
                block = dict(merged.get(key) or {})
                for k, v in llm[key].items():
                    if v and v != "Información pendiente":
                        block[k] = v
                    elif k not in block:
                        block[k] = v
                merged[key] = block
        if llm.get("specifications"):
            merged["specifications"] = llm["specifications"]
        if llm.get("compliance_matrix"):
            merged["compliance_matrix"] = llm["compliance_matrix"]
        if llm.get("observations"):
            merged["observations"] = llm["observations"]
        if llm.get("review_notes"):
            merged["review_notes"] = llm["review_notes"]
        return merged

    @staticmethod
    def export_markdown(sheet: dict[str, Any], draft: dict[str, Any]) -> str:
        h = draft.get("header") or {}
        p = draft.get("product") or {}
        lines = [
            f"# Ficha Técnica — {h.get('required_product') or sheet.get('required_product_name')}",
            "",
            "## Encabezado",
            f"- **Proceso:** {h.get('process_code')} — {h.get('process_title')}",
            f"- **Institución:** {h.get('institution')}",
            f"- **Empresa oferente:** {h.get('company')}",
            f"- **Fecha:** {h.get('date')}",
            f"- **Producto requerido:** {h.get('required_product')}",
            f"- **Producto ofertado:** {h.get('offered_product')}",
            "",
            "## Producto",
            f"- **Marca:** {p.get('brand')}",
            f"- **Modelo:** {p.get('model')}",
            f"- **Fabricante:** {p.get('manufacturer')}",
            f"- **SKU:** {p.get('sku') or '—'}",
            f"- **Descripción:** {p.get('description')}",
            "",
            "## Cumplimiento",
            "",
            "| Requisito del pliego | Producto ofertado | Cumple | Evidencia | Observación |",
            "|---|---|---|---|---|",
        ]
        for row in draft.get("compliance_matrix") or []:
            lines.append(
                f"| {row.get('pliego_requirement', '')} | {row.get('offered_product', '')} | "
                f"{row.get('complies', '')} | {row.get('evidence', '') or '—'} | {row.get('observation', '') or '—'} |"
            )
        ws = draft.get("warranty_support") or {}
        lines.extend([
            "",
            "## Garantía y soporte",
            f"- Garantía fabricante: {ws.get('manufacturer_warranty', 'Información pendiente')}",
            f"- Garantía ofrecida: {ws.get('offered_warranty', 'Información pendiente')}",
            f"- Tiempo de entrega: {ws.get('delivery_time', 'Información pendiente')}",
            f"- Soporte local: {ws.get('local_support', 'Información pendiente')}",
            "",
            "## Observaciones",
        ])
        for obs in draft.get("observations") or []:
            lines.append(f"- {obs}")
        lines.extend(["", "## Notas de revisión"])
        for note in draft.get("review_notes") or []:
            lines.append(f"- {note}")
        lines.extend([
            "",
            "---",
            "*Borrador JAIOS — requiere revisión y aprobación humana. No enviar automáticamente.*",
        ])
        return "\n".join(lines)
