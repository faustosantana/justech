"""Exportación PDF profesional de fichas técnicas (Fase 6.1)."""

from __future__ import annotations

import html
import logging
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Image,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.services.corporate_branding_service import CorporateBrandingContext, CorporateBrandingService

logger = logging.getLogger(__name__)

# Paleta corporativa
BRAND_NAVY = colors.HexColor("#1e3a5f")
BRAND_ACCENT = colors.HexColor("#2563eb")
TEXT_BODY = colors.HexColor("#1f2937")
TEXT_MUTED = colors.HexColor("#4b5563")
ROW_ALT = colors.HexColor("#f8fafc")
BORDER = colors.HexColor("#cbd5e1")

PAGE_W, PAGE_H = letter
CONTENT_W = PAGE_W - 1.3 * inch  # márgenes 0.65" × 2


class DGCPTechnicalSheetPdfService:
    """Genera PDF listo para entrega — logo, especificaciones, cumplimiento multipágina."""

    MAX_GALLERY_IMAGES = 6
    GALLERY_COLS = 3

    def __init__(self, branding: CorporateBrandingService):
        self.branding = branding
        self._styles = self._build_styles()

    @staticmethod
    def _build_styles() -> dict[str, ParagraphStyle]:
        base = getSampleStyleSheet()
        return {
            "title": ParagraphStyle(
                "SheetTitle",
                parent=base["Heading1"],
                fontSize=16,
                textColor=BRAND_NAVY,
                spaceAfter=4,
                fontName="Helvetica-Bold",
            ),
            "subtitle": ParagraphStyle(
                "SheetSubtitle",
                parent=base["Normal"],
                fontSize=10,
                textColor=TEXT_MUTED,
                spaceAfter=2,
            ),
            "section": ParagraphStyle(
                "SheetSection",
                parent=base["Heading2"],
                fontSize=11,
                textColor=BRAND_NAVY,
                spaceBefore=10,
                spaceAfter=6,
                fontName="Helvetica-Bold",
            ),
            "body": ParagraphStyle(
                "SheetBody",
                parent=base["Normal"],
                fontSize=9,
                textColor=TEXT_BODY,
                leading=12,
                spaceAfter=3,
            ),
            "body_small": ParagraphStyle(
                "SheetBodySmall",
                parent=base["Normal"],
                fontSize=8,
                textColor=TEXT_MUTED,
                leading=10,
                spaceAfter=2,
            ),
            "cell": ParagraphStyle(
                "SheetCell",
                parent=base["Normal"],
                fontSize=7.5,
                leading=9.5,
                textColor=TEXT_BODY,
                wordWrap="CJK",
            ),
            "cell_header": ParagraphStyle(
                "SheetCellHeader",
                parent=base["Normal"],
                fontSize=8,
                leading=10,
                textColor=colors.white,
                fontName="Helvetica-Bold",
                wordWrap="CJK",
            ),
            "cell_label": ParagraphStyle(
                "SheetCellLabel",
                parent=base["Normal"],
                fontSize=8,
                leading=10,
                textColor=TEXT_BODY,
                fontName="Helvetica-Bold",
            ),
            "footer_note": ParagraphStyle(
                "SheetFooterNote",
                parent=base["Normal"],
                fontSize=7,
                textColor=TEXT_MUTED,
                alignment=TA_CENTER,
            ),
            "missing_asset": ParagraphStyle(
                "SheetMissingAsset",
                parent=base["Normal"],
                fontSize=8,
                textColor=colors.HexColor("#92400e"),
                leading=10,
            ),
        }

    @staticmethod
    def _esc(value: Any, *, placeholder: str = "—") -> str:
        text = str(value).strip() if value is not None else ""
        if not text:
            return placeholder
        return html.escape(text)

    def _para(self, value: Any, style: ParagraphStyle, *, placeholder: str = "—") -> Paragraph:
        return Paragraph(self._esc(value, placeholder=placeholder), style)

    async def build_pdf(
        self,
        *,
        sheet: dict[str, Any],
        draft: dict[str, Any],
        company_key: str,
        opportunity: Any,
    ) -> bytes:
        branding = await self.branding.resolve(company_key)
        draft = self._enrich_draft_product(draft, sheet)
        buf = BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=letter,
            leftMargin=0.65 * inch,
            rightMargin=0.65 * inch,
            topMargin=0.55 * inch,
            bottomMargin=0.75 * inch,
            title=f"Ficha técnica — {sheet.get('required_product_name', '')}",
        )
        company_name = branding.company_name
        process_code = getattr(opportunity, "code", None) or (draft.get("header") or {}).get("process_code", "")

        def _on_page(canvas, document):  # noqa: ANN001
            canvas.saveState()
            canvas.setFont("Helvetica", 7)
            canvas.setFillColor(TEXT_MUTED)
            canvas.drawString(
                0.65 * inch,
                0.45 * inch,
                f"{company_name} · {process_code} · Ficha técnica",
            )
            canvas.drawRightString(PAGE_W - 0.65 * inch, 0.45 * inch, f"Página {canvas.getPageNumber()}")
            canvas.setStrokeColor(BORDER)
            canvas.setLineWidth(0.5)
            canvas.line(0.65 * inch, 0.58 * inch, PAGE_W - 0.65 * inch, 0.58 * inch)
            canvas.restoreState()

        story: list[Any] = []
        story.extend(self._header_block(branding, opportunity, draft))
        story.extend(self._product_summary_block(sheet, draft))
        story.extend(self._product_images_gallery(sheet))
        story.extend(self._product_identity_block(draft))
        story.extend(self._technical_specifications_table(draft))
        story.extend(self._compliance_table(draft))
        story.extend(self._warranty_block(draft.get("warranty_support") or {}))
        story.extend(self._certifications_block(draft.get("warranty_support") or {}))
        story.extend(self._observations_block(draft))
        story.extend(self._footer_block(branding))

        doc.build(story, onFirstPage=_on_page, onLaterPages=_on_page)
        return buf.getvalue()

    @classmethod
    def _enrich_draft_product(cls, draft: dict[str, Any], sheet: dict[str, Any]) -> dict[str, Any]:
        """Completa campos derivables de marca/modelo sin inventar specs del fabricante."""
        enriched = dict(draft)
        product = dict(enriched.get("product") or {})
        offered = sheet.get("offered_product") or {}
        for key in ("brand", "model", "manufacturer", "sku", "description"):
            if not product.get(key) and offered.get(key):
                product[key] = offered[key]
        brand = (product.get("brand") or "").strip()
        model = (product.get("model") or "").strip()
        if brand and not product.get("manufacturer"):
            product["manufacturer"] = brand
        if brand and model and not product.get("description"):
            product["description"] = f"{brand} {model}"
        enriched["product"] = product

        specs = list(enriched.get("specifications") or [])
        if not specs:
            for req in sheet.get("required_specs") or []:
                specs.append({
                    "requirement": req,
                    "offered": model or product.get("description") or "Información pendiente",
                    "complies": "requiere_revision",
                    "evidence": sheet.get("source_fragment"),
                    "source": sheet.get("detection_source"),
                })
            enriched["specifications"] = specs
        return enriched

    def _header_block(
        self,
        branding: CorporateBrandingContext,
        opportunity: Any,
        draft: dict[str, Any],
    ) -> list[Any]:
        blocks: list[Any] = []
        logo_bytes = CorporateBrandingService.read_image_bytes(branding.logo)
        left: list[Any] = []
        if logo_bytes:
            try:
                img = self._scaled_image(logo_bytes, max_w=1.75 * inch, max_h=0.85 * inch)
                img.hAlign = "LEFT"
                left.append(img)
            except Exception:
                left.append(Paragraph(f"<b>{self._esc(branding.company_name)}</b>", self._styles["title"]))
        else:
            left.append(Paragraph(f"<b>{self._esc(branding.company_name)}</b>", self._styles["title"]))
            left.append(self._missing_asset_note("logo", branding.logo))

        left.append(Paragraph(f"RNC: {self._esc(branding.rnc, placeholder='Información pendiente')}", self._styles["body_small"]))
        if branding.address:
            left.append(Paragraph(self._esc(branding.address), self._styles["body_small"]))
        contact = " · ".join(filter(None, [branding.phone, branding.email]))
        if contact:
            left.append(Paragraph(self._esc(contact), self._styles["body_small"]))

        h = draft.get("header") or {}
        right = [
            Paragraph("<b>FICHA TÉCNICA DE PRODUCTO</b>", self._styles["title"]),
            Paragraph(
                f"Proceso: {self._esc(getattr(opportunity, 'code', h.get('process_code', '—')))}",
                self._styles["subtitle"],
            ),
            Paragraph(
                f"Institución: {self._esc(getattr(opportunity, 'institution', h.get('institution', '—')))}",
                self._styles["subtitle"],
            ),
            Paragraph(
                f"Fecha: {datetime.now(timezone.utc).strftime('%d/%m/%Y')}",
                self._styles["subtitle"],
            ),
        ]
        header_tbl = Table([[left, right]], colWidths=[CONTENT_W * 0.52, CONTENT_W * 0.48])
        header_tbl.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ]))
        blocks.append(header_tbl)
        blocks.append(Spacer(1, 6))
        rule = Table([[""]], colWidths=[CONTENT_W], rowHeights=[2])
        rule.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), BRAND_NAVY)]))
        blocks.append(rule)
        blocks.append(Spacer(1, 10))
        return blocks

    def _product_summary_block(self, sheet: dict[str, Any], draft: dict[str, Any]) -> list[Any]:
        h = draft.get("header") or {}
        p = draft.get("product") or {}
        rows = [
            [
                self._para("Producto requerido (pliego)", self._styles["cell_label"]),
                self._para(
                    h.get("required_product") or sheet.get("required_product_name"),
                    self._styles["body"],
                ),
            ],
            [
                self._para("Producto ofertado", self._styles["cell_label"]),
                self._para(
                    h.get("offered_product") or p.get("model") or p.get("description"),
                    self._styles["body"],
                ),
            ],
        ]
        tbl = Table(rows, colWidths=[1.55 * inch, CONTENT_W - 1.55 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), ROW_ALT),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        return [tbl, Spacer(1, 12)]

    def _product_identity_block(self, draft: dict[str, Any]) -> list[Any]:
        p = draft.get("product") or {}
        fields = [
            ("Marca", p.get("brand")),
            ("Modelo", p.get("model")),
            ("Fabricante", p.get("manufacturer")),
            ("SKU / Código", p.get("sku")),
            ("Descripción comercial", p.get("description")),
        ]
        rows = [[self._para(label, self._styles["cell_label"]), self._para(val, self._styles["body"], placeholder="Información pendiente")] for label, val in fields]
        tbl = Table(rows, colWidths=[1.55 * inch, CONTENT_W - 1.55 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), ROW_ALT),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        return [
            Paragraph("1. Identificación del producto ofertado", self._styles["section"]),
            tbl,
            Spacer(1, 10),
        ]

    def _technical_specifications_table(self, draft: dict[str, Any]) -> list[Any]:
        specs = draft.get("specifications") or []
        if not specs:
            return []
        headers = ["Requisito / Característica", "Valor ofertado", "Cumplimiento", "Evidencia"]
        col_fracs = [0.34, 0.28, 0.14, 0.24]
        col_widths = [CONTENT_W * f for f in col_fracs]
        data: list[list[Any]] = [[self._para(h, self._styles["cell_header"]) for h in headers]]
        for row in specs:
            data.append([
                self._para(row.get("requirement"), self._styles["cell"]),
                self._para(row.get("offered"), self._styles["cell"]),
                self._para(self._compliance_label(row.get("complies")), self._styles["cell"]),
                self._para(row.get("evidence"), self._styles["cell"]),
            ])
        tbl = Table(data, colWidths=col_widths, repeatRows=1, splitByRow=1)
        tbl.setStyle(self._table_style(len(data)))
        return [
            Paragraph("2. Especificaciones técnicas", self._styles["section"]),
            tbl,
            Spacer(1, 10),
        ]

    def _compliance_table(self, draft: dict[str, Any]) -> list[Any]:
        matrix = draft.get("compliance_matrix") or []
        headers = ["Requisito del pliego", "Producto ofertado", "Cumple", "Evidencia", "Observación"]
        col_fracs = [0.26, 0.18, 0.10, 0.22, 0.24]
        col_widths = [CONTENT_W * f for f in col_fracs]
        data: list[list[Any]] = [[self._para(h, self._styles["cell_header"]) for h in headers]]
        for row in matrix:
            data.append([
                self._para(row.get("pliego_requirement"), self._styles["cell"]),
                self._para(row.get("offered_product"), self._styles["cell"]),
                self._para(self._compliance_label(row.get("complies")), self._styles["cell"]),
                self._para(row.get("evidence"), self._styles["cell"]),
                self._para(row.get("observation"), self._styles["cell"]),
            ])
        if len(data) == 1:
            data.append([
                self._para("Especificaciones según pliego", self._styles["cell"]),
                self._para("—", self._styles["cell"]),
                self._para("Requiere revisión", self._styles["cell"]),
                self._para("—", self._styles["cell"]),
                self._para("Validar contra datasheet del fabricante", self._styles["cell"]),
            ])
        tbl = Table(data, colWidths=col_widths, repeatRows=1, splitByRow=1)
        tbl.setStyle(self._table_style(len(data)))
        return [
            Paragraph("3. Tabla de cumplimiento", self._styles["section"]),
            tbl,
            Spacer(1, 10),
        ]

    @staticmethod
    def _compliance_label(value: Any) -> str:
        raw = str(value or "").strip().lower()
        mapping = {
            "cumple": "Cumple",
            "si": "Cumple",
            "yes": "Cumple",
            "no_cumple": "No cumple",
            "no": "No cumple",
            "requiere_revision": "Requiere revisión",
            "pendiente": "Pendiente",
        }
        return mapping.get(raw, str(value or "Requiere revisión"))

    def _table_style(self, row_count: int) -> TableStyle:
        style_commands: list[tuple[Any, ...]] = [
            ("BACKGROUND", (0, 0), (-1, 0), BRAND_NAVY),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]
        for i in range(1, row_count):
            if i % 2 == 0:
                style_commands.append(("BACKGROUND", (0, i), (-1, i), ROW_ALT))
        return TableStyle(style_commands)

    def _product_images_gallery(self, sheet: dict[str, Any]) -> list[Any]:
        images = self._sorted_product_images(sheet)[: self.MAX_GALLERY_IMAGES]
        blocks: list[Any] = [
            Paragraph("Imágenes del producto", self._styles["section"]),
            Spacer(1, 4),
        ]
        if not images:
            blocks.append(Paragraph("<i>Imagen pendiente</i>", self._styles["body_small"]))
            blocks.append(Spacer(1, 10))
            return blocks

        cell_w = CONTENT_W / self.GALLERY_COLS
        max_img_w = cell_w - 0.15 * inch
        max_img_h = 1.35 * inch
        rows: list[list[Any]] = []
        current: list[Any] = []
        rendered = 0
        for img_meta in images:
            label = img_meta.get("label") or img_meta.get("filename") or "Imagen"
            flowable = self._image_flowable(img_meta, max_w=max_img_w, max_h=max_img_h)
            if flowable is not None:
                cell = [flowable, Spacer(1, 2), Paragraph(f"<para align=center><font size=7>{self._esc(label)}</font></para>", self._styles["body_small"])]
                current.append(cell)
                rendered += 1
            else:
                current.append([
                    Paragraph(f"<i>{self._esc(label)}</i>", self._styles["body_small"]),
                    Paragraph("<font size=6>Archivo no disponible</font>", self._styles["body_small"]),
                ])
            if len(current) == self.GALLERY_COLS:
                rows.append(current)
                current = []
        if current:
            while len(current) < self.GALLERY_COLS:
                current.append("")
            rows.append(current)

        col_widths = [cell_w] * self.GALLERY_COLS
        tbl = Table(rows, colWidths=col_widths)
        tbl.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]))
        if rendered == 0:
            blocks.append(Paragraph("<i>Imagen pendiente — archivos no legibles</i>", self._styles["body_small"]))
        else:
            blocks.append(tbl)
        blocks.append(Spacer(1, 10))
        return blocks

    @staticmethod
    def _sorted_product_images(sheet: dict[str, Any]) -> list[dict[str, Any]]:
        images = list(sheet.get("product_images") or [])
        if sheet.get("offered_product", {}).get("image_url") and not images:
            return [{
                "label": "Producto",
                "url": sheet["offered_product"]["image_url"],
                "sort_order": 0,
            }]
        return sorted(images, key=lambda img: img.get("sort_order", 0))

    @classmethod
    def resolve_image_path(cls, img_meta: dict[str, Any]) -> Path | None:
        candidates: list[str | Path] = []
        for key in ("local_path", "path", "storage_path"):
            value = img_meta.get(key)
            if value:
                candidates.append(value)
        filename = img_meta.get("filename")
        if filename:
            candidates.append(filename)
        url = img_meta.get("url")
        if url and not str(url).startswith(("http://", "https://")):
            candidates.append(url)
        for raw in candidates:
            path = Path(str(raw))
            if path.is_file():
                return path
        return None

    @classmethod
    def load_image_bytes(cls, img_meta: dict[str, Any]) -> bytes | None:
        path = cls.resolve_image_path(img_meta)
        if not path:
            return None
        try:
            return path.read_bytes()
        except OSError:
            logger.warning("No se pudo leer imagen de ficha técnica: %s", path)
            return None

    @classmethod
    def _scaled_image(cls, raw: bytes, *, max_w: float, max_h: float) -> Image:
        from PIL import Image as PILImage

        with PILImage.open(BytesIO(raw)) as pil_img:
            w, h = pil_img.size
            if w <= 0 or h <= 0:
                raise ValueError("invalid image dimensions")
            scale = min(max_w / w, max_h / h, 1.0)
            draw_w, draw_h = w * scale, h * scale
            buf = BytesIO()
            pil_img.save(buf, format=pil_img.format or "PNG")
            buf.seek(0)
            img = Image(buf, width=draw_w, height=draw_h)
        return img

    @classmethod
    def _image_flowable(
        cls,
        img_meta: dict[str, Any],
        *,
        max_w: float = 1.5 * inch,
        max_h: float = 1.1 * inch,
    ) -> Image | None:
        raw = cls.load_image_bytes(img_meta)
        if not raw:
            return None
        try:
            from PIL import Image as PILImage

            with PILImage.open(BytesIO(raw)) as pil_img:
                pil_img.load()
            img = cls._scaled_image(raw, max_w=max_w, max_h=max_h)
            img.hAlign = "CENTER"
            return img
        except Exception:
            logger.exception("Error embebiendo imagen en PDF de ficha técnica")
            return None

    def _warranty_block(self, ws: dict[str, Any]) -> list[Any]:
        rows = [
            ["Garantía del fabricante", ws.get("manufacturer_warranty")],
            ["Garantía ofrecida", ws.get("offered_warranty")],
            ["Tiempo de entrega", ws.get("delivery_time")],
            ["Soporte local", ws.get("local_support")],
        ]
        data = [
            [self._para(label, self._styles["cell_label"]), self._para(val, self._styles["body"], placeholder="Información pendiente")]
            for label, val in rows
        ]
        tbl = Table(data, colWidths=[1.8 * inch, CONTENT_W - 1.8 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (0, -1), ROW_ALT),
            ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        return [
            Paragraph("4. Garantía y soporte", self._styles["section"]),
            tbl,
            Spacer(1, 10),
        ]

    def _certifications_block(self, ws: dict[str, Any]) -> list[Any]:
        certs = ws.get("certifications") or []
        if not certs:
            return []
        lines = " · ".join(self._esc(c) for c in certs if c)
        return [
            Paragraph("Certificaciones", self._styles["section"]),
            Paragraph(lines, self._styles["body"]),
            Spacer(1, 8),
        ]

    def _observations_block(self, draft: dict[str, Any]) -> list[Any]:
        obs = [o for o in (draft.get("observations") or []) if o and "borrador generado" not in str(o).lower()]
        notes = draft.get("review_notes") or []
        if not obs and not notes:
            return []
        blocks = [Paragraph("5. Observaciones", self._styles["section"]), Spacer(1, 4)]
        for item in obs:
            blocks.append(Paragraph(f"• {self._esc(item)}", self._styles["body_small"]))
        for note in notes:
            if "borrador inicial" not in str(note).lower():
                blocks.append(Paragraph(f"• {self._esc(note)}", self._styles["body_small"]))
        blocks.append(Spacer(1, 12))
        return blocks

    def _missing_asset_note(self, asset_type: str, asset: Any) -> Paragraph:
        filename = getattr(asset, "filename", None) or getattr(asset, "label", None)
        if asset_type == "logo":
            detail = filename or "logo corporativo (Repositorio / Perfil Empresarial → document_type=logo)"
        elif asset_type == "signature":
            detail = filename or "firma autorizada (Identidad corporativa / FIRMAS)"
        else:
            detail = filename or "sello corporativo (Identidad corporativa / SELLOS)"
        return Paragraph(
            f"<font color='#92400e'><i>Activo pendiente:</i> {self._esc(detail)}</font>",
            self._styles["missing_asset"],
        )

    def _footer_block(self, branding: CorporateBrandingContext) -> list[Any]:
        sig_bytes = CorporateBrandingService.read_image_bytes(branding.signature)
        stamp_bytes = CorporateBrandingService.read_image_bytes(branding.stamp)

        if sig_bytes:
            try:
                sig_cell: Any = self._scaled_image(sig_bytes, max_w=2.0 * inch, max_h=0.65 * inch)
            except Exception:
                sig_cell = self._missing_asset_note("signature", branding.signature)
        else:
            sig_cell = self._missing_asset_note("signature", branding.signature)

        if stamp_bytes:
            try:
                stamp_cell: Any = self._scaled_image(stamp_bytes, max_w=1.15 * inch, max_h=1.15 * inch)
            except Exception:
                stamp_cell = self._missing_asset_note("stamp", branding.stamp)
        else:
            stamp_cell = self._missing_asset_note("stamp", branding.stamp)

        rep = branding.representative_name or "Representante autorizado"
        role = branding.representative_role or "Cargo pendiente"
        footer = Table(
            [
                [Paragraph("<b>Representación legal</b>", self._styles["body_small"]), ""],
                [sig_cell, stamp_cell],
                [Paragraph(f"{self._esc(rep)}<br/>{self._esc(role)}", self._styles["body_small"]), ""],
            ],
            colWidths=[CONTENT_W * 0.55, CONTENT_W * 0.45],
        )
        footer.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LINEABOVE", (0, 0), (-1, 0), 0.75, BRAND_NAVY),
            ("TOPPADDING", (0, 1), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ]))
        disclaimer = Paragraph(
            "Documento preparado por el oferente para evaluación técnica. "
            "Las especificaciones deben contrastarse con el pliego y el datasheet oficial del fabricante.",
            self._styles["footer_note"],
        )
        return [Spacer(1, 8), footer, Spacer(1, 6), disclaimer]
