"""Servicio de fichas técnicas por producto — Fase 6.1 (manifest JSONB, feature flag)."""

from __future__ import annotations

import copy
import logging
import mimetypes
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified

from app.config import settings
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.dgcp_technical_sheet import (
    DGCPTechSheetActionResponse,
    DGCPTechSheetAddImageRequest,
    DGCPTechSheetBrandingContext,
    DGCPTechSheetDetectResponse,
    DGCPTechSheetDraft,
    DGCPTechSheetExportResponse,
    DGCPTechSheetGenerateDraftResponse,
    DGCPTechSheetItem,
    DGCPTechSheetProductImage,
    DGCPTechSheetReorderImagesRequest,
    DGCPTechSheetSelectProductRequest,
    DGCPTechSheetSummary,
    DGCPTechSheetsResponse,
)
from app.services.corporate_branding_service import CorporateBrandingService
from app.services.dgcp_technical_product_detection_service import DGCPTechnicalProductDetectionService
from app.services.dgcp_technical_sheet_generator_service import DGCPTechnicalSheetGeneratorService
from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService

logger = logging.getLogger(__name__)


class DGCPTechnicalSheetService:
    MANIFEST_KEY = "technical_sheets"

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.detector = DGCPTechnicalProductDetectionService()
        self.generator = DGCPTechnicalSheetGeneratorService()

    @staticmethod
    def enabled() -> bool:
        return bool(settings.dgcp_tech_sheets)

    async def list_sheets(self, opportunity_id: uuid.UUID) -> DGCPTechSheetsResponse:
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._get_package(opportunity_id)
        block = self._read_block(pkg)
        company_key = self._company_key(opportunity)
        items = [
            await self._to_item_enriched(i, company_key=company_key)
            for i in block.get("items") or []
        ]
        summary = self._build_summary(items, block)
        return DGCPTechSheetsResponse(
            opportunity_id=opportunity_id,
            enabled=self.enabled(),
            summary=summary,
            items=items,
        )

    async def detect(
        self,
        opportunity_id: uuid.UUID,
        *,
        force: bool = False,
        process_corpus: str | None = None,
    ) -> DGCPTechSheetDetectResponse:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._ensure_package(opportunity)
        corpus = process_corpus
        if corpus is None:
            corpus, _ = await self._build_corpus(opportunity_id, pkg)
        detected, requires, message = self.detector.detect(
            opportunity, pkg, process_corpus=corpus or "", force=force
        )
        existing = {i["id"]: i for i in (self._read_block(pkg).get("items") or [])}
        merged: list[dict[str, Any]] = []
        if force:
            preserved = [
                i for i in existing.values()
                if i.get("status") in ("aprobada", "rechazada", "no_aplica")
            ]
            merged = preserved + detected
        else:
            for raw in detected:
                prev = existing.get(raw["id"])
                if prev:
                    merged.append({**prev, **{k: v for k, v in raw.items() if k not in ("status", "offered_product", "draft")}})
                else:
                    merged.append(raw)
            for prev_id, prev in existing.items():
                if prev_id not in {i["id"] for i in detected} and prev.get("status") not in ("aprobada", "rechazada", "no_aplica"):
                    merged.append(prev)
        block = {
            "items": merged,
            "requires_technical_sheets": requires,
            "message": message,
            "detected_at": datetime.now(timezone.utc).isoformat(),
            "version": 1,
        }
        await self._save_block(pkg, block)
        await self._publish_event(pkg, "technical_sheets_detected", {"count": len(merged), "message": message})
        company_key = self._company_key(opportunity)
        items = [
            await self._to_item_enriched(i, company_key=company_key)
            for i in merged
        ]
        summary = self._build_summary(items, block)
        return DGCPTechSheetDetectResponse(
            opportunity_id=opportunity_id,
            detected_count=len(detected),
            summary=summary,
            items=items,
        )

    async def detect_after_analyze(
        self,
        opportunity_id: uuid.UUID,
        *,
        process_corpus: str = "",
    ) -> None:
        """Hook opcional post-analyze — no falla el flujo principal."""
        if not self.enabled():
            return
        try:
            await self.detect(opportunity_id, process_corpus=process_corpus)
        except Exception:
            return

    async def select_product(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        data: DGCPTechSheetSelectProductRequest,
    ) -> DGCPTechSheetItem:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        pkg = await self._require_package(opportunity_id)
        sheet = self._get_sheet_or_raise(pkg, sheet_id)
        offered = {
            "brand": data.brand,
            "model": data.model,
            "manufacturer": data.manufacturer,
            "sku": data.sku,
            "description": data.description,
            "source": data.source,
        }
        if data.odoo_product_id:
            offered["odoo_product_id"] = data.odoo_product_id
        sheet["offered_product"] = offered
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        missing = list(sheet.get("missing_fields") or [])
        if offered.get("model") or offered.get("description"):
            missing = [m for m in missing if m != "producto_ofertado"]
        if offered.get("brand"):
            missing = [m for m in missing if m != "marca"]
        if offered.get("model"):
            missing = [m for m in missing if m != "modelo"]
        sheet["missing_fields"] = missing
        has_product = bool(offered.get("model") or offered.get("description"))
        sheet["status"] = "lista_para_generar" if has_product else "pendiente_producto"
        await self._update_sheet(pkg, sheet)
        await self._publish_event(pkg, "technical_sheet_product_selected", {"sheet_id": sheet_id})
        opportunity = await self._get_opportunity(opportunity_id)
        return await self._to_item_enriched(sheet, company_key=self._company_key(opportunity))

    async def generate_draft(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        *,
        company: str = "justech",
        extra_notes: str | None = None,
    ) -> DGCPTechSheetGenerateDraftResponse:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._require_package(opportunity_id)
        sheet = self._get_sheet_or_raise(pkg, sheet_id)
        if not sheet.get("offered_product"):
            sheet["status"] = "pendiente_producto"
            await self._update_sheet(pkg, sheet)
            raise ValueError("Seleccione o indique el producto que se ofertará para esta partida.")
        draft_dict, confidence, missing, notes = await self.generator.generate_draft(
            opportunity,
            sheet,
            company_name=company,
            extra_notes=extra_notes,
        )
        sheet["draft"] = draft_dict
        sheet["compliance_matrix"] = draft_dict.get("compliance_matrix") or []
        sheet["missing_fields"] = list(dict.fromkeys((sheet.get("missing_fields") or []) + missing))
        sheet["confidence"] = confidence
        sheet["status"] = "requiere_revision" if missing else "borrador_generado"
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        await self._update_sheet(pkg, sheet)
        await self._publish_event(
            pkg,
            "technical_sheet_draft_generated",
            {"sheet_id": sheet_id, "confidence": confidence, "missing": missing},
        )
        return DGCPTechSheetGenerateDraftResponse(
            opportunity_id=opportunity_id,
            sheet_id=sheet_id,
            status=sheet["status"],
            confidence=confidence,
            missing_fields=missing,
            review_notes=notes,
            draft=DGCPTechSheetDraft.model_validate(draft_dict),
        )

    async def approve(self, opportunity_id: uuid.UUID, sheet_id: str) -> DGCPTechSheetActionResponse:
        return await self._set_status(opportunity_id, sheet_id, "aprobada", "Ficha técnica aprobada — pendiente firma/sello manual.")

    async def reject(self, opportunity_id: uuid.UUID, sheet_id: str) -> DGCPTechSheetActionResponse:
        return await self._set_status(opportunity_id, sheet_id, "rechazada", "Ficha técnica rechazada — requiere corrección.")

    async def export_sheet(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        *,
        fmt: str = "markdown",
        company: str | None = None,
    ) -> DGCPTechSheetExportResponse | tuple[bytes, str]:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._require_package(opportunity_id)
        await self.db.refresh(pkg)
        sheet = self._get_sheet_or_raise(pkg, sheet_id)
        draft = sheet.get("draft")
        if not draft:
            raise ValueError("No hay borrador generado para esta ficha.")
        safe_name = (sheet.get("required_product_name") or "ficha").replace("/", "-")[:60]
        if fmt.lower() == "pdf":
            company_key = company or self._company_key(opportunity)
            branding = CorporateBrandingService(self.db, self.tenant_id, user_id=self.user_id)
            pdf_svc = DGCPTechnicalSheetPdfService(branding)
            pdf_bytes = await pdf_svc.build_pdf(
                sheet=sheet,
                draft=draft,
                company_key=company_key,
                opportunity=opportunity,
            )
            return pdf_bytes, f"ficha-tecnica-{safe_name}.pdf"
        content = self.generator.export_markdown(sheet, draft)
        return DGCPTechSheetExportResponse(
            opportunity_id=opportunity_id,
            sheet_id=sheet_id,
            format=fmt,
            content=content,
            filename=f"ficha-tecnica-{safe_name}.md",
        )

    async def get_branding(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        *,
        company: str | None = None,
    ) -> DGCPTechSheetBrandingContext:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        opportunity = await self._get_opportunity(opportunity_id)
        if not opportunity:
            raise ValueError("Licitación no encontrada")
        pkg = await self._require_package(opportunity_id)
        self._get_sheet_or_raise(pkg, sheet_id)
        company_key = company or self._company_key(opportunity)
        branding = CorporateBrandingService(self.db, self.tenant_id, user_id=self.user_id)
        ctx = await branding.resolve(company_key)
        return DGCPTechSheetBrandingContext.model_validate(ctx.to_dict())

    async def add_image(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        data: DGCPTechSheetAddImageRequest,
        *,
        upload_path: Path | None = None,
    ) -> DGCPTechSheetItem:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        pkg = await self._require_package(opportunity_id)
        sheet = copy.deepcopy(self._get_sheet_or_raise(pkg, sheet_id))
        images = list(sheet.get("product_images") or [])
        image_id = str(uuid.uuid4())
        filename = upload_path.name if upload_path else None
        mime_type = mimetypes.guess_type(filename or "")[0] if filename else None
        images.append({
            "id": image_id,
            "label": data.label or "Imagen producto",
            "source": data.source,
            "url": data.url,
            "local_path": str(upload_path) if upload_path else None,
            "filename": filename,
            "mime_type": mime_type,
            "sort_order": len(images),
        })
        sheet["product_images"] = images
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        await self._update_sheet(pkg, sheet)
        opportunity = await self._get_opportunity(opportunity_id)
        return await self._to_item_enriched(sheet, company_key=self._company_key(opportunity))

    async def reorder_images(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        data: DGCPTechSheetReorderImagesRequest,
    ) -> DGCPTechSheetItem:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        pkg = await self._require_package(opportunity_id)
        sheet = copy.deepcopy(self._get_sheet_or_raise(pkg, sheet_id))
        by_id = {img["id"]: img for img in (sheet.get("product_images") or [])}
        ordered = []
        for idx, img_id in enumerate(data.image_ids):
            if img_id in by_id:
                row = dict(by_id[img_id])
                row["sort_order"] = idx
                ordered.append(row)
        for img in sheet.get("product_images") or []:
            if img["id"] not in data.image_ids:
                row = dict(img)
                row["sort_order"] = len(ordered)
                ordered.append(row)
        sheet["product_images"] = ordered
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        await self._update_sheet(pkg, sheet)
        opportunity = await self._get_opportunity(opportunity_id)
        return await self._to_item_enriched(sheet, company_key=self._company_key(opportunity))

    async def remove_image(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        image_id: str,
    ) -> DGCPTechSheetItem:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        pkg = await self._require_package(opportunity_id)
        sheet = copy.deepcopy(self._get_sheet_or_raise(pkg, sheet_id))
        images = [img for img in (sheet.get("product_images") or []) if img.get("id") != image_id]
        for idx, img in enumerate(images):
            img["sort_order"] = idx
        sheet["product_images"] = images
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        await self._update_sheet(pkg, sheet)
        opportunity = await self._get_opportunity(opportunity_id)
        return await self._to_item_enriched(sheet, company_key=self._company_key(opportunity))

    async def _set_status(
        self,
        opportunity_id: uuid.UUID,
        sheet_id: str,
        status: str,
        message: str,
    ) -> DGCPTechSheetActionResponse:
        if not self.enabled():
            raise ValueError("Fichas técnicas deshabilitadas (DGCP_TECH_SHEETS=false)")
        pkg = await self._require_package(opportunity_id)
        sheet = self._get_sheet_or_raise(pkg, sheet_id)
        sheet["status"] = status
        sheet["updated_at"] = datetime.now(timezone.utc).isoformat()
        await self._update_sheet(pkg, sheet)
        await self._publish_event(pkg, f"technical_sheet_{status}", {"sheet_id": sheet_id})
        return DGCPTechSheetActionResponse(
            opportunity_id=opportunity_id,
            sheet_id=sheet_id,
            status=status,
            message=message,
        )

    async def _get_opportunity(self, opportunity_id: uuid.UUID) -> DGCPOpportunity | None:
        from sqlalchemy import select

        result = await self.db.execute(
            select(DGCPOpportunity).where(
                DGCPOpportunity.id == opportunity_id,
                DGCPOpportunity.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _get_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage | None:
        from sqlalchemy import select

        result = await self.db.execute(
            select(DGCPBidPackage).where(
                DGCPBidPackage.opportunity_id == opportunity_id,
                DGCPBidPackage.tenant_id == self.tenant_id,
            )
        )
        return result.scalar_one_or_none()

    async def _ensure_package(self, opportunity: DGCPOpportunity) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity.id)
        if pkg:
            return pkg
        pkg = DGCPBidPackage(
            tenant_id=self.tenant_id,
            opportunity_id=opportunity.id,
            manifest={},
        )
        self.db.add(pkg)
        await self.db.commit()
        await self.db.refresh(pkg)
        return pkg

    async def _require_package(self, opportunity_id: uuid.UUID) -> DGCPBidPackage:
        pkg = await self._get_package(opportunity_id)
        if not pkg:
            raise ValueError("Expediente no analizado — ejecute análisis de requisitos primero.")
        return pkg

    async def _build_corpus(self, opportunity_id: uuid.UUID, pkg: DGCPBidPackage) -> tuple[str, list]:
        from app.services.dgcp_attachment_ingestion_service import DGCPAttachmentIngestionService

        ingestion = DGCPAttachmentIngestionService(self.db, self.tenant_id, user_id=self.user_id)
        corpus, docs = await ingestion.build_extraction_corpus(opportunity_id)
        if not corpus.strip():
            hermes = (pkg.manifest or {}).get("hermes_document_analysis") or {}
            corpus = str(hermes.get("summary") or "")
        return corpus, docs

    @classmethod
    def _read_block(cls, pkg: DGCPBidPackage | None) -> dict[str, Any]:
        if not pkg or not pkg.manifest:
            return {}
        return copy.deepcopy((pkg.manifest or {}).get(cls.MANIFEST_KEY) or {})

    async def _save_block(self, pkg: DGCPBidPackage, block: dict[str, Any]) -> None:
        manifest = copy.deepcopy(pkg.manifest or {})
        manifest[self.MANIFEST_KEY] = copy.deepcopy(block)
        manifest["technical_sheets_summary"] = self._manifest_summary(manifest[self.MANIFEST_KEY])
        pkg.manifest = manifest
        flag_modified(pkg, "manifest")
        await self.db.commit()
        await self.db.refresh(pkg)

    async def _update_sheet(self, pkg: DGCPBidPackage, sheet: dict) -> None:
        block = self._read_block(pkg)
        items = []
        for item in block.get("items") or []:
            if item.get("id") == sheet.get("id"):
                items.append(copy.deepcopy(sheet))
            else:
                items.append(copy.deepcopy(item))
        block["items"] = items
        await self._save_block(pkg, block)

    @staticmethod
    def _get_sheet_or_raise(pkg: DGCPBidPackage, sheet_id: str) -> dict[str, Any]:
        for item in (DGCPTechnicalSheetService._read_block(pkg).get("items") or []):
            if item.get("id") == sheet_id:
                return item
        raise ValueError("Ficha técnica no encontrada")

    @staticmethod
    def _company_key(opportunity: DGCPOpportunity | None) -> str:
        if not opportunity:
            return "justech"
        key = (opportunity.company or "justech").strip()
        return key if key and key != "unclassified" else "justech"

    async def _to_item_enriched(self, raw: dict[str, Any], *, company_key: str) -> DGCPTechSheetItem:
        item = self._to_item(raw)
        try:
            branding = CorporateBrandingService(self.db, self.tenant_id, user_id=self.user_id)
            ctx = await branding.resolve(company_key)
            payload = item.model_dump()
            payload["branding"] = DGCPTechSheetBrandingContext.model_validate(ctx.to_dict())
            images = payload.get("product_images") or []
            offered = payload.get("offered_product") or {}
            if not images and offered.get("image_url"):
                payload["product_images"] = [{
                    "id": "offered-default",
                    "label": "Producto",
                    "source": offered.get("source") or "catalog",
                    "url": offered["image_url"],
                    "sort_order": 0,
                }]
            return DGCPTechSheetItem.model_validate(payload)
        except Exception:
            logger.exception("Could not enrich tech sheet branding for %s", company_key)
            return item

    @staticmethod
    def _to_item(raw: dict[str, Any]) -> DGCPTechSheetItem:
        draft = raw.get("draft")
        payload = dict(raw)
        if draft and isinstance(draft, dict):
            payload["draft"] = DGCPTechSheetDraft.model_validate(draft)
        return DGCPTechSheetItem.model_validate(payload)

    @staticmethod
    def _build_summary(items: list[DGCPTechSheetItem], block: dict[str, Any]) -> DGCPTechSheetSummary:
        con_riesgo = sum(
            1 for i in items
            if i.missing_fields or i.status in ("requiere_revision", "pendiente_producto", "detectada")
        )
        return DGCPTechSheetSummary(
            total=len(items),
            detectadas=sum(1 for i in items if i.status == "detectada"),
            pendientes_producto=sum(1 for i in items if i.status == "pendiente_producto"),
            borradores=sum(1 for i in items if i.status in ("borrador_generado", "requiere_revision")),
            aprobadas=sum(1 for i in items if i.status == "aprobada"),
            con_riesgo=con_riesgo,
            requires_technical_sheets=bool(block.get("requires_technical_sheets")),
            message=block.get("message"),
        )

    @staticmethod
    def _manifest_summary(block: dict[str, Any]) -> dict[str, Any]:
        items = block.get("items") or []
        by_status: dict[str, int] = {}
        for item in items:
            st = item.get("status") or "detectada"
            by_status[st] = by_status.get(st, 0) + 1
        pending = sum(
            by_status.get(s, 0)
            for s in ("detectada", "pendiente_producto", "lista_para_generar", "requiere_revision")
        )
        return {
            "total": len(items),
            "by_status": by_status,
            "pending_human_review": pending,
            "requires_technical_sheets": bool(block.get("requires_technical_sheets")),
            "message": block.get("message"),
        }

    async def _publish_event(self, pkg: DGCPBidPackage, event_type: str, detail: dict[str, Any]) -> None:
        try:
            from app.services.dgcp_expediente_event_service import DGCPExpedienteEventService

            await DGCPExpedienteEventService.publish(
                pkg,
                event_type=event_type,
                actor_id=self.user_id,
                detail=detail,
                checklist=list(pkg.checklist or []),
            )
            await self.db.commit()
        except Exception:
            logger.exception("Non-fatal: could not publish expediente event %s", event_type)
