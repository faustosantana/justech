"""Vínculo documental universal — cualquier entidad JAIOS."""

from __future__ import annotations

import uuid
from datetime import UTC, date, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document_link import DocumentLink


class DocumentAttachmentService:
    """Servicio unificado para vincular/importar documentos a entidades."""

    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def link_document(
        self,
        *,
        entity_type: str,
        entity_id: uuid.UUID,
        file_name: str,
        source_system: str = "m365",
        source_type: str = "onedrive",
        drive_id: str | None = None,
        site_id: str | None = None,
        item_id: str | None = None,
        web_url: str | None = None,
        file_path: str | None = None,
        mime_type: str | None = None,
        size_bytes: int | None = None,
        content_hash: str | None = None,
        company_id: uuid.UUID | None = None,
        requirement_id: str | None = None,
        representative_id: uuid.UUID | None = None,
        person_id: uuid.UUID | None = None,
        expires_at: date | None = None,
        imported_storage_path: str | None = None,
        raw_payload: dict | None = None,
        status: str = "linked",
    ) -> DocumentLink:
        row = DocumentLink(
            tenant_id=self.tenant_id,
            company_id=company_id,
            entity_type=entity_type,
            entity_id=entity_id,
            requirement_id=requirement_id,
            representative_id=representative_id,
            person_id=person_id or representative_id,
            source_system=source_system,
            source_type=source_type,
            drive_id=drive_id,
            site_id=site_id,
            item_id=item_id,
            web_url=web_url,
            file_name=file_name,
            file_path=file_path,
            mime_type=mime_type,
            size_bytes=size_bytes,
            content_hash=content_hash,
            status=status,
            expires_at=expires_at,
            linked_by=self.user_id,
            linked_at=datetime.now(UTC),
            imported_storage_path=imported_storage_path,
            raw_payload_json=raw_payload,
        )
        self.db.add(row)
        await self.db.commit()
        await self.db.refresh(row)
        return row

    async def list_for_entity(
        self, entity_type: str, entity_id: uuid.UUID
    ) -> list[DocumentLink]:
        rows = (
            await self.db.execute(
                select(DocumentLink)
                .where(
                    DocumentLink.tenant_id == self.tenant_id,
                    DocumentLink.entity_type == entity_type,
                    DocumentLink.entity_id == entity_id,
                )
                .order_by(DocumentLink.linked_at.desc())
            )
        ).scalars().all()
        return list(rows)
