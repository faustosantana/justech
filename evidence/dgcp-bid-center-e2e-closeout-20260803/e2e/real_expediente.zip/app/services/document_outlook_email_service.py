"""Envío de correos documentales vía Outlook (Microsoft Graph)."""

from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.m365_account import M365UserAccount
from app.schemas.m365_mail import M365MailComposeRequest
from app.services.m365_mail_service import M365MailService

logger = logging.getLogger(__name__)


class DocumentOutlookEmailService:
    DEFAULT_RECIPIENT = "recepcion@justech.do"
    ESCALATION_RECIPIENT = "fausto@justech.do"

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, *, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def send(
        self,
        *,
        to: str | list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
    ) -> dict:
        sender_id = await self._resolve_sender_user_id()
        if not sender_id:
            return {"ok": False, "message": "M365 no conectado — no se puede enviar correo", "sent": False}

        recipients = [to] if isinstance(to, str) else list(to)
        mail = M365MailService(self.db, self.tenant_id, sender_id)
        result = await mail.send_mail(
            M365MailComposeRequest(
                subject=subject,
                body=body,
                to=recipients,
                cc=cc or [],
            )
        )
        logger.info(
            "Document email tenant=%s to=%s ok=%s msg=%s",
            self.tenant_id,
            recipients,
            result.ok,
            result.message,
        )
        return {"ok": result.ok, "message": result.message, "sent": result.ok}

    async def _resolve_sender_user_id(self) -> uuid.UUID | None:
        if self.user_id:
            return self.user_id
        account = (
            await self.db.execute(
                select(M365UserAccount)
                .where(
                    M365UserAccount.tenant_id == self.tenant_id,
                    M365UserAccount.connection_status == "connected",
                )
                .order_by(M365UserAccount.last_sync_at.desc().nullslast())
                .limit(1)
            )
        ).scalar_one_or_none()
        return account.jaios_user_id if account else None

    @classmethod
    def notify_recipient(cls) -> str:
        return getattr(settings, "documents_notify_email", None) or cls.DEFAULT_RECIPIENT

    @classmethod
    def escalation_recipient(cls) -> str:
        return getattr(settings, "documents_escalation_email", None) or cls.ESCALATION_RECIPIENT
