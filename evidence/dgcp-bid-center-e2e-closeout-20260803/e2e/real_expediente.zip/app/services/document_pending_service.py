"""Detección y gestión de pendientes documentales."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document_pending import DocumentPendingItem
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.schemas.documents_hub import (
    DocumentPendingItemResponse,
    MissingItemsResponse,
    RepresentativeMissingDocument,
    RequestMissingPayload,
    RequestMissingResponse,
)
from app.schemas.tasks import TaskCreateRequest
from app.services.company_missing_info_email_service import FIELD_LABELS
from app.services.company_profile_sync_service import REQUIRED_FIELDS
from app.services.corporate_identity_service import CorporateIdentityService
from app.services.licitador_dashboard_service import COMPANY_KEYS, EXPECTED_LEGAL, LicitadorDashboardService
from app.services.document_outlook_email_service import DocumentOutlookEmailService
from app.services.task_service import TaskService

ONEDRIVE_PATHS = {
    "field": "Justech-AI/00_DATOS_EMPRESAS/{company}",
    "document": "Justech-AI/01_DOCUMENTOS_LEGALES/{company}",
    "template": "Justech-AI/02_PLANTILLAS/DGCP/{company}",
    "identity": "Justech-AI/09_IDENTIDAD_CORPORATIVA/{company}",
}

LEGAL_LABELS = {
    "registro_mercantil": "Registro Mercantil",
    "rnc": "RNC",
    "dgii": "Certificación DGII",
    "tss": "Certificación TSS",
    "mipyme": "MIPYME",
    "proveedor_estado": "Proveedor del Estado",
    "estatutos": "Estatutos",
    "acta_asamblea": "Acta Asamblea",
    "poderes": "Poder representante",
    "cedula_representante": "Cédula representante",
    "certificacion_bancaria": "Certificación bancaria",
}

IDENTITY_ITEMS = (
    ("logo", "Logo corporativo"),
    ("signature", "Firma autorizada"),
    ("stamp", "Sello"),
    ("stamp_gomigraph", "Sello gomígrafo"),
    ("representative_signature", "Imagen firma representante"),
)


class DocumentPendingService:
    DEFAULT_RECIPIENT = "recepcion@justech.do"
    ESCALATION_RECIPIENT = "fausto@justech.do"
    REMINDER_DAYS = 3
    ESCALATION_DAYS = 7

    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def scan_and_upsert(self) -> int:
        """Detecta faltantes y crea/actualiza registros de pendientes."""
        profiles = {
            p.company_key: p
            for p in (
                await self.db.execute(
                    select(LicitadorCompanyProfile).where(
                        LicitadorCompanyProfile.tenant_id == self.tenant_id
                    )
                )
            ).scalars().all()
        }
        legal = await LicitadorDashboardService(self.db, self.tenant_id).legal_documents()
        identity_svc = CorporateIdentityService(self.db, self.tenant_id, user_id=self.user_id)
        created = 0
        now = datetime.now(UTC)

        for key, label in COMPANY_KEYS:
            profile = profiles.get(key)
            company_label = (profile.razon_social if profile else None) or label
            company_folder = label.upper().replace(" ", "_")

            for field in (profile.missing_fields if profile else list(REQUIRED_FIELDS)) or []:
                if await self._upsert_pending(
                    company_key=key,
                    company_profile_id=profile.id if profile else None,
                    item_type="field",
                    item_key=field,
                    item_label=FIELD_LABELS.get(field, field.replace("_", " ").title()),
                    severity="missing",
                    onedrive_path=ONEDRIVE_PATHS["field"].format(company=company_folder),
                    suggested_filename=f"datos_empresa_{company_folder.lower()}.json",
                    detected_at=now,
                ):
                    created += 1

            company_legal = next((c for c in legal.companies if c.company_key == key), None)
            if company_legal:
                for doc_key in company_legal.missing_documents:
                    label_doc = LEGAL_LABELS.get(doc_key, doc_key.replace("_", " ").title())
                    if await self._upsert_pending(
                        company_key=key,
                        company_profile_id=profile.id if profile else None,
                        item_type="document",
                        item_key=doc_key,
                        item_label=label_doc,
                        severity="missing",
                        onedrive_path=ONEDRIVE_PATHS["document"].format(company=company_folder),
                        suggested_filename=f"{doc_key}_{company_folder}.pdf",
                        detected_at=now,
                    ):
                        created += 1
                for expired_name in company_legal.expired_documents:
                    if await self._upsert_pending(
                        company_key=key,
                        company_profile_id=profile.id if profile else None,
                        item_type="document",
                        item_key=expired_name[:64],
                        item_label=expired_name,
                        severity="expired",
                        onedrive_path=ONEDRIVE_PATHS["document"].format(company=company_folder),
                        suggested_filename=f"{expired_name.replace(' ', '_')}.pdf",
                        detected_at=now,
                    ):
                        created += 1

            try:
                overview = await identity_svc.get_company_assets(key)
                missing_identity = list(overview.missing or [])
            except Exception:
                missing_identity = [label for _, label in IDENTITY_ITEMS]
            for asset_key, asset_label in IDENTITY_ITEMS:
                if asset_label in missing_identity or asset_key in missing_identity:
                    if await self._upsert_pending(
                        company_key=key,
                        company_profile_id=profile.id if profile else None,
                        item_type="identity",
                        item_key=asset_key,
                        item_label=asset_label,
                        severity="missing",
                        onedrive_path=ONEDRIVE_PATHS["identity"].format(company=company_folder),
                        suggested_filename=f"{asset_key}_{company_folder}.png",
                        detected_at=now,
                    ):
                        created += 1

        await self.db.commit()
        return created

    async def list_pending(
        self, *, status: str | None = None, company_key: str | None = None
    ) -> list[DocumentPendingItemResponse]:
        stmt = select(DocumentPendingItem).where(DocumentPendingItem.tenant_id == self.tenant_id)
        if status:
            stmt = stmt.where(DocumentPendingItem.status == status)
        if company_key:
            stmt = stmt.where(DocumentPendingItem.company_key == company_key)
        stmt = stmt.order_by(DocumentPendingItem.detected_at.desc())
        rows = (await self.db.execute(stmt)).scalars().all()
        labels = {k: v for k, v in COMPANY_KEYS}
        return [self._to_response(r, labels.get(r.company_key, r.company_key)) for r in rows]

    async def get_missing_for_company(self, company_id: uuid.UUID) -> MissingItemsResponse:
        profile = (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == company_id,
                    LicitadorCompanyProfile.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not profile:
            raise ValueError("Empresa no encontrada")

        legal = await LicitadorDashboardService(self.db, self.tenant_id).legal_documents()
        company_legal = next((c for c in legal.companies if c.company_key == profile.company_key), None)
        pending = await self.list_pending(company_key=profile.company_key)

        identity_missing = [p.item_label for p in pending if p.item_type == "identity"]

        from app.services.company_representative_service import CompanyRepresentativeService

        rep_svc = CompanyRepresentativeService(self.db, self.tenant_id, user_id=self.user_id)
        rep_summary = await rep_svc.list_representatives(company_id)
        rep_missing = [
            RepresentativeMissingDocument(**item)
            for item in rep_svc.missing_documents_summary(rep_summary)
        ]

        return MissingItemsResponse(
            company_key=profile.company_key,
            empresa=profile.razon_social or profile.company_key,
            missing_fields=list(profile.missing_fields or []),
            missing_documents=company_legal.missing_documents if company_legal else [],
            expired_documents=company_legal.expired_documents if company_legal else [],
            identity_missing=identity_missing,
            pending_items=pending,
            representative_documents=rep_missing,
            validation_pending_count=rep_summary.validation_pending_count,
            representatives_count=rep_summary.total_representatives,
        )

    async def request_missing(
        self, company_id: uuid.UUID, payload: RequestMissingPayload
    ) -> RequestMissingResponse:
        missing = await self.get_missing_for_company(company_id)
        recipient = payload.recipient_email or DocumentOutlookEmailService.notify_recipient()
        selected = await self._resolve_selected_items(company_id, payload.item_ids, missing)

        lines = []
        for item in selected:
            path_line = f"  Ruta: {item.onedrive_path}" if item.onedrive_path else ""
            file_line = f"  Nombre sugerido: {item.suggested_filename}" if item.suggested_filename else ""
            lines.append(f"- {item.item_label}\n{path_line}\n{file_line}".strip())

        if not lines:
            for f in missing.missing_fields:
                lines.append(f"- {FIELD_LABELS.get(f, f)} (dato)")
            for d in missing.missing_documents:
                lines.append(f"- {LEGAL_LABELS.get(d, d)} (documento)")
            for e in missing.expired_documents:
                lines.append(f"- {e} (vencido)")

        body = (
            f"Hola Jennipher,\n\n"
            f"JAIOS detectó información pendiente para la empresa:\n\n"
            f"{missing.empresa}\n\n"
            f"Documentos o datos faltantes:\n\n"
            + "\n\n".join(lines)
            + "\n\nUbicación donde deben colocarse en OneDrive:\n"
            f"Justech-AI/01_DOCUMENTOS_LEGALES/{missing.empresa.upper().replace(' ', '_')}\n"
            f"o Justech-AI/00_DATOS_EMPRESAS/{missing.empresa.upper().replace(' ', '_')}\n\n"
            "Una vez cargados los archivos, JAIOS los sincronizará automáticamente.\n\n"
            "Gracias."
        )
        subject = f"Pendientes documentales detectados — {missing.empresa}"

        task_id = None
        if payload.create_task and self.user_id:
            tasks = TaskService(self.db, self.tenant_id, user_id=self.user_id)
            task = await tasks.create_task(
                TaskCreateRequest(
                    title=f"Solicitar documentación — {missing.empresa}",
                    description=body[:2000],
                    category="documento",
                    department="legal",
                    priority="media",
                )
            )
            task_id = str(task.id)

        now = datetime.now(UTC)
        if not payload.copy_only:
            for item in selected:
                row = await self._get_pending_row(item.id)
                if row:
                    row.status = "requested"
                    row.requested_at = now
                    row.requested_to_email = recipient
                    row.requested_by_user_id = self.user_id
                    row.due_at = now + timedelta(days=self.REMINDER_DAYS)
            await self.db.commit()

        sent = False
        if payload.send_email and not payload.copy_only:
            mail_result = await DocumentOutlookEmailService(
                self.db, self.tenant_id, user_id=self.user_id
            ).send(to=recipient, subject=subject, body=body)
            sent = bool(mail_result.get("sent"))

        return RequestMissingResponse(
            subject=subject,
            body=body,
            recipient=recipient,
            missing_items=[i.item_label for i in selected] or lines,
            task_id=task_id,
            sent=sent,
            can_send_outlook=True,
        )

    async def auto_resolve(self) -> int:
        """Cierra pendientes cuyo ítem ya no figura como faltante."""
        await self.scan_and_upsert()
        legal = await LicitadorDashboardService(self.db, self.tenant_id).legal_documents()
        profiles = {
            p.company_key: p
            for p in (
                await self.db.execute(
                    select(LicitadorCompanyProfile).where(LicitadorCompanyProfile.tenant_id == self.tenant_id)
                )
            ).scalars().all()
        }
        still_missing: set[tuple[str, str]] = set()
        for key, _ in COMPANY_KEYS:
            profile = profiles.get(key)
            for f in (profile.missing_fields if profile else []) or []:
                still_missing.add((key, f))
            company_legal = next((c for c in legal.companies if c.company_key == key), None)
            if company_legal:
                for d in company_legal.missing_documents:
                    still_missing.add((key, d))
                for e in company_legal.expired_documents:
                    still_missing.add((key, e[:64]))

        open_rows = list(
            (
                await self.db.execute(
                    select(DocumentPendingItem).where(
                        DocumentPendingItem.tenant_id == self.tenant_id,
                        DocumentPendingItem.status.in_(("open", "requested")),
                    )
                )
            ).scalars().all()
        )
        resolved = 0
        now = datetime.now(UTC)
        for row in open_rows:
            if (row.company_key, row.item_key) not in still_missing:
                row.status = "resolved"
                row.resolved_at = now
                row.notes = (row.notes or "") + " [auto-sync]"
                resolved += 1
        if resolved:
            await self.db.commit()
        return resolved

    async def mark_received(self, pending_id: uuid.UUID) -> DocumentPendingItemResponse:
        row = (
            await self.db.execute(
                select(DocumentPendingItem).where(
                    DocumentPendingItem.id == pending_id,
                    DocumentPendingItem.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()
        if not row:
            raise ValueError("Pendiente no encontrado")
        row.status = "resolved"
        row.resolved_at = datetime.now(UTC)
        await self.db.commit()
        labels = {k: v for k, v in COMPANY_KEYS}
        return self._to_response(row, labels.get(row.company_key, row.company_key))

    async def _upsert_pending(self, **kwargs) -> bool:
        existing_rows = list(
            (
                await self.db.execute(
                    select(DocumentPendingItem)
                    .where(
                        DocumentPendingItem.tenant_id == self.tenant_id,
                        DocumentPendingItem.company_key == kwargs["company_key"],
                        DocumentPendingItem.item_key == kwargs["item_key"],
                        DocumentPendingItem.status.in_(("open", "requested")),
                    )
                    .order_by(DocumentPendingItem.detected_at.desc())
                )
            ).scalars().all()
        )
        if len(existing_rows) > 1:
            for dup in existing_rows[1:]:
                dup.status = "resolved"
                dup.resolved_at = datetime.now(UTC)
                dup.notes = (dup.notes or "") + " [duplicado]"
        existing = existing_rows[0] if existing_rows else None
        if existing:
            existing.severity = kwargs.get("severity", existing.severity)
            existing.item_label = kwargs.get("item_label", existing.item_label)
            existing.onedrive_path = kwargs.get("onedrive_path", existing.onedrive_path)
            existing.suggested_filename = kwargs.get("suggested_filename", existing.suggested_filename)
            return False
        row = DocumentPendingItem(tenant_id=self.tenant_id, **kwargs)
        self.db.add(row)
        return True

    async def _resolve_selected_items(
        self, company_id: uuid.UUID, item_ids: list[str], missing: MissingItemsResponse
    ) -> list[DocumentPendingItemResponse]:
        if not item_ids:
            return missing.pending_items
        selected = [p for p in missing.pending_items if p.id in item_ids]
        return selected

    async def _get_pending_row(self, item_id: str) -> DocumentPendingItem | None:
        try:
            pid = uuid.UUID(item_id)
        except ValueError:
            return None
        return (
            await self.db.execute(
                select(DocumentPendingItem).where(
                    DocumentPendingItem.id == pid,
                    DocumentPendingItem.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()

    @staticmethod
    def _to_response(row: DocumentPendingItem, company_label: str) -> DocumentPendingItemResponse:
        return DocumentPendingItemResponse(
            id=str(row.id),
            company_key=row.company_key,
            company_label=company_label,
            item_type=row.item_type,
            item_key=row.item_key,
            item_label=row.item_label,
            status=row.status,
            severity=row.severity,
            detected_at=row.detected_at,
            requested_at=row.requested_at,
            requested_to_email=row.requested_to_email,
            reminder_count=row.reminder_count,
            due_at=row.due_at,
            onedrive_path=row.onedrive_path,
            onedrive_url=row.onedrive_url,
            suggested_filename=row.suggested_filename,
        )
