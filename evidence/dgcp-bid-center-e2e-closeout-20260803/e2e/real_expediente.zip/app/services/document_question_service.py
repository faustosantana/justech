"""Consultas documentales para JAIOS Assistant."""

from __future__ import annotations

import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.assistant import AssistantQueryResponse
from app.services.business_answer_builder import build_business_answer
from app.services.document_completion_service import DocumentCompletionService
from app.services.document_expediente_service import DocumentExpedienteService
from app.services.document_service import DocumentService
from app.services.m365_connection_service import M365ConnectionService
from app.services.m365_graph_session import M365GraphSessionService
from app.services.m365_repository_service import M365RepositoryService
from integrations.microsoft365.errors import GraphError


class DocumentQuestionService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.docs = DocumentService(db, tenant_id, user_id)
        self.completion = DocumentCompletionService()
        self.expediente = DocumentExpedienteService(db, tenant_id)

    async def answer(self, question: str, *, sub_intent: str | None, search_term: str | None) -> AssistantQueryResponse:
        q = question.strip()
        lowered = q.lower()

        if sub_intent == "completion_preview" or "sncc" in lowered and "f042" in lowered:
            preview = await self.completion.preview(form_type="SNCC.F042")
            summary = f"Vista previa de completado para {preview.form_type} — {preview.company}."
            structured = build_business_answer(
                intent="document_query",
                source="documents",
                summary=summary,
                metrics=[{"label": k, "value": v} for k, v in preview.fields.items()],
                warnings=[preview.note],
            )
            return AssistantQueryResponse(
                question=q,
                answer=summary,
                sources=["documents"],
                query_type="document_query",
                structured_data=structured,
            )

        if "faltan" in lowered and "licit" in lowered:
            exp = await self.expediente.build("licitacion", "")
            summary = (
                f"Expediente de licitación: {exp.missing_count} documento(s) faltante(s)."
                if exp.missing_count
                else "Expediente de licitación completo según documentos registrados."
            )
            rows = [[i.label, i.status, i.document_title or "—"] for i in exp.items]
            structured = build_business_answer(
                intent="document_query",
                source="documents",
                summary=summary,
                tables=[{"title": "Expediente licitación", "columns": ["Requisito", "Estado", "Documento"], "rows": rows}],
            )
            return AssistantQueryResponse(
                question=q,
                answer=summary,
                sources=["documents"],
                query_type="document_query",
                structured_data=structured,
            )

        if "vencen" in lowered and ("certific" in lowered or "mes" in lowered):
            health = await self.docs.health()
            summary = f"Hay {health.alerts_open} alerta(s) de cumplimiento documental abiertas."
            structured = build_business_answer(
                intent="document_query",
                source="documents",
                summary=summary,
                metrics=[
                    {"label": "Alertas abiertas", "value": str(health.alerts_open)},
                    {"label": "Documentos", "value": str(health.documents_count)},
                ],
            )
            return AssistantQueryResponse(
                question=q,
                answer=summary,
                sources=["documents"],
                query_type="document_query",
                structured_data=structured,
            )

        if "vencid" in lowered and "document" in lowered:
            health = await self.docs.health()
            summary = (
                f"Hay {health.alerts_open} alerta(s) de cumplimiento documental abiertas."
                if health.alerts_open
                else "No hay documentos vencidos registrados en el módulo Documentos."
            )
            structured = build_business_answer(
                intent="document_query",
                source="documents",
                summary=summary,
                metrics=[
                    {"label": "Alertas abiertas", "value": str(health.alerts_open)},
                    {"label": "Documentos", "value": str(health.documents_count)},
                ],
            )
            return AssistantQueryResponse(
                question=q,
                answer=summary,
                sources=["documents"],
                query_type="document_query",
                structured_data=structured,
            )

        if "vigente" in lowered and any(k in lowered for k in ("dgii", "rpe", "tss", "registro", "certific")):
            health = await self.docs.health()
            doc_label = next((k.upper() for k in ("dgii", "rpe", "tss") if k in lowered), "documento")
            summary = (
                f"Consulta de vigencia {doc_label}: {health.documents_count} documento(s) en repositorio."
            )
            structured = build_business_answer(
                intent="document_query",
                source="documents",
                summary=summary,
                metrics=[{"label": "Documentos", "value": str(health.documents_count)}],
            )
            return AssistantQueryResponse(
                question=q,
                answer=summary,
                sources=["documents"],
                query_type="document_query",
                structured_data=structured,
            )

        term = search_term or self._extract_term(q)
        if not term:
            return AssistantQueryResponse(
                question=q,
                answer="Indica qué documento o término buscar. Ejemplo: «¿Dónde está el RPE de Justech?»",
                sources=["documents"],
                query_type="document_query",
            )

        results = await self.docs.search_content(term, limit=10)
        m365_rows = await self._search_m365(term, limit=10)

        if not results.hits and not m365_rows:
            return AssistantQueryResponse(
                question=q,
                answer=(
                    f"No encontré documentos relacionados con «{term}» en JAIOS ni en Microsoft 365. "
                    "Conecte M365 y sincronice el repositorio en Documentos → Repositorios."
                ),
                sources=["documents"],
                query_type="document_query",
            )

        parts: list[str] = []
        rows: list[list[str]] = []
        sources = ["documents"]

        if results.hits:
            parts.append(f"JAIOS: {results.total} coincidencia(s) para «{term}».")
            for h in results.hits[:5]:
                rows.append([h.title, h.snippet, str(h.page_number or "—"), "JAIOS", f"{h.score:.0f}"])

        if m365_rows:
            parts.append(f"Microsoft 365: {len(m365_rows)} documento(s).")
            sources.append("m365")
            for name, source_label, category, web_url in m365_rows[:8]:
                rows.append([name, category, source_label, web_url or "—", "M365"])

        summary = " ".join(parts) if parts else f"Resultados para «{term}»."
        structured = build_business_answer(
            intent="document_query",
            source="documents",
            summary=summary,
            metrics=[{"label": "Resultados", "value": str(len(rows))}],
            tables=[{
                "title": "Documentos encontrados",
                "columns": ["Documento", "Detalle", "Fuente", "Enlace", "Origen"],
                "rows": rows[:12],
            }],
        )
        return AssistantQueryResponse(
            question=q,
            answer=summary,
            sources=list(dict.fromkeys(sources)),
            query_type="document_query",
            structured_data=structured,
        )

    async def _search_m365(
        self, term: str, *, limit: int = 10
    ) -> list[tuple[str, str, str, str | None]]:
        """Busca en repositorio indexado y Graph (OneDrive + SharePoint)."""
        rows: list[tuple[str, str, str, str | None]] = []
        seen: set[str] = set()

        repo = await M365RepositoryService(self.db, self.tenant_id, self.user_id).list_files(
            search=term, limit=limit
        )
        for item in repo.items:
            key = (item.name or "").lower()
            if key in seen:
                continue
            seen.add(key)
            rows.append(
                (
                    item.name,
                    item.source or "repositorio",
                    item.document_category_label or item.document_category,
                    item.web_url,
                )
            )

        conn = await M365ConnectionService(self.db, self.tenant_id, self.user_id).connection_state()
        if not conn.account_connected or len(rows) >= limit:
            return rows[:limit]

        try:
            sess = await M365GraphSessionService(self.db, self.tenant_id, self.user_id).session_for_account(None)
            od_items = await sess.client.onedrive.list_items(search=term, limit=5)
            for item in od_items:
                if item.is_folder:
                    continue
                key = (item.name or "").lower()
                if key in seen:
                    continue
                seen.add(key)
                rows.append((item.name or "sin nombre", "onedrive", "OneDrive Business", item.web_url))
            sp_sites = await sess.client.sharepoint.list_sites(search=term, limit=3)
            for site in sp_sites:
                key = (site.name or "").lower()
                if key in seen:
                    continue
                seen.add(key)
                rows.append((site.name or "Sitio", "sharepoint", "SharePoint", site.web_url))
        except GraphError:
            pass

        return rows[:limit]

    @staticmethod
    def _extract_term(question: str) -> str | None:
        import re

        patterns = (
            r"(?i)(?:dónde está|donde esta|busca|buscar|muéstrame|muestrame|tenemos)\s+(?:el|la|los|las)?\s*(.+)",
            r"(?i)documentos?\s+(?:de|con|donde aparezca)\s+(.+)",
            r"(?i)contratos?\s+de\s+(.+)",
        )
        for pat in patterns:
            m = re.search(pat, question.strip().rstrip("?"))
            if m:
                return m.group(1).strip().rstrip("?.")
        return None
