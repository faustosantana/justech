"""Servicio de plantillas documentales y autollenado unificado."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document_template import DocumentTemplate
from app.services.document_completion_service import DocumentCompletionService

TEMPLATE_CATEGORIES = ("dgcp", "legal", "commercial", "internal")

DEFAULT_TEMPLATES: list[dict] = [
    {"slug": "sncc-f042", "name": "SNCC F.042", "category": "dgcp", "document_type": "form", "required_fields": ["razon_social", "rnc", "direccion", "representante_legal", "telefono", "correo"]},
    {"slug": "sncc-f033", "name": "SNCC F.033", "category": "dgcp", "document_type": "form", "required_fields": ["razon_social", "rnc", "representante_legal"]},
    {"slug": "sncc-f047", "name": "SNCC F.047", "category": "dgcp", "document_type": "form", "required_fields": ["razon_social", "rnc", "direccion", "cuenta_bancaria"]},
    {"slug": "carta-presentacion", "name": "Carta de presentación", "category": "commercial", "document_type": "letter", "required_fields": ["razon_social", "representante_legal", "proceso_dgcp", "entidad_contratante"]},
    {"slug": "declaracion-jurada", "name": "Declaración jurada", "category": "legal", "document_type": "declaration", "required_fields": ["razon_social", "rnc", "representante_legal", "cedula_representante"]},
    {"slug": "oferta-economica", "name": "Oferta económica", "category": "commercial", "document_type": "offer", "required_fields": ["razon_social", "proceso_dgcp", "monto", "productos", "plazo_entrega"]},
    {"slug": "oferta-tecnica", "name": "Oferta técnica", "category": "commercial", "document_type": "offer", "required_fields": ["razon_social", "proceso_dgcp", "productos", "garantias"]},
    {"slug": "checklist-interno", "name": "Checklist interno", "category": "internal", "document_type": "checklist", "required_fields": ["proceso_dgcp", "responsable"]},
]

FIELD_LABELS: dict[str, str] = {
    "razon_social": "Nombre empresa",
    "rnc": "RNC",
    "direccion": "Dirección",
    "representante_legal": "Representante",
    "cedula_representante": "Cédula representante",
    "telefono": "Teléfono",
    "correo": "Correo",
    "proceso_dgcp": "Código proceso",
    "entidad_contratante": "Entidad contratante",
    "modalidad": "Modalidad",
    "monto": "Monto",
    "productos": "Productos",
    "garantias": "Garantías",
    "plazo_entrega": "Plazo de entrega",
    "condiciones_pago": "Condiciones de pago",
    "cuenta_bancaria": "Cuenta bancaria",
    "responsable": "Responsable interno",
}


class DocumentTemplateService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.completion = DocumentCompletionService(db=db, tenant_id=tenant_id)
        self._templates_root = Path(__file__).resolve().parent.parent.parent / "templates"

    async def ensure_defaults(self) -> int:
        count = 0
        now = datetime.now(UTC)
        for tpl in DEFAULT_TEMPLATES:
            stmt = insert(DocumentTemplate).values(
                tenant_id=self.tenant_id,
                slug=tpl["slug"],
                name=tpl["name"],
                category=tpl["category"],
                document_type=tpl["document_type"],
                file_path=str(self._templates_root / tpl["category"] / f"{tpl['slug']}.docx"),
                required_fields=tpl["required_fields"],
                optional_fields=[],
                description=f"Plantilla {tpl['name']}",
                indexed_at=now,
            )
            stmt = stmt.on_conflict_do_nothing(constraint="uq_document_template_slug")
            result = await self.db.execute(stmt)
            if result.rowcount:
                count += 1
        return count

    async def list_templates(self, *, category: str | None = None) -> list[DocumentTemplate]:
        await self.ensure_defaults()
        stmt = select(DocumentTemplate).where(
            DocumentTemplate.tenant_id == self.tenant_id,
            DocumentTemplate.is_active.is_(True),
        )
        if category:
            stmt = stmt.where(DocumentTemplate.category == category)
        stmt = stmt.order_by(DocumentTemplate.category, DocumentTemplate.name)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_missing_fields(
        self,
        *,
        template_slug: str,
        company_key: str = "justech",
        extra_context: dict | None = None,
    ) -> dict:
        await self.ensure_defaults()
        result = await self.db.execute(
            select(DocumentTemplate).where(
                DocumentTemplate.tenant_id == self.tenant_id,
                DocumentTemplate.slug == template_slug,
            )
        )
        template = result.scalar_one_or_none()
        if not template:
            return {"error": "Plantilla no encontrada", "missing_fields": [], "hermes_message": ""}

        form_type = template.slug.upper().replace("-", ".")
        preview = await self.completion.preview(form_type=form_type, company_key=company_key)
        merged = dict(preview.fields)
        if extra_context:
            for k, v in extra_context.items():
                if v:
                    merged[k] = str(v)

        missing_keys = []
        for field in template.required_fields:
            if not merged.get(field):
                missing_keys.append(field)

        missing_labels = [FIELD_LABELS.get(k, k.replace("_", " ").title()) for k in missing_keys]
        hermes_message = ""
        if missing_labels:
            hermes_message = (
                f"Puedo autollenar «{template.name}», pero faltan estos datos: {', '.join(missing_labels)}."
            )
        else:
            hermes_message = f"Puedo autollenar «{template.name}» con los datos disponibles. Revise el preview antes de generar."

        return {
            "template_slug": template.slug,
            "template_name": template.name,
            "category": template.category,
            "filled_fields": merged,
            "missing_fields": missing_keys,
            "missing_labels": missing_labels,
            "hermes_message": hermes_message,
            "can_generate": len(missing_keys) == 0,
        }
