"""Hub unificado — Documentos y Repositorios."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime

from sqlalchemy import func, select

logger = logging.getLogger(__name__)
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.corporate_identity import CorporateIdentityAsset
from app.models.document_pending import DocumentPendingItem
from app.models.integration_settings import IntegrationRepositoryBinding
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.models.repository_sync import RepositorySyncJob
from app.schemas.documents_hub import (
    CompanyDocumentProfileResponse,
    CompanyHubCard,
    CompanyProfileUpdateRequest,
    DocumentsHubDashboardResponse,
    DocumentsHubMetricCard,
    DocumentsHubSyncInfo,
    DocumentsTrackingSummary,
    GeneralRepositoryCard,
    RepositoryBindingSummary,
)
from app.services.company_normalization_service import (
    CANONICAL_COMPANIES,
    COMPANY_KEYS,
    CompanyNormalizationService,
    canonical_label,
    company_folder,
    identity_onedrive_paths,
)
from app.services.company_profile_sync_service import CompanyProfileSyncService, REQUIRED_FIELDS
from app.services.corporate_repository_unified_service import CorporateRepositoryUnifiedService
from app.services.corporate_identity_service import CorporateIdentityService
from app.services.document_pending_service import DocumentPendingService
from app.services.integration_repository_service import IntegrationRepositoryService
from app.services.licitador_dashboard_service import LicitadorDashboardService
from app.services.repository_sync_service import GENERAL_REPOSITORY_KEYS, RepositorySyncService


class DocumentsHubService:
    DEFAULT_RECIPIENT = "recepcion@justech.do"

    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._profiles = CompanyProfileSyncService(db, tenant_id, user_id=user_id)
        self._dash = LicitadorDashboardService(db, tenant_id, user_id=user_id)
        self._pending = DocumentPendingService(db, tenant_id, user_id=user_id)
        self._repos = IntegrationRepositoryService(db, tenant_id, actor_id=user_id)

    async def dashboard(self, *, scan_pending: bool = False) -> DocumentsHubDashboardResponse:
        if scan_pending:
            try:
                await self._pending.scan_and_upsert()
            except Exception:
                logger.exception("documents hub pending scan failed tenant=%s", self.tenant_id)

        norm = CompanyNormalizationService(self.db, self.tenant_id)
        profile_rows = await norm.list_canonical_profiles()
        profiles = [self._profiles._profile_dict(r) for r in profile_rows]
        legal = await self._dash.legal_documents()
        templates = await self._dash.dgcp_templates()
        prices = await self._dash.price_intelligence()
        bindings = await self._repos.list_bindings()

        sig_count = int(
            await self.db.scalar(
                select(func.count())
                .select_from(CorporateIdentityAsset)
                .where(
                    CorporateIdentityAsset.tenant_id == self.tenant_id,
                    CorporateIdentityAsset.asset_type == "signature",
                    CorporateIdentityAsset.status == "disponible",
                )
            )
            or 0
        )
        stamp_count = int(
            await self.db.scalar(
                select(func.count())
                .select_from(CorporateIdentityAsset)
                .where(
                    CorporateIdentityAsset.tenant_id == self.tenant_id,
                    CorporateIdentityAsset.asset_type == "stamp",
                    CorporateIdentityAsset.status == "disponible",
                )
            )
            or 0
        )

        open_pending = int(
            await self.db.scalar(
                select(func.count())
                .select_from(DocumentPendingItem)
                .where(
                    DocumentPendingItem.tenant_id == self.tenant_id,
                    DocumentPendingItem.status.in_(("open", "requested")),
                )
            )
            or 0
        )

        complete = sum(1 for p in profiles if p.get("completeness_score", 0) >= 80)
        incomplete = max(len(profiles), len(COMPANY_KEYS)) - complete

        recent_jobs = list(
            (
                await self.db.execute(
                    select(RepositorySyncJob)
                    .where(RepositorySyncJob.tenant_id == self.tenant_id)
                    .order_by(RepositorySyncJob.started_at.desc())
                    .limit(8)
                )
            ).scalars().all()
        )

        binding_map = {str(b["folder_key"]): b for b in bindings}
        recent_syncs: list[DocumentsHubSyncInfo] = []
        for job in recent_jobs:
            binding = await self._binding_for_job(job.binding_id)
            if binding:
                recent_syncs.append(
                    DocumentsHubSyncInfo(
                        folder_key=binding.folder_key,
                        label=binding.label,
                        status=job.status,
                        last_sync_at=job.completed_at or job.started_at,
                        indexed_files=binding.indexed_files or 0,
                        last_error=job.error_message,
                    )
                )

        recent_errors = [
            j.error_message
            for j in recent_jobs
            if j.error_message and j.status == "error"
        ][:5]
        for b in bindings:
            if b.get("last_error"):
                recent_errors.append(f"{b.get('label')}: {b['last_error']}")
        recent_errors = list(dict.fromkeys(recent_errors))[:8]

        repo_summaries = [
            RepositoryBindingSummary(
                id=str(b["id"]) if b.get("id") else None,
                folder_key=b["folder_key"],
                label=b["label"],
                folder_path=b.get("folder_path"),
                status=b.get("status") or "not_configured",
                indexed_files=int(b.get("indexed_files") or 0),
                last_sync_at=b.get("last_sync_at"),
                last_error=b.get("last_error"),
                web_url=b.get("web_url"),
            )
            for b in bindings
        ]

        cards = [
            DocumentsHubMetricCard(
                key="empresas",
                label="Datos empresas",
                value=len(profiles) or len(COMPANY_KEYS),
                href="/documentos/empresas",
            ),
            DocumentsHubMetricCard(
                key="legales",
                label="Documentos legales",
                value=legal.total_documents,
                href="/documentos/legales",
            ),
            DocumentsHubMetricCard(
                key="plantillas",
                label="Plantillas DGCP",
                value=templates.total,
                href="/documentos/plantillas",
            ),
            DocumentsHubMetricCard(
                key="repositorios",
                label="Repositorios OneDrive",
                value=len(bindings),
                href="/documentos/repositorios",
                variant="blue",
            ),
            DocumentsHubMetricCard(
                key="identidad",
                label="Identidad corporativa",
                value=sig_count + stamp_count,
                href="/documentos/identidad",
            ),
            DocumentsHubMetricCard(
                key="precios",
                label="Inteligencia de precios",
                value=prices.total_products,
                href="/documentos/precios",
            ),
            DocumentsHubMetricCard(
                key="salidas",
                label="Expedientes / Salidas",
                value=open_pending,
                href="/documentos/salidas",
            ),
        ]

        if not recent_syncs and repo_summaries:
            recent_syncs = [
                DocumentsHubSyncInfo(
                    folder_key=r.folder_key,
                    label=r.label,
                    status=r.status,
                    last_sync_at=r.last_sync_at,
                    indexed_files=r.indexed_files,
                    last_error=r.last_error,
                )
                for r in repo_summaries[:8]
            ]

        general_repos = self._build_general_repositories(bindings, templates, prices)
        company_cards = await self._build_company_cards(legal)

        return DocumentsHubDashboardResponse(
            total_companies=len(CANONICAL_COMPANIES),
            legal_documents_loaded=legal.total_documents,
            documents_missing=legal.total_missing,
            documents_expired=legal.total_expired,
            dgcp_templates_available=templates.total,
            price_lists_pending=len(prices.pending_files),
            price_lists_processed=len(prices.processed_files),
            stamps_registered=stamp_count,
            signatures_registered=sig_count,
            pending_items_open=open_pending,
            companies_complete=complete,
            companies_incomplete=incomplete,
            recent_syncs=recent_syncs,
            recent_errors=recent_errors,
            submodule_cards=cards,
            repository_bindings=repo_summaries,
            general_repositories=general_repos,
            company_cards=company_cards,
        )

    async def list_general_repositories(self) -> list[GeneralRepositoryCard]:
        bindings = await self._repos.list_bindings()
        templates = await self._dash.dgcp_templates()
        prices = await self._dash.price_intelligence()
        return self._build_general_repositories(bindings, templates, prices)

    def _build_general_repositories(self, bindings, templates, prices) -> list[GeneralRepositoryCard]:
        binding_map = {b["folder_key"]: b for b in bindings}
        cards = [
            GeneralRepositoryCard(
                key="plantillas",
                label="Plantillas DGCP",
                folder_path=binding_map.get("02_PLANTILLAS_DGCP", {}).get("folder_path")
                or "Justech-AI/02_PLANTILLAS/DGCP/PROVEEDORES_DEL_ESTADO",
                href="/documentos/plantillas",
                indexed_files=templates.total,
                status=binding_map.get("02_PLANTILLAS_DGCP", {}).get("status", "not_configured"),
                description="Plantillas oficiales DGCP — no por empresa",
            ),
            GeneralRepositoryCard(
                key="precios",
                label="Listas de precios",
                folder_path="Justech-AI/03_PROVEEDORES/ENTRADAS · PROCESADOS",
                href="/documentos/precios",
                indexed_files=len(prices.pending_files) + len(prices.processed_files),
                status="synced" if prices.pending_files or prices.processed_files else "not_configured",
                description="Entradas y listas procesadas de proveedores",
            ),
            GeneralRepositoryCard(
                key="salidas",
                label="Expedientes / Salidas",
                folder_path="Justech-AI/SALIDAS · LICITACIONES",
                href="/documentos/salidas",
                indexed_files=int(binding_map.get("SALIDAS", {}).get("indexed_files", 0))
                + int(binding_map.get("LICITACIONES", {}).get("indexed_files", 0)),
                status=binding_map.get("SALIDAS", {}).get("status", "not_configured"),
                description="Expedientes generados y licitaciones",
            ),
            GeneralRepositoryCard(
                key="fichas",
                label="Fichas técnicas",
                folder_path=binding_map.get("FICHAS_TECNICAS", {}).get("folder_path")
                or "Justech-AI/FICHAS_TECNICAS",
                href="/documentos/repositorios",
                indexed_files=int(binding_map.get("FICHAS_TECNICAS", {}).get("indexed_files", 0)),
                status=binding_map.get("FICHAS_TECNICAS", {}).get("status", "not_configured"),
                description="Catálogos y fichas técnicas generales",
            ),
            GeneralRepositoryCard(
                key="repositorios",
                label="Repositorios OneDrive",
                folder_path="Justech-AI/",
                href="/documentos/repositorios",
                indexed_files=sum(int(b.get("indexed_files") or 0) for b in bindings),
                status="synced",
                description="Vista técnica de todas las carpetas sincronizadas",
            ),
        ]
        return cards

    async def _build_company_cards(self, legal) -> list[CompanyHubCard]:
        norm = CompanyNormalizationService(self.db, self.tenant_id)
        profiles = await norm.list_canonical_profiles()
        legal_map = {c.company_key: c for c in legal.companies}
        identity_svc = CorporateIdentityService(self.db, self.tenant_id, user_id=self.user_id)

        cards: list[CompanyHubCard] = []
        for row in profiles:
            company_legal = legal_map.get(row.company_key)
            try:
                identity = await identity_svc.get_company_assets(row.company_key)
                identity_missing = list(identity.missing or [])
                identity_available = len(identity_missing) == 0 and (
                    len(identity.signatures or []) > 0 or len(identity.stamps or []) > 0
                )
            except Exception:
                identity_missing = []
                identity_available = False

            folder = company_folder(row.company_key)
            id_primary, _id_fb = identity_onedrive_paths(row.company_key)
            cards.append(
                CompanyHubCard(
                    id=str(row.id),
                    company_key=row.company_key,
                    razon_social=canonical_label(row.company_key),
                    rnc=row.rnc,
                    completeness_score=row.completeness_score or 0,
                    legal_documents_loaded=len(company_legal.documents) if company_legal else 0,
                    documents_missing=len(company_legal.missing_documents) if company_legal else 0,
                    documents_expired=len(company_legal.expired_documents) if company_legal else 0,
                    identity_available=identity_available,
                    identity_missing=identity_missing,
                    missing_fields_count=len(row.missing_fields or []),
                    onedrive_data_path=f"Justech-AI/00_DATOS_EMPRESAS/{folder}",
                    onedrive_legal_path=f"Justech-AI/01_DOCUMENTOS_LEGALES/{folder}",
                    onedrive_identity_path=id_primary,
                    href=f"/apps/empresas-grupo/perfil/{row.id}",
                )
            )
        return cards

    async def list_companies(self) -> list[CompanyDocumentProfileResponse]:
        norm = CompanyNormalizationService(self.db, self.tenant_id)
        rows = await norm.list_canonical_profiles()
        return [
            await self._to_profile_response(self._profiles._profile_dict(row), row=row)
            for row in rows
        ]

    async def sync_all_onedrive(self) -> dict:
        sync = RepositorySyncService(self.db, self.tenant_id, user_id=self.user_id)
        bindings = await sync.list_bindings()
        synced = []
        errors = []
        for b in bindings:
            if b.get("id"):
                try:
                    result = await sync.sync_binding(uuid.UUID(str(b["id"])))
                    synced.append({"folder": b["folder_key"], **result})
                except Exception as exc:
                    errors.append(f"{b['folder_key']}: {exc}")
        try:
            await self._pending.scan_and_upsert()
        except Exception:
            logger.exception("pending scan after full sync failed")
        return {"synced": synced, "errors": errors}

    async def get_company(self, company_id: uuid.UUID) -> CompanyDocumentProfileResponse | None:
        row = await self._get_profile_row(company_id)
        if not row:
            return None
        return await self._to_profile_response(self._profiles._profile_dict(row), row=row)

    async def update_company(
        self, company_id: uuid.UUID, payload: CompanyProfileUpdateRequest
    ) -> CompanyDocumentProfileResponse:
        row = await self._get_profile_row(company_id)
        if not row:
            raise ValueError("Empresa no encontrada")

        data = payload.model_dump(exclude_unset=True)
        raw = dict(row.raw_json or {})
        for field, value in data.items():
            if value is not None:
                setattr(row, field, value) if hasattr(row, field) else None
                raw[field] = value

        if payload.datos_bancarios is not None:
            raw["datos_bancarios"] = payload.datos_bancarios
        if payload.registro_mercantil is not None:
            raw["registro_mercantil"] = payload.registro_mercantil
        if payload.proveedor_estado is not None:
            raw["proveedor_estado"] = payload.proveedor_estado
        for resp_field in ("responsable_legal", "responsable_financiero", "responsable_licitaciones"):
            if getattr(payload, resp_field, None) is not None:
                raw[resp_field] = getattr(payload, resp_field)

        row.raw_json = raw
        missing = []
        normalized = CompanyProfileSyncService._normalize_json(raw)
        for f in REQUIRED_FIELDS:
            if not normalized.get(f):
                missing.append(f)
        row.missing_fields = missing
        total = len(REQUIRED_FIELDS)
        row.completeness_score = int(((total - len(missing)) / total) * 100) if total else 0
        await self.db.commit()
        await self.db.refresh(row)
        await self._pending.scan_and_upsert()
        return await self._to_profile_response(self._profiles._profile_dict(row), row=row)

    async def tracking_summary(self) -> DocumentsTrackingSummary:
        norm = CompanyNormalizationService(self.db, self.tenant_id)
        profile_rows = await norm.list_canonical_profiles()
        profiles = [self._profiles._profile_dict(r) for r in profile_rows]
        legal = await self._dash.legal_documents()
        pending_rows = list(
            (
                await self.db.execute(
                    select(DocumentPendingItem).where(
                        DocumentPendingItem.tenant_id == self.tenant_id,
                    )
                )
            ).scalars().all()
        )
        now = datetime.now(UTC)
        return DocumentsTrackingSummary(
            companies_complete=sum(1 for p in profiles if p.get("completeness_score", 0) >= 80),
            companies_incomplete=sum(1 for p in profiles if p.get("completeness_score", 0) < 80),
            documents_expired=legal.total_expired,
            documents_missing=legal.total_missing,
            requests_sent=sum(1 for p in pending_rows if p.status == "requested"),
            requests_pending=sum(1 for p in pending_rows if p.status in ("open", "requested")),
            requests_overdue=sum(
                1 for p in pending_rows
                if p.status == "requested" and p.due_at and p.due_at < now
            ),
        )

    async def _binding_for_job(self, binding_id: uuid.UUID | None) -> IntegrationRepositoryBinding | None:
        if not binding_id:
            return None
        return (
            await self.db.execute(
                select(IntegrationRepositoryBinding).where(
                    IntegrationRepositoryBinding.id == binding_id,
                    IntegrationRepositoryBinding.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()

    async def _get_profile_row(self, company_id: uuid.UUID) -> LicitadorCompanyProfile | None:
        return (
            await self.db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == company_id,
                    LicitadorCompanyProfile.tenant_id == self.tenant_id,
                )
            )
        ).scalar_one_or_none()

    async def _to_profile_response(
        self, profile: dict, *, row: LicitadorCompanyProfile | None = None
    ) -> CompanyDocumentProfileResponse:
        raw = (row.raw_json if row else {}) or {}
        if row:
            unified = CorporateRepositoryUnifiedService(
                self.db, self.tenant_id, company_key=row.company_key
            )
            legal_docs = await unified.resolve_legal_documents()
            normalized = await unified.enrich_profile_from_documents(row, legal_docs=legal_docs)
        else:
            normalized = CompanyProfileSyncService._normalize_json(raw)
        company_key = profile["company_key"]
        return CompanyDocumentProfileResponse(
            id=profile["id"],
            company_key=company_key,
            razon_social=normalized.get("razon_social") or canonical_label(company_key),
            nombre_comercial=normalized.get("nombre_comercial"),
            rnc=normalized.get("rnc"),
            direccion=normalized.get("direccion"),
            telefono=normalized.get("telefono"),
            correo=normalized.get("correo"),
            representante_legal=normalized.get("representante_legal"),
            cedula_representante=normalized.get("cedula_representante"),
            cargo_representante=normalized.get("cargo_representante"),
            registro_mercantil=str(normalized.get("registro_mercantil") or "") or None,
            proveedor_estado=CorporateRepositoryUnifiedService.resolve_rpe_display(normalized)
                if row
                else str(normalized.get("proveedor_estado") or normalized.get("rpe") or "") or None,
            datos_bancarios=str(normalized.get("datos_bancarios") or "") or None,
            responsable_legal=str(normalized.get("responsable_legal") or "") or None,
            responsable_financiero=str(normalized.get("responsable_financiero") or "") or None,
            responsable_licitaciones=str(normalized.get("responsable_licitaciones") or "") or None,
            missing_fields=profile.get("missing_fields") or [],
            completeness_score=profile.get("completeness_score") or 0,
            synced_at=profile.get("synced_at"),
            source_filename=profile.get("source_filename"),
            raw_json=raw,
        )
