"""Búsqueda comercial unificada — listas indexadas, proveedores live y directorio."""

from __future__ import annotations

import asyncio
import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.search import SearchResultGroup, SearchResultItem
from app.schemas.supplier import SupplierSearchRequest
from app.services.enterprise_search_service import EnterpriseSearchService, GROUP_LABELS
from app.services.price_intelligence_pro_service import CommercialSourceFlags, PriceIntelligenceProService
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters
from app.services.search_source_filters import (
    DISTRIBUTOR_SOURCES,
    PRICE_RELATED_SOURCES,
    any_source_active,
    source_active,
)
from app.services.supplier_service import SupplierService

LIVE_CONNECTOR_TIMEOUT_SECONDS = 8.0


class EnterpriseCommercialSearchService:
    """Adapta Inteligencia de Precios y Directorio de Proveedores al formato Enterprise Search."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._price_pro = PriceIntelligenceProService(db, tenant_id)
        self._price_base = PriceIntelligenceService(db, tenant_id)
        self._suppliers = SupplierService(db, tenant_id, user_id=user_id)

    @staticmethod
    def _price_item(product, query: str) -> SearchResultItem:
        supplier = (product.supplier or "lista_indexada").strip()
        title = product.description or product.model or product.sku or "Producto comercial"
        subtitle_parts = [p for p in (product.brand, product.sku, product.mpn) if p]
        subtitle = " · ".join(subtitle_parts) if subtitle_parts else supplier

        price_str = ""
        if product.preferred_price is not None:
            price_str = f"${product.preferred_price:,.2f} {product.currency or 'USD'}"
        stock_parts: list[str] = []
        if product.stock is not None:
            stock_parts.append(f"Stock: {product.stock}")
        if product.in_transit is not None and product.in_transit > 0:
            stock_parts.append(f"Tránsito: {product.in_transit}")
        list_date = ""
        if product.source_file_date:
            list_date = product.source_file_date.strftime("%d/%m/%Y")

        desc_parts = [p for p in (price_str, " · ".join(stock_parts) if stock_parts else None, f"Lista: {list_date}" if list_date else None) if p]
        description = " · ".join(desc_parts) if desc_parts else None

        source_key = supplier.lower().replace(" ", "_")
        known_live = {"ingram", "omega", "intcomex", "cecomsa", "tecnosinergia", "cenicsa", "tecnomarket"}
        source = source_key if source_key in known_live else "prices"

        return SearchResultItem(
            id=str(product.id),
            type="producto_comercial",
            title=title[:300],
            subtitle=subtitle[:200],
            description=description,
            source=source,
            url=f"/prices?product={product.id}",
            company=supplier,
            score=EnterpriseSearchService._score(query, title, subtitle, product.brand, product.sku, supplier),
            metadata={
                "supplier": supplier,
                "brand": product.brand,
                "sku": product.sku,
                "mpn": product.mpn,
                "price": str(product.preferred_price) if product.preferred_price else None,
                "currency": product.currency,
                "stock": product.stock,
                "in_transit": product.in_transit,
                "list_date": product.source_file_date.isoformat() if product.source_file_date else None,
                "source_filename": product.source_filename,
                "classification": product.classification_label,
            },
        )

    @staticmethod
    def _supplier_item(match, query: str) -> SearchResultItem:
        s = match.supplier
        title = s.name
        subtitle = s.company_type or s.status
        brands = ", ".join(match.matched_brands[:3]) if match.matched_brands else None
        cats = ", ".join(match.matched_categories[:3]) if match.matched_categories else None
        desc_parts = [p for p in (brands, cats, match.recommendation_reason) if p]
        description = " · ".join(desc_parts) if desc_parts else None

        return SearchResultItem(
            id=str(s.id),
            type="proveedor_distribuidor",
            title=title,
            subtitle=subtitle,
            description=description,
            source="suppliers",
            url=f"/empresas/{s.id}",
            company=s.name,
            score=float(match.score) * 10,
            metadata={
                "status": s.status,
                "company_type": s.company_type,
                "confidence": match.confidence,
                "matched_terms": match.matched_terms,
                "brands": match.matched_brands,
                "categories": match.matched_categories,
            },
        )

    async def search_commercial_intelligence(
        self,
        query: str,
        *,
        limit_per_group: int = 8,
        include_live: bool = True,
        source_filters: list[str] | None = None,
    ) -> tuple[SearchResultGroup | None, list[str]]:
        """Listas indexadas + conectores live (Ingram, Omega, etc.)."""
        q = query.strip()
        if len(q) < 2:
            return None, []

        if source_filters is not None and not any_source_active(source_filters, PRICE_RELATED_SOURCES):
            return None, []

        filters = PriceSearchFilters(q=q, limit=limit_per_group * 3, commercial_only=True)
        sources_consulted: list[str] = []
        products: list = []

        if source_filters is None or source_active(source_filters, "prices"):
            indexed = await self._price_base.search(filters)
            products.extend(indexed.items)
            sources_consulted.append("prices")

        if include_live:
            live_sources = CommercialSourceFlags(
                include_indexed=False,
                include_historical=False,
                include_ingram=source_filters is None or source_active(source_filters, "ingram"),
                include_omega=source_filters is None or source_active(source_filters, "omega"),
            )
            if live_sources.include_ingram or live_sources.include_omega:
                try:
                    live_items, _warnings, _live_providers, live_consulted = await asyncio.wait_for(
                        self._price_pro.fetch_from_sources(
                            filters,
                            sources=live_sources,
                            live_query=q,
                        ),
                        timeout=LIVE_CONNECTOR_TIMEOUT_SECONDS,
                    )
                    products.extend(live_items)
                    sources_consulted.extend(live_consulted)
                except asyncio.TimeoutError:
                    sources_consulted.append("live_timeout")

        if not products:
            return None, sources_consulted

        seen: set[str] = set()
        unique_products = []
        for p in products:
            key = f"{(p.supplier or '').lower()}:{(p.sku or p.description or '')[:80].lower()}"
            if key in seen:
                continue
            seen.add(key)
            unique_products.append(p)

        search_items = [self._price_item(p, q) for p in unique_products[: limit_per_group * 2]]
        if source_filters:
            allowed = set(source_filters)
            search_items = [
                i
                for i in search_items
                if i.source in allowed or (i.source == "prices" and "prices" in allowed)
            ]
        search_items = search_items[:limit_per_group]
        search_items.sort(key=lambda x: x.score, reverse=True)

        return (
            SearchResultGroup(
                type="commercial_intelligence",
                label=GROUP_LABELS["commercial_intelligence"],
                count=len(search_items),
                items=search_items,
            ),
            sources_consulted,
        )

    async def search_suppliers_directory(
        self,
        query: str,
        *,
        limit_per_group: int = 8,
    ) -> tuple[SearchResultGroup | None, list[str]]:
        """Directorio de distribuidores cargados."""
        q = query.strip()
        if len(q) < 2:
            return None, []

        try:
            result = await self._suppliers.search(
                SupplierSearchRequest(query=q, company_type="proveedor", limit=limit_per_group)
            )
        except Exception:
            return None, []

        if not result.results:
            return None, []

        items = [self._supplier_item(m, q) for m in result.results[:limit_per_group]]
        items.sort(key=lambda x: x.score, reverse=True)

        return (
            SearchResultGroup(
                type="suppliers",
                label=GROUP_LABELS["suppliers"],
                count=len(items),
                items=items,
            ),
            ["suppliers"],
        )

    async def search_all(
        self,
        query: str,
        *,
        source_filters: list[str] | None = None,
        type_filter: str | None = None,
        limit_per_group: int = 8,
    ) -> tuple[list[SearchResultGroup], list[str]]:
        """Fan-out comercial según filtros."""
        groups: list[SearchResultGroup] = []
        sources: list[str] = []

        search_prices = any_source_active(source_filters, PRICE_RELATED_SOURCES)
        search_suppliers = source_active(source_filters, "suppliers")

        if type_filter and type_filter not in (
            "commercial_intelligence", "producto_comercial", "suppliers", "proveedor_distribuidor"
        ):
            return [], []

        if search_prices and type_filter not in ("suppliers", "proveedor_distribuidor"):
            price_group, price_src = await self.search_commercial_intelligence(
                query,
                limit_per_group=limit_per_group,
                source_filters=source_filters,
            )
            if price_group:
                groups.append(price_group)
                sources.extend(price_src)

        if search_suppliers and type_filter not in ("commercial_intelligence", "producto_comercial"):
            sup_group, sup_src = await self.search_suppliers_directory(
                query, limit_per_group=limit_per_group
            )
            if sup_group:
                groups.append(sup_group)
                sources.extend(sup_src)

        return groups, list(dict.fromkeys(sources))
