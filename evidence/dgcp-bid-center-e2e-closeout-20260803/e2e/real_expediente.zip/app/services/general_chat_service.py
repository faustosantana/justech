"""Respuestas conversacionales — sin consultas a bases de datos."""

from __future__ import annotations

import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.schemas.assistant import AssistantQueryResponse


class GeneralChatService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def answer(self, question: str) -> AssistantQueryResponse:
        user = await self.db.get(User, self.user_id)
        first = (user.full_name or "").split()[0] if user and user.full_name else ""
        prefix = f"Hola {first}, " if first else "Hola, "

        lowered = question.lower().strip()
        if "gracias" in lowered:
            text = f"{prefix}de nada. ¿En qué más puedo ayudarte?"
        elif any(k in lowered for k in ("buenos", "buenas", "días", "dias", "tardes", "noches")):
            text = (
                f"{prefix}buen día. Soy el Copiloto JAIOS — puedo ayudarte con precios, "
                "ventas Odoo, licitaciones DGCP y documentos. ¿Qué necesitas?"
            )
        elif any(k in lowered for k in ("cómo estás", "como estas", "qué tal", "que tal")):
            text = (
                f"{prefix}listo para ayudarte. Pregúntame sobre productos, clientes, "
                "licitaciones o documentos cuando lo necesites."
            )
        else:
            text = f"{prefix}soy el Copiloto JAIOS. ¿En qué puedo ayudarte?"

        return AssistantQueryResponse(
            question=question,
            answer=text,
            sources=["jaios"],
            query_type="general_chat",
        )

    def answer_identity(self, question: str) -> AssistantQueryResponse:
        return AssistantQueryResponse(
            question=question,
            answer=(
                "Soy el Copiloto JAIOS, un asistente empresarial conectado a tus módulos de "
                "licitaciones, Odoo, DGCP, repositorio documental, proveedores, solicitudes de "
                "cotización y datos internos. Puedo ayudarte a analizar información, buscar "
                "oportunidades, revisar ventas, preparar expedientes y responder consultas del negocio."
            ),
            sources=["jaios"],
            query_type="identity_question",
        )
