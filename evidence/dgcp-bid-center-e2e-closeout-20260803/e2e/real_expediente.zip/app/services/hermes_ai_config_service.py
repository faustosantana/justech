"""Resolución unificada de configuración IA Hermes / Huawei ModelArts."""

from __future__ import annotations

from app.config import settings


def _first(*values: str | None) -> str:
    for v in values:
        if v and str(v).strip():
            return str(v).strip()
    return ""


class HermesAIConfigService:
    """Centraliza provider, modelo y credenciales reutilizando keys existentes."""

    @staticmethod
    def provider() -> str:
        return _first(
            settings.hermes_provider,
            settings.hermes_default_provider,
            "huawei_modelarts",
        )

    @staticmethod
    def model() -> str:
        return _first(
            settings.huawei_modelarts_model,
            settings.hermes_default_model,
            settings.hermes_model,
            "DeepSeek-V3.2",
        )

    @staticmethod
    def analysis_model() -> str:
        return _first(
            getattr(settings, "hermes_analysis_model", ""),
            "deepseek-v4-flash",
        )

    @staticmethod
    def llm_api_url() -> str:
        return _first(
            settings.huawei_modelarts_api_url,
            settings.hermes_model_api_url,
            "https://api-ap-southeast-1.modelarts-maas.com/v2/chat/completions",
        )

    @staticmethod
    def llm_api_key() -> str:
        return _first(
            settings.huawei_modelarts_api_key,
            settings.hermes_model_api_key,
            settings.deepseek_huawei_api_key,
        )

    @staticmethod
    def api_key_configured() -> bool:
        return bool(HermesAIConfigService.llm_api_key())

    @staticmethod
    def masked_api_key() -> str:
        key = HermesAIConfigService.llm_api_key()
        if not key:
            return ""
        if len(key) <= 8:
            return "••••"
        return f"••••••••{key[-4:]}"

    @staticmethod
    def to_public_dict() -> dict:
        return {
            "provider": HermesAIConfigService.provider(),
            "provider_label": "Huawei ModelArts",
            "model": HermesAIConfigService.model(),
            "analysis_model": HermesAIConfigService.analysis_model(),
            "api_url": HermesAIConfigService.llm_api_url(),
            "api_key_configured": HermesAIConfigService.api_key_configured(),
            "api_key_masked": HermesAIConfigService.masked_api_key(),
            "hermes_service_url": settings.hermes_service_url,
            "enabled": settings.hermes_enabled,
            "copilot_primary": settings.hermes_copilot_primary,
        }
