"""Formateo breve y razonado de respuestas comerciales Hermes."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from app.services.commercial_currency import format_price_dual, normalize_currency, to_target_currency
from app.services.commercial_product_filter import accessory_exclusion_note
from app.services.commercial_search.intent import SearchIntent


def format_category_price_answer(
    *,
    query: str,
    intent: SearchIntent,
    odoo_items: list[Any],
    max_price: Decimal,
    price_currency: str,
    price_list_result: dict | None = None,
    conversion_warning: str | None = None,
) -> str:
    count = len(odoo_items)
    cat_label = intent.category_label or intent.target_category or "productos"
    cur = normalize_currency(price_currency)

    lines: list[str] = []
    lines.append("**Resumen:**")
    if count:
        lines.append(f"Encontré **{count} {cat_label.lower()}** por debajo de US${max_price}.")
    else:
        lines.append(
            f"No encontré **{cat_label.lower()}** válidos por debajo de US${max_price} en el índice Odoo."
        )

    note = accessory_exclusion_note(intent)
    if note:
        lines.append("")
        lines.append("**Notas:**")
        lines.append(note)
    if conversion_warning:
        lines.append(conversion_warning)

    if odoo_items:
        lines.append("")
        lines.append("**Top resultados (historial Odoo):**")
        for i, item in enumerate(odoo_items[:5], 1):
            name = getattr(item, "product_name", None) or getattr(item, "description", None) or "Producto"
            doc = getattr(item, "document_type", None) or "registro"
            price_txt = format_price_dual(item.unit_price, getattr(item, "currency", None))
            lines.append(f"{i}. {name} — {price_txt} — {doc}")

    lines.append("")
    lines.append("**Listas de precios actuales:**")
    if price_list_result and price_list_result.get("count", 0) > 0:
        lines.append(price_list_result.get("summary_line", "Hay resultados en listas indexadas."))
    else:
        lines.append("No encontré resultados en listas indexadas para esta búsqueda.")

    lines.append("")
    lines.append("**Fuentes:** índice comercial Odoo · listas de precios indexadas")

    lines.append("")
    lines.append("**Siguiente acción:**")
    if count:
        lines.append("¿Quieres comparar proveedores, filtrar por marca o ver el detalle de alguna opción?")
    else:
        lines.append("Prueba con otra marca, revisa listas de precios o sincroniza Odoo si el índice está desactualizado.")

    return "\n".join(lines)


def format_commercial_history_answer(
    *,
    query: str,
    items: list[Any],
    total: int,
    last_sold: bool = False,
) -> str:
    if not items:
        return f"No encontré historial comercial indexado para «{query}»."

    lines: list[str] = ["**Resumen:**"]
    first = items[0]
    name = getattr(first, "product_name", None) or getattr(first, "description", None) or "Producto"
    price_txt = format_price_dual(first.unit_price, getattr(first, "currency", None)) if first.unit_price else "—"
    date_str = str(first.date) if getattr(first, "date", None) else "—"
    doc = getattr(first, "document_type", None) or "registro"

    if last_sold:
        lines.append(
            f"Último precio vendido de **{name}**: {price_txt} ({date_str}, {doc})."
        )
    else:
        lines.append(f"Encontré **{total}** registros comerciales indexados desde Odoo.")

    lines.append("")
    lines.append("**Top resultados:**")
    for i, item in enumerate(items[:5], 1):
        iname = getattr(item, "product_name", None) or getattr(item, "description", None) or "Producto"
        iprice = format_price_dual(item.unit_price, getattr(item, "currency", None)) if item.unit_price else "—"
        idate = str(item.date) if getattr(item, "date", None) else "—"
        idoc = getattr(item, "document_type", None) or "registro"
        customer = getattr(item, "customer_name", None) or ""
        cust = f" · {customer}" if customer else ""
        lines.append(f"{i}. {iname} — {iprice} — {idate}{cust} ({idoc})")

    lines.extend([
        "",
        "**Fuentes:** índice comercial Odoo",
        "",
        "**Siguiente acción:** ¿Quieres filtrar por cliente, fecha o ver más detalle?",
    ])
    return "\n".join(lines)


def format_price_list_overview(data: dict) -> str:
    lines = [
        "**Resumen:**",
        (
            f"Tienes **{data.get('total_products', 0)} productos** indexados de "
            f"**{data.get('total_suppliers', 0)} proveedores**."
        ),
        f"Listas cargadas hoy: **{data.get('lists_today', 0)}**. Pendientes: **{data.get('pending_count', 0)}**.",
    ]
    if data.get("last_indexed_at"):
        lines.append(f"Última indexación: {data['last_indexed_at']}.")
    if data.get("lists_today", 0) == 0 and data.get("last_indexed_at"):
        lines.append(
            "No hay listas nuevas hoy; los productos indexados provienen de cargas anteriores."
        )

    lines.extend([
        "",
        "**Para buscar la mejor oferta** indica categoría o producto, por ejemplo:",
        "laptops · switches · toners · servidores · monitores",
        "",
        "También puedo mostrar:",
        "• proveedor con mejores precios por categoría",
        "• productos más baratos",
        "• listas más recientes",
        "• diferencias entre proveedores",
        "",
        "**Siguiente acción:** ¿Qué categoría quieres revisar?",
    ])
    return "\n".join(lines)
