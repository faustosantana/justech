"""Motor de Inteligencia Comercial Proactiva — enriquece solicitudes observadas."""

from __future__ import annotations

import logging
import re
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import forbidden, not_found
from app.models.business_company import BusinessCompany
from app.models.hermes_observed_event import HermesObservedEvent
from app.models.m365_operative import M365ProcessedEmail
from app.services.commercial_search_service import CommercialSearchService
from app.services.copilot_access_service import CopilotAccessService
from app.services.business_intent_router import BusinessIntentRouter
from app.services.hermes_client import HermesClient
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters
from app.services.sales_question_service import SalesQuestionService

logger = logging.getLogger(__name__)

CONTEXT_SOURCE_LABELS = {
    "whatsapp": "WhatsApp",
    "email": "Correos",
    "outlook": "Correos",
    "quotes": "Cotizaciones anteriores",
    "purchase_orders": "Órdenes de compra",
    "supplier_chats": "Conversaciones con proveedores",
}


class HermesCommercialIntelligenceService:
    """Analista comercial proactivo — consulta fuentes autorizadas y construye brief."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.client = HermesClient()
        self.access = CopilotAccessService(db, tenant_id, user_id) if user_id else None

    async def _scopes(self) -> frozenset[str]:
        if not self.access:
            return frozenset()
        return await self.access.extra_scopes()

    async def _can(self, *needed: str) -> bool:
        scopes = await self._scopes()
        if not scopes:
            return True
        return bool(scopes & set(needed)) or "sales.read.all" in scopes

    def _primary_product(self, row: HermesObservedEvent) -> dict[str, Any]:
        products = row.products or []
        if products:
            return products[0]
        analysis = row.analysis or {}
        if analysis.get("products"):
            return analysis["products"][0]
        return {}

    def _product_search_text(self, product: dict[str, Any], row: HermesObservedEvent) -> str:
        parts = [
            product.get("description"),
            product.get("brand"),
            product.get("category"),
        ]
        specs = product.get("specs") or {}
        if isinstance(specs, dict):
            parts.extend(str(v) for v in specs.values() if v)
        text = " ".join(str(p) for p in parts if p).strip()
        if text:
            return text
        return (row.summary or row.raw_body_preview or "")[:200]

    async def build_brief(
        self,
        row: HermesObservedEvent,
        *,
        include_context: frozenset[str] | None = None,
    ) -> dict[str, Any]:
        """Construye resumen ejecutivo comercial. include_context vacío = no leer conversaciones."""
        product = self._primary_product(row)
        customer = row.customer or {}
        search_text = self._product_search_text(product, row)
        scopes = await self._scopes()

        detected = {
            "product": product.get("description") or search_text.split(",")[0][:120],
            "quantity": product.get("quantity"),
            "brand": product.get("brand"),
            "model": (product.get("specs") or {}).get("model") if isinstance(product.get("specs"), dict) else None,
            "category": product.get("category") or self._guess_category(search_text),
            "customer": customer.get("name") or row.raw_from,
            "customer_email": customer.get("email"),
            "customer_phone": customer.get("phone"),
            "priority": (row.analysis or {}).get("urgency") or self._guess_priority(row),
            "required_date": product.get("required_date"),
            "confidence": float(row.confidence or 0),
            "channel": row.channel,
        }

        sales_history: dict[str, Any] = {"available": False, "customers": [], "summary": ""}
        price_intel: dict[str, Any] = {"suppliers": [], "average_price": None}
        similar: dict[str, Any] = {"observations_count": 0, "quotes_count": 0}
        recommendations: list[str] = []
        drafts: dict[str, str] = {}
        context_available: list[dict[str, Any]] = []

        can_sales = await self._can("sales.read.all", "sales.read.team", "sales.read.own")
        can_prices = await self._can("providers.read", "providers.cost.read")
        can_finance = await self._can("finance.read", "sales.margin.read")

        if can_sales and self.user_id and search_text:
            sales_history = await self._fetch_sales_history(search_text, customer.get("name"))

        if can_prices and search_text:
            price_intel = await self._fetch_price_intel(search_text, row.suppliers_mentioned or [])

        similar = await self._count_similar(row, search_text)
        context_available = await self._list_context_sources(row, include_context or frozenset())

        if include_context:
            extra = await self._load_optional_context(row, include_context)
            if extra:
                sales_history["optional_context"] = extra

        recommendations = self._build_recommendations(detected, sales_history, price_intel, row)
        drafts = self._build_drafts(detected, sales_history, price_intel, row)

        executive_summary = await self._synthesize_executive(
            detected, sales_history, price_intel, similar, recommendations
        )

        return {
            "detected": detected,
            "executive_summary": executive_summary,
            "sales_history": sales_history,
            "suppliers": price_intel.get("suppliers", []),
            "price_average": price_intel.get("average_price"),
            "similar_requests": similar,
            "recommendations": recommendations,
            "drafts": drafts,
            "context_sources_available": context_available,
            "context_loaded": sorted(include_context) if include_context else [],
            "permissions": {
                "sales": can_sales,
                "prices": can_prices,
                "margin": can_finance,
            },
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    async def enrich_event(
        self,
        event_id: uuid.UUID,
        *,
        include_context: frozenset[str] | None = None,
    ) -> dict[str, Any]:
        row = await self._get_row(event_id)
        brief = await self.build_brief(row, include_context=include_context)
        analysis = dict(row.analysis or {})
        analysis["commercial_intelligence"] = brief
        row.analysis = analysis
        if brief.get("drafts", {}).get("client_email"):
            row.draft_response = brief["drafts"]["client_email"]
        if brief.get("drafts", {}).get("internal_note"):
            row.draft_internal = brief["drafts"]["internal_note"]
        await self.db.commit()
        await self.db.refresh(row)
        return brief

    async def ask_about_event(self, event_id: uuid.UUID, question: str) -> dict[str, Any]:
        row = await self._get_row(event_id)
        analysis = row.analysis or {}
        brief = analysis.get("commercial_intelligence")
        if not brief:
            brief = await self.enrich_event(event_id)

        q = question.lower().strip()
        product = self._primary_product(row)
        search_text = self._product_search_text(product, row)
        customer = (row.customer or {}).get("name") or ""

        # Preguntas naturales sobre el contexto activo
        if any(p in q for p in ("ya le hemos vendido", "ya le vendimos", "hemos vendido esto", "ya vendimos")):
            if customer:
                live = await self._fetch_sales_history(search_text, customer, customer_only=True)
                return {"answer": live.get("customer_specific") or live.get("summary") or "Sin ventas registradas a este cliente para este producto.", "source": "odoo"}
            live = await self._fetch_sales_history(search_text, None)
            return {"answer": live.get("summary") or "No hay historial de ventas para este producto.", "source": "odoo"}

        if any(p in q for p in ("a cuánto", "a cuanto", "precio", "cuánto vendimos", "cuanto vendimos")):
            live = await self._fetch_sales_history(search_text, customer or None)
            stats = live.get("price_stats") or {}
            if stats:
                return {
                    "answer": (
                        f"Precio mínimo: RD${stats.get('min', '—'):,} · "
                        f"máximo: RD${stats.get('max', '—'):,} · "
                        f"promedio: RD${stats.get('avg', '—'):,} · "
                        f"último: RD${stats.get('last', '—'):,}"
                    ).replace(",", ""),
                    "source": "odoo",
                    "data": stats,
                }
            return {"answer": "No hay precios de venta históricos en Odoo para este producto.", "source": "odoo"}

        if any(p in q for p in ("dónde lo compramos", "donde lo compramos", "proveedor principal", "quien nos vende")):
            suppliers = brief.get("suppliers") or []
            if suppliers:
                top = suppliers[0]
                alts = ", ".join(s.get("name", "") for s in suppliers[1:3])
                return {
                    "answer": f"Proveedor principal sugerido: {top.get('name')} (último registro: {top.get('last_seen', '—')}). Alternativas: {alts or 'ninguna'}.",
                    "source": "price_intelligence",
                }
            return {"answer": "No encontré proveedores registrados en listas de precios para este producto.", "source": "price_intelligence"}

        # Fallback Hermes con facts del brief
        if self.client.is_available():
            facts = {"brief": brief, "question": question, "product": product, "customer": row.customer}
            result = await self.client.interpret_question(question=question, context={"observation_id": str(row.id)}, facts=facts)
            if result and result.summary:
                return {"answer": result.summary, "source": "hermes"}

        return {
            "answer": brief.get("executive_summary") or row.summary,
            "source": "brief",
        }

    async def _get_row(self, event_id: uuid.UUID) -> HermesObservedEvent:
        row = await self.db.get(HermesObservedEvent, event_id)
        if not row or row.tenant_id != self.tenant_id:
            raise not_found("Solicitud no encontrada")
        if self.user_id:
            scopes = await self._scopes()
            allowed = {"communications.read", "sales.read.all", "sales.read.own", "m365.read"}
            if not (scopes & allowed) and "system.help" not in scopes:
                raise forbidden("Sin permiso para inteligencia comercial.")
        return row

    async def _fetch_sales_history(
        self,
        product_text: str,
        customer_name: str | None,
        *,
        customer_only: bool = False,
    ) -> dict[str, Any]:
        if not self.user_id:
            return {"available": False}
        svc = SalesQuestionService(self.db, self.tenant_id, self.user_id)
        try:
            if customer_name and customer_only:
                q = f"¿Cuánto le hemos vendido a {customer_name} de {product_text}?"
            elif customer_name:
                q = f"¿Cuánto le hemos vendido a {customer_name} de {product_text}?"
            else:
                q = f"¿Cuánto hemos vendido de {product_text}?"
            result = await svc.answer_product_lookup(q) or await svc.answer(q)
            if not result:
                return {"available": True, "summary": "Odoo conectado — sin ventas coincidentes.", "customers": []}

            data = result.data or {}
            customers = data.get("customers") or data.get("top_customers") or []
            if isinstance(customers, dict):
                customers = [{"name": k, **v} if isinstance(v, dict) else {"name": k, "detail": v} for k, v in customers.items()]

            price_stats = data.get("price_stats") or {}
            if not price_stats and data.get("average_price") is not None:
                price_stats = {
                    "avg": data.get("average_price"),
                    "min": data.get("min_price"),
                    "max": data.get("max_price"),
                    "last": data.get("last_price"),
                }

            return {
                "available": True,
                "summary": result.answer[:2000],
                "customers": customers[:5],
                "price_stats": price_stats,
                "customer_specific": result.answer if customer_only else None,
                "query_type": result.query_type,
            }
        except Exception:
            logger.exception("Sales history fetch failed")
            return {"available": False, "error": "No se pudo consultar Odoo"}

    async def _fetch_price_intel(
        self,
        search_text: str,
        mentioned: list[dict[str, Any]],
    ) -> dict[str, Any]:
        svc = PriceIntelligenceService(self.db, self.tenant_id)
        filters = PriceSearchFilters(q=search_text, limit=20)
        brand = self._extract_brand(search_text)
        if brand:
            filters.brand = brand
        try:
            search = await svc.search(filters)
        except Exception:
            logger.exception("Price search failed")
            return {"suppliers": [], "average_price": None}

        by_supplier: dict[str, dict] = {}
        prices: list[float] = []
        for item in search.items[:15]:
            sup = item.supplier or "Proveedor"
            price = float(item.price) if item.price else None
            if price:
                prices.append(price)
            entry = by_supplier.setdefault(sup, {"name": sup, "products": 0, "last_price": None, "last_seen": None, "stock": None})
            entry["products"] += 1
            if price and (entry["last_price"] is None or price < entry["last_price"]):
                entry["last_price"] = price
            if item.source_file_date:
                entry["last_seen"] = str(item.source_file_date)[:10]
            if item.stock is not None:
                entry["stock"] = item.stock

        for m in mentioned:
            name = (m.get("name") or "").strip()
            if name and name not in by_supplier:
                by_supplier[name] = {
                    "name": name,
                    "products": 0,
                    "last_price": m.get("price"),
                    "last_seen": "mencionado en conversación",
                    "stock": m.get("stock"),
                    "source": "conversation",
                }

        supplier_list = sorted(by_supplier.values(), key=lambda x: (-x.get("products", 0), x.get("name", "")))[:8]
        avg = sum(prices) / len(prices) if prices else None
        return {"suppliers": supplier_list, "average_price": round(avg, 2) if avg else None, "items_found": len(search.items)}

    async def _count_similar(self, row: HermesObservedEvent, search_text: str) -> dict[str, Any]:
        tokens = [t for t in re.split(r"\W+", search_text.lower()) if len(t) > 3][:4]
        if not tokens:
            return {"observations_count": 0, "quotes_count": 0}
        conditions = [HermesObservedEvent.summary.ilike(f"%{t}%") for t in tokens]
        q = select(func.count()).select_from(HermesObservedEvent).where(
            HermesObservedEvent.tenant_id == self.tenant_id,
            HermesObservedEvent.id != row.id,
            HermesObservedEvent.detected_type.in_(("rfq_request", "cotizacion")),
            or_(*conditions),
        )
        count = (await self.db.execute(q)).scalar_one()
        return {
            "observations_count": count,
            "quotes_count": count,
            "purchase_orders_count": 0,
            "message": f"Se encontraron {count} solicitud(es) similar(es) en la bandeja.",
        }

    async def _list_context_sources(
        self,
        row: HermesObservedEvent,
        loaded: frozenset[str],
    ) -> list[dict[str, Any]]:
        sources: list[dict[str, Any]] = []
        email = (row.customer or {}).get("email") or row.raw_from
        if row.channel == "whatsapp" and "whatsapp" not in loaded:
            sources.append({"key": "whatsapp", "label": CONTEXT_SOURCE_LABELS["whatsapp"], "count": 1})
        if row.channel in ("email", "outlook") and "email" not in loaded:
            sources.append({"key": "email", "label": CONTEXT_SOURCE_LABELS["email"], "count": 1})
        if email and "email" not in loaded:
            result = await self.db.execute(
                select(func.count()).select_from(M365ProcessedEmail).where(
                    M365ProcessedEmail.tenant_id == self.tenant_id,
                    M365ProcessedEmail.sender_email.ilike(f"%{email.split('@')[0]}%"),
                )
            )
            cnt = result.scalar_one()
            if cnt:
                sources.append({"key": "email_history", "label": "Correos del contacto", "count": cnt})
        similar = await self._count_similar(row, self._product_search_text(self._primary_product(row), row))
        if similar["observations_count"] and "quotes" not in loaded:
            sources.append({"key": "quotes", "label": "Solicitudes anteriores", "count": similar["observations_count"]})
        return sources

    async def _load_optional_context(
        self,
        row: HermesObservedEvent,
        sources: frozenset[str],
    ) -> dict[str, Any]:
        out: dict[str, Any] = {}
        email = (row.customer or {}).get("email") or row.raw_from
        if "email" in sources or "email_history" in sources:
            if email and "@" in str(email):
                result = await self.db.execute(
                    select(M365ProcessedEmail)
                    .where(
                        M365ProcessedEmail.tenant_id == self.tenant_id,
                        M365ProcessedEmail.sender_email == email,
                    )
                    .order_by(desc(M365ProcessedEmail.received_at))
                    .limit(5)
                )
                emails = result.scalars().all()
                out["emails"] = [
                    {"subject": e.subject, "date": e.received_at.isoformat() if e.received_at else None, "preview": (e.body_preview or "")[:200]}
                    for e in emails
                ]
        if "quotes" in sources:
            out["similar_requests"] = (await self._count_similar(row, self._product_search_text(self._primary_product(row), row)))
        return out

    def _build_recommendations(
        self,
        detected: dict,
        sales: dict,
        prices: dict,
        row: HermesObservedEvent,
    ) -> list[str]:
        recs: list[str] = []
        suppliers = prices.get("suppliers") or []
        if suppliers:
            recs.append(f"Solicitar disponibilidad a {suppliers[0].get('name')}.")
            if len(suppliers) > 1:
                recs.append(f"Comparar precio con {suppliers[1].get('name')}.")
        if detected.get("brand"):
            recs.append(f"Utilizar plantilla de cotización {detected['brand']} estándar.")
        qty = detected.get("quantity")
        if qty:
            recs.append(f"Preparar propuesta para {qty} unidades.")
        if sales.get("customers"):
            recs.append("Revisar historial comercial con clientes que ya compraron productos similares.")
        for a in row.recommended_actions or []:
            label = {
                "create_task": "Crear tarea de seguimiento comercial.",
                "search_prices": "Buscar precios en listas indexadas.",
                "prepare_quote_draft": "Preparar borrador de cotización.",
                "create_rfq": "Registrar solicitud de cotización formal.",
            }.get(a)
            if label and label not in recs:
                recs.append(label)
        return recs[:8]

    def _build_drafts(
        self,
        detected: dict,
        sales: dict,
        prices: dict,
        row: HermesObservedEvent,
    ) -> dict[str, str]:
        product = detected.get("product") or "producto solicitado"
        qty = detected.get("quantity") or "la cantidad indicada"
        customer = detected.get("customer") or "cliente"
        client_email = (
            row.draft_response
            or f"Estimado/a {customer},\n\nGracias por su solicitud. Estamos validando disponibilidad y precio para {qty} unidades de {product}. "
            f"Le enviaremos la cotización formal a la brevedad posible.\n\nSaludos cordiales,\nEquipo comercial Justech"
        )
        internal = (
            row.draft_internal
            or f"Solicitud vía {row.channel}: {product} x{qty}. "
            f"{'Historial Odoo disponible.' if sales.get('available') else 'Sin historial Odoo.'} "
            f"Proveedores a consultar: {', '.join(s.get('name','') for s in (prices.get('suppliers') or [])[:3]) or 'pendiente'}."
        )
        supplier_req = ""
        if prices.get("suppliers"):
            sup = prices["suppliers"][0]["name"]
            supplier_req = f"Buenos días,\n\nFavor cotizar {qty} unidades de {product}.\n\nGracias."
        return {
            "client_email": client_email,
            "internal_note": internal,
            "supplier_rfq": supplier_req,
            "quote_outline": f"{product} · Cant: {qty} · Cliente: {customer}",
        }

    async def _synthesize_executive(
        self,
        detected: dict,
        sales: dict,
        prices: dict,
        similar: dict,
        recommendations: list[str],
    ) -> str:
        lines = [
            f"**{detected.get('product', 'Producto')}** — Cantidad: {detected.get('quantity') or '—'} · Confianza: {int((detected.get('confidence') or 0)*100)}%",
        ]
        if sales.get("summary"):
            lines.append(f"\nHistorial comercial: {sales['summary'][:400]}")
        if prices.get("average_price"):
            lines.append(f"\nPrecio promedio en listas: RD${prices['average_price']:,.2f}".replace(",", ""))
        if prices.get("suppliers"):
            names = ", ".join(s["name"] for s in prices["suppliers"][:4])
            lines.append(f"\nProveedores relacionados: {names}")
        if similar.get("observations_count"):
            lines.append(f"\n{similar.get('message', '')}")
        if recommendations:
            lines.append("\nRecomendaciones: " + "; ".join(recommendations[:4]))
        text = "\n".join(lines)
        if self.client.is_available():
            try:
                result = await self.client.interpret_question(
                    question="Resume en 4-6 oraciones ejecutivas para un vendedor.",
                    facts={"detected": detected, "sales": sales, "prices": prices, "recommendations": recommendations},
                )
                if result and result.summary and len(result.summary) > 80:
                    return result.summary
            except Exception:
                pass
        return text

    @staticmethod
    def _guess_category(text: str) -> str:
        t = text.lower()
        if any(w in t for w in ("laptop", "notebook", "computadora", "pc")):
            return "Computadoras"
        if any(w in t for w in ("toner", "impresora")):
            return "Impresión"
        if any(w in t for w in ("servidor", "server")):
            return "Servidores"
        return "General"

    @staticmethod
    def _guess_priority(row: HermesObservedEvent) -> str:
        blob = f"{row.summary} {row.raw_body_preview or ''}".lower()
        if any(w in blob for w in ("urgente", "inmediato", "hoy", "asap")):
            return "alta"
        return "media"

    @staticmethod
    def _extract_brand(text: str) -> str | None:
        for brand in ("Dell", "HP", "Lenovo", "Asus", "Acer", "Apple", "Microsoft"):
            if brand.lower() in text.lower():
                return brand
        return None
