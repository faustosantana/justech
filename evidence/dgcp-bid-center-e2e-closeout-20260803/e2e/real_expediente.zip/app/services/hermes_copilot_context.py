"""Contexto enriquecido para Hermes Copiloto."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.schemas.assistant import AssistantQueryRequest
from app.services.copilot_access_service import CopilotAccessService
from app.services.global_company_context_service import GlobalCompanyContextService


@dataclass
class HermesQueryContext:
    company_id: int | None
    company_name: str | None
    company_scope_label: str
    selected_company_ids: list[int]
    user_id: uuid.UUID
    user_email: str
    user_name: str
    user_role: str
    module: str | None
    record_type: str | None
    record_id: str | None
    today: str
    permissions_summary: str
    odoo_connected: bool

    def to_prompt_block(self) -> str:
        lines = [
            f"Fecha actual: {self.today}",
            f"Usuario: {self.user_name} ({self.user_email}) — rol {self.user_role}",
            f"Empresa activa: {self.company_name or 'no definida'} (ID Odoo: {self.company_id or 'N/A'})",
            f"Alcance: {self.company_scope_label}",
            f"Módulo UI: {self.module or 'general'}",
            f"Odoo conectado: {'sí' if self.odoo_connected else 'no'}",
            f"Permisos copiloto: {self.permissions_summary}",
        ]
        if self.record_type and self.record_id:
            lines.append(f"Registro activo: {self.record_type} #{self.record_id}")
        return "\n".join(lines)

    def to_hermes_dict(self) -> dict:
        return {
            "empresa_actual": self.company_name,
            "empresa_actual_id": self.company_id,
            "empresas_seleccionadas": self.selected_company_ids,
            "usuario_actual": self.user_email,
            "usuario_nombre": self.user_name,
            "modulo_actual": self.module,
            "fecha_actual": self.today,
            "permisos": self.permissions_summary,
            "odoo_connected": self.odoo_connected,
            "record_type": self.record_type,
            "record_id": self.record_id,
        }


class HermesCopilotContextService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.company_svc = GlobalCompanyContextService(db, tenant_id, user_id)
        self.access = CopilotAccessService(db, tenant_id, user_id)

    async def resolve(
        self,
        payload: AssistantQueryRequest,
        user: User | None = None,
    ) -> HermesQueryContext:
        try:
            ctx = await self.company_svc.ensure_active_company()
        except Exception:
            ctx = await self.company_svc.get_context()
        company_id = payload.current_company_context or ctx.active_company_id
        if company_id and ctx.active_company_id != company_id:
            company_id = ctx.active_company_id or company_id

        user_email = user.email if user else ""
        user_name = (user.full_name or user_email.split("@")[0]) if user else ""
        role = await self.access.role()
        perms = await self.access.permissions_summary()

        return HermesQueryContext(
            company_id=company_id,
            company_name=ctx.active_company_name,
            company_scope_label=ctx.scope_label,
            selected_company_ids=list(ctx.selected_company_ids or []),
            user_id=self.user_id,
            user_email=user_email,
            user_name=user_name,
            user_role=role,
            module=payload.current_module,
            record_type=payload.record_type,
            record_id=payload.current_record_id,
            today=date.today().isoformat(),
            permissions_summary=perms,
            odoo_connected=bool(ctx.odoo_connected),
        )
