"""Hermes como motor conversacional principal del Copiloto."""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.user import User
from app.schemas.assistant import AssistantQueryRequest, AssistantQueryResponse
from app.services.hermes_client import HermesClient
from app.services.hermes_copilot_tools import HermesCopilotTools
from app.services.hermes_prompt_service import HermesPromptService
from app.services.copilot_access_service import CopilotAccessService
from app.services.copilot_audit_service import CopilotAuditService
from app.services.persistent_conversation_store import PersistentConversationStore
from app.services.hermes_copilot_context import HermesCopilotContextService
from app.services.hermes_intent_router import HermesRoute, match as match_intent

logger = logging.getLogger(__name__)


class HermesCopilotService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.client = HermesClient()
        self.tools = HermesCopilotTools(db, tenant_id, user_id)
        self.prompts = HermesPromptService(db, tenant_id, user_id)
        self.access = CopilotAccessService(db, tenant_id, user_id)
        self.audit = CopilotAuditService(db)

    @staticmethod
    def is_primary() -> bool:
        return bool(settings.hermes_enabled and getattr(settings, "hermes_copilot_primary", True))

    async def handle(
        self,
        question: str,
        payload: AssistantQueryRequest,
        conv,
        persistent: PersistentConversationStore | None = None,
        user: User | None = None,
    ) -> AssistantQueryResponse | None:
        started = time.perf_counter()
        query_ctx = await HermesCopilotContextService(self.db, self.tenant_id, self.user_id).resolve(
            payload, user=user
        )
        self.tools.set_context(query_ctx)

        company_name = query_ctx.company_name or conv.current_company_scope if conv else None
        extra: dict[str, Any] = {"contexto_sistema": query_ctx.to_prompt_block()}
        if conv:
            if conv.current_product:
                extra["producto_activo"] = conv.current_product
            if conv.current_customer:
                extra["cliente_activo"] = conv.current_customer
            if conv.current_bid_label:
                extra["licitacion_activa"] = conv.current_bid_label

        route = match_intent(question)
        execution_steps: list[str] = []

        if route and route.skip_llm:
            return await self._handle_deterministic_route(
                question=question,
                payload=payload,
                conv=conv,
                route=route,
                query_ctx=query_ctx,
                company_name=company_name,
                started=started,
            )

        if not self.client.is_available():
            return await self._fallback_without_llm(question, route, query_ctx, started)

        system_prompt, model = await self.prompts.build_system_prompt(
            current_module=payload.current_module,
            company_name=company_name,
            extra_context=extra,
            user_role=query_ctx.user_role,
            permissions_summary=query_ctx.permissions_summary,
        )

        history = await self._load_history(persistent, payload.conversation_id)
        context = query_ctx.to_hermes_dict()
        context.update(
            {
                "module": payload.current_module,
                "record_type": payload.record_type,
                "record_id": payload.current_record_id,
            }
        )

        execution_steps = ["Analizando solicitud", "Consultando motor Hermes (DeepSeek)"]
        turn = await self.client.copilot_turn(
            system_prompt=system_prompt,
            question=question,
            messages=history,
            model=model,
            context=context,
        )
        if not turn:
            return await self._fallback_without_llm(question, route, query_ctx, started, reason="hermes_unreachable")

        total_latency = turn.get("latency_ms") or 0
        tools_used: list[str] = []
        sources: list[str] = ["hermes"]
        data: dict[str, Any] = {"execution_steps": execution_steps}

        if turn.get("action") == "use_tools" and turn.get("tools"):
            intent = turn.get("intent") or ""
            execution_steps.extend(self._tool_steps(turn["tools"]))
            pre_check = await self.access.check_intent_before_tools(intent, turn["tools"])
            if pre_check and not pre_check.allowed:
                await self.audit.log_query(
                    tenant_id=self.tenant_id,
                    user_id=self.user_id,
                    question=question,
                    intent=intent,
                    allowed=False,
                    data_returned=False,
                    model=turn.get("active_model") or model,
                    decision=pre_check,
                )
                await self.db.commit()
                return AssistantQueryResponse(
                    question=question,
                    answer=pre_check.reason,
                    sources=["hermes", "access_control"],
                    query_type="access_denied",
                    data={"denied": True, "missing_scope": pre_check.missing_scope},
                    structured_data={
                        "type": "access_denied",
                        "classification": pre_check.classification,
                        "resource": pre_check.resource,
                    },
                )

            tool_results = await self.tools.execute_many(
                turn["tools"],
                intent=intent,
                question=question,
                model=turn.get("active_model") or model,
            )
            if any(r.get("denied") for r in tool_results):
                denied = next(r for r in tool_results if r.get("denied"))
                return AssistantQueryResponse(
                    question=question,
                    answer=denied.get("error") or "Acceso denegado.",
                    sources=["hermes", "access_control"],
                    query_type="access_denied",
                    data={"denied": True, "tool_results": tool_results},
                    structured_data={"type": "access_denied"},
                )

            tools_used = [r.get("name", "") for r in tool_results if r.get("name")]
            sources.extend(t for t in tools_used if t)
            execution_steps.append("Preparando respuesta")

            synth = await self.client.copilot_synthesize(
                system_prompt=system_prompt,
                question=question,
                messages=history,
                tool_results=tool_results,
                model=model,
            )
            if synth:
                answer = synth.get("text") or ""
                total_latency += synth.get("latency_ms") or 0
                tools_used = synth.get("tools_used") or tools_used
                data["tool_results"] = tool_results
            else:
                answer = self._fallback_tool_answer(tool_results)
                data["tool_results"] = tool_results
                data["fallback_reason"] = "synthesis_failed"
        else:
            answer = turn.get("text") or ""
            execution_steps.append("Preparando respuesta")

        if not answer.strip():
            return await self._fallback_without_llm(question, route, query_ctx, started, reason="empty_llm_answer")

        return self._build_response(
            question=question,
            answer=answer.strip(),
            turn=turn,
            model=model,
            tools_used=tools_used,
            sources=sources,
            data=data,
            total_latency=total_latency,
            started=started,
            execution_steps=execution_steps,
            query_ctx=query_ctx,
        )

    async def _handle_deterministic_route(
        self,
        *,
        question: str,
        payload: AssistantQueryRequest,
        conv,
        route: HermesRoute,
        query_ctx,
        company_name: str | None,
        started: float,
    ) -> AssistantQueryResponse:
        execution_steps = list(route.execution_steps)
        intent = route.intent

        pre_check = await self.access.check_intent_before_tools(intent, route.tools)
        if pre_check and not pre_check.allowed:
            return AssistantQueryResponse(
                question=question,
                answer=pre_check.reason,
                sources=["hermes", "access_control"],
                query_type="access_denied",
                data={"denied": True, "missing_scope": pre_check.missing_scope},
            )

        tool_results = await self.tools.execute_many(
            route.tools,
            intent=intent,
            question=question,
        )
        if any(r.get("denied") for r in tool_results):
            denied = next(r for r in tool_results if r.get("denied"))
            return AssistantQueryResponse(
                question=question,
                answer=denied.get("error") or "Acceso denegado.",
                query_type="access_denied",
                sources=["hermes"],
                data={"tool_results": tool_results},
            )

        answer = self._format_route_answer(route, tool_results)
        if not answer:
            answer = self._fallback_tool_answer(tool_results)

        tools_used = [r.get("name", "") for r in tool_results if r.get("name")]
        sources = list(dict.fromkeys(["hermes"] + tools_used))

        return self._build_response(
            question=question,
            answer=answer,
            turn={"intent": intent, "model": "deterministic", "active_model": "tools"},
            model="deterministic",
            tools_used=tools_used,
            sources=sources,
            data={
                "tool_results": tool_results,
                "execution_steps": execution_steps,
                "deterministic_route": route.formatter,
            },
            total_latency=0,
            started=started,
            execution_steps=execution_steps,
            query_ctx=query_ctx,
        )

    async def _fallback_without_llm(
        self,
        question: str,
        route: HermesRoute | None,
        query_ctx,
        started: float,
        reason: str = "hermes_unavailable",
    ) -> AssistantQueryResponse | None:
        """Intenta responder solo con herramientas si el LLM no está disponible."""
        if route and route.tools:
            tool_results = await self.tools.execute_many(route.tools, question=question)
            answer = self._fallback_tool_answer(tool_results)
            if answer and answer != "No pude obtener datos para responder.":
                return self._build_response(
                    question=question,
                    answer=answer,
                    turn={"intent": route.intent, "model": "fallback"},
                    model="fallback",
                    tools_used=[r.get("name", "") for r in tool_results],
                    sources=["hermes", "fallback"],
                    data={"tool_results": tool_results, "fallback_reason": reason},
                    total_latency=0,
                    started=started,
                    execution_steps=route.execution_steps,
                    query_ctx=query_ctx,
                )
        return None

    def _format_route_answer(self, route: HermesRoute, results: list[dict[str, Any]]) -> str:
        if route.formatter == "daily_briefing":
            for r in results:
                if r.get("name") == "daily_briefing" and r.get("answer"):
                    return str(r["answer"])
        if route.formatter == "commercial_count":
            for r in results:
                if r.get("name") == "commercial_index" and r.get("answer"):
                    return str(r["answer"])
            parts = []
            for r in results:
                if r.get("answer") and not r.get("error"):
                    parts.append(str(r["answer"]))
            return "\n\n".join(parts) if parts else ""
        if route.formatter == "price_list_overview":
            for r in results:
                if r.get("name") == "price_list_status" and r.get("answer"):
                    return str(r["answer"])
        if route.formatter == "commercial_history":
            for r in results:
                if r.get("name") == "commercial_history" and r.get("answer"):
                    return str(r["answer"])
        return self._fallback_tool_answer(results)

    @staticmethod
    def _tool_steps(tools: list[dict]) -> list[str]:
        labels = {
            "search_prices": "Buscando precios",
            "commercial_history": "Consultando historial comercial",
            "commercial_index": "Consultando índice comercial Odoo",
            "odoo_sales": "Consultando Odoo ventas",
            "odoo": "Consultando Odoo",
            "dgcp": "Consultando licitaciones",
            "tasks": "Consultando tareas",
            "daily_briefing": "Generando resumen del día",
            "intelligence_center": "Consultando centro Hermes",
            "price_list_status": "Consultando listas de precios indexadas",
            "m365": "Consultando Microsoft 365",
        }
        return [labels.get(t.get("name", ""), f"Ejecutando {t.get('name', 'herramienta')}") for t in tools if t.get("name")]

    def _build_response(
        self,
        *,
        question: str,
        answer: str,
        turn: dict,
        model: str,
        tools_used: list[str],
        sources: list[str],
        data: dict,
        total_latency: int,
        started: float,
        execution_steps: list[str],
        query_ctx,
    ) -> AssistantQueryResponse:
        elapsed = int((time.perf_counter() - started) * 1000)
        diagnostic = {
            "engine": "hermes",
            "provider": "huawei_modelarts" if model != "deterministic" else "deterministic",
            "model": turn.get("model") or model,
            "intent": turn.get("intent"),
            "latency_ms": elapsed,
            "hermes_latency_ms": total_latency,
            "tools_used": tools_used,
            "sources_consulted": sources,
            "execution_steps": execution_steps,
            "company_scope": query_ctx.company_scope_label,
            "company_id": query_ctx.company_id,
        }
        data = dict(data)
        data["execution_steps"] = execution_steps
        data["company_scope"] = query_ctx.company_scope_label
        return AssistantQueryResponse(
            question=question,
            answer=answer,
            sources=list(dict.fromkeys(sources)),
            query_type="hermes_chat",
            data=data,
            structured_data={
                "type": "hermes_copilot",
                "hermes_diagnostic": diagnostic,
                "execution_steps": execution_steps,
            },
        )

    async def _load_history(
        self,
        persistent: PersistentConversationStore | None,
        conversation_id: str | None,
    ) -> list[dict[str, str]]:
        limit = getattr(settings, "hermes_copilot_history_limit", 50)
        if persistent and conversation_id:
            return await persistent.get_message_history(conversation_id, limit=limit)
        return []

    @staticmethod
    def _fallback_tool_answer(results: list[dict[str, Any]]) -> str:
        parts: list[str] = []
        errors: list[str] = []
        for r in results:
            if r.get("answer") or r.get("summary"):
                parts.append(str(r.get("answer") or r.get("summary")))
            elif r.get("error"):
                err = str(r["error"])
                if r.get("error_type"):
                    err = f"{err} ({r['error_type']})"
                errors.append(f"• {r.get('name', 'tool')}: {err}")
        if parts:
            return "\n\n".join(parts)
        if errors:
            return "No pude completar todas las consultas:\n" + "\n".join(errors)
        return "No pude obtener datos para responder."
