"""Ejecutor de herramientas empresariales para Hermes Copiloto."""

from __future__ import annotations

import logging
import uuid
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.business_intent_router import BusinessIntentRouter
from app.services.commercial_search_service import CommercialSearchService
from app.services.copilot_access_service import AccessDecision, CopilotAccessService
from app.services.copilot_audit_service import CopilotAuditService
from app.services.corporate_knowledge_question_service import CorporateKnowledgeQuestionService
from app.services.dgcp_question_service import DgcpQuestionService
from app.services.document_question_service import DocumentQuestionService
from app.services.enterprise_search_service import EnterpriseSearchService
from app.services.hermes_copilot_context import HermesQueryContext
from app.services.odoo_query_service import OdooQueryService

logger = logging.getLogger(__name__)

TOOL_NAMES = frozenset({
    "search_prices",
    "commercial_history",
    "commercial_index",
    "form_autofill",
    "odoo",
    "odoo_sales",
    "dgcp",
    "documents",
    "enterprise_search",
    "knowledge",
    "m365",
    "tasks",
    "daily_briefing",
    "intelligence_center",
    "calendar",
    "price_list_status",
})

_NO_QUERY_TOOLS = frozenset({
    "daily_briefing",
    "intelligence_center",
    "tasks",
    "calendar",
    "price_list_status",
    "odoo_sales",
})


class HermesCopilotTools:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.access = CopilotAccessService(db, tenant_id, user_id)
        self.audit = CopilotAuditService(db)
        self.query_context: HermesQueryContext | None = None

    def set_context(self, ctx: HermesQueryContext | None) -> None:
        self.query_context = ctx

    def _company_id(self) -> int | None:
        return self.query_context.company_id if self.query_context else None

    async def execute(
        self,
        name: str,
        query: str,
        parameters: dict[str, Any] | None = None,
        *,
        intent: str | None = None,
        question: str | None = None,
        model: str | None = None,
    ) -> dict[str, Any]:
        normalized = (name or "").strip().lower().replace("-", "_")
        params = parameters or {}
        q = (query or params.get("query") or params.get("search") or "").strip()

        decision = await self.access.check_tool(normalized, intent=intent, parameters=params)
        if not decision.allowed:
            await self.audit.log_query(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                question=question or q,
                intent=intent,
                tool=normalized,
                allowed=False,
                data_returned=False,
                model=model,
                decision=decision,
            )
            await self.db.commit()
            return {
                "name": normalized,
                "success": False,
                "denied": True,
                "error": decision.reason,
                "missing_scope": decision.missing_scope,
                "classification": decision.classification,
            }

        if not q and normalized not in _NO_QUERY_TOOLS:
            return {"name": normalized, "error": "Consulta vacía", "success": False}

        try:
            if normalized in ("search_prices", "commercial_search", "provider_search"):
                result = await self._search_prices(q or "productos", params)
            elif normalized in ("commercial_history", "commercial_index", "sales_history"):
                if normalized == "commercial_index":
                    result = await self._commercial_index(q, params)
                else:
                    result = await self._commercial_history(q, params)
            elif normalized in ("form_autofill", "autofill", "document_autofill"):
                result = await self._form_autofill(q, params)
            elif normalized == "odoo_sales":
                result = await self._odoo_sales(q, params)
            elif normalized == "odoo":
                result = await self._odoo(q or params.get("query", ""))
            elif normalized in ("dgcp", "dgcp_search", "tender_analysis"):
                result = await self._dgcp(q or "licitaciones activas")
            elif normalized in ("documents", "document", "document_search"):
                result = await self._documents(q or params.get("query", ""))
            elif normalized == "enterprise_search":
                result = await self._enterprise_search(q)
            elif normalized == "knowledge":
                result = await self._knowledge(q)
            elif normalized in ("m365", "outlook", "sharepoint", "onedrive"):
                result = await self._m365(q or params.get("query", ""))
            elif normalized in ("tasks", "task_creation"):
                result = await self._tasks(q or "tareas pendientes hoy")
            elif normalized == "daily_briefing":
                result = await self._daily_briefing(params)
            elif normalized == "intelligence_center":
                result = await self._intelligence_center(q or params.get("filter", ""))
            elif normalized in ("calendar", "calendario"):
                result = await self._calendar(q or "eventos de hoy")
            elif normalized == "price_list_status":
                result = await self._price_list_status(q, params)
            else:
                return {"name": normalized, "error": f"Herramienta «{name}» no disponible", "success": False}

            await self.audit.log_query(
                tenant_id=self.tenant_id,
                user_id=self.user_id,
                question=question or q,
                intent=intent,
                tool=normalized,
                allowed=True,
                data_returned=bool(result.get("success")),
                model=model,
                decision=decision,
                customer=params.get("customer") or params.get("cliente"),
            )
            await self.db.commit()
            return result
        except Exception as exc:
            logger.exception("Hermes tool failed name=%s", normalized)
            err_type = type(exc).__name__
            return {
                "name": normalized,
                "error": str(exc),
                "error_type": err_type,
                "success": False,
                "retryable": err_type in ("TimeoutError", "ReadTimeout", "ConnectError", "OdooConnectionError"),
            }

    async def execute_many(
        self,
        tools: list[dict[str, Any]],
        *,
        intent: str | None = None,
        question: str | None = None,
        model: str | None = None,
    ) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        for tool in tools[:3]:
            name = tool.get("name") or tool.get("tool") or ""
            query = tool.get("query") or tool.get("input") or tool.get("question") or ""
            params = tool.get("parameters") or {}
            tool_intent = tool.get("intent") or intent
            result = await self.execute(
                name,
                query,
                params,
                intent=tool_intent,
                question=question,
                model=model,
            )
            if tool.get("reason"):
                result["reason"] = tool["reason"]
            results.append(result)
            if result.get("denied"):
                break
        return results

    async def _odoo_sales(self, query: str, params: dict[str, Any]) -> dict[str, Any]:
        from app.services.sales_question_service import SalesQuestionService

        svc = SalesQuestionService(self.db, self.tenant_id, self.user_id)
        search_q = query or params.get("query") or "ventas"
        if params.get("group_by") == "customer" or params.get("metric") == "amount_sold":
            if not query:
                search_q = "¿cuál cliente nos ha comprado más?"
        result = await svc.answer(search_q, source_labels=["odoo"])
        if result is None:
            return await self._odoo(search_q)
        return {
            "name": "odoo_sales",
            "success": True,
            "answer": result.answer,
            "summary": result.answer[:2000],
            "query_type": result.query_type,
            "data": result.data,
            "parameters": params,
        }

    async def _tasks(self, query: str) -> dict[str, Any]:
        from app.services.business_intent_router import BusinessIntentRouter
        from app.services.tasks_question_service import TasksQuestionService

        classified = BusinessIntentRouter.classify(query)
        result = await TasksQuestionService(self.db, self.tenant_id, self.user_id).answer(query, classified)
        return {
            "name": "tasks",
            "success": True,
            "answer": result.answer,
            "summary": result.answer[:2000],
            "sources": result.sources,
        }

    async def _form_autofill(self, query: str, params: dict[str, Any]) -> dict[str, Any]:
        from app.services.document_template_service import DocumentTemplateService

        slug = params.get("template_slug") or params.get("form_type") or "sncc-f042"
        company = params.get("company") or "justech"
        svc = DocumentTemplateService(self.db, self.tenant_id)
        result = await svc.get_missing_fields(
            template_slug=str(slug).lower().replace(".", "-"),
            company_key=str(company),
            extra_context={
                k: v
                for k, v in {
                    "proceso_dgcp": params.get("proceso") or params.get("code"),
                    "entidad_contratante": params.get("entidad") or params.get("institution"),
                }.items()
                if v
            },
        )
        if result.get("error"):
            return {"name": "form_autofill", "success": False, "error": result["error"]}
        return {
            "name": "form_autofill",
            "success": True,
            "answer": result.get("hermes_message", ""),
            "summary": result.get("hermes_message", "")[:2000],
            "data": result,
            "sources": [{"system": "templates", "slug": result.get("template_slug")}],
        }

    async def _commercial_history(self, query: str, params: dict[str, Any]) -> dict[str, Any]:
        from app.services.commercial_index_search_service import CommercialIndexSearchService

        search_q = query or params.get("query") or params.get("product") or "historial ventas"
        svc = CommercialIndexSearchService(self.db, self.tenant_id)
        result = await svc.answer_for_hermes(
            search_q,
            limit=int(params.get("limit") or 10),
            company_id=self._company_id(),
            last_sold=bool(params.get("last_sold")),
        )
        return {
            "name": "commercial_history",
            "success": result.get("success", True),
            "answer": result.get("answer", ""),
            "summary": (result.get("answer") or "")[:2000],
            "sources": result.get("sources", []),
            "data": result.get("data"),
        }

    async def _commercial_index(self, query: str, params: dict[str, Any]) -> dict[str, Any]:
        from app.services.commercial_index_search_service import CommercialIndexSearchService
        from app.services.price_list_summary_service import PriceListSummaryService

        svc = CommercialIndexSearchService(self.db, self.tenant_id)
        pl_svc = PriceListSummaryService(self.db, self.tenant_id, self.user_id)
        max_price_raw = params.get("max_price")
        product = params.get("product") or "laptop"
        q_lower = (query or "").lower()
        product_type = "laptop" if product in ("laptop", "portátil", "portatil", "notebook") or "laptop" in q_lower else None

        pl_result = None
        try:
            pl_result = await pl_svc.search_price_lists(
                query=product if product != "producto" else query,
                product_type=product_type,
                price_max_usd=Decimal(str(max_price_raw)) if max_price_raw else None,
            )
        except Exception as exc:
            pl_result = {"count": 0, "summary_line": f"No pude consultar listas de precios: {exc}"}

        if max_price_raw:
            try:
                max_price = Decimal(str(max_price_raw))
            except InvalidOperation:
                max_price = None
            if max_price is not None:
                result = await svc.count_under_price(
                    query or product,
                    max_price=max_price,
                    currency=params.get("currency") or "USD",
                    company_id=self._company_id(),
                    price_list_result=pl_result,
                )
                return {"name": "commercial_index", **result}

        search_q = query or params.get("query") or "productos"
        result = await svc.answer_for_hermes(search_q, limit=8, company_id=self._company_id())
        return {
            "name": "commercial_index",
            "success": result.get("success", True),
            "answer": result.get("answer", ""),
            "summary": (result.get("answer") or "")[:2000],
            "sources": result.get("sources", []),
            "data": result.get("data"),
        }

    async def _price_list_status(self, query: str, params: dict[str, Any]) -> dict[str, Any]:
        from app.services.hermes_commercial_formatter import format_price_list_overview
        from app.services.price_list_summary_service import PriceListSummaryService

        svc = PriceListSummaryService(self.db, self.tenant_id, self.user_id)
        mode = params.get("mode")
        if mode == "suppliers":
            cat = params.get("category") or "laptop"
            data = await svc.suppliers_for_category(cat)
            if not data["suppliers"]:
                answer = f"No encontré proveedores con «{cat}» en listas indexadas."
            else:
                lines = [f"• {s['supplier']}: {s['count']} productos" for s in data["suppliers"][:8]]
                answer = f"Proveedores con {cat} en listas indexadas:\n" + "\n".join(lines)
            return {
                "name": "price_list_status",
                "success": True,
                "answer": answer,
                "summary": answer[:500],
                "sources": ["price_intelligence"],
                "data": data,
            }

        summary = await svc.get_summary()
        answer = format_price_list_overview(summary)
        return {
            "name": "price_list_status",
            "success": True,
            "answer": answer,
            "summary": answer[:800],
            "sources": ["price_intelligence"],
            "data": summary,
        }

    async def _daily_briefing(self, params: dict[str, Any]) -> dict[str, Any]:
        from app.models.user import User
        from app.services.hermes_daily_summary_service import HermesDailySummaryService

        user = await self.db.get(User, self.user_id)
        if not user:
            return {"name": "daily_briefing", "success": False, "error": "Usuario no encontrado"}
        mode = str(params.get("mode") or "operational")
        result = await HermesDailySummaryService(self.db, self.tenant_id, self.user_id).build_summary(
            user,
            mode=mode,
            query_ctx=self.query_context,
        )
        return {"name": "daily_briefing", **result}

    async def _intelligence_center(self, query: str) -> dict[str, Any]:
        from app.services.hermes_intelligence_center_service import HermesIntelligenceCenterService

        data = await HermesIntelligenceCenterService(self.db, self.tenant_id).get_cards(limit=10)
        cards = data.get("cards") or []
        q_lower = query.lower()
        if q_lower:
            cards = [
                c
                for c in cards
                if q_lower in (c.get("type") or "").lower()
                or q_lower in (c.get("title") or "").lower()
                or q_lower in (c.get("summary") or "").lower()
            ]
        if not cards:
            return {
                "name": "intelligence_center",
                "success": True,
                "answer": "No hay alertas proactivas pendientes en el centro Hermes para este filtro.",
                "summary": "Sin alertas",
                "sources": ["intelligence_center"],
            }
        lines = [f"• **{c.get('title')}**: {c.get('summary', '')[:200]}" for c in cards[:8]]
        answer = "Alertas del centro Hermes:\n\n" + "\n".join(lines)
        return {
            "name": "intelligence_center",
            "success": True,
            "answer": answer,
            "summary": answer[:2000],
            "sources": ["intelligence_center"],
            "data": {"cards": cards[:8]},
        }

    async def _calendar(self, query: str) -> dict[str, Any]:
        from app.services.m365_service import M365Service

        m365 = M365Service(self.db, self.tenant_id, user_id=self.user_id)
        health = await m365.health()
        if not health.connected:
            return {
                "name": "calendar",
                "success": True,
                "answer": "Microsoft 365 no está conectado. No puedo consultar calendario en este momento.",
                "summary": "M365 no conectado",
                "sources": ["m365"],
            }
        events = await m365.calendar_events(limit=8)
        if not events.items:
            return {
                "name": "calendar",
                "success": True,
                "answer": "No hay eventos próximos en el calendario M365.",
                "summary": "Calendario vacío",
                "sources": ["m365", "calendar"],
            }
        lines = []
        for ev in events.items[:8]:
            lines.append(f"• {ev.get('subject', 'Evento')} — {ev.get('start', '')}")
        answer = "Próximos eventos en calendario:\n" + "\n".join(lines)
        return {
            "name": "calendar",
            "success": True,
            "answer": answer,
            "summary": answer[:2000],
            "sources": ["m365", "calendar"],
        }

    async def _search_prices(self, query: str, params: dict | None = None) -> dict[str, Any]:
        from app.services.price_list_summary_service import PriceListSummaryService

        params = params or {}
        pl_svc = PriceListSummaryService(self.db, self.tenant_id, self.user_id)
        product = params.get("product") or query
        product_type = "laptop" if "laptop" in (query or "").lower() or product in ("laptop", "portátil", "portatil") else None
        max_usd = Decimal(str(params["max_price"])) if params.get("max_price") else None
        try:
            pl = await pl_svc.search_price_lists(
                query=product,
                product_type=product_type,
                price_max_usd=max_usd,
            )
        except Exception as exc:
            return {
                "name": "search_prices",
                "success": False,
                "error": str(exc),
                "answer": f"No pude consultar listas de precios ahora mismo ({type(exc).__name__}).",
                "summary": "Listas de precios no disponibles",
            }
        if not pl.get("count"):
            return {
                "name": "search_prices",
                "success": True,
                "answer": "Listas de precios actuales: sin resultados para esta búsqueda.",
                "summary": "0 en listas indexadas",
                "data": pl,
            }
        lines = [
            f"• {i['supplier']}: {i['description'][:70]} — {i['currency']} {i['price']}"
            for i in pl.get("items", [])[:5]
        ]
        answer = f"{pl['count']} resultado(s) en listas indexadas:\n" + "\n".join(lines)
        return {
            "name": "search_prices",
            "success": True,
            "answer": answer,
            "summary": pl.get("summary_line", ""),
            "data": pl,
        }

    async def _odoo(self, query: str) -> dict[str, Any]:
        svc = OdooQueryService(self.db, self.tenant_id, user_id=self.user_id)
        result = await svc.answer(query)
        return {
            "name": "odoo",
            "success": result.query_type not in ("help", "empty", "not_connected"),
            "answer": result.answer,
            "summary": result.answer[:2000],
            "query_type": result.query_type,
            "data": result.data,
        }

    async def _dgcp(self, query: str) -> dict[str, Any]:
        classified = BusinessIntentRouter.classify(query)
        result = await DgcpQuestionService(self.db, self.tenant_id).answer(query, classified)
        return {
            "name": "dgcp",
            "success": True,
            "answer": result.answer,
            "summary": result.answer[:2000],
            "sources": result.sources,
            "data": result.data,
        }

    async def _documents(self, query: str) -> dict[str, Any]:
        classified = BusinessIntentRouter.classify(query)
        result = await DocumentQuestionService(self.db, self.tenant_id, self.user_id).answer(
            query,
            sub_intent=classified.sub_intent,
            search_term=classified.search_term or query,
        )
        return {
            "name": "documents",
            "success": True,
            "answer": result.answer,
            "summary": result.answer[:2000],
            "sources": result.sources,
        }

    async def _enterprise_search(self, query: str) -> dict[str, Any]:
        hits = await EnterpriseSearchService(self.db, self.tenant_id, self.user_id).search(query, limit=8)
        if not hits.get("results"):
            return {
                "name": "enterprise_search",
                "success": False,
                "summary": f"Sin resultados para «{query}»",
                "answer": "No encontré resultados en el índice empresarial.",
            }
        lines = []
        for h in hits["results"][:8]:
            lines.append(f"- {h.get('title', h.get('name', 'Resultado'))}: {h.get('snippet', '')[:200]}")
        answer = "Resultados encontrados:\n" + "\n".join(lines)
        return {
            "name": "enterprise_search",
            "success": True,
            "answer": answer,
            "summary": answer[:2000],
            "count": len(hits["results"]),
        }

    async def _knowledge(self, query: str) -> dict[str, Any]:
        result = await CorporateKnowledgeQuestionService(self.db, self.tenant_id).answer(query)
        return {
            "name": "knowledge",
            "success": True,
            "answer": result["answer"],
            "summary": result["answer"][:2000],
            "query_type": result.get("query_type"),
        }

    async def _m365(self, query: str) -> dict[str, Any]:
        from app.services.m365_assistant_service import M365AssistantService

        result = await M365AssistantService(self.db, self.tenant_id, self.user_id).answer(query)
        return {
            "name": "m365",
            "success": result.query_type not in ("not_connected",),
            "answer": result.answer,
            "summary": result.answer[:2000],
            "sources": result.sources,
        }
