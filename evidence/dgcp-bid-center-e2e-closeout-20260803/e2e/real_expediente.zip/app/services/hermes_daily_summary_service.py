"""Resumen ejecutivo del día para Hermes — datos reales sin inventar."""

from __future__ import annotations

import uuid
from datetime import date, timedelta

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import User
from app.services.copilot_briefing_service import CopilotBriefingService
from app.services.hermes_intelligence_center_service import HermesIntelligenceCenterService
from app.services.hermes_copilot_context import HermesQueryContext


class HermesDailySummaryService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def build_summary(
        self,
        user: User,
        *,
        mode: str = "operational",
        query_ctx: HermesQueryContext | None = None,
    ) -> dict:
        briefing = await CopilotBriefingService(self.db, self.tenant_id, self.user_id).get_briefing(
            user, mode=mode
        )
        intel = await HermesIntelligenceCenterService(self.db, self.tenant_id).get_cards(limit=8)

        from app.services.tasks_question_service import TasksQuestionService
        from app.services.business_intent_router import BusinessIntentRouter

        tasks_result = await TasksQuestionService(self.db, self.tenant_id, self.user_id).answer(
            "tareas pendientes hoy",
            BusinessIntentRouter.classify("tareas pendientes hoy"),
        )

        calendar_note = ""
        try:
            from app.services.m365_service import M365Service

            m365 = M365Service(self.db, self.tenant_id, user_id=self.user_id)
            health = await m365.health()
            if health.connected:
                events = await m365.calendar_events(limit=5)
                if events.items:
                    calendar_note = "\n".join(
                        f"- {ev.get('subject', 'Evento')} ({ev.get('start', '')})"
                        for ev in events.items[:5]
                    )
                else:
                    calendar_note = "Sin eventos próximos en calendario M365."
            else:
                calendar_note = "Calendario M365 no conectado."
        except Exception:
            calendar_note = "Calendario no disponible en este momento."

        sections: list[str] = []
        company = query_ctx.company_name if query_ctx else briefing.company_name
        header = f"**Resumen para hoy ({date.today().isoformat()})**"
        if company:
            header += f" — {company}"
        sections.append(header)
        sections.append("")
        sections.append(briefing.greeting.strip())

        def _items(title: str, items) -> None:
            if not items:
                return
            sections.append("")
            sections.append(f"### {title}")
            for it in items[:6]:
                detail = f" — {it.detail}" if getattr(it, "detail", None) else ""
                sections.append(f"- {it.label}{detail}")

        _items("Prioridades", briefing.priorities.items)
        _items("Alertas", briefing.alerts.items)
        _items("Oportunidades", briefing.opportunities.items)

        sections.append("")
        sections.append("### Tareas pendientes")
        sections.append(tasks_result.answer[:1200])

        sections.append("")
        sections.append("### Calendario")
        sections.append(calendar_note)

        if intel.get("cards"):
            sections.append("")
            sections.append("### Centro Hermes (detección proactiva)")
            for card in intel["cards"][:6]:
                sections.append(f"- **{card.get('title')}**: {card.get('summary', '')[:160]}")

        sections.append("")
        sections.append(
            "_Fuentes: tareas JAIOS, DGCP, documentos, Odoo"
            + (", M365" if mode == "operational" else "")
            + ", centro de inteligencia Hermes._"
        )

        return {
            "success": True,
            "answer": "\n".join(sections),
            "summary": briefing.greeting[:500],
            "sources": ["briefing", "intelligence_center", "tasks", "dgcp", "odoo"],
            "data": {
                "mode": mode,
                "intel_cards": len(intel.get("cards") or []),
                "company": company,
            },
        }
