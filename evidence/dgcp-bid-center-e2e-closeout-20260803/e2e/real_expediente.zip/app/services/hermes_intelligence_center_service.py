"""Centro de Inteligencia Hermes — tarjetas proactivas (Fase 4)."""

from __future__ import annotations

import uuid
from datetime import date, datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.commercial_search import CommercialSearchItem
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.document_pending import DocumentPendingItem
from app.models.hermes_observed_event import HermesObservedEvent
from app.services.dgcp_service import DGCPService


class HermesIntelligenceCenterService:
    PRIORITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def get_cards(self, *, limit: int = 30) -> dict:
        cards: list[dict] = []
        cards.extend(await self._detect_dgcp_opportunities())
        cards.extend(await self._detect_dgcp_deadlines())
        cards.extend(await self._detect_stale_quotations())
        cards.extend(await self._detect_pending_observations())
        cards.extend(await self._detect_missing_documents())
        cards.extend(await self._detect_commercial_matches())

        cards.sort(key=lambda c: (self.PRIORITY_ORDER.get(c.get("priority", "low"), 9), c.get("date") or ""))
        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total": len(cards),
            "cards": cards[:limit],
        }

    async def _detect_dgcp_opportunities(self) -> list[dict]:
        today = date.today()
        horizon = today + timedelta(days=14)
        result = await self.db.execute(
            select(DGCPOpportunity)
            .where(
                DGCPOpportunity.tenant_id == self.tenant_id,
                DGCPOpportunity.status.in_(("detected", "to_review", "analyzing", "interested", "qualified")),
                DGCPOpportunity.deadline <= horizon,
                DGCPOpportunity.deadline >= today,
            )
            .order_by(DGCPOpportunity.score.desc())
            .limit(8)
        )
        cards = []
        for opp in result.scalars().all():
            cards.append({
                "id": f"dgcp-opp-{opp.id}",
                "type": "licitacion_recomendada",
                "title": f"Licitación: {opp.code}",
                "summary": f"{opp.institution} · {opp.title[:120]}",
                "priority": "high" if opp.score >= 70 else "medium",
                "source": "dgcp",
                "recommendation": f"Plazo {opp.deadline}. Score {opp.score}. Analice viabilidad y prepare expediente.",
                "date": str(opp.deadline),
                "href": f"/dgcp/{opp.id}",
                "suggested_actions": [
                    {"action": "view_detail", "label": "Ver detalle", "requires_approval": False},
                    {"action": "search_history", "label": "Buscar historial comercial", "requires_approval": False},
                    {"action": "create_expediente", "label": "Preparar expediente", "requires_approval": True},
                    {"action": "autofill_document", "label": "Autollenar formulario", "requires_approval": True},
                    {"action": "ignore", "label": "Ignorar", "requires_approval": False},
                ],
            })
        return cards

    async def _detect_dgcp_deadlines(self) -> list[dict]:
        today = date.today()
        urgent = today + timedelta(days=3)
        result = await self.db.execute(
            select(DGCPOpportunity)
            .where(
                DGCPOpportunity.tenant_id == self.tenant_id,
                DGCPOpportunity.status.in_(("to_bid", "preparing", "pending_documents", "ready_to_submit")),
                DGCPOpportunity.deadline <= urgent,
                DGCPOpportunity.deadline >= today,
            )
            .limit(5)
        )
        return [
            {
                "id": f"dgcp-deadline-{opp.id}",
                "type": "licitacion_vencimiento",
                "title": f"Plazo próximo: {opp.code}",
                "summary": opp.title[:100],
                "priority": "critical",
                "source": "dgcp",
                "recommendation": f"Vence {opp.deadline}. Revise checklist y documentos pendientes.",
                "date": str(opp.deadline),
                "href": f"/dgcp/{opp.id}",
                "suggested_actions": [
                    {"action": "view_detail", "label": "Ver expediente", "requires_approval": False},
                    {"action": "create_task", "label": "Crear tarea", "requires_approval": True},
                ],
            }
            for opp in result.scalars().all()
        ]

    async def _detect_stale_quotations(self) -> list[dict]:
        cutoff = date.today() - timedelta(days=5)
        result = await self.db.execute(
            select(CommercialSearchItem)
            .where(
                CommercialSearchItem.tenant_id == self.tenant_id,
                CommercialSearchItem.document_type == "quotation",
                CommercialSearchItem.date.isnot(None),
                CommercialSearchItem.date <= cutoff,
            )
            .order_by(CommercialSearchItem.date.asc())
            .limit(10)
        )
        seen: set[str] = set()
        cards = []
        for item in result.scalars().all():
            key = item.document_number or str(item.source_id)
            if key in seen:
                continue
            seen.add(key)
            days = (date.today() - item.date).days if item.date else 0
            cards.append({
                "id": f"quote-stale-{item.source_id}",
                "type": "cotizacion_sin_seguimiento",
                "title": f"Cotización sin respuesta: {item.document_number or '—'}",
                "summary": f"{item.customer_name} · {item.product_name or item.description or '—'}",
                "priority": "high" if days >= 7 else "medium",
                "source": "odoo_index",
                "recommendation": f"Lleva {days} días sin cierre. Contacte al cliente y revise precio histórico.",
                "date": str(item.date) if item.date else None,
                "href": "/inteligencia/busqueda-comercial",
                "suggested_actions": [
                    {"action": "search_history", "label": "Ver historial", "requires_approval": False},
                    {"action": "prepare_response", "label": "Preparar borrador respuesta", "requires_approval": True},
                    {"action": "mark_reviewed", "label": "Marcar revisado", "requires_approval": False},
                ],
                "metadata": {
                    "source_model": item.source_model,
                    "source_id": item.source_id,
                    "unit_price": str(item.unit_price) if item.unit_price else None,
                },
            })
        return cards

    async def _detect_pending_observations(self) -> list[dict]:
        result = await self.db.execute(
            select(HermesObservedEvent)
            .where(
                HermesObservedEvent.tenant_id == self.tenant_id,
                HermesObservedEvent.status == "pending_review",
            )
            .order_by(HermesObservedEvent.created_at.desc())
            .limit(5)
        )
        return [
            {
                "id": f"obs-{ev.id}",
                "type": "cliente_esperando_respuesta",
                "title": "Cliente esperando respuesta",
                "summary": ev.summary or (ev.raw_body_preview[:120] if ev.raw_body_preview else "Solicitud pendiente"),
                "priority": "high" if ev.confidence >= 0.7 else "medium",
                "source": ev.channel,
                "recommendation": "Revise historial comercial y prepare borrador (requiere aprobación para enviar).",
                "date": ev.created_at.isoformat() if ev.created_at else None,
                "href": "/inteligencia/comercial",
                "suggested_actions": [
                    {"action": "view_detail", "label": "Ver solicitud", "requires_approval": False},
                    {"action": "prepare_response", "label": "Preparar respuesta", "requires_approval": True},
                ],
            }
            for ev in result.scalars().all()
        ]

    async def _detect_missing_documents(self) -> list[dict]:
        result = await self.db.execute(
            select(DocumentPendingItem)
            .where(DocumentPendingItem.tenant_id == self.tenant_id)
            .limit(5)
        )
        return [
            {
                "id": f"doc-pending-{item.id}",
                "type": "documento_faltante",
                "title": f"Documento pendiente: {item.item_label or item.item_key}",
                "summary": item.notes or item.company_key or "Revisar repositorio documental",
                "priority": "medium",
                "source": "documents",
                "recommendation": "Complete el perfil documental o suba el archivo requerido.",
                "date": item.created_at.isoformat() if item.created_at else None,
                "href": "/documentos/pendientes",
                "suggested_actions": [
                    {"action": "view_detail", "label": "Ver pendiente", "requires_approval": False},
                    {"action": "autofill_document", "label": "Autollenar si aplica", "requires_approval": True},
                ],
            }
            for item in result.scalars().all()
        ]

    async def _detect_commercial_matches(self) -> list[dict]:
        dgcp = DGCPService(self.db)
        summary = await dgcp.compute_dashboard(self.tenant_id, user_id=self.user_id)
        if not summary.to_bid:
            return []
        return [{
            "id": "commercial-pipeline",
            "type": "oportunidad_detectada",
            "title": f"{summary.to_bid} licitación(es) en preparación",
            "summary": "Procesos activos con historial comercial consultable",
            "priority": "medium",
            "source": "jaios",
            "recommendation": "Cruce historial Odoo + precios proveedor antes de presentar oferta.",
            "date": datetime.now(timezone.utc).date().isoformat(),
            "href": "/apps/licitaciones/procesos",
            "suggested_actions": [
                {"action": "search_history", "label": "Buscar historial", "requires_approval": False},
            ],
        }]
