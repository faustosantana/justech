"""Enrutamiento determinístico de intenciones Hermes — sin depender del LLM."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation


@dataclass
class HermesRoute:
    intent: str
    tools: list[dict]
    execution_steps: list[str] = field(default_factory=list)
    skip_llm: bool = True
    formatter: str = "default"


_TODAY = re.compile(
    r"(qu[eé]\s+(tenemos|hay|tengo)\s+(para\s+)?hoy|"
    r"qu[eé]\s+(tengo|hay)\s+pendiente(\s+hoy)?|"
    r"agenda\s+de\s+hoy|"
    r"qu[eé]\s+debemos\s+revisar\s+hoy|"
    r"resumen\s+de\s+hoy|"
    r"briefing\s+de\s+hoy|"
    r"plan\s+del\s+d[ií]a)",
    re.I,
)

_PRICE_LIST_OVERVIEW = re.compile(
    r"(listas?\s+de\s+precios?|precios?\s+indexados?|productos?\s+indexados?|"
    r"dime de las listas|estado de (?:las )?listas|"
    r"por qu[eé] no hay listas|qu[eé] productos hay indexados)",
    re.I,
)

_COMMERCIAL_COUNT = re.compile(
    r"(cu[aá]nt[oa]s?|how many|n[uú]mero de|cantidad de).{0,50}"
    r"(laptop|port[aá]til|monitor|impresora|servidor|switch|producto)",
    re.I,
)

_CATEGORY_PRICE = re.compile(
    r"(laptop|port[aá]til|notebook|monitor|impresora|servidor|switch|toner).{0,40}"
    r"(menos de|under|hasta|m[aá]ximo).{0,20}(\d+)",
    re.I,
)

_LAST_SOLD = re.compile(
    r"(último|ultimo|last).{0,20}(precio|vendido|venta).{0,40}(laptop|port[aá]til|hp|dell)",
    re.I,
)

_SUPPLIERS_CATEGORY = re.compile(
    r"qu[eé]\s+proveedores?\s+(tienen|hay|con).{0,30}(laptop|switch|toner|monitor|servidor)",
    re.I,
)

_CISCO_SWITCH_HISTORY = re.compile(
    r"(busca|historial|ventas?).{0,30}(switch|cisco)",
    re.I,
)

_PRICE_UNDER = re.compile(
    r"(menos de|under|por debajo de|hasta|m[aá]ximo|max\.?)\s*"
    r"[\$]?\s*(\d+(?:[.,]\d+)?)\s*(usd|d[oó]lar(?:es)?|\$|rd\$|dop|pesos)?",
    re.I,
)

_DGCP_DEADLINE = re.compile(
    r"(licitacion(?:es)?|procesos?\s+dgcp).{0,30}(vencen|vence|esta semana|pr[oó]xim[oa]s?)",
    re.I,
)

_STALE_QUOTES = re.compile(
    r"cotizacion(?:es)?.*sin\s+seguimiento|sin\s+seguimiento.*cotizacion",
    re.I,
)

_WAITING_CLIENTS = re.compile(
    r"clientes?\s+(?:esperan|esperando)\s+respuesta",
    re.I,
)

_DELL_SALES = re.compile(
    r"(busca|historial|ventas?\s+anteriores?).{0,30}(dell|laptop)",
    re.I,
)


def _extract_max_price(question: str) -> tuple[Decimal | None, str | None]:
    m = _PRICE_UNDER.search(question)
    if not m:
        return None, None
    raw = m.group(2).replace(",", ".")
    try:
        amount = Decimal(raw)
    except InvalidOperation:
        return None, None
    cur = (m.group(3) or "").lower()
    if cur in ("usd", "dolar", "dolares", "dólar", "dólares", "$"):
        currency = "USD"
    elif cur in ("rd$", "dop", "pesos", "peso"):
        currency = "DOP"
    else:
        currency = "USD" if "usd" in question.lower() or "dolar" in question.lower() else "USD"
    return amount, currency


def _last_sold_search_terms(question: str) -> str:
    lower = question.lower()
    terms: list[str] = []
    for term in (
        "laptop", "portátil", "portatil", "notebook",
        "hp", "dell", "lenovo", "asus", "acer", "msi",
        "monitor", "impresora", "servidor", "switch",
    ):
        if term in lower:
            terms.append(term)
    return " ".join(dict.fromkeys(terms)) or "laptop"


def _product_term(question: str) -> str:
    lower = question.lower()
    for term in (
        "laptop", "portátil", "portatil", "notebook", "monitor", "impresora",
        "servidor", "switch", "toner", "dell", "hp", "cisco",
    ):
        if term in lower:
            return term
    return "producto"


def _commercial_count_route(q: str, lower: str) -> HermesRoute | None:
    if not (_COMMERCIAL_COUNT.search(lower) or _CATEGORY_PRICE.search(lower) or (
        _PRICE_UNDER.search(lower) and any(w in lower for w in ("laptop", "portátil", "portatil", "monitor", "switch"))
    )):
        return None
    max_price, currency = _extract_max_price(q)
    product = _product_term(q)
    params: dict = {"product": product, "query": q}
    if max_price is not None:
        params["max_price"] = str(max_price)
    if currency:
        params["currency"] = currency
    return HermesRoute(
        intent="product_category_search",
        tools=[
            {"name": "commercial_index", "query": q, "parameters": params},
        ],
        execution_steps=[
            "Analizando solicitud",
            "Consultando listas de precios indexadas",
            "Consultando historial comercial Odoo",
            "Filtrando accesorios y aplicando moneda",
            "Preparando respuesta",
        ],
        formatter="commercial_count",
    )


def match(question: str) -> HermesRoute | None:
    q = question.strip()
    if not q:
        return None
    lower = q.lower()

    if _TODAY.search(lower):
        return HermesRoute(
            intent="daily_briefing",
            tools=[{"name": "daily_briefing", "query": q, "parameters": {"mode": "operational"}}],
            execution_steps=[
                "Analizando solicitud",
                "Consultando tareas y calendario",
                "Consultando licitaciones y cotizaciones",
                "Preparando resumen ejecutivo",
            ],
            formatter="daily_briefing",
        )

    if _PRICE_LIST_OVERVIEW.search(lower):
        return HermesRoute(
            intent="commercial_search",
            tools=[{"name": "price_list_status", "query": q}],
            execution_steps=[
                "Analizando solicitud",
                "Consultando estado de listas indexadas",
                "Preparando resumen",
            ],
            formatter="price_list_overview",
        )

    if _SUPPLIERS_CATEGORY.search(lower):
        cat = _product_term(q)
        return HermesRoute(
            intent="commercial_search",
            tools=[{"name": "price_list_status", "query": q, "parameters": {"mode": "suppliers", "category": cat}}],
            execution_steps=["Analizando solicitud", "Consultando proveedores en listas indexadas"],
            formatter="default",
        )

    commercial = _commercial_count_route(q, lower)
    if commercial:
        return commercial

    if _LAST_SOLD.search(lower):
        search_q = _last_sold_search_terms(q)
        return HermesRoute(
            intent="commercial_search",
            tools=[{
                "name": "commercial_history",
                "query": search_q,
                "parameters": {"limit": 5, "last_sold": True},
            }],
            execution_steps=["Analizando solicitud", "Consultando último precio en Odoo"],
            formatter="commercial_history",
        )

    if _CISCO_SWITCH_HISTORY.search(lower):
        return HermesRoute(
            intent="commercial_search",
            tools=[{"name": "commercial_history", "query": q}],
            execution_steps=["Analizando solicitud", "Consultando índice comercial Odoo"],
            formatter="commercial_history",
        )

    if _DGCP_DEADLINE.search(lower):
        return HermesRoute(
            intent="dgcp_search",
            tools=[{"name": "dgcp", "query": "licitaciones que vencen esta semana"}],
            execution_steps=["Analizando solicitud", "Consultando licitaciones DGCP"],
            formatter="default",
        )

    if _STALE_QUOTES.search(lower):
        return HermesRoute(
            intent="commercial_search",
            tools=[{"name": "intelligence_center", "query": "cotizaciones sin seguimiento"}],
            execution_steps=["Analizando solicitud", "Consultando cotizaciones estancadas"],
            formatter="default",
        )

    if _WAITING_CLIENTS.search(lower):
        return HermesRoute(
            intent="daily_briefing",
            tools=[{"name": "intelligence_center", "query": "clientes esperando respuesta"}],
            execution_steps=["Analizando solicitud", "Consultando observaciones Hermes"],
            formatter="default",
        )

    if _DELL_SALES.search(lower):
        return HermesRoute(
            intent="commercial_search",
            tools=[{"name": "commercial_history", "query": q}],
            execution_steps=["Analizando solicitud", "Consultando historial comercial indexado"],
            formatter="commercial_history",
        )

    if re.search(r"oportunidades?\s+importantes?\s+(de\s+)?hoy", lower):
        return HermesRoute(
            intent="daily_briefing",
            tools=[
                {"name": "daily_briefing", "query": q, "parameters": {"mode": "managerial"}},
                {"name": "dgcp", "query": "oportunidades importantes activas"},
            ],
            execution_steps=["Analizando solicitud", "Consultando oportunidades DGCP"],
            formatter="daily_briefing",
        )

    return None
