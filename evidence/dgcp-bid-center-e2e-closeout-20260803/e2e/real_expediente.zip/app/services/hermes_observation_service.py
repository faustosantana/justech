"""Servicio Bandeja Inteligente — observación Hermes WhatsApp/correo."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.business_company import BusinessCompany
from app.models.hermes_observed_event import HermesObservedEvent
from app.schemas.observation import ObservationIngestRequest, ObservationResponse
from app.schemas.tasks import TaskCreateRequest
from app.services.audit_service import AuditService
from app.core.exceptions import forbidden, not_found
from app.services.copilot_access_service import CopilotAccessService
from app.services.hermes_client import HermesClient
from app.services.hermes_commercial_intelligence_service import HermesCommercialIntelligenceService
from app.services.task_service import TaskService


class HermesObservationService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.client = HermesClient()
        self.audit = AuditService(db)

    async def _require_view(self) -> None:
        if not self.user_id:
            return
        access = CopilotAccessService(self.db, self.tenant_id, self.user_id)
        scopes = await access.extra_scopes()
        allowed = {"m365.read", "sales.read.own", "sales.read.team", "sales.read.all", "communications.read"}
        if not (scopes & allowed) and "system.help" not in scopes:
            raise forbidden("No tienes permisos para ver la bandeja inteligente.")

    def _to_response(self, row: HermesObservedEvent) -> ObservationResponse:
        return ObservationResponse(
            id=row.id,
            channel=row.channel,
            direction=row.direction,
            status=row.status,
            detected_type=row.detected_type,
            confidence=float(row.confidence or 0),
            summary=row.summary,
            source_ref=row.source_ref,
            source_meta=row.source_meta or {},
            customer=row.customer or {},
            products=row.products or [],
            suppliers_mentioned=row.suppliers_mentioned or [],
            recommended_actions=row.recommended_actions or [],
            analysis=row.analysis or {},
            draft_response=row.draft_response,
            draft_internal=row.draft_internal,
            raw_subject=row.raw_subject,
            raw_from=row.raw_from,
            raw_body_preview=row.raw_body_preview,
            received_at=row.received_at,
            reviewer_id=row.reviewer_id,
            reviewed_at=row.reviewed_at,
            converted_resource_type=row.converted_resource_type,
            converted_resource_id=row.converted_resource_id,
            commercial_brief=(row.analysis or {}).get("commercial_intelligence"),
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    async def ingest(self, payload: ObservationIngestRequest) -> ObservationResponse:
        if self.user_id:
            await self._require_view()
        if payload.source_ref:
            existing = await self.db.execute(
                select(HermesObservedEvent).where(
                    HermesObservedEvent.tenant_id == self.tenant_id,
                    HermesObservedEvent.source_ref == payload.source_ref,
                    HermesObservedEvent.channel == payload.channel,
                )
            )
            found = existing.scalar_one_or_none()
            if found:
                return self._to_response(found)

        analysis_data: dict = {}
        detected_type = "unknown"
        confidence = Decimal("0.2")
        summary = (payload.subject or payload.body or "")[:500]
        customer: dict = {"name": payload.from_name or "", "email": payload.from_address or "", "phone": ""}
        products: list = []
        suppliers: list = []
        actions: list = []
        draft_response = None
        draft_internal = None

        if payload.analyze and self.client.is_available():
            result = await self.client.analyze_observation(
                channel=payload.channel,
                direction=payload.direction,
                subject=payload.subject,
                body=payload.body,
                from_address=payload.from_address,
                from_name=payload.from_name,
                to_addresses=payload.to_addresses,
            )
            if result:
                analysis_data = result
                detected_type = result.get("detected_type", "unknown")
                confidence = Decimal(str(min(1.0, max(0.0, float(result.get("confidence", 0.2))))))
                summary = result.get("summary") or summary
                customer = result.get("customer") or customer
                products = result.get("products") or []
                suppliers = result.get("suppliers_mentioned") or []
                actions = result.get("recommended_actions") or []
                draft_response = result.get("draft_response")
                draft_internal = result.get("draft_internal")

        status = "pending_review" if detected_type in ("rfq_request", "supplier_mention") else "detected"

        row = HermesObservedEvent(
            tenant_id=self.tenant_id,
            channel=payload.channel,
            direction=payload.direction,
            status=status,
            detected_type=detected_type,
            confidence=confidence,
            summary=summary,
            source_ref=payload.source_ref,
            source_meta=payload.source_meta,
            customer=customer,
            products=products,
            suppliers_mentioned=suppliers,
            recommended_actions=actions,
            analysis=analysis_data,
            draft_response=draft_response,
            draft_internal=draft_internal,
            raw_subject=payload.subject,
            raw_from=payload.from_address or payload.from_name,
            raw_body_preview=(payload.body or "")[:2000],
            received_at=payload.received_at or datetime.now(timezone.utc),
        )
        self.db.add(row)
        await self.audit.log(
            action="hermes.observation.ingested",
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            resource_type="hermes_observation",
            resource_id=row.id,
            details={
                "channel": payload.channel,
                "detected_type": detected_type,
                "source_ref": payload.source_ref,
            },
        )
        await self.db.commit()
        await self.db.refresh(row)

        if payload.analyze and detected_type in ("rfq_request", "supplier_mention", "cotizacion"):
            try:
                intel = HermesCommercialIntelligenceService(self.db, self.tenant_id, self.user_id)
                await intel.enrich_event(row.id)
                await self.db.refresh(row)
            except Exception:
                import logging
                logging.getLogger(__name__).exception("Commercial intelligence enrich failed (non-blocking)")

        return self._to_response(row)

    async def list_events(
        self,
        *,
        status: str | None = None,
        channel: str | None = None,
        detected_type: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[list[ObservationResponse], int]:
        await self._require_view()
        q = select(HermesObservedEvent).where(HermesObservedEvent.tenant_id == self.tenant_id)
        if status:
            q = q.where(HermesObservedEvent.status == status)
        if channel:
            q = q.where(HermesObservedEvent.channel == channel)
        if detected_type:
            q = q.where(HermesObservedEvent.detected_type == detected_type)

        count_q = select(func.count()).select_from(q.subquery())
        total = (await self.db.execute(count_q)).scalar_one()

        q = q.order_by(desc(HermesObservedEvent.received_at), desc(HermesObservedEvent.created_at))
        q = q.offset(offset).limit(min(limit, 200))
        result = await self.db.execute(q)
        rows = result.scalars().all()
        return [self._to_response(r) for r in rows], total

    async def get(self, event_id: uuid.UUID) -> ObservationResponse | None:
        await self._require_view()
        row = await self.db.get(HermesObservedEvent, event_id)
        if not row or row.tenant_id != self.tenant_id:
            return None
        return self._to_response(row)

    async def execute_action(
        self,
        event_id: uuid.UUID,
        action: str,
        *,
        note: str | None = None,
    ) -> ObservationResponse:
        if not self.user_id:
            raise forbidden("Usuario requerido")

        row = await self.db.get(HermesObservedEvent, event_id)
        if not row or row.tenant_id != self.tenant_id:
            raise not_found("Evento no encontrado")

        now = datetime.now(timezone.utc)
        row.reviewer_id = self.user_id
        row.reviewed_at = now

        if action == "discard":
            row.status = "discarded"
        elif action == "validate":
            row.status = "validated"
        elif action == "mark_pending":
            row.status = "pending_review"
        elif action == "create_task":
            task_svc = TaskService(self.db, self.tenant_id, self.user_id)
            dept = "ventas" if row.detected_type == "rfq_request" else "compras"
            customer_name = (row.customer or {}).get("name") or row.raw_from
            task = await task_svc.create_task(
                TaskCreateRequest(
                    title=f"[Hermes] {row.summary[:120]}",
                    description=self._task_description(row, note),
                    category="cotizacion" if row.detected_type == "rfq_request" else "otro",
                    department=dept,
                    source=f"hermes_{row.channel}",
                    priority="alta" if row.detected_type == "rfq_request" else "media",
                    customer_name=customer_name,
                    related_email_id=row.source_ref if row.channel in ("email", "outlook") else None,
                    metadata={"hermes_observation_id": str(row.id), "channel": row.channel},
                    checklist=[
                        "Revisar productos detectados",
                        "Buscar precios en listas",
                        "Preparar borrador de cotización",
                    ],
                )
            )
            row.status = "converted_task"
            row.converted_resource_type = "task"
            row.converted_resource_id = str(task.id)
        elif action == "create_supplier":
            supplier_name = self._primary_supplier_name(row)
            if not supplier_name:
                from fastapi import HTTPException

                raise HTTPException(400, "No hay proveedor detectado en este mensaje")
            company = BusinessCompany(
                tenant_id=self.tenant_id,
                name=supplier_name,
                company_type="proveedor",
                status="activo",
                notes=(
                    f"Pendiente de validación — detectado por Hermes desde {row.channel}. "
                    f"Fuente: {row.source_ref or 'manual'}. {note or ''}"
                ).strip(),
                category=(row.products[0].get("category") if row.products else None),
                products_services=[
                    p.get("description", "")[:255] for p in (row.products or [])[:5] if p.get("description")
                ],
                tags=["hermes_observation", "pending_validation"],
            )
            self.db.add(company)
            await self.db.flush()
            row.status = "converted_supplier"
            row.converted_resource_type = "business_company"
            row.converted_resource_id = str(company.id)
        elif action == "create_draft":
            row.status = "converted_draft"
            row.converted_resource_type = "quote_draft"
            row.converted_resource_id = str(row.id)
        else:
            from fastapi import HTTPException

            raise HTTPException(400, f"Acción «{action}» no soportada")

        await self.audit.log(
            action="hermes.observation.action",
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            resource_type="hermes_observation",
            resource_id=row.id,
            details={"action": action, "status": row.status, "note": note},
        )
        await self.db.commit()
        await self.db.refresh(row)
        return self._to_response(row)

    @staticmethod
    def _primary_supplier_name(row: HermesObservedEvent) -> str | None:
        for s in row.suppliers_mentioned or []:
            if s.get("name"):
                return str(s["name"])[:255]
        return None

    @staticmethod
    def _task_description(row: HermesObservedEvent, note: str | None) -> str:
        lines = [row.summary, ""]
        if row.products:
            lines.append("Productos detectados:")
            for p in row.products[:10]:
                lines.append(f"- {p.get('description', p.get('name', ''))} x{p.get('quantity', '?')}")
        if row.draft_internal:
            lines.append(f"\nNota interna Hermes:\n{row.draft_internal}")
        if note:
            lines.append(f"\nNota revisor: {note}")
        return "\n".join(lines)

    async def ingest_from_m365_email(self, email_row) -> ObservationResponse | None:
        """Hook no destructivo — llamado tras procesar correo M365."""
        classification = (email_row.classification or "").lower()
        if classification not in ("cotizacion", "quote", "rfq", "solicitud_cotizacion", "commercial"):
            body = (email_row.body_text or email_row.body_preview or "").lower()
            if not any(w in body for w in ("cotiz", "precio", "presupuesto", "necesito", "laptop")):
                return None

        return await self.ingest(
            ObservationIngestRequest(
                channel="email",
                direction="inbound",
                subject=email_row.subject,
                body=email_row.body_text or email_row.body_preview or "",
                from_address=email_row.sender_email,
                from_name=email_row.sender_name,
                received_at=email_row.received_at,
                source_ref=f"m365:{email_row.id}",
                source_meta={
                    "mailbox": email_row.mailbox,
                    "external_message_id": email_row.external_message_id,
                    "m365_processed_email_id": str(email_row.id),
                },
                analyze=True,
            )
        )

    async def ingest_from_whatsapp(self, session, message, chat, payload: dict) -> ObservationResponse | None:
        """Hook no destructivo — mensaje entrante WhatsApp Web."""
        if payload.get("from_me") or message.from_me:
            return None
        body = (message.body or payload.get("body") or "").strip()
        if not body and not payload.get("media_type"):
            return None

        phone = (payload.get("remote_jid") or message.remote_jid or "").split("@")[0]
        ts_ms = payload.get("timestamp") or message.wa_timestamp_ms
        received_at = None
        if ts_ms:
            received_at = datetime.fromtimestamp(int(ts_ms) / 1000, tz=timezone.utc)

        return await self.ingest(
            ObservationIngestRequest(
                channel="whatsapp",
                direction="inbound",
                subject=chat.name or phone,
                body=body or f"[{payload.get('media_type') or 'media'}]",
                from_address=phone,
                from_name=chat.name or payload.get("push_name"),
                received_at=received_at,
                source_ref=f"whatsapp:{session.id}:{message.wa_message_id}",
                source_meta={
                    "provider": "whatsapp_web",
                    "session_id": str(session.id),
                    "bridge_session_id": session.bridge_session_id,
                    "chat_id": str(chat.id),
                    "remote_jid": message.remote_jid,
                    "wa_message_id": message.wa_message_id,
                    "media_type": payload.get("media_type"),
                },
                analyze=True,
            )
        )
