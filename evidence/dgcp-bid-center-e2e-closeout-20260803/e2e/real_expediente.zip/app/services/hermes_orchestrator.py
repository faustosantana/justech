"""Orquestador Hermes — JAIOS envía, Hermes analiza, JAIOS decide qué guardar."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.hermes import HermesAnalysisResult, HermesEmailRfqContext, HermesTenderContext
from app.services.audit_service import AuditService
from app.services.commercial_memory_service import CommercialMemoryService
from app.services.hermes_client import HermesClient


class HermesOrchestrator:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
        client: HermesClient | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.client = client or HermesClient()
        self.audit = AuditService(db)

    async def analyze_tender_for_opportunity(
        self,
        opp: DGCPOpportunity,
        *,
        bid_package: DGCPBidPackage | None = None,
        module: str = "dgcp",
    ) -> HermesAnalysisResult | None:
        requirements: list[dict[str, Any]] = []
        documents_text = ""
        if bid_package and isinstance(bid_package.requirements, dict):
            for section in ("technical", "mandatory_documents", "legal", "financial"):
                for item in bid_package.requirements.get(section) or []:
                    if isinstance(item, dict):
                        requirements.append(item)
                        if item.get("matched_text"):
                            documents_text += " " + str(item["matched_text"])

        ctx = HermesTenderContext(
            process_code=opp.code,
            title=opp.title,
            institution=opp.institution,
            description=opp.description,
            objeto_proceso=opp.objeto_proceso,
            amount=str(opp.amount),
            deadline=opp.deadline.isoformat() if opp.deadline else None,
            documents_text=documents_text[:20_000] or None,
            requirements=requirements,
        )
        result = await self.client.analyze_tender(**ctx.model_dump())
        await self._audit(
            action="hermes.analyze.tender",
            module=module,
            resource_type="dgcp_opportunity",
            resource_id=opp.id,
            analysis_type="tender",
            source="hermes-service",
            result=result,
            extra={"process_code": opp.code},
        )
        return result

    async def analyze_quotation_email(
        self,
        ctx: HermesEmailRfqContext,
        *,
        module: str = "m365",
        resource_id: uuid.UUID | None = None,
    ) -> HermesAnalysisResult | None:
        result = await self.client.analyze_email_rfq(**ctx.model_dump())
        if result:
            memory = await CommercialMemoryService(self.db, self.tenant_id).query(
                ctx.subject or ctx.body[:200], limit=5
            )
            for hit in memory.get("results") or []:
                result.items_detected.append(
                    {
                        "name": hit.get("description") or hit.get("reference"),
                        "quantity": hit.get("amount"),
                        "notes": f"histórico {hit.get('type')} — {hit.get('client')}",
                    }
                )
            if memory.get("has_history") and not any("similar" in a.lower() for a in result.next_actions):
                result.next_actions.insert(0, "Revisar venta o licitación similar en memoria comercial")
        await self._audit(
            action="hermes.analyze.email_rfq",
            module=module,
            resource_type="email",
            resource_id=resource_id,
            analysis_type="email_rfq",
            source="hermes-service",
            result=result,
        )
        return result

    async def search_knowledge(
        self,
        query: str,
        *,
        hits: list[dict[str, Any]] | None = None,
        module: str = "repositorio",
    ) -> HermesAnalysisResult | None:
        result = await self.client.search_knowledge(
            query=query,
            hits=hits or [],
            limit=10,
        )
        await self._audit(
            action="hermes.search.knowledge",
            module=module,
            resource_type="knowledge_query",
            resource_id=None,
            analysis_type="knowledge",
            source="hermes-service",
            result=result,
            extra={"query": query[:200]},
        )
        return result

    async def analyze_form(
        self,
        *,
        form_type: str,
        fields: list[dict[str, Any]],
        company_profile: dict[str, Any] | None = None,
        resource_id: uuid.UUID | None = None,
    ) -> HermesAnalysisResult | None:
        result = await self.client.analyze_form(
            form_type=form_type,
            fields=fields,
            company_profile=company_profile or {},
        )
        await self._audit(
            action="hermes.analyze.form",
            module="dgcp",
            resource_type="dgcp_form",
            resource_id=resource_id,
            analysis_type="form",
            source="hermes-service",
            result=result,
            extra={"form_type": form_type},
        )
        return result

    async def health(self) -> dict[str, Any]:
        return (await self.client.health()) or {"status": "unavailable"}

    async def _audit(
        self,
        *,
        action: str,
        module: str,
        resource_type: str | None,
        resource_id: uuid.UUID | None,
        analysis_type: str,
        source: str,
        result: HermesAnalysisResult | None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        details: dict[str, Any] = {
            "module": module,
            "analysis_type": analysis_type,
            "source": source,
            "hermes_enabled": self.client.is_available(),
            "analyzed_at": datetime.now(UTC).isoformat(),
            **(extra or {}),
        }
        if result:
            details["confidence"] = result.confidence
            details["detected_type"] = result.detected_type
            details["recommendation"] = result.recommendation
            details["summary_preview"] = result.summary[:500]
        await self.audit.log(
            action=action,
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details,
        )
