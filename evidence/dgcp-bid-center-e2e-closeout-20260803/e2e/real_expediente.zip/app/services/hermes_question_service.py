"""Hermes — interpretación de preguntas contextuales con datos de JAIOS."""

from __future__ import annotations

import logging
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.assistant import AssistantLink, AssistantQueryRequest, AssistantQueryResponse
from app.services.commercial_memory_service import CommercialMemoryService
from app.services.dgcp_historical_similarity_engine import core_query_tokens, display_keywords
from app.services.hermes_client import HermesClient
from app.services.odoo_detail_service import OdooDetailService
from app.services.odoo_service import OdooService
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters

logger = logging.getLogger(__name__)


class HermesQuestionService:
    DEICTIC_SIGNALS = (
        "este ", "esta ", "estos ", "estas ", "aquí", "aqui", "actual",
        "de este", "de esta", "este equipo", "este producto", "del proceso",
    )
    ANALYTICS_SIGNALS = (
        "precio", "promedio", "vend", "margen", "historial", "cuánto", "cuanto",
        "costo", "cotiz", "adjudic", "similar", "recomend", "barato", "caro",
    )

    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID | None = None,
        *,
        hermes: HermesClient | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.hermes = hermes or HermesClient()
        self.odoo = OdooService(db, tenant_id, user_id=user_id)
        self.odoo_detail = OdooDetailService(self.odoo)

    @classmethod
    def should_handle(cls, question: str, payload: AssistantQueryRequest) -> bool:
        if not settings.hermes_enabled:
            return False
        if not payload.current_record_id or not payload.record_type:
            return False
        lowered = question.lower()
        deictic = any(s in lowered for s in cls.DEICTIC_SIGNALS)
        analytics = any(s in lowered for s in cls.ANALYTICS_SIGNALS)
        if payload.record_type in ("dgcp", "dgcp_opportunity"):
            return deictic or analytics
        if payload.record_type == "product":
            return deictic or analytics
        return deictic and analytics

    async def try_answer(
        self,
        question: str,
        payload: AssistantQueryRequest,
        source_labels: list[str],
        *,
        conv=None,
    ) -> AssistantQueryResponse | None:
        if not self.should_handle(question, payload):
            return None

        context_entity = await self._resolve_context(payload)
        if not context_entity:
            return None

        facts = await self._gather_facts(question, context_entity)
        if not facts and not context_entity.get("title"):
            return None

        hermes_result = await self.hermes.interpret_question(
            question=question,
            context=context_entity,
            facts=facts,
        )
        if hermes_result is None:
            return self._local_fallback(question, context_entity, facts, source_labels, payload)

        links = self._build_links(context_entity, facts, payload)
        return AssistantQueryResponse(
            question=question,
            answer=hermes_result.summary,
            sources=list(dict.fromkeys(["hermes"] + source_labels)),
            query_type="hermes_question",
            links=links,
            data={
                "facts": facts,
                "context": context_entity,
                "confidence": hermes_result.confidence,
                "metadata": hermes_result.metadata,
            },
        )

    async def _resolve_context(self, payload: AssistantQueryRequest) -> dict | None:
        rt = payload.record_type
        rid = payload.current_record_id
        if not rt or not rid:
            return None

        if rt in ("dgcp", "dgcp_opportunity"):
            try:
                opp_id = uuid.UUID(rid)
            except ValueError:
                return None
            opp = (
                await self.db.execute(
                    select(DGCPOpportunity).where(
                        DGCPOpportunity.id == opp_id,
                        DGCPOpportunity.tenant_id == self.tenant_id,
                    )
                )
            ).scalar_one_or_none()
            if not opp:
                return None
            tokens = core_query_tokens(opp.title, opp.description, opp.objeto_proceso)
            keywords = display_keywords(tokens)
            intel = opp.jaios_intelligence if isinstance(opp.jaios_intelligence, dict) else {}
            return {
                "record_type": rt,
                "record_id": rid,
                "title": opp.title,
                "code": opp.code,
                "institution": opp.institution,
                "amount": str(opp.amount),
                "currency": opp.currency,
                "search_terms": keywords,
                "product_query": " ".join(keywords[:3]) if keywords else opp.title[:80],
                "dgcp": {
                    "score": intel.get("premium_score"),
                    "executive_summary": intel.get("executive_summary"),
                    "recommendation": intel.get("recommendation"),
                    "stage": intel.get("stage"),
                },
            }

        if rt == "product":
            try:
                product_id = int(rid)
            except ValueError:
                return None
            try:
                detail = await self.odoo_detail.get_product_detail(product_id)
            except Exception:
                logger.exception("Hermes product context failed id=%s", rid)
                return None
            return {
                "record_type": rt,
                "record_id": rid,
                "product_name": detail.name,
                "product_code": detail.default_code,
                "search_terms": [detail.name] if detail.name else [],
                "product_query": detail.name,
                "odoo_snapshot": {
                    "last_price": str(detail.last_price) if detail.last_price else None,
                    "average_price": str(detail.average_price) if detail.average_price else None,
                    "min_price": str(detail.min_price) if detail.min_price else None,
                    "max_price": str(detail.max_price) if detail.max_price else None,
                    "standard_price": str(detail.standard_price) if detail.standard_price else None,
                },
            }

        return {"record_type": rt, "record_id": rid}

    async def _gather_facts(self, question: str, context: dict) -> dict:
        facts: dict = {}
        search_query = context.get("product_query") or " ".join(context.get("search_terms") or [])
        if not search_query and context.get("title"):
            search_query = context["title"][:120]

        odoo_health = await self.odoo.health()
        if odoo_health.connected:
            product_names = list(dict.fromkeys(
                [context.get("product_name"), search_query]
                + (context.get("search_terms") or [])[:4]
            ))
            product_names = [n for n in product_names if n]
            for name in product_names:
                result = await self.odoo.last_price(product_name=name)
                if result.sales_count:
                    facts["odoo_sales"] = result.model_dump(mode="json")
                    facts["odoo_sales"]["matched_query"] = name
                    break
            if "odoo_sales" not in facts and context.get("odoo_snapshot"):
                facts["odoo_sales"] = {**context["odoo_snapshot"], "sales_count": 0, "source": "product_detail"}

        if search_query:
            price_svc = PriceIntelligenceService(self.db, self.tenant_id)
            search = await price_svc.search(PriceSearchFilters(q=search_query, limit=8))
            if search.items:
                facts["price_lists"] = [
                    {
                        "description": (p.description or "")[:120],
                        "price": str(p.preferred_price or p.price or ""),
                        "currency": p.currency,
                        "supplier": p.supplier,
                        "sku": p.sku,
                    }
                    for p in search.items[:6]
                ]

            memory = await CommercialMemoryService(self.db, self.tenant_id).query(search_query, limit=6)
            if memory.get("results"):
                facts["commercial_memory"] = memory

        if context.get("dgcp"):
            facts["dgcp"] = context["dgcp"]

        return facts

    def _build_links(
        self,
        context: dict,
        facts: dict,
        payload: AssistantQueryRequest,
    ) -> list[AssistantLink]:
        links: list[AssistantLink] = []
        if payload.record_type in ("dgcp", "dgcp_opportunity") and payload.current_record_id:
            code = context.get("code") or "Licitación"
            links.append(
                AssistantLink(
                    label=code,
                    url=f"/dgcp/{payload.current_record_id}",
                    type="dgcp",
                )
            )
        elif payload.record_type == "product" and payload.current_record_id:
            name = context.get("product_name") or "Producto"
            links.append(
                AssistantLink(
                    label=name,
                    url=f"/odoo/products/{payload.current_record_id}",
                    type="product",
                )
            )
        odoo = facts.get("odoo_sales") or {}
        if odoo.get("partner_name"):
            links.append(AssistantLink(label=odoo["partner_name"], url="/odoo", type="customer"))
        return links

    def _local_fallback(
        self,
        question: str,
        context: dict,
        facts: dict,
        source_labels: list[str],
        payload: AssistantQueryRequest,
    ) -> AssistantQueryResponse | None:
        parts: list[str] = []
        odoo = facts.get("odoo_sales") or {}
        avg = odoo.get("average_price")
        if avg is not None:
            try:
                avg_f = float(avg)
                count = odoo.get("sales_count", 0)
                product = odoo.get("product_name") or context.get("product_name") or "el producto"
                parts.append(
                    f"Precio promedio de venta de {product}: {avg_f:,.2f} "
                    f"({count} venta(s) en Odoo)."
                )
            except (TypeError, ValueError):
                pass
        elif odoo.get("sales_count") == 0:
            product = context.get("product_name") or context.get("product_query") or "este equipo"
            parts.append(f"No hay ventas previas de {product} en Odoo.")

        price_lists = facts.get("price_lists") or []
        if price_lists:
            top = price_lists[0]
            if top.get("price"):
                parts.append(
                    f"En listas de proveedor: desde {top['price']} {top.get('currency', 'DOP')} "
                    f"({top.get('supplier', 'N/A')})."
                )

        if not parts:
            return None

        return AssistantQueryResponse(
            question=question,
            answer=" ".join(parts),
            sources=list(dict.fromkeys(["hermes", "odoo", "price_intelligence"] + source_labels)),
            query_type="hermes_question_fallback",
            links=self._build_links(context, facts, payload),
            data={"facts": facts, "context": context},
        )
