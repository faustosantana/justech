"""Hermes Retrieval — capa local de recuperación + análisis Hermes Service."""

from __future__ import annotations

import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.schemas.search import KnowledgeEngineResponse
from app.services.hermes_orchestrator import HermesOrchestrator
from app.services.knowledge_engine_service import KnowledgeEngineService


class HermesRetrievalService:
    """Recuperación documental + búsqueda empresarial (Hermes / índice JAIOS)."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.knowledge = KnowledgeEngineService(db, tenant_id, user_id)

    async def search(self, query: str, *, limit: int = 8) -> KnowledgeEngineResponse:
        engine_result = await self.knowledge.search_global(
            query,
            limit_per_group=limit,
            channel="assistant_hermes",
        )
        if settings.hermes_enabled:
            hits: list[dict] = []
            for group in engine_result.groups:
                for item in group.items[:3]:
                    hits.append(
                        {
                            "title": item.title,
                            "description": item.description or item.subtitle,
                            "reference": item.id,
                            "type": group.type,
                            "source": item.source,
                        }
                    )
            await HermesOrchestrator(self.db, self.tenant_id, user_id=self.user_id).search_knowledge(
                query, hits=hits[: limit * 2], module="assistant"
            )
        return engine_result
