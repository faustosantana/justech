"""Registro unificado: integraciones built-in + conectores dinámicos."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.services.dynamic_connector_service import DynamicConnectorService
from app.services.hermes_ai_config_service import HermesAIConfigService
from app.services.integration_settings_service import IntegrationSettingsService, PROVIDER_CATALOG


def _is_uuid(value: str) -> bool:
    try:
        uuid.UUID(value)
        return True
    except ValueError:
        return False


BUILTIN_CONFIG_URLS: dict[str, str] = {
    "microsoft365": "/configuracion/integraciones/microsoft365",
    "outlook": "/configuracion/integraciones/microsoft365",
    "teams": "/configuracion/integraciones/microsoft365",
    "onedrive": "/configuracion/integraciones/microsoft365",
    "sharepoint": "/configuracion/integraciones/microsoft365",
    "odoo": "/configuracion/integraciones/odoo",
    "dgcp": "/configuracion/integraciones/dgcp",
    "whatsapp_web": "/configuracion/integraciones/whatsapp",
    "whatsapp_cloud": "/configuracion/integraciones/whatsapp",
    "openai": "/configuracion/integraciones/openai",
    "anthropic": "/configuracion/integraciones/anthropic",
    "deepseek": "/configuracion/integraciones/deepseek",
    "hermes": "/configuracion/integraciones/hermes",
    "n8n": "/configuracion/integraciones/n8n",
    "qdrant": "/configuracion/integraciones/qdrant",
    "smtp": "/configuracion/integraciones/smtp",
    "ingram": "/configuracion/integraciones/proveedores/ingram",
    "omega": "/configuracion/integraciones/proveedores/omega",
    "intcomex": "/configuracion/integraciones/proveedores/intcomex",
    "tecnomarket": "/configuracion/integraciones/proveedores/tecnomarket",
    "cecomsa": "/configuracion/integraciones/proveedores/cecomsa",
    "tecnosinergia": "/configuracion/integraciones/proveedores/tecnosinergia",
}

BUILTIN_DOCUMENTATION: dict[str, str] = {
    "hermes": "Motor IA interno del Copiloto. Variables: HERMES_ENABLED, HERMES_SERVICE_URL, HERMES_API_TOKEN, HERMES_MODEL.",
    "openai": "Requiere OPENAI_API_KEY. Opcional: base URL y modelo (p. ej. gpt-4o).",
    "anthropic": "Requiere ANTHROPIC_API_KEY y modelo opcional (claude-3-5-sonnet).",
    "deepseek": "DeepSeek / Huawei Cloud. Requiere API Key, base URL y modelo.",
    "whatsapp_cloud": "Meta WhatsApp Cloud API: Phone Number ID, Access Token, Verify Token y webhook.",
    "odoo": "URL, base de datos, usuario API y API Key / contraseña.",
    "dgcp": "Fuente pública DGCP. Opcional API Key si aplica en su despliegue.",
    "n8n": "URL del webhook n8n y API Key opcional.",
    "qdrant": "Host, puerto y API Key opcional del vector store.",
    "smtp": "Servidor SMTP, puerto, credenciales y remitente.",
    "microsoft365": "Azure AD: Tenant ID, Client ID, Client Secret y Redirect URI.",
}

DIAGNOSTIC_SLUGS: tuple[str, ...] = (
    "hermes",
    "openai",
    "anthropic",
    "deepseek",
    "qdrant",
    "odoo",
    "dgcp",
    "whatsapp_cloud",
    "whatsapp_web",
    "n8n",
    "smtp",
    "microsoft365",
    "outlook",
    "teams",
    "onedrive",
    "sharepoint",
    "ingram",
    "omega",
    "intcomex",
    "cecomsa",
    "tecnosinergia",
    "tecnomarket",
)


class IntegrationRegistryService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, actor_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.actor_id = actor_id
        self.settings_svc = IntegrationSettingsService(db, tenant_id, actor_id)
        self.dynamic_svc = DynamicConnectorService(db, tenant_id, actor_id)

    @staticmethod
    def environment() -> str:
        return settings.app_env or "development"

    async def list_all(self) -> dict:
        builtin_raw = await self.settings_svc.list_integrations()
        builtin_items = []
        for item in builtin_raw["items"]:
            provider = item["provider"]
            meta = PROVIDER_CATALOG.get(provider, {})
            model = self._model_for_provider(provider)
            builtin_items.append({
                "id": provider,
                "slug": provider,
                "name": item["label"],
                "connector_type": meta.get("category", item.get("category", "other")),
                "auth_method": "builtin",
                "base_url": None,
                "is_active": True,
                "is_builtin": True,
                "is_dynamic": False,
                "connected": item["connected"],
                "status": item.get("status", "not_configured"),
                "read_only": item.get("read_only"),
                "environment": item["environment"],
                "user_link_mode": "per_user" if provider in ("microsoft365", "odoo", "whatsapp_web") else "none",
                "last_test_at": item.get("last_test_at"),
                "last_test_ok": item.get("last_test_ok"),
                "last_test_message": item.get("last_test_message"),
                "endpoint_count": 0,
                "user_link_count": 0,
                "config_url": BUILTIN_CONFIG_URLS.get(provider, "/configuracion/integraciones"),
                "documentation": BUILTIN_DOCUMENTATION.get(provider),
                "model": model,
                "latency_ms": None,
            })

        dynamic_items = await self.dynamic_svc.list_providers()
        for d in dynamic_items:
            d["config_url"] = f"/configuracion/apis/{d['id']}"

        return {
            "environment": self.environment(),
            "builtin_items": builtin_items,
            "dynamic_items": dynamic_items,
            "items": builtin_items + dynamic_items,
        }

    @staticmethod
    def _model_for_provider(provider: str) -> str | None:
        mapping = {
            "hermes": HermesAIConfigService.model(),
            "openai": settings.openai_default_model,
            "anthropic": settings.anthropic_default_model,
            "deepseek": settings.deepseek_huawei_default_model,
        }
        return mapping.get(provider) or None

    async def diagnostic(self) -> dict:
        listed = await self.list_all()
        by_slug = {i["slug"]: i for i in listed["items"]}
        rows = []
        for slug in DIAGNOSTIC_SLUGS:
            item = by_slug.get(slug)
            if not item:
                continue
            configured = item["status"] != "not_configured"
            last_error = None
            if item.get("last_test_ok") is False:
                last_error = item.get("last_test_message")
            rows.append({
                "slug": slug,
                "name": item["name"],
                "configured": configured,
                "connected": item.get("connected", False),
                "status": item.get("status", "not_configured"),
                "last_test_at": item.get("last_test_at"),
                "last_test_ok": item.get("last_test_ok"),
                "latency_ms": item.get("latency_ms"),
                "last_error": last_error,
                "model": item.get("model"),
                "config_url": item.get("config_url"),
            })
        return {
            "environment": self.environment(),
            "checked_at": datetime.now(timezone.utc),
            "items": rows,
        }

    async def test_all(self) -> dict:
        results = []
        for slug in DIAGNOSTIC_SLUGS:
            try:
                data = await self.settings_svc.test_integration(slug)
                results.append({
                    "slug": slug,
                    "name": PROVIDER_CATALOG.get(slug, {}).get("label", slug),
                    **data,
                })
            except Exception as exc:
                results.append({
                    "slug": slug,
                    "name": PROVIDER_CATALOG.get(slug, {}).get("label", slug),
                    "ok": False,
                    "success": False,
                    "message": str(exc),
                    "error": str(exc),
                    "missing_config": [],
                    "latency_ms": None,
                    "details": {},
                })
        ok_count = sum(1 for r in results if r.get("ok"))
        return {
            "environment": self.environment(),
            "tested_at": datetime.now(timezone.utc),
            "total": len(results),
            "passed": ok_count,
            "failed": len(results) - ok_count,
            "results": results,
        }

    def is_dynamic_id(self, ref: str) -> bool:
        return _is_uuid(ref)

    async def resolve_builtin(self, provider: str) -> dict:
        detail = await self.settings_svc.get_integration(provider)
        detail["id"] = provider
        detail["is_dynamic"] = False
        detail["config_url"] = BUILTIN_CONFIG_URLS.get(provider, "/configuracion/integraciones")
        return detail
