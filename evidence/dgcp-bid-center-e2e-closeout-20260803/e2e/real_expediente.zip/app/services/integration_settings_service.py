"""Centro de configuración — integraciones por tenant con vault cifrado."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.integration_settings import TenantIntegrationSetting
from app.services.audit_service import AuditService
from app.services.credential_vault import decrypt_secret, encrypt_secret, mask_secret

PROVIDER_CATALOG: dict[str, dict[str, Any]] = {
    "microsoft365": {"label": "Microsoft 365", "category": "productivity"},
    "outlook": {"label": "Outlook", "category": "productivity", "parent": "microsoft365"},
    "teams": {"label": "Microsoft Teams", "category": "productivity", "parent": "microsoft365"},
    "onedrive": {"label": "OneDrive", "category": "productivity", "parent": "microsoft365"},
    "sharepoint": {"label": "SharePoint", "category": "productivity", "parent": "microsoft365"},
    "whatsapp_web": {"label": "WhatsApp Web", "category": "messaging"},
    "whatsapp_cloud": {"label": "WhatsApp Cloud API", "category": "messaging"},
    "odoo": {"label": "Odoo ERP", "category": "erp"},
    "dgcp": {"label": "DGCP Licitaciones", "category": "procurement"},
  "ingram": {"label": "Ingram Micro", "category": "suppliers"},
    "omega": {"label": "Omega Tech", "category": "suppliers"},
    "intcomex": {"label": "Intcomex", "category": "suppliers"},
    "tecnomarket": {"label": "Tecnomarket", "category": "suppliers"},
    "cecomsa": {"label": "Cecomsa", "category": "suppliers"},
    "tecnosinergia": {"label": "Tecnosinergia", "category": "suppliers"},
    "openai": {"label": "OpenAI", "category": "llm"},
    "anthropic": {"label": "Anthropic", "category": "llm"},
    "deepseek": {"label": "DeepSeek / Huawei", "category": "llm"},
    "hermes": {"label": "Hermes AI", "category": "llm"},
    "n8n": {"label": "n8n Automations", "category": "automation"},
    "qdrant": {"label": "Qdrant Vector DB", "category": "data"},
    "postgresql": {"label": "PostgreSQL", "category": "data"},
    "smtp": {"label": "SMTP Email", "category": "messaging"},
    "webhooks": {"label": "Webhooks externos", "category": "automation"},
}

ENV_FIELD_MAP: dict[str, list[tuple[str, str, str, bool]]] = {
    # provider -> [(key, env_attr, label, is_secret)]
    "microsoft365": [
        ("tenant_id", "m365_tenant_id", "Tenant ID (Azure)", False),
        ("client_id", "m365_client_id", "Client ID", False),
        ("client_secret", "m365_client_secret", "Client Secret", True),
        ("redirect_uri", "m365_redirect_uri", "Redirect URI", False),
        ("webhook_url", "m365_webhook_url", "Webhook URL", False),
        ("webhook_client_state", "m365_webhook_client_state", "Webhook Client State", True),
        ("read_only", "m365_read_only", "Solo lectura", False),
    ],
    "odoo": [
        ("url", "odoo_url", "Odoo URL", False),
        ("database", "odoo_db", "Base de datos", False),
        ("username", "odoo_username", "Usuario API", False),
        ("api_key", "odoo_api_key", "API Key / Password", True),
        ("company_id", "", "Company ID (opcional)", False),
        ("read_only", "odoo_read_only", "Modo solo lectura", False),
    ],
    "dgcp": [
        ("base_url", "dgcp_api_base_url", "API Endpoint", False),
        ("api_key", "dgcp_api_key", "API Key", True),
        ("sync_max_pages", "dgcp_sync_default_max_pages", "Páginas por sync", False),
    ],
    "openai": [
        ("api_key", "openai_api_key", "API Key", True),
        ("base_url", "openai_base_url", "Base URL", False),
        ("default_model", "openai_default_model", "Modelo", False),
    ],
    "anthropic": [
        ("api_key", "anthropic_api_key", "API Key", True),
        ("default_model", "anthropic_default_model", "Modelo", False),
    ],
    "deepseek": [
        ("api_key", "deepseek_huawei_api_key", "API Key", True),
        ("base_url", "deepseek_huawei_base_url", "Base URL", False),
        ("default_model", "deepseek_huawei_default_model", "Modelo", False),
    ],
    "hermes": [
        ("enabled", "hermes_enabled", "Habilitado", False),
        ("service_url", "hermes_service_url", "URL servicio interno", False),
        ("api_token", "hermes_api_token", "API Token", True),
        ("model", "hermes_model", "Modelo", False),
        ("system_prompt", "", "System Prompt (Copiloto)", False),
    ],
    "n8n": [
        ("url", "n8n_webhook_url", "n8n URL", False),
        ("api_key", "n8n_api_key", "API Key", True),
    ],
    "qdrant": [
        ("host", "qdrant_host", "Host", False),
        ("port", "qdrant_port", "Puerto", False),
        ("api_key", "qdrant_api_key", "API Key", True),
    ],
    "postgresql": [
        ("database_url", "database_url", "Connection URL", True),
    ],
    "whatsapp_cloud": [
        ("app_id", "", "Meta App ID", False),
        ("phone_number_id", "", "Phone Number ID", False),
        ("access_token", "", "Access Token", True),
        ("verify_token", "", "Verify Token", True),
        ("webhook_url", "", "Webhook URL", False),
    ],
    "smtp": [
        ("host", "smtp_host", "Servidor SMTP", False),
        ("port", "smtp_port", "Puerto", False),
        ("username", "smtp_username", "Usuario SMTP", False),
        ("password", "smtp_password", "Contraseña SMTP", True),
        ("from_email", "smtp_from_email", "Email remitente", False),
        ("use_tls", "smtp_use_tls", "Usar TLS", False),
    ],
    "ingram": [
        ("enabled", "ingram_enabled", "Habilitado", False),
        ("demo_mode", "ingram_demo_mode", "Modo demo (sin credenciales)", False),
        ("use_sandbox", "ingram_use_sandbox", "Sandbox API", False),
        ("api_base_url", "ingram_api_base_url", "API Base URL", False),
        ("portal_url", "ingram_portal_url", "Portal URL (CEP: mi.ingrammicro.com/cep/app)", False),
        ("client_id", "ingram_client_id", "Client ID (Xvantage API)", False),
        ("client_secret", "ingram_client_secret", "Client Secret", True),
        ("customer_number", "ingram_customer_number", "IM-CustomerNumber", False),
        ("country_code", "ingram_country_code", "IM-CountryCode", False),
        ("username", "ingram_username", "Usuario portal (fallback scraper)", False),
        ("password", "ingram_password", "Contraseña portal", True),
    ],
    "omega": [
        ("enabled", "omega_enabled", "Habilitado", False),
        ("demo_mode", "omega_demo_mode", "Modo demo", False),
        ("store_url", "omega_store_url", "URL portal (vip.omega.com.do)", False),
        ("locale", "omega_locale", "Idioma/ruta tienda legacy (es)", False),
        ("currency", "omega_currency", "Moneda (USD/DOP)", False),
        ("username", "omega_username", "Usuario portal VIP", False),
        ("password", "omega_password", "Contraseña portal VIP", True),
    ],
    "intcomex": [
        ("enabled", "", "Habilitado", False),
        ("username", "", "Usuario", False),
        ("password", "", "Contraseña", True),
        ("api_key", "", "API Key", True),
    ],
    "tecnomarket": [
        ("enabled", "", "Habilitado", False),
        ("username", "", "Usuario", False),
        ("password", "", "Contraseña", True),
        ("api_key", "", "API Key", True),
    ],
    "cecomsa": [
        ("enabled", "", "Habilitado", False),
        ("username", "", "Usuario", False),
        ("password", "", "Contraseña", True),
        ("api_key", "", "API Key", True),
    ],
    "tecnosinergia": [
        ("enabled", "", "Habilitado", False),
        ("username", "", "Usuario", False),
        ("password", "", "Contraseña", True),
        ("api_key", "", "API Key", True),
    ],
}


def _parse_bool(val: Any) -> bool:
    if isinstance(val, bool):
        return val
    if val in (None, ""):
        return False
    return str(val).lower() in ("1", "true", "yes", "on")


def _connection_status(
    *,
    creds_ok: bool,
    connected: bool,
    last_test_ok: bool | None,
    read_only: bool | None = None,
) -> str:
    if not creds_ok:
        return "not_configured"
    if last_test_ok is False:
        return "credential_error"
    if connected:
        if read_only is True:
            return "read_only"
        if read_only is False:
            return "read_write"
        return "connected"
    return "configured"


class IntegrationSettingsService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, actor_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.actor_id = actor_id

    @staticmethod
    def environment() -> str:
        return settings.app_env or "development"

    async def _row(self, provider: str) -> TenantIntegrationSetting | None:
        result = await self.db.execute(
            select(TenantIntegrationSetting).where(
                TenantIntegrationSetting.tenant_id == self.tenant_id,
                TenantIntegrationSetting.provider == provider,
            )
        )
        return result.scalar_one_or_none()

    def _env_value(self, attr: str) -> Any:
        if not attr:
            return ""
        return getattr(settings, attr, "")

    def _resolve_fields(self, provider: str, row: TenantIntegrationSetting | None) -> tuple[dict, dict, str]:
        cfg = dict(row.config) if row else {}
        secrets = dict(row.secrets_encrypted) if row else {}
        source = "database" if row else "env"
        for key, env_attr, _label, is_secret in ENV_FIELD_MAP.get(provider, []):
            if key in cfg or key in secrets:
                continue
            env_val = self._env_value(env_attr)
            if env_val in ("", None):
                continue
            if is_secret:
                secrets[key] = encrypt_secret(str(env_val))
            else:
                cfg[key] = env_val
            if row is None:
                source = "env"
        return cfg, secrets, source

    def _field_list(self, provider: str, cfg: dict, secrets: dict) -> list[dict]:
        fields = []
        for key, _env_attr, label, is_secret in ENV_FIELD_MAP.get(provider, []):
            if is_secret:
                enc = secrets.get(key)
                plain = ""
                if enc:
                    try:
                        plain = decrypt_secret(enc)
                    except ValueError:
                        plain = ""
                fields.append({
                    "key": key,
                    "label": label,
                    "value": None,
                    "masked": mask_secret(plain) if plain else None,
                    "secret": True,
                    "configured": bool(plain),
                    "field_type": "secret",
                })
            else:
                val = cfg.get(key)
                if key in ("read_only", "use_tls"):
                    if val is None and _env_attr:
                        val = getattr(settings, _env_attr, False)
                    bool_val = _parse_bool(val)
                    fields.append({
                        "key": key,
                        "label": label,
                        "value": bool_val,
                        "masked": None,
                        "secret": False,
                        "configured": True,
                        "field_type": "boolean",
                    })
                else:
                    field_type = "textarea" if key == "system_prompt" else "text"
                    fields.append({
                        "key": key,
                        "label": label,
                        "value": val,
                        "masked": None,
                        "secret": False,
                        "configured": val not in (None, "", False) if val is not False else True,
                        "field_type": field_type,
                    })
        return fields

    def _credentials_ok(self, provider: str, cfg: dict, secrets: dict) -> bool:
        fields = self._field_list(provider, cfg, secrets)
        required = [f for f in fields if f["label"] and f["key"] not in ("read_only", "sync_max_pages")]
        if not required:
            return False
        optional_keys = {
            "redirect_uri",
            "webhook_url",
            "webhook_client_state",
            "base_url",
            "default_model",
            "system_prompt",
            "model",
            "enabled",
            "service_url",
        }
        secret_keys = {f["key"] for f in fields if f["secret"]}
        for f in required:
            if f["key"] in optional_keys:
                continue
            if f["key"] in secret_keys:
                if not f["configured"]:
                    return False
                continue
            if not f.get("configured"):
                if provider == "microsoft365" and f["key"] in ("tenant_id", "client_id"):
                    return False
                if provider == "odoo" and f["key"] in ("url", "database", "username"):
                    return False
        if provider == "hermes":
            enabled = _parse_bool(cfg.get("enabled")) if "enabled" in cfg else settings.hermes_enabled
            url = cfg.get("service_url") or settings.hermes_service_url
            return bool(enabled and url)
        return True

    async def list_integrations(self) -> dict:
        items = []
        for provider, meta in PROVIDER_CATALOG.items():
            if meta.get("parent"):
                continue
            detail = await self.get_integration(provider)
            items.append({
                "provider": provider,
                "label": meta["label"],
                "category": meta["category"],
                "connected": detail["connected"],
                "credentials_configured": detail["credentials_configured"],
                "status": detail.get("status", "not_configured"),
                "read_only": detail.get("read_only"),
                "last_test_at": detail.get("last_test_at"),
                "last_test_ok": detail.get("last_test_ok"),
                "last_test_message": detail.get("last_test_message"),
                "environment": self.environment(),
                "source": detail["source"],
                "recent_logs": detail.get("recent_logs", []),
            })
        for provider, meta in PROVIDER_CATALOG.items():
            if not meta.get("parent"):
                continue
            parent = await self.get_integration(meta["parent"])
            items.append({
                "provider": provider,
                "label": meta["label"],
                "category": meta["category"],
                "connected": parent["connected"],
                "credentials_configured": parent["credentials_configured"],
                "status": parent.get("status", "not_configured"),
                "read_only": parent.get("read_only"),
                "last_test_at": parent.get("last_test_at"),
                "last_test_ok": parent.get("last_test_ok"),
                "last_test_message": parent.get("last_test_message"),
                "environment": self.environment(),
                "source": parent["source"],
                "recent_logs": parent.get("recent_logs", []),
            })
        return {"environment": self.environment(), "items": items}

    async def get_integration(self, provider: str) -> dict:
        if provider not in PROVIDER_CATALOG:
            provider = provider.replace("-", "_")
        meta = PROVIDER_CATALOG.get(provider, {"label": provider, "category": "other"})
        row = await self._row(provider if provider in ENV_FIELD_MAP else provider)
        if provider in ("outlook", "teams", "onedrive", "sharepoint"):
            row = await self._row("microsoft365")
            provider = "microsoft365"
        cfg, secrets, source = self._resolve_fields(provider, row)
        creds_ok = self._credentials_ok(provider, cfg, secrets)
        read_only = _parse_bool(cfg.get("read_only")) if "read_only" in cfg else None
        if read_only is None and provider == "odoo":
            read_only = settings.odoo_read_only
        if read_only is None and provider == "microsoft365":
            read_only = settings.m365_read_only
        connected = row.connected if row else creds_ok
        last_test_ok = row.last_test_ok if row else None
        status = _connection_status(
            creds_ok=creds_ok,
            connected=connected,
            last_test_ok=last_test_ok,
            read_only=read_only,
        )
        logs = await self.integration_logs(provider, limit=5)
        extra: dict[str, Any] = {}
        if provider == "hermes":
            extra = {
                "enabled": settings.hermes_enabled,
                "service_url": settings.hermes_service_url,
                "model": settings.hermes_model,
            }
        elif provider == "dgcp":
            extra = {"source": "API pública DGCP", "base_url": settings.dgcp_api_base_url_resolved}
        return {
            "provider": provider,
            "label": meta["label"],
            "connected": connected,
            "credentials_configured": creds_ok,
            "status": status,
            "read_only": read_only,
            "environment": self.environment(),
            "source": source if row else "env",
            "fields": self._field_list(provider, cfg, secrets),
            "last_test_at": row.last_test_at if row else None,
            "last_test_ok": last_test_ok,
            "last_test_message": row.last_test_message if row else None,
            "permissions": [],
            "recent_logs": logs["items"],
            "extra": extra,
        }

    async def update_integration(self, provider: str, *, config: dict, secrets: dict, delete_secrets: list[str]) -> dict:
        row = await self._row(provider)
        if not row:
            row = TenantIntegrationSetting(tenant_id=self.tenant_id, provider=provider)
            self.db.add(row)
        normalized = dict(config)
        for k, v in list(normalized.items()):
            if k in ("read_only", "use_tls"):
                normalized[k] = _parse_bool(v)
        row.config = {**dict(row.config or {}), **normalized}
        enc = dict(row.secrets_encrypted or {})
        for k in delete_secrets:
            enc.pop(k, None)
        for k, v in secrets.items():
            if v:
                enc[k] = encrypt_secret(v)
        row.secrets_encrypted = enc
        row.updated_by = self.actor_id
        if provider == "microsoft365":
            await self._sync_m365_tenant_settings(row)
        await AuditService(self.db).log(
            action="settings.integration_updated",
            tenant_id=self.tenant_id,
            user_id=self.actor_id,
            resource_type="integration",
            details={"provider": provider, "config_keys": list(config.keys()), "secret_keys": list(secrets.keys())},
        )
        await self.db.commit()
        return await self.get_integration(provider)

    async def _sync_m365_tenant_settings(self, row: TenantIntegrationSetting) -> None:
        from app.models.tenant import Tenant

        result = await self.db.execute(select(Tenant).where(Tenant.id == self.tenant_id))
        tenant = result.scalar_one_or_none()
        if not tenant:
            return
        cfg = row.config or {}
        secrets = row.secrets_encrypted or {}
        m365: dict = {
            "tenant_id": cfg.get("tenant_id"),
            "client_id": cfg.get("client_id"),
            "redirect_uri": cfg.get("redirect_uri"),
            "webhook_url": cfg.get("webhook_url"),
            "webhook_client_state": cfg.get("webhook_client_state"),
        }
        if secrets.get("client_secret"):
            m365["client_secret_encrypted"] = secrets["client_secret"]
        elif secrets.get("client_secret_encrypted"):
            m365["client_secret_encrypted"] = secrets["client_secret_encrypted"]
        settings_json = dict(tenant.settings or {})
        settings_json["m365"] = {k: v for k, v in m365.items() if v}
        tenant.settings = settings_json

    def _decrypt_secrets(self, secrets: dict) -> dict[str, str]:
        out: dict[str, str] = {}
        for k, v in (secrets or {}).items():
            try:
                out[k] = decrypt_secret(v)
            except ValueError:
                continue
        return out

    async def test_integration(self, provider: str) -> dict:
        import time

        started = time.perf_counter()
        detail = await self.get_integration(provider)
        row = await self._row(provider if provider in ENV_FIELD_MAP else "microsoft365" if provider in ("outlook", "teams", "onedrive", "sharepoint") else provider)
        cfg = dict(row.config) if row else {}
        secrets = self._decrypt_secrets(row.secrets_encrypted if row else {})
        if not row:
            cfg, secrets_enc, _ = self._resolve_fields(provider, None)
            secrets = self._decrypt_secrets(secrets_enc)

        missing = self._missing_config_fields(provider, cfg, secrets, detail)
        ok = False
        message = "Proveedor no soportado para prueba automática"
        extra: dict = {}

        try:
            if missing and provider in ("openai", "anthropic", "deepseek", "whatsapp_cloud", "smtp"):
                ok = False
                message = f"No se puede probar {detail['label']} porque faltan: {', '.join(missing)}."
            elif provider in ("microsoft365", "outlook", "teams", "onedrive", "sharepoint"):
                from app.services.m365_admin_service import M365AdminService

                res = await M365AdminService(self.db, self.tenant_id, self.actor_id or uuid.uuid4()).test_connection()
                ok, message = res.ok, res.message
            elif provider == "odoo":
                from integrations.odoo.client import OdooClient
                from integrations.odoo.config import OdooConfig

                client = OdooClient(
                    str(self.tenant_id),
                    OdooConfig(
                        url=cfg.get("url") or settings.odoo_url,
                        database=cfg.get("database") or settings.odoo_db,
                        username=cfg.get("username") or settings.odoo_username,
                        api_key=secrets.get("api_key") or settings.odoo_api_key,
                    ),
                )
                res = await client.test_connection()
                ok = bool(res.get("connected"))
                message = "Conexión exitosa" if ok else res.get("error", "Error de conexión")
                extra = dict(res)
                if ok:
                    try:
                        companies = await client.search_read(
                            "res.company",
                            [],
                            ["id", "name"],
                            limit=50,
                        )
                        extra["companies"] = companies
                        message = f"Conexión exitosa — {len(companies)} empresa(s) encontrada(s)"
                    except Exception as exc:
                        extra["companies_error"] = str(exc)
            elif provider == "dgcp":
                from integrations.dgcp.client import DGCPClient
                from integrations.dgcp.config import DGCPConfig

                client = DGCPClient(DGCPConfig(
                    base_url=cfg.get("base_url") or settings.dgcp_api_base_url_resolved,
                    api_key=secrets.get("api_key") or settings.dgcp_api_key,
                ))
                res = await client.health_check()
                ok = bool(res.get("reachable"))
                total = res.get("total_procesos")
                message = (
                    f"DGCP accesible — {total} proceso(s) en API"
                    if ok
                    else res.get("error", "DGCP no accesible")
                )
                extra = dict(res)
            elif provider == "hermes":
                from app.services.hermes_client import HermesClient

                client = HermesClient()
                health = await client.health() or {}
                ok = bool(settings.hermes_enabled and health.get("status") == "ok")
                if not settings.hermes_enabled:
                    message = "Hermes deshabilitado (HERMES_ENABLED=false)"
                elif ok:
                    model = health.get("model") or settings.hermes_model
                    llm = "LLM OK" if health.get("llm_configured") else "LLM no configurado"
                    message = f"Hermes activo — {model} ({llm})"
                else:
                    message = health.get("error") or "Hermes no alcanzable"
                extra = health or {}
            elif provider == "n8n":
                url = cfg.get("url") or settings.n8n_webhook_url
                if not url:
                    ok = False
                    message = "Falta N8N_WEBHOOK_URL"
                else:
                    ok = True
                    message = f"n8n configurado — {url[:80]}"
                    extra = {"webhook_url": url}
            elif provider == "openai":
                ok, message, extra = await self._test_llm_provider(
                    api_key=secrets.get("api_key") or settings.openai_api_key,
                    label="OpenAI",
                )
            elif provider == "anthropic":
                ok, message, extra = await self._test_llm_provider(
                    api_key=secrets.get("api_key") or settings.anthropic_api_key,
                    label="Anthropic",
                )
            elif provider == "deepseek":
                ok, message, extra = await self._test_llm_provider(
                    api_key=secrets.get("api_key") or settings.deepseek_huawei_api_key,
                    label="DeepSeek/Huawei",
                )
            elif provider == "whatsapp_cloud":
                if missing:
                    ok = False
                    message = "No configurado. Falta token, phone number id o proveedor."
                else:
                    ok = True
                    message = "Credenciales WhatsApp Cloud guardadas."
                    extra = {"phone_number_id": cfg.get("phone_number_id")}
            elif provider == "whatsapp_web":
                ok = bool(settings.whatsapp_enabled and settings.whatsapp_bridge_url)
                message = (
                    "WhatsApp Web bridge configurado"
                    if ok
                    else "WhatsApp Web no configurado (WHATSAPP_BRIDGE_URL)"
                )
            elif provider == "smtp":
                host = cfg.get("host") or settings.smtp_host
                ok = bool(host)
                message = f"SMTP — {host}" if ok else "Falta servidor SMTP"
            elif provider == "ingram":
                from app.services.supplier_connector_service import SupplierConnectorService

                svc = SupplierConnectorService(self.db, self.tenant_id)
                connector = await svc.ingram_connector()
                health = await connector.health_check()
                session = await svc.ingram_status()
                ok = bool(health.get("ok")) or bool(session.get("session_active"))
                if session.get("session_active"):
                    message = "Conexión exitosa. Sesión Ingram MFA activa."
                elif health.get("ok"):
                    message = health.get("message") or "Conexión exitosa. Proveedor autenticado correctamente."
                else:
                    message = health.get("message") or session.get("message") or "Configure credenciales y MFA"
                extra = {**health, **{k: v for k, v in session.items() if k in ("session_active", "mfa_pending")}}
            elif provider == "omega":
                from app.services.supplier_connector_service import SupplierConnectorService

                svc = SupplierConnectorService(self.db, self.tenant_id)
                status = await svc.omega_status()
                if status.get("has_credentials"):
                    login = await svc.omega_login()
                    ok = bool(login.get("ok"))
                    message = (
                        "Conexión exitosa. Proveedor autenticado correctamente."
                        if ok
                        else (login.get("message") or "No fue posible autenticar en tienda Omega")
                    )
                    extra = login
                else:
                    connector = await svc.omega_connector()
                    health = await connector.health_check()
                    ok = bool(health.get("ok"))
                    message = (
                        health.get("message") or "Tienda pública accesible (sin credenciales de canal)"
                        if ok
                        else "Configure credenciales de tienda Omega"
                    )
                    extra = health
            elif provider == "cecomsa":
                from app.services.cecomsa_config_resolver import resolve_cecomsa_config
                from integrations.suppliers.cecomsa_connector import CecomsaConnector

                cfg_ce = await resolve_cecomsa_config(self.db, self.tenant_id)
                connector = CecomsaConnector(cfg_ce, tenant_id=str(self.tenant_id))
                health = await connector.health_check()
                ok = bool(health.get("ok"))
                message = health.get("message") or ("Catálogo Cecomsa accesible" if ok else "Cecomsa no accesible")
                extra = health
            elif provider in ("intcomex", "tecnomarket", "tecnosinergia"):
                ok = detail["credentials_configured"]
                message = "Credenciales guardadas" if ok else "Complete los campos requeridos"
            elif provider == "qdrant":
                from qdrant_client import QdrantClient

                host = cfg.get("host") or settings.qdrant_host
                port = int(cfg.get("port") or settings.qdrant_port)
                c = QdrantClient(host=host, port=port, check_compatibility=False)
                collections = c.get_collections()
                names = [col.name for col in collections.collections]
                ok, message = True, f"Qdrant accesible — {len(names)} colección(es)"
                extra = {"collections": names[:10]}
            else:
                ok = detail["credentials_configured"]
                message = "Credenciales guardadas" if ok else "Complete los campos requeridos"
        except Exception as exc:
            ok, message = False, str(exc)

        latency_ms = int((time.perf_counter() - started) * 1000)

        if row:
            row.last_test_at = datetime.now(timezone.utc)
            row.last_test_ok = ok
            row.last_test_message = message
            row.connected = ok

        await AuditService(self.db).log(
            action="settings.integration_tested",
            tenant_id=self.tenant_id,
            user_id=self.actor_id,
            resource_type="integration",
            details={"provider": provider, "ok": ok, "message": message, "latency_ms": latency_ms},
        )
        await self.db.commit()
        return {
            "ok": ok,
            "success": ok,
            "message": message,
            "error": None if ok else message,
            "missing_config": missing,
            "latency_ms": latency_ms,
            "details": extra,
        }

    @staticmethod
    def _missing_config_fields(
        provider: str,
        cfg: dict,
        secrets: dict,
        detail: dict,
    ) -> list[str]:
        required: dict[str, list[str]] = {
            "openai": ["api_key"],
            "anthropic": ["api_key"],
            "deepseek": ["api_key"],
            "whatsapp_cloud": ["phone_number_id", "access_token"],
            "smtp": ["host"],
            "odoo": ["url", "database", "username", "api_key"],
        }
        keys = required.get(provider, [])
        missing: list[str] = []
        for key in keys:
            field = next((f for f in detail.get("fields", []) if f.get("key") == key), None)
            label = field["label"] if field else key.upper()
            val = secrets.get(key) or cfg.get(key)
            if not val and not (field and field.get("configured")):
                missing.append(label)
        return missing

    @staticmethod
    async def _test_llm_provider(*, api_key: str | None, label: str) -> tuple[bool, str, dict]:
        if not api_key:
            return False, f"No se puede probar {label} porque falta API Key.", {}
        return True, f"{label} — API Key configurada.", {"configured": True}

    async def disconnect_integration(self, provider: str) -> dict:
        row = await self._row(provider)
        if row:
            row.connected = False
            row.last_test_ok = False
            row.last_test_message = "Desconectado manualmente"
            await self.db.commit()
        await AuditService(self.db).log(
            action="settings.integration_disconnected",
            tenant_id=self.tenant_id,
            user_id=self.actor_id,
            resource_type="integration",
            details={"provider": provider},
        )
        await self.db.commit()
        return await self.get_integration(provider)

    async def system_status(self) -> dict:
        now = datetime.now(timezone.utc)
        items = [
            {"name": "Backend API", "status": "ok", "message": settings.app_name, "checked_at": now},
            {"name": "PostgreSQL", "status": "ok", "message": "Conectado", "checked_at": now},
            {"name": "Redis", "status": "configured" if settings.redis_url else "missing", "message": settings.redis_url[:30] + "…" if settings.redis_url else "No configurado", "checked_at": now},
            {"name": "Qdrant", "status": "configured", "message": f"{settings.qdrant_host}:{settings.qdrant_port}", "checked_at": now},
        ]
        for prov in ("microsoft365", "odoo", "dgcp"):
            d = await self.get_integration(prov)
            items.append({
                "name": d["label"],
                "status": "connected" if d["connected"] else ("configured" if d["credentials_configured"] else "disconnected"),
                "message": d.get("last_test_message") or ("Credenciales OK" if d["credentials_configured"] else "Sin configurar"),
                "checked_at": d.get("last_test_at") or now,
            })
        return {"environment": self.environment(), "items": items}

    async def integration_logs(self, provider: str, *, limit: int = 30) -> dict:
        from app.models.audit_log import AuditLog

        result = await self.db.execute(
            select(AuditLog)
            .where(
                AuditLog.tenant_id == self.tenant_id,
                AuditLog.action.like("settings.%"),
            )
            .order_by(AuditLog.created_at.desc())
            .limit(limit * 3)
        )
        rows = [
            r
            for r in result.scalars().all()
            if (r.details or {}).get("provider") in (provider, provider.replace("-", "_"))
        ][:limit]
        return {
            "items": [
                {
                    "id": r.id,
                    "action": r.action,
                    "user_id": r.user_id,
                    "resource_type": r.resource_type,
                    "details": r.details or {},
                    "ip_address": str(r.ip_address) if r.ip_address else None,
                    "created_at": r.created_at,
                }
                for r in rows
            ],
            "total": len(rows),
        }

    async def audit_log(self, *, limit: int = 50) -> dict:
        from app.models.audit_log import AuditLog

        result = await self.db.execute(
            select(AuditLog)
            .where(
                AuditLog.tenant_id == self.tenant_id,
                AuditLog.action.like("settings.%"),
            )
            .order_by(AuditLog.created_at.desc())
            .limit(limit)
        )
        rows = list(result.scalars().all())
        return {
            "items": [
                {
                    "id": r.id,
                    "action": r.action,
                    "user_id": r.user_id,
                    "resource_type": r.resource_type,
                    "details": r.details or {},
                    "ip_address": str(r.ip_address) if r.ip_address else None,
                    "created_at": r.created_at,
                }
                for r in rows
            ],
            "total": len(rows),
        }
