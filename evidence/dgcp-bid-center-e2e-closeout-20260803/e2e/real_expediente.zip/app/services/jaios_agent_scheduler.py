"""Scheduler — agentes autónomos JAIOS."""

from __future__ import annotations

import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler

from app.services.jaios_agent_runner import run_agents_all_tenants

logger = logging.getLogger(__name__)
_scheduler: AsyncIOScheduler | None = None


async def _run_jaios_agents() -> None:
    try:
        results = await run_agents_all_tenants()
        ok = sum(1 for r in results if r.get("status") == "completed")
        logger.info("JAIOS agents finished: %s/%s ok", ok, len(results))
    except Exception:
        logger.exception("JAIOS agents run failed")


def start_jaios_agent_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = AsyncIOScheduler()
    _scheduler.add_job(_run_jaios_agents, "interval", hours=6, id="jaios_agents")
    _scheduler.start()
    logger.info("JAIOS agent scheduler started (every 6h)")
    return _scheduler


def stop_jaios_agent_scheduler() -> None:
    global _scheduler
    if _scheduler:
        _scheduler.shutdown(wait=False)
        _scheduler = None
