"""Compat — reexporta resolución de knowledge assets."""

from __future__ import annotations

from typing import Any

from app.services.document_access_service import (
    DocumentAccess as KnowledgeAssetAccess,
    can_read_local_path,
    is_remote_knowledge_path,
    resolve_canonical_knowledge_asset,
    resolve_knowledge_asset_access,
    resolve_knowledge_asset_web_url,
)


def can_read_knowledge_asset_local(asset: Any) -> bool:
    path = getattr(asset, "relative_path", None) if not isinstance(asset, str) else asset
    return can_read_local_path(path)

__all__ = [
    "KnowledgeAssetAccess",
    "can_read_knowledge_asset_local",
    "is_remote_knowledge_path",
    "resolve_canonical_knowledge_asset",
    "resolve_knowledge_asset_access",
    "resolve_knowledge_asset_web_url",
]
