"""Clasifica documentos legales sincronizados desde OneDrive."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.knowledge import KnowledgeAsset
from app.models.m365_repository import M365RepositoryFile
from app.services.company_normalization_service import normalize_company_key
from app.services.vigency_engine import VigencyEngine

LEGAL_TYPE_HINTS: dict[str, tuple[str, ...]] = {
    "registro_mercantil": ("registro", "mercantil", "rm"),
    "rnc": ("rnc",),
    "dgii": ("dgii", "certificacion fiscal"),
    "tss": ("tss",),
    "mipyme": ("mipyme",),
    "estatutos": ("estatuto",),
    "acta_asamblea": ("acta", "asamblea"),
    "poderes": ("poder",),
    "cedula_representante": ("cedula", "cédula", "identidad"),
    "certificacion_bancaria": ("banco", "bancaria", "cuenta"),
    "proveedor_estado": ("proveedor", "estado", "rpe", "dgcp"),
}


logger = logging.getLogger(__name__)


class LegalDocumentSyncService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.vigency = VigencyEngine()

    async def sync_from_binding(self, binding_id: uuid.UUID) -> dict:
        files = (
            await self.db.execute(
                select(M365RepositoryFile).where(
                    M365RepositoryFile.tenant_id == self.tenant_id,
                    M365RepositoryFile.binding_id == binding_id,
                    M365RepositoryFile.is_folder.is_(False),
                    M365RepositoryFile.is_deleted.is_(False),
                )
            )
        ).scalars().all()

        synced = 0
        skipped = 0
        db_errors = 0
        for f in files:
            name = (f.name or "").strip()
            if not name or name.lower() in ("sin nombre", "untitled"):
                skipped += 1
                continue
            try:
                async with self.db.begin_nested():
                    company_key = self._company_key(f.parent_path)
                    doc_type = self._detect_type(name)
                    vigency_status = self.vigency.SIN_FECHA

                    rel = f"m365/{f.graph_item_id}/{name}".strip("/")
                    existing = (
                        await self.db.execute(
                            select(KnowledgeAsset).where(
                                KnowledgeAsset.tenant_id == self.tenant_id,
                                KnowledgeAsset.source_provider == "onedrive",
                                KnowledgeAsset.relative_path == rel,
                            )
                        )
                    ).scalar_one_or_none()
                    if not existing and f.graph_item_id:
                        rows = (
                            await self.db.execute(
                                select(KnowledgeAsset).where(
                                    KnowledgeAsset.tenant_id == self.tenant_id,
                                    KnowledgeAsset.metadata_["graph_item_id"].astext == f.graph_item_id,
                                )
                            )
                        ).scalars().all()
                        existing = rows[0] if rows else None

                    if not existing:
                        existing = KnowledgeAsset(
                            tenant_id=self.tenant_id,
                            source_provider="onedrive",
                            source_root="m365",
                            relative_path=rel,
                            folder_category="legal_documents",
                            filename=name,
                            title=name,
                            format=(name.rsplit(".", 1)[-1] if "." in name else "other").lower(),
                            content_hash=f.content_hash or "",
                        )
                        self.db.add(existing)

                    existing.document_type = doc_type
                    existing.company_key = company_key
                    existing.mime_type = f.mime_type
                    existing.file_size = f.size_bytes or 0
                    if f.content_hash:
                        existing.content_hash = f.content_hash
                    existing.source_modified_at = f.modified_at_graph
                    existing.valid_from = None
                    existing.valid_until = None
                    existing.vigency_status = vigency_status
                    existing.synced_at = datetime.now(UTC)
                    existing.is_active = True
                    existing.metadata_ = {
                        "graph_item_id": f.graph_item_id,
                        "drive_id": f.drive_id,
                        "web_url": f.web_url,
                        "binding_id": str(binding_id),
                        "parent_path": f.parent_path,
                        "source_type": f.source or "onedrive",
                    }
                    await self.db.flush()
                synced += 1
            except IntegrityError as exc:
                db_errors += 1
                logger.warning(
                    "[M365_SYNC_SAVE_DOCUMENT] skipped duplicate tenant=%s graph_item=%s name=%s detail=%s",
                    self.tenant_id,
                    f.graph_item_id,
                    name,
                    exc.orig,
                )

        if synced:
            await self.db.commit()
        return {
            "records_indexed": synced,
            "skipped": skipped,
            "db_errors": db_errors,
            "message": f"{synced} documentos legales clasificados ({skipped} omitidos sin nombre, {db_errors} duplicados omitidos)",
        }

    @staticmethod
    def _company_key(parent_path: str) -> str | None:
        parts = [p for p in parent_path.split("/") if p.strip()]
        for p in reversed(parts):
            canon = normalize_company_key(p)
            if canon:
                return canon
        return normalize_company_key(parts[-1]) if parts else None

    @staticmethod
    def _detect_type(filename: str) -> str:
        low = filename.lower()
        for doc_type, hints in LEGAL_TYPE_HINTS.items():
            if any(h in low for h in hints):
                return doc_type
        return "otros"
