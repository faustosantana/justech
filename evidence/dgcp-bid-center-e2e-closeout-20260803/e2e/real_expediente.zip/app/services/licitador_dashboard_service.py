"""Dashboards premium — documentos legales, plantillas DGCP, inteligencia de precios."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.knowledge import KnowledgeAsset
from app.models.licitador_company_profile import LicitadorCompanyProfile
from app.models.m365_repository import M365RepositoryFile
from app.models.price_list import PriceListFile, PriceListProduct
from app.schemas.licitador import (
    CompanyLegalSummary,
    DgcpTemplateItem,
    DgcpTemplatesDashboardResponse,
    LegalDocumentItem,
    LegalDocumentsDashboardResponse,
    PriceFileItem,
    PriceIntelligenceDashboardResponse,
)
from app.services.company_profile_sync_service import CompanyProfileSyncService
from app.services.corporate_repository_unified_service import CorporateRepositoryUnifiedService
from app.services.supplier_price_file_service import SupplierPriceFileService

from app.services.company_normalization_service import COMPANY_KEYS, normalize_company_key

EXPECTED_LEGAL = (
    "registro_mercantil",
    "rnc",
    "dgii",
    "tss",
    "mipyme",
    "estatutos",
    "acta_asamblea",
    "poderes",
    "cedula_representante",
    "certificacion_bancaria",
    "proveedor_estado",
)

TEMPLATE_TYPE_HINTS: dict[str, tuple[str, ...]] = {
    "sncc": ("sncc", "f.033", "f033", "f.042", "f042", "f.047", "f047"),
    "oferta_economica": ("oferta", "economica", "económica", "precio"),
    "declaracion_jurada": ("declaracion", "declaración", "jurada"),
    "autorizacion_fabricante": ("autorizacion", "autorización", "fabricante"),
    "informacion_oferente": ("oferente", "informacion", "información"),
    "carta": ("carta",),
    "dgcp": ("dgcp", "proveedores del estado"),
}


class LicitadorDashboardService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def legal_documents(self) -> LegalDocumentsDashboardResponse:
        profiles = {
            p.company_key: p
            for p in (
                await self.db.execute(
                    select(LicitadorCompanyProfile).where(LicitadorCompanyProfile.tenant_id == self.tenant_id)
                )
            ).scalars().all()
        }

        knowledge_assets = list(
            (
                await self.db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == self.tenant_id,
                        KnowledgeAsset.is_active.is_(True),
                        or_(
                            KnowledgeAsset.folder_category == "legal_documents",
                            KnowledgeAsset.relative_path.ilike("%01_DOCUMENTOS_LEGALES%"),
                        ),
                    )
                )
            ).scalars().all()
        )

        m365_legal = list(
            (
                await self.db.execute(
                    select(M365RepositoryFile).where(
                        M365RepositoryFile.tenant_id == self.tenant_id,
                        M365RepositoryFile.is_folder.is_(False),
                        M365RepositoryFile.is_deleted.is_(False),
                        or_(
                            M365RepositoryFile.document_category == "legal",
                            M365RepositoryFile.parent_path.ilike("%01_DOCUMENTOS_LEGALES%"),
                        ),
                    )
                )
            ).scalars().all()
        )

        companies: list[CompanyLegalSummary] = []
        total_docs = total_expired = total_missing = 0

        for key, label in COMPANY_KEYS:
            profile = profiles.get(key)
            docs: list[LegalDocumentItem] = []
            found_types: set[str] = set()

            for asset in knowledge_assets:
                ck = (asset.company_key or "").lower().replace(" ", "_")
                if ck != key and label.upper() not in (asset.relative_path or "").upper():
                    continue
                docs.append(
                    LegalDocumentItem(
                        id=str(asset.id),
                        name=asset.title or asset.filename,
                        document_type=asset.document_type,
                        vigency_status=asset.vigency_status,
                        valid_until=asset.valid_until.isoformat() if asset.valid_until else None,
                        web_url=(asset.metadata_ or {}).get("web_url"),
                        source="knowledge",
                    )
                )
                found_types.add(asset.document_type.lower())
                canonical = CorporateRepositoryUnifiedService.canonical_field_for_type(asset.document_type)
                if canonical:
                    found_types.add(canonical)

            for f in m365_legal:
                ck = self._company_from_path(f.parent_path)
                if ck != key:
                    continue
                doc_type = f.document_type or "otros"
                docs.append(
                    LegalDocumentItem(
                        id=str(f.id),
                        name=f.name,
                        document_type=doc_type,
                        vigency_status="sin_fecha",
                        web_url=f.web_url,
                        source="onedrive",
                    )
                )
                found_types.add(doc_type.lower())
                canonical = CorporateRepositoryUnifiedService.canonical_field_for_type(doc_type)
                if canonical:
                    found_types.add(canonical)

            missing = [t for t in EXPECTED_LEGAL if t not in found_types]
            expired = [d.name for d in docs if d.vigency_status == "vencido"]
            upcoming = [d.name for d in docs if d.vigency_status == "proximo_a_vencer"]

            companies.append(
                CompanyLegalSummary(
                    company_key=key,
                    company_label=label,
                    completeness_score=profile.completeness_score if profile else 0,
                    missing_profile_fields=list(profile.missing_fields or []) if profile else [],
                    documents=docs,
                    missing_documents=missing,
                    expired_documents=expired,
                    upcoming_documents=upcoming,
                )
            )
            total_docs += len(docs)
            total_expired += len(expired)
            total_missing += len(missing)

        return LegalDocumentsDashboardResponse(
            companies=companies,
            total_documents=total_docs,
            total_expired=total_expired,
            total_missing=total_missing,
        )

    async def dgcp_templates(self) -> DgcpTemplatesDashboardResponse:
        rows = list(
            (
                await self.db.execute(
                    select(M365RepositoryFile)
                    .where(
                        M365RepositoryFile.tenant_id == self.tenant_id,
                        M365RepositoryFile.is_folder.is_(False),
                        M365RepositoryFile.is_deleted.is_(False),
                        or_(
                            M365RepositoryFile.document_category.in_(("plantilla", "formulario")),
                            M365RepositoryFile.parent_path.ilike("%PLANTILLAS%"),
                            M365RepositoryFile.parent_path.ilike("%DGCP%"),
                        ),
                    )
                    .order_by(M365RepositoryFile.document_category, M365RepositoryFile.name)
                    .limit(200)
                )
            ).scalars().all()
        )

        templates: list[DgcpTemplateItem] = []
        by_cat: dict[str, int] = {}

        for r in rows:
            ttype = self._detect_template_type(r.name)
            cat = r.document_category or "plantilla"
            by_cat[cat] = by_cat.get(cat, 0) + 1
            templates.append(
                DgcpTemplateItem(
                    id=str(r.id),
                    name=r.name,
                    source="onedrive",
                    document_category=cat,
                    mime_type=r.mime_type,
                    template_type=ttype,
                    web_url=r.web_url,
                    parent_path=r.parent_path,
                    fillable_fields_estimate=6 if ttype and "sncc" in ttype else 4,
                )
            )

        return DgcpTemplatesDashboardResponse(templates=templates, total=len(templates), by_category=by_cat)

    async def price_intelligence(self) -> PriceIntelligenceDashboardResponse:
        pending_raw = await SupplierPriceFileService(self.db, self.tenant_id, self.user_id).list_pending()
        pending = [
            PriceFileItem(
                id=p["id"],
                name=p["name"],
                status="pending",
                parent_path=p.get("parent_path", ""),
            )
            for p in pending_raw
        ]

        processed_rows = list(
            (
                await self.db.execute(
                    select(PriceListFile)
                    .where(
                        PriceListFile.tenant_id == self.tenant_id,
                        PriceListFile.is_current.is_(True),
                    )
                    .order_by(PriceListFile.indexed_at.desc().nullslast())
                    .limit(30)
                )
            ).scalars().all()
        )

        processed = [
            PriceFileItem(
                id=str(r.id),
                name=r.filename,
                supplier=r.supplier,
                records=r.total_records,
                status=r.status,
                indexed_at=r.indexed_at.isoformat() if r.indexed_at else None,
                parent_path=r.relative_path,
            )
            for r in processed_rows
        ]

        total_products = int(
            await self.db.scalar(
                select(func.count())
                .select_from(PriceListProduct)
                .where(
                    PriceListProduct.tenant_id == self.tenant_id,
                    PriceListProduct.is_current.is_(True),
                )
            )
            or 0
        )

        suppliers = (
            await self.db.execute(
                select(PriceListProduct.supplier)
                .where(
                    PriceListProduct.tenant_id == self.tenant_id,
                    PriceListProduct.is_current.is_(True),
                    PriceListProduct.supplier.isnot(None),
                )
                .distinct()
            )
        ).scalars().all()

        since = datetime.now(UTC) - timedelta(days=1)
        lists_today = int(
            await self.db.scalar(
                select(func.count())
                .select_from(PriceListFile)
                .where(
                    PriceListFile.tenant_id == self.tenant_id,
                    PriceListFile.indexed_at >= since,
                )
            )
            or 0
        )

        errors: list[str] = []
        for r in processed_rows:
            if r.errors:
                errors.extend([f"{r.filename}: {e}" for e in r.errors[:2]])

        return PriceIntelligenceDashboardResponse(
            pending_files=pending,
            processed_files=processed,
            total_products=total_products,
            total_suppliers=len(list(suppliers)),
            lists_today=lists_today,
            recent_errors=errors[:10],
        )

    @staticmethod
    def _company_from_path(parent_path: str) -> str | None:
        from app.services.company_normalization_service import CANONICAL_COMPANIES

        canonical = {c["key"] for c in CANONICAL_COMPANIES}
        parts = [p for p in parent_path.split("/") if p.strip()]
        for part in parts:
            canon = normalize_company_key(part)
            if canon in canonical:
                return canon
        for part in reversed(parts):
            canon = normalize_company_key(part)
            if canon:
                return canon
        return None

    @staticmethod
    def _detect_template_type(filename: str) -> str | None:
        low = filename.lower()
        for ttype, hints in TEMPLATE_TYPE_HINTS.items():
            if any(h in low for h in hints):
                return ttype
        if low.endswith((".docx", ".doc", ".xlsx", ".xls", ".pdf")):
            return "dgcp"
        return None
