"""Microsoft 365 Intelligence Center — Graph real por cuenta."""

from __future__ import annotations

import uuid
from typing import Any, Callable

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.schemas.m365 import (
    M365ConfigKey,
    M365Diagnostics,
    M365HealthResponse,
    M365ListResponse,
    M365RequiredConfig,
    M365SearchResponse,
    M365SetupStep,
    M365StatusResponse,
    NOT_CONNECTED_MESSAGE,
)
from app.services.audit_service import AuditService
from app.services.m365_connection_service import M365ConnectionService
from app.services.m365_config_resolver import resolve_m365_config
from app.services.m365_graph_errors import graph_error_message
from app.services.m365_graph_session import M365GraphSession, M365GraphSessionService
from app.services.m365_qdrant_service import M365QdrantService
from integrations.microsoft365.client import M365Client
from integrations.microsoft365.config import ADMIN_CONSENT_SCOPES, DEFAULT_APP_SCOPES, DEFAULT_READ_SCOPES, M365Config
from integrations.microsoft365.errors import GraphError


class M365Service:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._audit_svc = AuditService(db)

    def _client(self) -> M365Client:
        return M365Client(
            M365Config(
                tenant_id=settings.m365_tenant_id,
                client_id=settings.m365_client_id,
                client_secret=settings.m365_client_secret,
                redirect_uri=settings.m365_redirect_uri,
                read_only=settings.m365_read_only,
            )
        )

    def _required_config(self) -> M365RequiredConfig:
        client = self._client()
        raw = client.required_config()
        config_keys = [
            M365ConfigKey(
                key="M365_TENANT_ID",
                label="Tenant ID (Azure AD)",
                description="Identificador del directorio Microsoft Entra ID",
                configured=bool(settings.m365_tenant_id.strip()),
            ),
            M365ConfigKey(
                key="M365_CLIENT_ID",
                label="Client ID (App Registration)",
                description="ID de la aplicación registrada en Azure",
                configured=bool(settings.m365_client_id.strip()),
            ),
            M365ConfigKey(
                key="M365_CLIENT_SECRET",
                label="Client Secret",
                description="Secreto de aplicación",
                configured=bool(settings.m365_client_secret.strip()),
            ),
            M365ConfigKey(
                key="M365_REDIRECT_URI",
                label="Redirect URI",
                description="Callback OAuth tras consentimiento del usuario",
                configured=bool(settings.m365_redirect_uri.strip()),
            ),
        ]
        return M365RequiredConfig(
            read_only=raw["read_only"],
            redirect_uri=raw["redirect_uri"],
            missing_env_keys=raw["missing_env_keys"],
            config_keys=config_keys,
            delegated_scopes=list(DEFAULT_READ_SCOPES),
            application_scopes=list(DEFAULT_APP_SCOPES),
            oauth_ready=raw["oauth_ready"],
            graph_ready=raw["graph_ready"],
            multi_user_ready=raw["multi_user_ready"],
            indexing_ready=M365QdrantService(self.tenant_id).is_ready(),
            enterprise_search_ready=M365QdrantService(self.tenant_id).is_ready(),
            hermes_memory_ready=False,
            qdrant_ready=M365QdrantService(self.tenant_id).is_ready(),
        )

    def _diagnostics(self) -> M365Diagnostics:
        cfg = self._client().config
        return M365Diagnostics(
            api_reachable=True,
            graph_configured=cfg.is_configured(),
            oauth_implemented=True,
            graph_implemented=cfg.is_configured(),
            read_only_enforced=settings.m365_read_only,
            audit_enabled=True,
            notes=[
                "OAuth delegado — requiere App Registration en Azure.",
                f"Admin consent requerido para: {', '.join(ADMIN_CONSENT_SCOPES[:4])}…",
                "M365_READ_ONLY bloquea solo escritura; lectura siempre activa con cuenta OAuth.",
            ],
        )

    def _setup_steps(self) -> list[M365SetupStep]:
        return [
            M365SetupStep(step=1, title="Registrar aplicación en Azure", description="Permisos delegados + admin consent.", status="pending"),
            M365SetupStep(step=2, title="Configurar variables de entorno", description="M365_TENANT_ID, CLIENT_ID, CLIENT_SECRET, REDIRECT_URI.", status="pending"),
            M365SetupStep(step=3, title="Conectar cuenta Microsoft 365", description="OAuth por usuario con refresh tokens.", status="pending"),
            M365SetupStep(step=4, title="Validar permisos Graph", description="Probar inbox, calendario, OneDrive, SharePoint.", status="pending"),
            M365SetupStep(step=5, title="Búsqueda e indexación", description="Enterprise Search + JAIOS Assistant.", status="pending"),
        ]

    async def _log_audit(self, action: str, details: dict | None = None) -> None:
        await self._audit_svc.log(
            action=action,
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            resource_type="m365",
            details=details or {},
        )

    async def health(self) -> M365HealthResponse:
        conn = await M365ConnectionService(self.db, self.tenant_id, self.user_id).connection_state()
        await self._log_audit("m365.status_checked", {"endpoint": "health"})
        return M365HealthResponse(
            connected=conn.account_connected,
            account_connected=conn.account_connected,
            azure_configured=conn.azure_configured,
            read_only=settings.m365_read_only,
            message=conn.message,
            required_config=self._required_config(),
            diagnostics=self._diagnostics(),
            connection=conn,
        )

    async def status(self) -> M365StatusResponse:
        conn = await M365ConnectionService(self.db, self.tenant_id, self.user_id).connection_state()
        await self._log_audit("m365.status_checked", {"endpoint": "status"})
        steps = self._setup_steps()
        if conn.azure_configured:
            steps[1].status = "done"
        if conn.account_connected:
            steps[2].status = "done"
            steps[3].status = "done"
        return M365StatusResponse(
            connected=conn.account_connected,
            account_connected=conn.account_connected,
            azure_configured=conn.azure_configured,
            read_only=settings.m365_read_only,
            message=conn.message,
            required_config=self._required_config(),
            setup_steps=steps,
            diagnostics=self._diagnostics(),
            connection=conn,
        )

    def _session_svc(self) -> M365GraphSessionService:
        if not self.user_id:
            raise GraphError(401, NOT_CONNECTED_MESSAGE)
        return M365GraphSessionService(self.db, self.tenant_id, self.user_id)

    def _error_list(self, exc: GraphError, *, account_id: uuid.UUID | None = None, email: str | None = None) -> M365ListResponse:
        return M365ListResponse(
            items=[],
            total=0,
            connected=False,
            read_only=settings.m365_read_only,
            message=graph_error_message(exc),
            required_config=self._required_config(),
            account_id=account_id,
            account_email=email,
            error=exc.message,
            permission_hint=exc.permission_hint,
        )

    async def _graph_list(
        self,
        *,
        resource: str,
        loader: Callable[[M365GraphSession, int], Any],
        account_id: uuid.UUID | None = None,
        limit: int = 50,
        **kwargs,
    ) -> M365ListResponse:
        try:
            sess = await self._session_svc().session_for_account(account_id)
            raw = await loader(sess, limit, **kwargs)
            items = [m.model_dump(mode="json") for m in raw]
            await self._log_audit(f"m365.{resource}", {"count": len(items), "account": str(sess.account.id)})
            return M365ListResponse(
                items=items,
                total=len(items),
                connected=True,
                read_only=settings.m365_read_only,
                message=f"{len(items)} resultados",
                required_config=self._required_config(),
                account_id=sess.account.id,
                account_email=sess.email,
            )
        except GraphError as exc:
            await self._log_audit("m365.graph_error", {"resource": resource, "error": exc.message})
            return self._error_list(exc, account_id=account_id)

    async def outlook_messages(self, *, search: str = "", limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="outlook.messages",
            loader=lambda s, lim, **kw: s.client.outlook.list_messages(search=search, limit=lim),
            account_id=account_id,
            limit=limit,
            search=search,
        )

    async def sharepoint_sites(self, *, search: str = "", limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="sharepoint.sites",
            loader=lambda s, lim, **kw: s.client.sharepoint.list_sites(search=search, limit=lim),
            account_id=account_id,
            limit=limit,
            search=search,
        )

    async def onedrive_files(
        self,
        *,
        search: str = "",
        folder_id: str | None = None,
        limit: int = 50,
        account_id: uuid.UUID | None = None,
    ) -> M365ListResponse:
        return await self._graph_list(
            resource="onedrive.files",
            loader=lambda s, lim, **kw: s.client.onedrive.list_items(
                folder_id=folder_id, search=search, limit=lim
            ),
            account_id=account_id,
            limit=limit,
            search=search,
            folder_id=folder_id,
        )

    async def sharepoint_drives(self, site_id: str, *, limit: int = 25, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="sharepoint.drives",
            loader=lambda s, lim, **kw: s.client.sharepoint.list_site_drives(site_id, limit=lim),
            account_id=account_id,
            limit=limit,
        )

    async def sharepoint_items(
        self,
        drive_id: str,
        *,
        folder_id: str | None = None,
        search: str = "",
        limit: int = 50,
        account_id: uuid.UUID | None = None,
    ) -> M365ListResponse:
        return await self._graph_list(
            resource="sharepoint.items",
            loader=lambda s, lim, **kw: s.client.sharepoint.list_drive_items(
                drive_id, folder_id=folder_id, search=search, limit=lim
            ),
            account_id=account_id,
            limit=limit,
        )

    async def calendar_events(
        self,
        *,
        limit: int = 50,
        start: str | None = None,
        end: str | None = None,
        account_id: uuid.UUID | None = None,
    ) -> M365ListResponse:
        from datetime import UTC, datetime, timedelta

        if start and end:
            start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
            end_dt = datetime.fromisoformat(end.replace("Z", "+00:00"))
            return await self._graph_list(
                resource="calendar.view",
                loader=lambda s, lim, **kw: s.client.calendar.list_calendar_view(
                    start=start_dt, end=end_dt, limit=lim
                ),
                account_id=account_id,
                limit=limit,
            )
        return await self._graph_list(
            resource="calendar.events",
            loader=lambda s, lim, **kw: s.client.calendar.list_events(limit=lim),
            account_id=account_id,
            limit=limit,
        )

    async def teams_channels(self, team_id: str, *, limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        try:
            sess = await self._session_svc().session_for_account(account_id)
            items = await sess.client.teams.list_channels(team_id, limit=limit)
            return M365ListResponse(
                items=items,
                total=len(items),
                connected=True,
                read_only=settings.m365_read_only,
                message=f"{len(items)} canales",
                account_id=sess.account.id,
                account_email=sess.email,
            )
        except GraphError as exc:
            return self._error_list(exc, account_id=account_id)

    async def teams_messages(
        self, team_id: str, channel_id: str, *, limit: int = 25, account_id: uuid.UUID | None = None
    ) -> M365ListResponse:
        try:
            sess = await self._session_svc().session_for_account(account_id)
            items = await sess.client.teams.list_channel_messages(team_id, channel_id, limit=limit)
            return M365ListResponse(
                items=items,
                total=len(items),
                connected=True,
                read_only=settings.m365_read_only,
                message=f"{len(items)} mensajes",
                account_id=sess.account.id,
                account_email=sess.email,
            )
        except GraphError as exc:
            return self._error_list(exc, account_id=account_id)

    async def teams(self, *, limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="teams",
            loader=lambda s, lim, **kw: s.client.teams.list_teams(limit=lim),
            account_id=account_id,
            limit=limit,
        )

    async def contacts(self, *, search: str = "", limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="contacts",
            loader=lambda s, lim, **kw: s.client.contacts.list_contacts(search=search, limit=lim),
            account_id=account_id,
            limit=limit,
            search=search,
        )

    async def documents(self, *, search: str = "", limit: int = 50, account_id: uuid.UUID | None = None) -> M365ListResponse:
        return await self._graph_list(
            resource="documents",
            loader=lambda s, lim, **kw: s.client.documents.list_documents(search=search, limit=lim),
            account_id=account_id,
            limit=limit,
            search=search,
        )

    async def search(self, query: str, *, limit: int = 25, account_id: uuid.UUID | None = None) -> M365SearchResponse:
        await self._log_audit("m365.search_requested", {"query": query[:200], "limit": limit})
        if not query.strip():
            return M365SearchResponse(
                query=query,
                hits=[],
                total=0,
                connected=False,
                read_only=settings.m365_read_only,
                message="Indique un término de búsqueda",
                required_config=self._required_config(),
            )
        try:
            sess = await self._session_svc().session_for_account(account_id)
            groups: dict[str, list[dict[str, Any]]] = {}
            hits: list[dict[str, Any]] = []
            per_type = max(5, limit // 5)

            async def _add(group: str, loader, reason: str):
                try:
                    rows = await loader(sess, per_type)
                    items = [m.model_dump(mode="json") if hasattr(m, "model_dump") else m for m in rows]
                    for item in items:
                        if isinstance(item, dict):
                            item["match_reason"] = reason
                    groups[group] = items
                    for item in items:
                        hits.append({"type": group, "match_reason": reason, **item})
                except GraphError as exc:
                    groups[group] = [{"error": exc.message, "permission_hint": exc.permission_hint}]

            await _add("mail", lambda s, lim: s.client.outlook.list_messages(search=query, limit=lim), f"Asunto o contenido: {query}")
            await _add("contacts", lambda s, lim: s.client.contacts.list_contacts(search=query, limit=lim), f"Contacto: {query}")
            await _add("onedrive", lambda s, lim: s.client.onedrive.list_items(search=query, limit=lim), f"Archivo OneDrive: {query}")
            await _add("sharepoint", lambda s, lim: s.client.sharepoint.list_sites(search=query, limit=lim), f"Sitio SharePoint: {query}")
            async def _teams_filtered(s, lim):
                teams = await s.client.teams.list_teams(limit=lim)
                q = query.lower()
                return [t for t in teams if q in (t.display_name or "").lower() or q in (t.description or "").lower()]

            await _add("teams", _teams_filtered, f"Equipo Teams: {query}")

            qdrant = M365QdrantService(self.tenant_id)
            if qdrant.is_ready():
                semantic = qdrant.search(query, limit=per_type)
                if semantic:
                    groups["semantic"] = semantic
                    for item in semantic:
                        hits.append({"type": "semantic", **item})

            return M365SearchResponse(
                query=query,
                hits=hits[:limit],
                groups=groups,
                total=len(hits),
                connected=True,
                read_only=settings.m365_read_only,
                message=f"{len(hits)} resultados agrupados",
                required_config=self._required_config(),
                account_id=sess.account.id,
            )
        except GraphError as exc:
            return M365SearchResponse(
                query=query,
                hits=[],
                total=0,
                connected=False,
                read_only=settings.m365_read_only,
                message=graph_error_message(exc),
                required_config=self._required_config(),
                error=exc.message,
                permission_hint=exc.permission_hint,
            )
