"""Permisos Odoo — sincronización y validación (autoridad: Odoo, no JAIOS)."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.exceptions import JAIOSException
from app.models.odoo_context import OdooUserMapping, OdooUserPermissionCache
from app.services.audit_service import AuditService
from integrations.odoo.exceptions import OdooConnectionError
from integrations.odoo.normalize import odoo_m2m_ids, odoo_m2o_id, odoo_str

SYNC_MAX_AGE_HOURS = 12

MODULE_MODELS: dict[str, list[str]] = {
    "sales": ["sale.order", "sale.order.line"],
    "crm": ["crm.lead"],
    "contacts": ["res.partner"],
    "accounting": ["account.move", "account.payment", "account.move.line"],
    "project": ["project.project", "project.task"],
    "purchase": ["purchase.order"],
    "inventory": ["product.product", "stock.picking"],
}

MODULE_LABELS: dict[str, str] = {
    "sales": "Ventas y cotizaciones",
    "crm": "CRM / Oportunidades",
    "contacts": "Clientes y contactos",
    "accounting": "Contabilidad (CxC, CxP, facturas)",
    "project": "Proyectos y tareas",
    "purchase": "Compras y proveedores",
    "inventory": "Inventario",
}


class OdooPermissionService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        *,
        odoo_client_factory,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._odoo_client_factory = odoo_client_factory

    async def _client(self):
        return await self._odoo_client_factory()

    async def _get_mapping(self) -> OdooUserMapping | None:
        result = await self.db.execute(
            select(OdooUserMapping).where(
                OdooUserMapping.tenant_id == self.tenant_id,
                OdooUserMapping.jaios_user_id == self.user_id,
                OdooUserMapping.is_active.is_(True),
            )
        )
        return result.scalar_one_or_none()

    async def _get_cache(self) -> OdooUserPermissionCache | None:
        result = await self.db.execute(
            select(OdooUserPermissionCache).where(
                OdooUserPermissionCache.tenant_id == self.tenant_id,
                OdooUserPermissionCache.jaios_user_id == self.user_id,
            )
        )
        return result.scalar_one_or_none()

    def _is_stale(self, row: OdooUserPermissionCache | None) -> bool:
        if not row:
            return True
        age = datetime.now(timezone.utc) - row.synced_at
        return age > timedelta(hours=SYNC_MAX_AGE_HOURS)

    async def sync_permissions(self, *, force: bool = False) -> dict:
        mapping = await self._get_mapping()
        if not mapping:
            raise JAIOSException("Usuario Odoo no vinculado", code="ODOO_USER_NOT_LINKED")

        cache = await self._get_cache()
        if not force and cache and not self._is_stale(cache):
            return self._cache_to_dict(cache)

        client = await self._client()
        if not client.is_configured:
            raise JAIOSException("Odoo no conectado", code="ODOO_NOT_CONNECTED")

        user_fields = ["group_ids", "login", "name"]
        try:
            users = await client.search_read(
                "res.users",
                [("id", "=", mapping.odoo_user_id)],
                user_fields,
                limit=1,
            )
        except OdooConnectionError as exc:
            if "groups_id" in str(exc) or "group_ids" in str(exc):
                users = await client.search_read(
                    "res.users",
                    [("id", "=", mapping.odoo_user_id)],
                    ["groups_id", "login", "name"],
                    limit=1,
                )
            else:
                raise
        if not users:
            raise JAIOSException("Usuario Odoo no encontrado", code="ODOO_USER_NOT_FOUND")

        group_ids = odoo_m2m_ids(users[0].get("group_ids") or users[0].get("groups_id"))
        groups: list[dict] = []
        if group_ids:
            group_rows = await client.search_read(
                "res.groups",
                [("id", "in", group_ids)],
                ["name", "full_name"],
                limit=200,
            )
            groups = [
                {
                    "id": g["id"],
                    "name": odoo_str(g.get("name")),
                    "full_name": odoo_str(g.get("full_name")),
                }
                for g in group_rows
            ]

        model_access: dict[str, dict[str, bool]] = {}
        if group_ids:
            access_rows = await client.search_read(
                "ir.model.access",
                [("group_id", "in", group_ids)],
                ["model_id", "perm_read", "perm_write", "perm_create", "perm_unlink"],
                limit=500,
            )
            model_ids = list({mid for r in access_rows if (mid := odoo_m2o_id(r.get("model_id")))})
            model_names: dict[int, str] = {}
            if model_ids:
                model_rows = await client.search_read(
                    "ir.model", [("id", "in", model_ids)], ["model"], limit=500
                )
                model_names = {m["id"]: odoo_str(m.get("model")) for m in model_rows}

            for row in access_rows:
                mid = odoo_m2o_id(row.get("model_id"))
                if not mid or mid not in model_names:
                    continue
                name = model_names[mid]
                cur = model_access.setdefault(name, {"read": False, "write": False, "create": False, "unlink": False})
                cur["read"] = cur["read"] or bool(row.get("perm_read"))
                cur["write"] = cur["write"] or bool(row.get("perm_write"))
                cur["create"] = cur["create"] or bool(row.get("perm_create"))
                cur["unlink"] = cur["unlink"] or bool(row.get("perm_unlink"))

        module_access = self._derive_modules(model_access)
        now = datetime.now(timezone.utc)

        if cache:
            cache.odoo_user_id = mapping.odoo_user_id
            cache.groups = groups
            cache.model_access = model_access
            cache.module_access = module_access
            cache.synced_at = now
        else:
            cache = OdooUserPermissionCache(
                tenant_id=self.tenant_id,
                jaios_user_id=self.user_id,
                odoo_user_id=mapping.odoo_user_id,
                groups=groups,
                model_access=model_access,
                module_access=module_access,
                synced_at=now,
            )
            self.db.add(cache)

        await AuditService(self.db).log(
            action="odoo.permissions_synced",
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            resource_type="odoo_permissions",
            details={"odoo_user_id": mapping.odoo_user_id, "groups": len(groups), "models": len(model_access)},
        )
        await self.db.commit()
        await self.db.refresh(cache)
        return self._cache_to_dict(cache)

    @staticmethod
    def _derive_modules(model_access: dict[str, dict[str, bool]]) -> dict[str, dict]:
        out: dict[str, dict] = {}
        for module, models in MODULE_MODELS.items():
            perms = {"read": False, "write": False, "create": False, "unlink": False}
            for model in models:
                m = model_access.get(model, {})
                for k in perms:
                    perms[k] = perms[k] or bool(m.get(k))
            out[module] = {
                "label": MODULE_LABELS.get(module, module),
                "enabled": perms["read"],
                **perms,
            }
        return out

    @staticmethod
    def _cache_to_dict(row: OdooUserPermissionCache) -> dict:
        return {
            "odoo_user_id": row.odoo_user_id,
            "groups": row.groups,
            "model_access": row.model_access,
            "module_access": row.module_access,
            "synced_at": row.synced_at.isoformat() if row.synced_at else None,
        }

    async def get_permissions(self, *, auto_sync: bool = True) -> dict | None:
        mapping = await self._get_mapping()
        if not mapping:
            return None
        cache = await self._get_cache()
        if auto_sync and self._is_stale(cache):
            try:
                return await self.sync_permissions()
            except JAIOSException:
                if cache:
                    return self._cache_to_dict(cache)
                return None
        if cache:
            return self._cache_to_dict(cache)
        try:
            return await self.sync_permissions(force=True)
        except JAIOSException:
            return None

    def _perm_from_cache(self, cache: OdooUserPermissionCache | None, model: str, operation: str) -> bool:
        if not cache:
            return False
        return bool(cache.model_access.get(model, {}).get(operation))

    async def require_permission(self, model: str, operation: str, *, message: str | None = None) -> OdooUserPermissionCache:
        mapping = await self._get_mapping()
        if not mapping:
            raise JAIOSException("Vincule su usuario Odoo en Configuración", code="ODOO_USER_NOT_LINKED")

        cache = await self._get_cache()
        if self._is_stale(cache):
            await self.sync_permissions()

        cache = await self._get_cache()
        if not self._perm_from_cache(cache, model, operation):
            default_msg = {
                "create": f"Su perfil de Odoo no tiene permisos para crear en {model}.",
                "write": f"Su perfil de Odoo no tiene permisos para modificar en {model}.",
                "unlink": f"Su perfil de Odoo no tiene permisos para eliminar en {model}.",
                "read": f"Su perfil de Odoo no tiene permisos para ver {model}.",
            }
            raise JAIOSException(message or default_msg.get(operation, "Permiso denegado en Odoo"), code="ODOO_PERMISSION_DENIED")

        from app.services.odoo_config_resolver import resolve_odoo_read_only

        if await resolve_odoo_read_only(self.db, self.tenant_id) and operation in ("create", "write", "unlink"):
            raise JAIOSException(
                "JAIOS está en modo solo lectura. El administrador puede habilitar escritura en Configuración → Integraciones → Odoo.",
                code="ODOO_READ_ONLY",
            )
        return cache  # type: ignore[return-value]

    async def require_module(self, module: str) -> None:
        cache = await self._get_cache()
        if self._is_stale(cache):
            await self.sync_permissions()
            cache = await self._get_cache()
        if not cache or not cache.module_access.get(module, {}).get("enabled"):
            label = MODULE_LABELS.get(module, module)
            raise JAIOSException(
                f"Su perfil de Odoo no tiene acceso al módulo: {label}.",
                code="ODOO_MODULE_DENIED",
            )

    async def permissions_summary(self) -> dict:
        perms = await self.get_permissions()
        if not perms:
            return {
                "linked": False,
                "modules": {},
                "can_create_quotation": False,
                "can_create_task": False,
                "can_create_customer": False,
                "can_view_accounting": False,
            }
        ma = perms.get("model_access", {})
        return {
            "linked": True,
            "synced_at": perms.get("synced_at"),
            "groups": perms.get("groups", []),
            "modules": perms.get("module_access", {}),
            "can_create_quotation": bool(ma.get("sale.order", {}).get("create")),
            "can_create_task": bool(ma.get("project.task", {}).get("create")),
            "can_create_customer": bool(ma.get("res.partner", {}).get("create")),
            "can_view_accounting": bool(ma.get("account.move", {}).get("read")),
            "can_edit_customer": bool(ma.get("res.partner", {}).get("write")),
            "can_view_sales": bool(perms.get("module_access", {}).get("sales", {}).get("enabled")),
        }
