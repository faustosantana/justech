"""Resuelve configuración Omega desde tenant settings + .env."""

from __future__ import annotations

import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.integration_settings import TenantIntegrationSetting
from app.services.credential_vault import decrypt_secret
from integrations.suppliers.config import OmegaConnectorConfig


def _parse_bool(val) -> bool:
    if isinstance(val, bool):
        return val
    if val in (None, ""):
        return False
    return str(val).lower() in ("1", "true", "yes", "on")


async def resolve_omega_config(db: AsyncSession, tenant_id: uuid.UUID) -> OmegaConnectorConfig:
    result = await db.execute(
        select(TenantIntegrationSetting).where(
            TenantIntegrationSetting.tenant_id == tenant_id,
            TenantIntegrationSetting.provider == "omega",
        )
    )
    row = result.scalar_one_or_none()
    cfg = dict(row.config) if row else {}
    secrets = dict(row.secrets_encrypted) if row else {}

    def secret(key: str, env_attr: str = "") -> str:
        if secrets.get(key):
            try:
                return decrypt_secret(secrets[key])
            except ValueError:
                pass
        if env_attr:
            return getattr(settings, env_attr, "") or ""
        return ""

    return OmegaConnectorConfig(
        enabled=_parse_bool(cfg.get("enabled", settings.omega_enabled)),
        store_url=(cfg.get("store_url") or settings.omega_store_url or "https://vip.omega.com.do").strip(),
        locale=(cfg.get("locale") or settings.omega_locale or "es").strip(),
        currency=(cfg.get("currency") or settings.omega_currency or "USD").strip(),
        username=(cfg.get("username") or settings.omega_username or "").strip(),
        password=secret("password", "omega_password"),
        rate_limit_per_minute=int(cfg.get("rate_limit_per_minute") or settings.omega_rate_limit_per_minute),
        cache_ttl_seconds=int(cfg.get("cache_ttl_seconds") or settings.omega_cache_ttl_seconds),
        demo_mode=_parse_bool(cfg.get("demo_mode", settings.omega_demo_mode)),
        source="database" if row else "env",
    )
