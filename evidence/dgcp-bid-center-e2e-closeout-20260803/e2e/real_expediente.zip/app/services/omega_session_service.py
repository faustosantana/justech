"""Sesión Omega tienda (cookies) en Redis por tenant."""

from __future__ import annotations

import json
import time
import uuid
from datetime import UTC, datetime
from typing import Any

from app.core.redis_client import get_redis

SESSION_PREFIX = "jaios:omega:session:"
SESSION_TTL_SECONDS = 8 * 3600


class OmegaSessionService:
    def _session_key(self, tenant_id: uuid.UUID) -> str:
        return f"{SESSION_PREFIX}{tenant_id}"

    async def get_session(self, tenant_id: uuid.UUID) -> dict[str, Any] | None:
        redis = await get_redis()
        raw = await redis.get(self._session_key(tenant_id))
        if not raw:
            return None
        data = json.loads(raw)
        if data.get("expires_at", 0) < time.time():
            await self.clear_session(tenant_id)
            return None
        return data

    async def save_session(
        self,
        tenant_id: uuid.UUID,
        *,
        cookies: list[dict[str, str]],
        username: str,
        ttl_seconds: int = SESSION_TTL_SECONDS,
    ) -> dict[str, Any]:
        payload = {
            "username": username,
            "cookies": cookies,
            "created_at": datetime.now(UTC).isoformat(),
            "expires_at": time.time() + ttl_seconds,
        }
        redis = await get_redis()
        await redis.set(
            self._session_key(tenant_id),
            json.dumps(payload, ensure_ascii=False),
            ex=ttl_seconds,
        )
        return payload

    async def clear_session(self, tenant_id: uuid.UUID) -> None:
        redis = await get_redis()
        await redis.delete(self._session_key(tenant_id))

    async def session_status(self, tenant_id: uuid.UUID) -> dict[str, Any]:
        session = await self.get_session(tenant_id)
        if not session:
            return {"session_active": False}
        expires = datetime.fromtimestamp(session["expires_at"], tz=UTC)
        return {
            "session_active": True,
            "expires_at": expires.isoformat(),
            "username": session.get("username"),
        }
