"""Resuelve el catálogo de aplicaciones visibles para el usuario autenticado."""

from __future__ import annotations

import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.module_access import (
    MODULE_PRICES,
    MODULE_SUPPLIERS,
    platform_access,
    tenant_module_enabled,
)
from app.platform.app_catalog import APP_CATALOG, AppCatalogEntry
from app.schemas.platform_modules import PlatformModuleCatalogResponse, PlatformModuleItem


def _has_any_perm(permissions: set[str], required: tuple[str, ...]) -> bool:
    if not required:
        return True
    return any(p in permissions for p in required)


def _permission_ok(entry: AppCatalogEntry, access: dict) -> bool:
    perms = set(access.get("permissions") or [])
    if entry.admin_only:
        return bool(access.get("can_view_admin"))
    if entry.module_key == "precios":
        return bool(access.get("can_view_prices"))
    if entry.module_key == "proveedores":
        return bool(access.get("can_view_suppliers"))
    if entry.module_key in {"documentos", "empresas-grupo"}:
        return _has_any_perm(perms, ("view_documents", "view_modules"))
    if entry.module_key == "agentes-ia":
        return _has_any_perm(perms, ("view_assistant", "view_modules"))
    if entry.module_key == "lottery":
        return _has_any_perm(perms, ("lottery.access", "lottery_view", "view_modules"))
    if entry.required_permissions:
        return _has_any_perm(perms, entry.required_permissions)
    return "view_modules" in perms


def _passes_allowed_modules(module_key: str, access: dict) -> bool:
    allowed = access.get("allowed_modules")
    if allowed is None or len(allowed) == 0:
        return True
    aliases = {
        "precios": MODULE_PRICES,
        "proveedores": MODULE_SUPPLIERS,
    }
    key = aliases.get(module_key, module_key)
    return module_key in allowed or key in allowed


async def build_module_catalog(
    db: AsyncSession,
    *,
    tenant_id: uuid.UUID,
    user_id: uuid.UUID,
    role: str | None,
    is_superadmin: bool = False,
    correlation_id: str | None = None,
    include_hidden: bool = False,
) -> PlatformModuleCatalogResponse:
    access = await platform_access(
        db, tenant_id, user_id, role, is_superadmin=is_superadmin,
    )
    items: list[PlatformModuleItem] = []

    for entry in APP_CATALOG:
        tenant_key = entry.tenant_module_key
        enabled = True
        if tenant_key:
            enabled = await tenant_module_enabled(db, tenant_id, tenant_key)

        perm_ok = _permission_ok(entry, access) and _passes_allowed_modules(entry.module_key, access)

        if entry.coming_soon:
            status = "coming_soon"
            route: str | None = None
        elif not enabled:
            status = "disabled"
            route = entry.route or None
        elif not perm_ok:
            status = "forbidden"
            route = entry.route or None
        else:
            status = "available"
            route = entry.route or None

        # forbidden se oculta (el menú no debe tentar rutas sin permiso).
        if status == "forbidden" and not include_hidden:
            continue

        items.append(
            PlatformModuleItem(
                module_key=entry.module_key,
                name=entry.name,
                description=entry.description,
                route=route if status == "available" else (None if status == "coming_soon" else route),
                order=entry.order,
                status=status,
                enabled=enabled and status == "available",
                badge=entry.badge,
                beta=entry.beta,
                icon_key=entry.icon_key,
                required_permissions=list(entry.required_permissions),
            )
        )

    items.sort(key=lambda m: m.order)
    return PlatformModuleCatalogResponse(items=items, correlation_id=correlation_id)
