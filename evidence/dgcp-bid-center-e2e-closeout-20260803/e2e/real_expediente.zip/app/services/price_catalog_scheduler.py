"""Scheduler — sincronización periódica de catálogos de precios (martes y viernes)."""

from __future__ import annotations

import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy import select

from app.db.session import AsyncSessionLocal
from app.models.price_catalog_sync import PriceCatalogSyncSchedule
from app.services.price_catalog_sync_service import PriceCatalogSyncService

logger = logging.getLogger(__name__)
_scheduler: AsyncIOScheduler | None = None


async def _run_due_catalog_syncs() -> None:
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(PriceCatalogSyncSchedule).where(PriceCatalogSyncSchedule.is_enabled.is_(True))
        )
        schedules = list(result.scalars().all())
        if not schedules:
            return

        for schedule in schedules:
            svc = PriceCatalogSyncService(db, schedule.tenant_id)
            if not svc.is_due(schedule):
                continue
            try:
                job = await svc.run_sync(trigger="scheduled")
                logger.info(
                    "Price catalog sync tenant=%s job=%s status=%s",
                    schedule.tenant_id,
                    job.id,
                    job.status,
                )
            except Exception:
                logger.exception("Price catalog sync failed tenant=%s", schedule.tenant_id)


def start_price_catalog_scheduler() -> AsyncIOScheduler:
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = AsyncIOScheduler()
    _scheduler.add_job(_run_due_catalog_syncs, "interval", hours=1, id="price_catalog_sync_check")
    _scheduler.start()
    logger.info("Price catalog scheduler started (hourly check, daily default 04:00 UTC)")
    return _scheduler


def stop_price_catalog_scheduler() -> None:
    global _scheduler
    if _scheduler:
        _scheduler.shutdown(wait=False)
        _scheduler = None
        logger.info("Price catalog scheduler stopped")
