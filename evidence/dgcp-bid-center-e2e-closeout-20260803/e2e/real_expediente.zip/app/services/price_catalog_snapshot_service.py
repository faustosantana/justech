"""Persistencia de snapshots de catálogo desde conectores live (sin modificar conectores)."""

from __future__ import annotations

import hashlib
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.price_list import PriceListFile, PriceListProduct
from app.schemas.prices import PriceProductResponse
from app.services.supplier_connector_service import SupplierConnectorService

CATALOG_SEED_QUERIES = (
    "notebook",
    "monitor",
    "server",
    "switch",
    "printer",
    "dell",
    "hp",
    "lenovo",
    "cisco",
    "ssd",
    "laptop",
)

PROVIDER_META = {
    "omega": {"supplier": "Omega Tech", "origin": "omega_vip", "label": "omega_catalog"},
    "ingram": {"supplier": "Ingram Micro", "origin": "ingram_api", "label": "ingram_catalog"},
    "cecomsa": {"supplier": "Cecomsa", "origin": "cecomsa_shop", "label": "cecomsa_catalog"},
}

FULL_CATALOG_PROVIDERS = frozenset({"omega", "cecomsa"})


@dataclass
class CatalogSnapshotReport:
    provider: str
    products_indexed: int = 0
    products_new: int = 0
    price_changes: int = 0
    discontinued: int = 0
    errors: list[str] = field(default_factory=list)
    skipped: bool = False
    skip_reason: str | None = None
    sync_mode: str | None = None


def catalog_key(supplier: str, sku: str | None, mpn: str | None, description: str | None) -> str:
    token = (sku or mpn or (description or "")[:100]).strip().lower()
    return f"{supplier.lower()}:{token}"[:160]


class PriceCatalogSnapshotService:
    """Indexa catálogos completos o snapshots de conectores como índice local versionado."""

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._connectors = SupplierConnectorService(db, tenant_id)

    async def sync_provider(self, provider: str, *, per_query_limit: int = 40) -> CatalogSnapshotReport:
        meta = PROVIDER_META.get(provider)
        if not meta:
            return CatalogSnapshotReport(provider=provider, skipped=True, skip_reason="Proveedor no soportado")

        if provider in FULL_CATALOG_PROVIDERS:
            return await self._sync_full_catalog(provider, meta)

        return await self._sync_seed_queries(provider, meta, per_query_limit=per_query_limit)

    async def _sync_full_catalog(self, provider: str, meta: dict) -> CatalogSnapshotReport:
        report = CatalogSnapshotReport(provider=provider, sync_mode="full_catalog")
        status = await (
            self._connectors.omega_status()
            if provider == "omega"
            else self._connectors.cecomsa_status()
        )
        if not status.get("enabled"):
            report.skipped = True
            report.skip_reason = "Conector deshabilitado"
            return report

        if provider == "omega":
            sync_result = await self._connectors.sync_omega_catalog()
        else:
            sync_result = await self._connectors.sync_cecomsa_catalog()

        report.errors.extend(sync_result.get("errors") or [])
        if sync_result.get("message") and not sync_result.get("ok"):
            report.errors.append(sync_result["message"])

        items: list[PriceProductResponse] = sync_result.get("items") or []
        if not items:
            report.skipped = True
            report.skip_reason = sync_result.get("message") or "Sin productos obtenidos del conector"
            return report

        report.sync_mode = sync_result.get("mode") or "full_catalog"
        return await self._persist_catalog(provider, meta, items, report, audit_extra={"full_catalog": True})

    async def _sync_seed_queries(self, provider: str, meta: dict, *, per_query_limit: int) -> CatalogSnapshotReport:
        report = CatalogSnapshotReport(provider=provider, sync_mode="seed_queries")
        status = await (
            self._connectors.omega_status() if provider == "omega" else self._connectors.ingram_status()
        )
        if not status.get("enabled"):
            report.skipped = True
            report.skip_reason = "Conector deshabilitado"
            return report

        collected: dict[str, PriceProductResponse] = {}
        for query in CATALOG_SEED_QUERIES:
            try:
                if provider == "omega":
                    resp = await self._connectors.search_omega(query, limit=per_query_limit, use_cache=False)
                else:
                    resp = await self._connectors.search_ingram(query, limit=per_query_limit, use_cache=False)
                if resp.status in ("disabled", "auth_failed", "awaiting_mfa", "error"):
                    if resp.message:
                        report.errors.append(f"{query}: {resp.message}")
                    continue
                for item in resp.items:
                    key = catalog_key(meta["supplier"], item.sku, item.mpn, item.description)
                    if key not in collected:
                        collected[key] = item
            except Exception as exc:
                report.errors.append(f"{query}: {exc}")

        if not collected:
            report.skipped = True
            report.skip_reason = "Sin productos obtenidos del conector"
            return report

        return await self._persist_catalog(
            provider,
            meta,
            list(collected.values()),
            report,
            audit_extra={"seed_queries": list(CATALOG_SEED_QUERIES)},
        )

    async def _persist_catalog(
        self,
        provider: str,
        meta: dict,
        items: list[PriceProductResponse],
        report: CatalogSnapshotReport,
        *,
        audit_extra: dict,
    ) -> CatalogSnapshotReport:
        collected: dict[str, PriceProductResponse] = {}
        for item in items:
            key = catalog_key(meta["supplier"], item.sku, item.mpn, item.description)
            if key not in collected:
                collected[key] = item

        now = datetime.now(timezone.utc)
        rel_path = f"catalog_sync/{provider}/{now.strftime('%Y%m%d_%H%M%S')}.snapshot"
        content_hash = hashlib.sha256(
            "|".join(sorted(f"{k}:{p.preferred_price}" for k, p in collected.items())).encode()
        ).hexdigest()

        previous_keys = await self._previous_catalog_keys(provider, meta["supplier"])
        new_keys = set(collected.keys())
        report.products_new = len(new_keys - previous_keys)
        report.discontinued = len(previous_keys - new_keys)

        prev_prices = await self._previous_prices(provider, meta["supplier"])
        for key, item in collected.items():
            old_price = prev_prices.get(key)
            if old_price is not None and item.preferred_price is not None and old_price != item.preferred_price:
                report.price_changes += 1

        await self._retire_previous_catalog(provider)

        file_row = PriceListFile(
            tenant_id=self.tenant_id,
            supplier=meta["supplier"],
            manufacturer=None,
            filename=f"{provider}_catalog.snapshot",
            relative_path=rel_path,
            file_modified_at=now,
            file_date_estimated=False,
            indexed_at=now,
            content_hash=content_hash,
            version=1,
            total_records=len(collected),
            status="indexed",
            errors=report.errors,
            audit_json=[{"provider": provider, **audit_extra}],
            is_current=True,
            processing_status="catalog_sync",
        )
        self.db.add(file_row)
        await self.db.flush()

        batch: list[PriceListProduct] = []
        for key, item in collected.items():
            batch.append(self._to_product_row(item, file_row=file_row, meta=meta, catalog_key=key, now=now))
            if len(batch) >= 400:
                self.db.add_all(batch)
                await self.db.flush()
                batch.clear()
        if batch:
            self.db.add_all(batch)
            await self.db.flush()

        report.products_indexed = len(collected)
        return report

    async def _previous_catalog_keys(self, provider: str, supplier: str) -> set[str]:
        rows = await self._previous_catalog_rows(provider, supplier)
        return {r.catalog_key for r in rows if r.catalog_key}

    async def _previous_prices(self, provider: str, supplier: str) -> dict[str, Decimal]:
        rows = await self._previous_catalog_rows(provider, supplier)
        return {r.catalog_key: r.preferred_price for r in rows if r.catalog_key and r.preferred_price is not None}

    async def _previous_catalog_rows(self, provider: str, supplier: str) -> list[PriceListProduct]:
        stmt = (
            select(PriceListProduct)
            .join(PriceListFile, PriceListProduct.file_id == PriceListFile.id)
            .where(
                PriceListProduct.tenant_id == self.tenant_id,
                PriceListProduct.is_current.is_(True),
                PriceListProduct.source_sheet == "catalog_sync",
                PriceListProduct.supplier == supplier,
                PriceListFile.relative_path.like(f"catalog_sync/{provider}/%"),
            )
        )
        return list((await self.db.execute(stmt)).scalars().all())

    async def _retire_previous_catalog(self, provider: str) -> None:
        files = list(
            (
                await self.db.execute(
                    select(PriceListFile).where(
                        PriceListFile.tenant_id == self.tenant_id,
                        PriceListFile.is_current.is_(True),
                        PriceListFile.relative_path.like(f"catalog_sync/{provider}/%"),
                    )
                )
            ).scalars().all()
        )
        for f in files:
            await self.db.execute(update(PriceListFile).where(PriceListFile.id == f.id).values(is_current=False))
            await self.db.execute(
                update(PriceListProduct).where(PriceListProduct.file_id == f.id).values(is_current=False)
            )

    @staticmethod
    def _to_product_row(
        item: PriceProductResponse,
        *,
        file_row: PriceListFile,
        meta: dict,
        catalog_key: str,
        now: datetime,
    ) -> PriceListProduct:
        blob = " ".join(
            p for p in (item.description, item.sku, item.mpn, item.brand, item.supplier) if p
        ).lower()
        return PriceListProduct(
            tenant_id=file_row.tenant_id,
            file_id=file_row.id,
            version=file_row.version,
            is_current=True,
            supplier=meta["supplier"],
            manufacturer=item.manufacturer or item.brand,
            sku=item.sku,
            mpn=item.mpn,
            model=item.model,
            description=item.description,
            category=item.category or "catalog",
            product_type=item.product_type or "general",
            brand=item.brand,
            processor=item.processor,
            ram_gb=item.ram_gb,
            storage_gb=item.storage_gb,
            storage_type=item.storage_type,
            display=item.display,
            operating_system=item.operating_system,
            price=item.preferred_price or item.price,
            preferred_price=item.preferred_price or item.price,
            preferred_price_field="catalog_sync",
            currency=item.currency or "USD",
            stock=item.stock,
            in_transit=item.in_transit,
            raw_row_json={"catalog_snapshot": True, "live_source": item.source_filename},
            raw_columns_json=[],
            search_blob=blob[:4000],
            is_commercial=True,
            excluded_from_laptop=item.excluded_from_laptop,
            is_cotizable=bool(item.preferred_price or item.price),
            price_review_status="ok",
            classification_label=meta["label"],
            source_filename=item.source_filename or f"{meta['supplier']}_catalog",
            source_sheet="catalog_sync",
            source_row=None,
            source_file_date=now,
            indexed_at=now,
            source_origin=meta["origin"],
            source_url=None,
            product_status="active",
            catalog_key=catalog_key,
            updated_at=now,
        )
