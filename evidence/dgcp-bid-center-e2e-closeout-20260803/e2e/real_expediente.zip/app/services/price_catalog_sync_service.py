"""Orquestador de sincronización periódica de catálogos de precios."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.integration_settings import IntegrationRepositoryBinding
from app.models.price_catalog_sync import PriceCatalogSyncJob, PriceCatalogSyncSchedule
from app.services.price_catalog_snapshot_service import PriceCatalogSnapshotService
from app.services.price_list_indexer import PriceListIndexer
from app.services.supplier_price_file_service import SupplierPriceFileService


class PriceCatalogSyncService:
    DEFAULT_SYNC_DAYS = [1, 2, 3, 4, 5, 6, 7]  # diario

    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    async def get_or_create_schedule(self) -> PriceCatalogSyncSchedule:
        result = await self.db.execute(
            select(PriceCatalogSyncSchedule).where(PriceCatalogSyncSchedule.tenant_id == self.tenant_id)
        )
        schedule = result.scalar_one_or_none()
        if schedule:
            return schedule
        now = datetime.now(UTC)
        schedule = PriceCatalogSyncSchedule(
            tenant_id=self.tenant_id,
            is_enabled=True,
            sync_days=list(self.DEFAULT_SYNC_DAYS),
            sync_hour_utc=4,
            include_file_lists=True,
            include_omega=False,
            include_ingram=False,
            include_cecomsa=False,
            next_run_at=self._compute_next_run(now, self.DEFAULT_SYNC_DAYS, 4),
        )
        self.db.add(schedule)
        await self.db.flush()
        return schedule

    async def update_schedule(self, **fields) -> PriceCatalogSyncSchedule:
        schedule = await self.get_or_create_schedule()
        for key, value in fields.items():
            if value is not None and hasattr(schedule, key):
                setattr(schedule, key, value)
        schedule.next_run_at = self._compute_next_run(
            datetime.now(UTC),
            schedule.sync_days or self.DEFAULT_SYNC_DAYS,
            schedule.sync_hour_utc,
        )
        await self.db.flush()
        return schedule

    async def list_jobs(self, *, limit: int = 20) -> list[PriceCatalogSyncJob]:
        result = await self.db.execute(
            select(PriceCatalogSyncJob)
            .where(PriceCatalogSyncJob.tenant_id == self.tenant_id)
            .order_by(PriceCatalogSyncJob.started_at.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def run_sync(self, *, trigger: str = "manual") -> PriceCatalogSyncJob:
        schedule = await self.get_or_create_schedule()
        started = datetime.now(UTC)
        job = PriceCatalogSyncJob(
            tenant_id=self.tenant_id,
            trigger=trigger,
            status="running",
            started_at=started,
            summary={},
            errors=[],
        )
        self.db.add(job)
        await self.db.flush()

        summary: dict = {"providers": {}, "file_lists": {}}
        errors: list[str] = []

        try:
            if schedule.include_file_lists:
                file_summary: dict = {"local_fs": {}, "onedrive_entradas": []}
                indexer = PriceListIndexer(self.db, self.tenant_id)
                file_report = await indexer.sync()
                file_summary["local_fs"] = {
                    "files_detected": file_report.files_detected,
                    "files_new": file_report.files_new,
                    "files_updated": file_report.files_updated,
                    "files_unchanged": file_report.files_unchanged,
                    "records_created": file_report.records_created,
                    "duration_ms": file_report.duration_ms,
                }
                errors.extend(file_report.errors)

                bindings = list(
                    (
                        await self.db.execute(
                            select(IntegrationRepositoryBinding).where(
                                IntegrationRepositoryBinding.tenant_id == self.tenant_id,
                                IntegrationRepositoryBinding.auto_sync.is_(True),
                                IntegrationRepositoryBinding.repository_type == "price_inbox",
                            )
                        )
                    ).scalars().all()
                )
                price_svc = SupplierPriceFileService(self.db, self.tenant_id)
                for binding in bindings:
                    try:
                        od_result = await price_svc.process_inbox(binding.id)
                        file_summary["onedrive_entradas"].append({
                            "folder": binding.folder_key,
                            "path": binding.folder_path,
                            **od_result,
                        })
                        errors.extend(od_result.get("errors") or [])
                    except Exception as exc:
                        errors.append(f"OneDrive {binding.folder_key}: {exc}")

                summary["file_lists"] = file_summary

            snapshot_svc = PriceCatalogSnapshotService(self.db, self.tenant_id)
            if schedule.include_omega:
                omega_report = await snapshot_svc.sync_provider("omega")
                summary["providers"]["omega"] = {
                    "indexed": omega_report.products_indexed,
                    "new": omega_report.products_new,
                    "price_changes": omega_report.price_changes,
                    "discontinued": omega_report.discontinued,
                    "skipped": omega_report.skipped,
                    "skip_reason": omega_report.skip_reason,
                    "sync_mode": omega_report.sync_mode,
                }
                errors.extend(omega_report.errors)

            if schedule.include_ingram:
                ingram_report = await snapshot_svc.sync_provider("ingram")
                summary["providers"]["ingram"] = {
                    "indexed": ingram_report.products_indexed,
                    "new": ingram_report.products_new,
                    "price_changes": ingram_report.price_changes,
                    "discontinued": ingram_report.discontinued,
                    "skipped": ingram_report.skipped,
                    "skip_reason": ingram_report.skip_reason,
                }
                errors.extend(ingram_report.errors)

            if schedule.include_cecomsa:
                cecomsa_report = await snapshot_svc.sync_provider("cecomsa")
                summary["providers"]["cecomsa"] = {
                    "indexed": cecomsa_report.products_indexed,
                    "new": cecomsa_report.products_new,
                    "price_changes": cecomsa_report.price_changes,
                    "discontinued": cecomsa_report.discontinued,
                    "skipped": cecomsa_report.skipped,
                    "skip_reason": cecomsa_report.skip_reason,
                    "sync_mode": cecomsa_report.sync_mode,
                }
                errors.extend(cecomsa_report.errors)

            finished = datetime.now(UTC)
            job.status = "completed"
            job.finished_at = finished
            job.duration_ms = int((finished - started).total_seconds() * 1000)
            job.summary = summary
            job.errors = errors[:50]

            schedule.last_run_at = finished
            schedule.next_run_at = self._compute_next_run(
                finished,
                schedule.sync_days or self.DEFAULT_SYNC_DAYS,
                schedule.sync_hour_utc,
            )
            await self.db.commit()
        except Exception as exc:
            job.status = "failed"
            job.finished_at = datetime.now(UTC)
            job.errors = [str(exc)]
            await self.db.commit()
            raise

        return job

    @staticmethod
    def _compute_next_run(from_dt: datetime, sync_days: list[int], hour_utc: int) -> datetime:
        days = sorted({int(d) for d in (sync_days or PriceCatalogSyncService.DEFAULT_SYNC_DAYS) if 0 <= int(d) <= 6})
        if not days:
            days = PriceCatalogSyncService.DEFAULT_SYNC_DAYS
        base = from_dt.astimezone(UTC)
        for offset in range(0, 8):
            candidate = base + timedelta(days=offset)
            if candidate.isoweekday() in days:
                scheduled = candidate.replace(hour=hour_utc, minute=0, second=0, microsecond=0)
                if scheduled <= base:
                    continue
                return scheduled
        return base + timedelta(days=7)

    @staticmethod
    def is_due(schedule: PriceCatalogSyncSchedule, now: datetime | None = None) -> bool:
        if not schedule.is_enabled or not schedule.next_run_at:
            return False
        now = now or datetime.now(UTC)
        nxt = schedule.next_run_at
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=UTC)
        return now >= nxt
