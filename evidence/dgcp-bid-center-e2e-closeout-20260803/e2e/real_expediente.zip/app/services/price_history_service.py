"""Histórico de precios desde versiones indexadas de listas."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.price_list import PriceListProduct
from app.schemas.prices import PriceHistoryPoint, PriceHistoryResponse


class PriceHistoryService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id

    async def get_history(self, product_id: uuid.UUID) -> PriceHistoryResponse | None:
        current = await self.db.get(PriceListProduct, product_id)
        if not current or current.tenant_id != self.tenant_id:
            return None

        keys = [k for k in (current.sku, current.mpn, current.model) if k]
        if not keys and current.catalog_key:
            clauses = [PriceListProduct.catalog_key == current.catalog_key]
        else:
            clauses = []
            if current.sku:
                clauses.append(PriceListProduct.sku == current.sku)
            if current.mpn:
                clauses.append(PriceListProduct.mpn == current.mpn)
            if current.model:
                clauses.append(PriceListProduct.model == current.model)

        stmt = (
            select(PriceListProduct)
            .where(
                PriceListProduct.tenant_id == self.tenant_id,
                or_(*clauses) if clauses else PriceListProduct.id == product_id,
                PriceListProduct.preferred_price.is_not(None),
            )
            .order_by(PriceListProduct.source_file_date.desc().nullslast(), PriceListProduct.indexed_at.desc())
            .limit(50)
        )
        rows = list((await self.db.execute(stmt)).scalars().all())

        points: list[PriceHistoryPoint] = []
        seen_dates: set[str] = set()
        for row in rows:
            dt = row.source_file_date or row.indexed_at
            if not dt:
                continue
            key = dt.date().isoformat()
            if key in seen_dates:
                continue
            seen_dates.add(key)
            points.append(
                PriceHistoryPoint(
                    date=dt,
                    price=row.preferred_price,
                    currency=row.currency,
                    supplier=row.supplier,
                    source_filename=row.source_filename,
                    is_current=row.is_current,
                )
            )

        trend = self._trend(points)
        now = datetime.now(timezone.utc)
        p30 = self._price_at_days(points, 30, now)
        p90 = self._price_at_days(points, 90, now)
        p180 = self._price_at_days(points, 180, now)

        return PriceHistoryResponse(
            product_id=product_id,
            sku=current.sku,
            mpn=current.mpn,
            current_price=current.preferred_price,
            currency=current.currency,
            trend=trend,
            price_30d_ago=p30,
            price_90d_ago=p90,
            price_180d_ago=p180,
            points=points[:20],
        )

    @staticmethod
    def _trend(points: list[PriceHistoryPoint]) -> str:
        if len(points) < 2:
            return "estable"
        recent = points[0].price
        older = points[min(len(points) - 1, 3)].price
        if recent is None or older is None:
            return "estable"
        if recent < older * Decimal("0.98"):
            return "bajando"
        if recent > older * Decimal("1.02"):
            return "subiendo"
        return "estable"

    @staticmethod
    def _price_at_days(points: list[PriceHistoryPoint], days: int, now: datetime) -> Decimal | None:
        target = now - timedelta(days=days)
        best = None
        best_delta = None
        for pt in points:
            if pt.date is None or pt.price is None:
                continue
            d = pt.date if pt.date.tzinfo else pt.date.replace(tzinfo=timezone.utc)
            delta = abs((d - target).total_seconds())
            if best_delta is None or delta < best_delta:
                best_delta = delta
                best = pt.price
        return best
