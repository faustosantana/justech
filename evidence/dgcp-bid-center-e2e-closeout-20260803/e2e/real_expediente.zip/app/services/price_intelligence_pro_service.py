"""Price Intelligence Pro — motor sobre listas indexadas."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.prices import (
    CommercialSearchIntentResponse,
    DGCPPriceAnalysisResponse,
    DGCPPriceLineAnalysis,
    PriceAlternativeProduct,
    PriceCompareProResponse,
    PriceHistoryResponse,
    PriceProductResponse,
    PriceRecommendation,
    PriceSearchResponse,
    PriceSupplierOffer,
)
from app.services.price_history_service import PriceHistoryService
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters
from app.services.price_margin_engine import MarginConfig, PriceMarginEngine
from app.services.price_product_matcher import (
    ALTERNATIVE_BRANDS,
    extract_dgcp_line_items,
    filters_from_requirement,
    parse_requirement_line,
)
from app.services.price_supplier_scorer import score_supplier_offer
from app.services.commercial_search import CommercialSearchEngine, CommercialSearchOptions
from app.services.commercial_search.intent import detect_search_intent
from app.services.commercial_search.live_query_expander import expand_live_queries


@dataclass
class CommercialSourceFlags:
    include_indexed: bool = True
    include_historical: bool = True
    include_ingram: bool = False
    include_omega: bool = False


class PriceIntelligenceProService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._base = PriceIntelligenceService(db, tenant_id)
        self._margin = PriceMarginEngine()
        self._history = PriceHistoryService(db, tenant_id)

    async def fetch_from_sources(
        self,
        filters: PriceSearchFilters,
        *,
        sources: CommercialSourceFlags,
        live_query: str | None = None,
        live_queries: list[str] | None = None,
    ) -> tuple[list[PriceProductResponse], list[str], list[str], list[str]]:
        """Consulta todas las fuentes seleccionadas y devuelve candidatos unificados."""
        candidates: list[PriceProductResponse] = []
        warnings: list[str] = []
        live_providers: list[str] = []
        sources_consulted: list[str] = []
        seen_keys: dict[str, int] = {}

        def _add_item(item: PriceProductResponse) -> None:
            key = f"{(item.supplier or '').lower()}:{(item.sku or item.description or '').lower()[:120]}"
            if key in seen_keys:
                idx = seen_keys[key]
                existing = candidates[idx]
                if item.stock is not None and (existing.stock is None or existing.stock == 0):
                    candidates[idx] = existing.model_copy(update={"stock": item.stock})
                if item.preferred_price is not None and existing.preferred_price is None:
                    candidates[idx] = candidates[idx].model_copy(
                        update={"preferred_price": item.preferred_price, "price": item.price}
                    )
                return
            seen_keys[key] = len(candidates)
            candidates.append(item)

        indexed_limit = max(15, filters.limit // 2) if (sources.include_ingram or sources.include_omega) else filters.limit

        if sources.include_indexed:
            indexed_filters = PriceSearchFilters(**{**filters.__dict__, "current_lists_only": True, "limit": indexed_limit})
            result = await self._base.search(indexed_filters)
            sources_consulted.append("indexed")
            for item in result.items:
                _add_item(item)

        if sources.include_historical:
            hist_filters = PriceSearchFilters(**{**filters.__dict__, "current_lists_only": False, "limit": indexed_limit})
            result = await self._base.search(hist_filters)
            sources_consulted.append("historical")
            for item in result.items:
                tagged = item.model_copy(
                    update={
                        "classification_label": "base_histórica",
                        "source_filename": item.source_filename or "base_histórica",
                    }
                )
                _add_item(tagged)

        query_text = (live_query or filters.q or filters.brand or filters.category or "").strip()
        if not query_text and filters.brand:
            query_text = filters.brand.strip()
        if not query_text and filters.category:
            query_text = filters.category.strip()

        search_queries: list[str] = []
        if live_queries:
            search_queries = [q.strip() for q in live_queries if q and q.strip()]
        elif query_text:
            search_queries = [query_text]

        live_limit = min(15, max(8, filters.limit // len(search_queries) if search_queries else filters.limit))

        async def _safe_live(coro, provider: str) -> tuple[list, str | None]:
            import asyncio

            try:
                resp = await asyncio.wait_for(coro, timeout=50)
                return resp.items, None
            except asyncio.TimeoutError:
                return [], f"{provider}: tiempo de espera agotado — intente de nuevo."
            except Exception as exc:
                return [], f"{provider}: {exc}"

        if search_queries and (sources.include_ingram or sources.include_omega):
            from app.services.supplier_connector_service import SupplierConnectorService

            connectors = SupplierConnectorService(self.db, self.tenant_id)

            if sources.include_omega:
                omega_items: list = []
                for lq in search_queries:
                    items, err = await _safe_live(connectors.search_omega(lq, limit=live_limit), "Omega")
                    if items:
                        omega_items.extend(items)
                    elif err and lq == search_queries[0]:
                        warnings.append(err)
                sources_consulted.append("omega")
                if omega_items:
                    live_providers.append("omega")
                    for item in omega_items:
                        _add_item(item)
                    warnings.append("Precios Omega live — portal VIP; verificar antes de cotizar.")
                elif not omega_items:
                    msg = "Sin resultados en Omega VIP — verifique sesión en Integraciones."
                    warnings.append(f"Omega: {msg}")

            if sources.include_ingram:
                ingram_items: list = []
                for lq in search_queries:
                    items, err = await _safe_live(connectors.search_ingram(lq, limit=live_limit), "Ingram")
                    if items:
                        ingram_items.extend(items)
                    elif err and lq == search_queries[0]:
                        warnings.append(err)
                sources_consulted.append("ingram")
                if ingram_items:
                    live_providers.append("ingram")
                    for item in ingram_items:
                        _add_item(item)
                    warnings.append("Precios Ingram live — requiere verificación antes de cotizar.")
                elif not ingram_items:
                    warnings.append("Ingram: sin resultados live — verifique MFA en Integraciones de Proveedores.")

        if not sources_consulted:
            warnings.append("Seleccione al menos una fuente para consultar.")

        def _sort_key(p: PriceProductResponse) -> tuple:
            is_live = (p.source_sheet or "") == "live" or (p.source_filename or "").startswith(
                ("ingram:", "omega:", "omega_t", "omega_v")
            )
            has_stock = 1 if (p.stock or 0) > 0 else 0
            price = p.preferred_price or Decimal("999999")
            return (-int(is_live), -has_stock, price)

        candidates.sort(key=_sort_key)
        return candidates[: filters.limit], warnings, live_providers, sources_consulted

    async def search_commercial(
        self,
        filters: PriceSearchFilters,
        *,
        sources: CommercialSourceFlags,
        live_query: str | None = None,
        main_products_only: bool = True,
        include_accessories: bool = False,
        stock_only: bool = False,
    ) -> PriceSearchResponse:
        fetch_limit = max(filters.limit * 4, 80)
        fetch_filters = PriceSearchFilters(**{**filters.__dict__, "limit": fetch_limit})

        query_text = (live_query or filters.q or "").strip()
        if not query_text:
            query_text = " ".join(p for p in (filters.brand, filters.category) if p).strip()

        intent = detect_search_intent(query_text, main_products_only=main_products_only and not include_accessories) if query_text else None
        expanded_live = expand_live_queries(query_text, intent) if query_text else []

        raw_items, warnings, _, sources_consulted = await self.fetch_from_sources(
            fetch_filters,
            sources=sources,
            live_query=live_query,
            live_queries=expanded_live if expanded_live else None,
        )

        engine = CommercialSearchEngine()
        if query_text:
            result = engine.process(
                query_text,
                raw_items,
                options=CommercialSearchOptions(
                    main_products_only=main_products_only,
                    include_accessories=include_accessories,
                    stock_only=stock_only or bool(filters.stock_disponible),
                ),
                limit=filters.limit,
            )
            items = [s.product for s in result.items]
            all_warnings = list(warnings) + result.warnings
            intent_resp = CommercialSearchIntentResponse(
                intent=result.intent.intent,
                target_category=result.intent.target_category,
                category_label=result.intent.category_label,
                brand=result.intent.brand,
                model=result.intent.model,
                confidence=result.intent.confidence,
                main_products_only=result.intent.main_products_only,
            )
            return PriceSearchResponse(
                query=filters.q,
                total=len(items),
                items=items,
                sources_consulted=sources_consulted,
                warnings=all_warnings,
                search_intent=intent_resp,
                excluded_count=result.excluded_count,
                filter_explanation=result.filter_explanation,
            )

        return PriceSearchResponse(
            query=filters.q,
            total=len(raw_items[: filters.limit]),
            items=raw_items[: filters.limit],
            sources_consulted=sources_consulted,
            warnings=warnings,
        )

    async def compare_pro(
        self,
        requirement_text: str,
        *,
        quantity: int | None = None,
        target_margin_pct: Decimal = Decimal("20"),
        limit: int = 50,
        include_live: bool = True,
        include_omega_live: bool = True,
        include_indexed: bool = True,
        include_historical: bool = False,
    ) -> PriceCompareProResponse:
        parsed = parse_requirement_line(requirement_text)
        qty = quantity or parsed["quantity"] or 1
        filters = filters_from_requirement(requirement_text, limit=limit)

        if parsed["product_type"] == "laptop" or parsed["ram_gb"]:
            filters.product_type = "laptop"
            filters.commercial_only = True

        sources = CommercialSourceFlags(
            include_indexed=include_indexed,
            include_historical=include_historical,
            include_ingram=include_live,
            include_omega=include_omega_live,
        )
        fetch_filters = PriceSearchFilters(**{**filters.__dict__, "limit": max(limit * 4, 80)})
        req_intent = detect_search_intent(requirement_text, main_products_only=True)
        expanded = expand_live_queries(requirement_text, req_intent)
        candidates, warnings, live_providers, sources_consulted = await self.fetch_from_sources(
            fetch_filters,
            sources=sources,
            live_query=requirement_text,
            live_queries=expanded if expanded else None,
        )

        engine = CommercialSearchEngine()
        intel = engine.process(
            requirement_text,
            candidates,
            options=CommercialSearchOptions(main_products_only=True, include_accessories=False),
            limit=limit,
        )
        candidates = [s.product for s in intel.items]
        warnings = list(warnings) + intel.warnings

        cotizable = [
            p
            for p in candidates
            if p.preferred_price is not None
            and p.price_review_status == "ok"
            and p.is_cotizable
        ]
        if cotizable:
            candidates = cotizable
        else:
            candidates = [p for p in candidates if p.preferred_price is not None and p.price_review_status == "ok"]

        if not candidates:
            return PriceCompareProResponse(
                question=requirement_text,
                quantity=qty,
                offers=[],
                recommendation=None,
                alternatives=[],
                warnings=warnings
                or ["No hay productos en las fuentes seleccionadas. Sincronice listas o configure conectores."],
                summary="Sin datos disponibles.",
                data_source="indexed+live" if live_providers else "indexed_lists",
                live_providers=live_providers,
            )

        candidates.sort(key=lambda p: (p.preferred_price or Decimal("999999"), -(p.stock or 0)))

        cfg = MarginConfig(target_margin_pct=target_margin_pct)
        scored: list[tuple] = []
        for rank, product in enumerate(candidates[:15]):
            hist = await self._history.get_history(product.id)
            trend = hist.trend if hist else "estable"
            score, risk, reasons = score_supplier_offer(product, price_rank=rank, total_offers=len(candidates), quantity_needed=qty)
            margin = self._margin.calculate(product.preferred_price or Decimal("0"), currency=product.currency, quantity=qty, config=cfg)
            availability = None
            if product.stock is not None and qty > 0:
                availability = min(100.0, round((product.stock / qty) * 100, 1))
            eta = "inmediata" if (product.stock or 0) >= qty else ("parcial" if (product.stock or 0) > 0 else "verificar")
            scored.append((product, score, risk, reasons, margin, trend, availability, eta, rank))

        scored.sort(key=lambda x: (-x[1], x[8]))

        offers: list[PriceSupplierOffer] = []
        for product, score, risk, reasons, margin, trend, availability, eta, _ in scored[:10]:
            offers.append(
                PriceSupplierOffer(
                    product=product,
                    score=score,
                    risk_level=risk,
                    margin=margin.as_dict(),
                    price_trend=trend,
                    eta_label=eta,
                    availability_pct=availability,
                    reasons=reasons,
                )
            )

        alternatives = await self._find_alternatives(candidates[0] if candidates else None, filters, qty)

        recommendation = None
        if offers:
            best = offers[0]
            recommendation = PriceRecommendation(
                primary_supplier=best.product.supplier,
                primary_product_id=best.product.id,
                product_description=best.product.description or best.product.sku,
                confidence=min(98, best.score + 5),
                reasons=best.reasons[:5],
                estimated_margin_pct=Decimal(str(best.margin.get("margin_pct_actual"))) if best.margin.get("margin_pct_actual") is not None else None,
                risk_level=best.risk_level,
                sale_price_suggested=Decimal(str(best.margin.get("sale_price_suggested"))) if best.margin.get("sale_price_suggested") is not None else None,
                currency=best.product.currency,
            )

        if not any((o.product.stock or 0) >= qty for o in offers):
            warnings.append(f"Ningún proveedor confirma stock para {qty} unidad(es) en listas indexadas.")

        best_name = offers[0].product.supplier if offers else "—"
        summary = (
            f"Recomendación: {best_name} — {offers[0].product.description[:80] if offers else 'sin match'} "
            f"({offers[0].product.currency} {offers[0].product.preferred_price}, score {offers[0].score}/100). "
            f"Fuentes: {', '.join(sources_consulted) or 'listas indexadas'}."
            if offers
            else "Sin recomendación."
        )

        return PriceCompareProResponse(
            question=requirement_text,
            quantity=qty,
            offers=offers,
            recommendation=recommendation,
            alternatives=alternatives,
            warnings=warnings,
            summary=summary,
            data_source="indexed+live" if live_providers else "indexed_lists",
            live_providers=live_providers,
        )

    async def _find_alternatives(
        self,
        reference: PriceProductResponse | None,
        filters: PriceSearchFilters,
        qty: int,
    ) -> list[PriceAlternativeProduct]:
        if reference is None:
            return []
        brand = (reference.brand or "").lower()
        alt_brands = ALTERNATIVE_BRANDS.get(brand, [])
        if not alt_brands:
            return []

        alt_filters = PriceSearchFilters(
            product_type=reference.product_type or filters.product_type,
            ram_gb=reference.ram_gb or filters.ram_gb,
            storage_gb=reference.storage_gb or filters.storage_gb,
            commercial_only=True,
            limit=30,
        )
        search = await self._base.search(alt_filters)
        out: list[PriceAlternativeProduct] = []
        ref_brand = brand
        for p in search.items:
            pb = (p.brand or "").lower()
            if pb == ref_brand or pb not in alt_brands:
                continue
            if not p.is_cotizable or not p.preferred_price:
                continue
            compat = "alta" if p.ram_gb == reference.ram_gb and p.storage_gb == reference.storage_gb else "media"
            diff = []
            if p.ram_gb != reference.ram_gb:
                diff.append(f"RAM {p.ram_gb}GB vs {reference.ram_gb}GB")
            if p.storage_gb != reference.storage_gb:
                diff.append(f"Almacenamiento {p.storage_gb}GB vs {reference.storage_gb}GB")
            risk = "medio" if compat == "media" else "bajo"
            out.append(
                PriceAlternativeProduct(
                    brand=p.brand,
                    supplier=p.supplier,
                    description=p.description,
                    product_id=p.id,
                    price=p.preferred_price,
                    currency=p.currency,
                    stock=p.stock,
                    compatibility=compat,
                    risk_level=risk,
                    differences=diff,
                )
            )
            if len(out) >= 5:
                break
        return out

    async def product_history(self, product_id: uuid.UUID) -> PriceHistoryResponse | None:
        return await self._history.get_history(product_id)

    async def analyze_dgcp_opportunity(self, opportunity_id: uuid.UUID) -> DGCPPriceAnalysisResponse | None:
        opp = await self.db.get(DGCPOpportunity, opportunity_id)
        if not opp or opp.tenant_id != self.tenant_id:
            return None

        texts = [opp.title, opp.description or "", str(opp.full_info or {}), opp.objeto_proceso or ""]
        lines = extract_dgcp_line_items(*texts)
        if not lines:
            lines = [{"label": opp.title, **parse_requirement_line(opp.title)}]

        analyses: list[DGCPPriceLineAnalysis] = []
        total_cost = Decimal("0")
        total_sale = Decimal("0")
        currency = "USD"

        for line in lines:
            req_text = line.get("label") or line.get("raw") or opp.title
            compare = await self.compare_pro(req_text, quantity=line.get("quantity", 1))
            if compare.offers:
                currency = compare.offers[0].product.currency
                mc = compare.offers[0].margin.get("total_cost_all") or compare.offers[0].margin.get("total_cost")
                ms = compare.offers[0].margin.get("total_sale_all") or compare.offers[0].margin.get("sale_price_suggested")
                if mc:
                    total_cost += Decimal(str(mc))
                if ms:
                    total_sale += Decimal(str(ms))
            analyses.append(
                DGCPPriceLineAnalysis(
                    label=req_text,
                    quantity=line.get("quantity", 1),
                    requirement_specs={
                        "ram_gb": line.get("ram_gb"),
                        "storage_gb": line.get("storage_gb"),
                        "product_type": line.get("product_type"),
                    },
                    compare=compare,
                )
            )

        margin_pct = None
        if total_sale > 0 and total_cost > 0:
            margin_pct = ((total_sale - total_cost) / total_sale * Decimal("100")).quantize(Decimal("0.01"))

        overall = (
            f"Licitación {opp.code}: {len(analyses)} línea(s) analizada(s) contra listas indexadas. "
            f"Costo estimado {currency} {total_cost}, venta sugerida {currency} {total_sale}."
        )
        if analyses and analyses[0].compare.recommendation:
            rec = analyses[0].compare.recommendation
            overall += f" Proveedor principal sugerido: {rec.primary_supplier}."

        return DGCPPriceAnalysisResponse(
            opportunity_id=opp.id,
            opportunity_code=opp.code,
            title=opp.title,
            institution=opp.institution,
            line_items=analyses,
            total_estimated_cost=total_cost if total_cost else None,
            total_suggested_sale=total_sale if total_sale else None,
            estimated_margin_pct=margin_pct,
            currency=currency,
            overall_recommendation=overall,
            data_source="indexed_lists",
        )
