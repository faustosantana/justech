"""Resumen de listas de precios indexadas para Hermes."""

from __future__ import annotations

import uuid
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.price_list import PriceListFile, PriceListProduct
from app.services.licitador_dashboard_service import LicitadorDashboardService


class PriceListSummaryService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID | None = None):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def get_summary(self) -> dict:
        dash = await LicitadorDashboardService(
            self.db, self.tenant_id, self.user_id or uuid.uuid4()
        ).price_intelligence()

        last_file = (
            await self.db.execute(
                select(PriceListFile.indexed_at)
                .where(
                    PriceListFile.tenant_id == self.tenant_id,
                    PriceListFile.is_current.is_(True),
                    PriceListFile.indexed_at.isnot(None),
                )
                .order_by(PriceListFile.indexed_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()

        return {
            "total_products": dash.total_products,
            "total_suppliers": dash.total_suppliers,
            "lists_today": dash.lists_today,
            "pending_count": len(dash.pending_files),
            "processed_count": len(dash.processed_files),
            "last_indexed_at": last_file.isoformat() if last_file else None,
            "recent_errors": dash.recent_errors[:3],
        }

    async def search_price_lists(
        self,
        query: str,
        *,
        product_type: str | None = None,
        price_max_usd: Decimal | None = None,
        limit: int = 10,
    ) -> dict:
        from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters

        filters = PriceSearchFilters(q=query, limit=limit, commercial_only=True)
        if product_type == "laptop":
            filters.product_type = "laptop"
            filters.q = query if query and query.lower() not in ("laptop", "laptops") else None
        if price_max_usd is not None:
            filters.price_max = price_max_usd
            filters.currency = "USD"

        search = await PriceIntelligenceService(self.db, self.tenant_id).search(filters)
        items = search.items[:limit]
        return {
            "count": search.total,
            "items": [
                {
                    "supplier": p.supplier,
                    "description": (p.description or p.sku or "")[:100],
                    "price": str(p.preferred_price or p.price),
                    "currency": p.currency,
                }
                for p in items
            ],
            "summary_line": (
                f"{search.total} resultado(s) en listas indexadas."
                if search.total
                else "Sin resultados en listas indexadas."
            ),
        }

    async def suppliers_for_category(self, category: str) -> dict:
        q = category
        if category == "laptops":
            stmt = (
                select(PriceListProduct.supplier, func.count())
                .where(
                    PriceListProduct.tenant_id == self.tenant_id,
                    PriceListProduct.is_current.is_(True),
                    PriceListProduct.product_type == "laptop",
                    PriceListProduct.excluded_from_laptop.is_(False),
                )
                .group_by(PriceListProduct.supplier)
                .order_by(func.count().desc())
                .limit(10)
            )
        else:
            term = f"%{category}%"
            stmt = (
                select(PriceListProduct.supplier, func.count())
                .where(
                    PriceListProduct.tenant_id == self.tenant_id,
                    PriceListProduct.is_current.is_(True),
                    PriceListProduct.search_blob.ilike(term),
                )
                .group_by(PriceListProduct.supplier)
                .order_by(func.count().desc())
                .limit(10)
            )
        rows = (await self.db.execute(stmt)).all()
        suppliers = [{"supplier": r[0], "count": int(r[1])} for r in rows if r[0]]
        return {"category": category, "suppliers": suppliers, "total": len(suppliers)}
