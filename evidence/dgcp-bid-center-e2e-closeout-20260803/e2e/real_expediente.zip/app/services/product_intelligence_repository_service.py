"""Repositorio técnico 99_PRODUCT_INTELLIGENCE — almacenamiento y reutilización de datasheets."""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

from app.config import settings

logger = logging.getLogger(__name__)

VENDOR_ALIASES: dict[str, str] = {
    "cisco": "CISCO",
    "fortinet": "FORTINET",
    "fortigate": "FORTINET",
    "hpe": "HPE",
    "hewlett": "HPE",
    "aruba": "ARUBA",
    "dell": "DELL",
    "lenovo": "LENOVO",
    "ubiquiti": "UBIQUITI",
    "unifi": "UBIQUITI",
    "huawei": "HUAWEI",
    "apc": "APC",
    "microsoft": "MICROSOFT",
    "vmware": "VMWARE",
    "hp": "HP",
}

DEFAULT_VENDORS = [
    "CISCO", "FORTINET", "HPE", "DELL", "LENOVO", "UBIQUITI",
    "HUAWEI", "APC", "MICROSOFT", "VMWARE", "HP", "ARUBA", "OTROS",
]


class ProductIntelligenceRepositoryService:
    """Gestiona 99_PRODUCT_INTELLIGENCE — lectura en knowledge source, escritura en path mutable."""

    def __init__(self, *, read_root: Path | None = None, write_root: Path | None = None):
        knowledge = Path(read_root or settings.knowledge_source_path)
        self.read_root = knowledge / settings.product_intelligence_folder
        self.write_root = Path(write_root or settings.product_intelligence_writable_path)

    def ensure_structure(self) -> None:
        self.write_root.mkdir(parents=True, exist_ok=True)
        for vendor in DEFAULT_VENDORS:
            (self.write_root / vendor).mkdir(parents=True, exist_ok=True)

    @classmethod
    def classify_vendor(cls, text: str) -> str:
        lower = (text or "").lower()
        for alias, folder in VENDOR_ALIASES.items():
            if alias in lower:
                return folder
        return "OTROS"

    def vendor_path(self, vendor: str, *, writable: bool = True) -> Path:
        folder = vendor.upper() if vendor else "OTROS"
        if folder not in DEFAULT_VENDORS:
            folder = "OTROS"
        base = self.write_root if writable else self.read_root
        path = base / folder
        if writable:
            path.mkdir(parents=True, exist_ok=True)
        return path

    def _scan_roots(self) -> list[Path]:
        roots: list[Path] = []
        if self.read_root.exists():
            roots.append(self.read_root)
        if self.write_root.exists() and self.write_root != self.read_root:
            roots.append(self.write_root)
        return roots

    def search_local(
        self,
        query: str,
        *,
        manufacturer: str | None = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Busca PDFs/imágenes indexados localmente por nombre."""
        tokens = [t for t in re.split(r"\W+", query.lower()) if len(t) >= 2]
        if not tokens:
            return []
        vendor_hint = self.classify_vendor(manufacturer or query)
        scan_dirs: list[Path] = []
        for root in self._scan_roots():
            scan_dirs.append(root / vendor_hint if (root / vendor_hint).exists() else root / "OTROS")
            if vendor_hint != "OTROS":
                scan_dirs.append(root / "OTROS")
        results: list[tuple[float, dict[str, Any]]] = []
        seen: set[str] = set()
        for directory in scan_dirs:
            if not directory.exists():
                continue
            for path in directory.rglob("*"):
                if not path.is_file():
                    continue
                if path.suffix.lower() not in {".pdf", ".png", ".jpg", ".jpeg", ".webp"}:
                    continue
                name_lower = path.name.lower()
                score = sum(1.0 for t in tokens if t in name_lower)
                if score <= 0:
                    continue
                key = str(path.resolve())
                if key in seen:
                    continue
                seen.add(key)
                root_used = self.read_root if str(path).startswith(str(self.read_root)) else self.write_root
                try:
                    rel = path.relative_to(root_used)
                except ValueError:
                    rel = Path(path.name)
                results.append((score, {
                    "path": str(path),
                    "relative_path": str(rel),
                    "filename": path.name,
                    "vendor": rel.parts[0] if rel.parts else "OTROS",
                    "source": "repositorio_tecnico",
                    "source_type": "repositorio_tecnico",
                    "is_technical_source": True,
                    "confidence": min(0.95, 0.5 + score * 0.1),
                }))
        results.sort(key=lambda x: -x[0])
        return [r[1] for r in results[:limit]]

    async def store_datasheet(
        self,
        *,
        url: str,
        manufacturer: str,
        model: str,
        content: bytes | None = None,
    ) -> dict[str, Any] | None:
        """Descarga y almacena un datasheet oficial."""
        if not url and not content:
            return None
        vendor = self.classify_vendor(manufacturer or model)
        dest_dir = self.vendor_path(vendor, writable=True)
        safe_model = re.sub(r"[^\w\-.]+", "_", model or "unknown")[:80]
        filename = f"{safe_model}_datasheet.pdf"
        dest = dest_dir / filename
        if dest.exists():
            return {
                "path": str(dest),
                "relative_path": str(dest.relative_to(self.write_root)),
                "filename": dest.name,
                "vendor": vendor,
                "source": "repositorio_tecnico",
                "cached": True,
            }
        try:
            if content is None:
                async with httpx.AsyncClient(timeout=60.0, follow_redirects=True) as client:
                    response = await client.get(url)
                    response.raise_for_status()
                    content = response.content
            if not content or len(content) < 100:
                return None
            dest.write_bytes(content)
            meta_path = dest_dir / f"{safe_model}_meta.json"
            meta_path.write_text(
                __import__("json").dumps({
                    "url": url,
                    "manufacturer": manufacturer,
                    "model": model,
                    "stored_at": datetime.now(timezone.utc).isoformat(),
                    "sha256": hashlib.sha256(content).hexdigest(),
                }, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            return {
                "path": str(dest),
                "relative_path": str(dest.relative_to(self.write_root)),
                "filename": dest.name,
                "vendor": vendor,
                "source": "repositorio_tecnico",
                "url": url,
                "cached": False,
            }
        except Exception:
            logger.exception("Failed to store datasheet url=%s", url[:120] if url else "")
            return None
