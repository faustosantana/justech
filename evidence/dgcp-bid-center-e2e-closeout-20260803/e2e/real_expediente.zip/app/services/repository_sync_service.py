"""Sincronización orquestada de repositorios OneDrive — binding scope, delta, post-proceso."""

from __future__ import annotations

import hashlib
import logging
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.integration_settings import IntegrationRepositoryBinding
from app.models.repository_sync import RepositorySyncJob
from app.services.company_profile_sync_service import CompanyProfileSyncService
from app.services.legal_document_sync_service import LegalDocumentSyncService
from app.services.m365_repository_service import M365RepositoryService
from app.services.supplier_price_file_service import SupplierPriceFileService

FOLDER_DEFAULTS: list[tuple[str, str, str, str]] = [
    ("00_DATOS_EMPRESAS", "00 — Datos empresas", "company_data", "Justech-AI/00_DATOS_EMPRESAS"),
    ("01_DOCUMENTOS_LEGALES", "01 — Documentos legales", "legal_documents", "Justech-AI/01_DOCUMENTOS_LEGALES"),
    ("02_PLANTILLAS_DGCP", "02 — Plantillas DGCP", "dgcp_templates", "Justech-AI/02_PLANTILLAS/DGCP/PROVEEDORES_DEL_ESTADO"),
    ("02_PLANTILLAS", "02 — Plantillas", "templates", "Justech-AI/02_PLANTILLAS"),
    ("03_PROVEEDORES_ENTRADAS", "03 — Proveedores / Entradas", "price_inbox", "Justech-AI/03_PROVEEDORES/ENTRADAS"),
    ("03_PROVEEDORES_PROCESADOS", "03 — Proveedores / Procesados", "price_processed", "Justech-AI/03_PROVEEDORES/PROCESADOS"),
    ("LICITACIONES", "Licitaciones", "licitations", "Justech-AI/LICITACIONES"),
    ("SALIDAS", "Salidas", "outputs", "Justech-AI/SALIDAS"),
    ("CLIENTES", "Clientes", "clients", "Justech-AI/CLIENTES"),
    ("COTIZACIONES", "Cotizaciones", "quotes", "Justech-AI/COTIZACIONES"),
    ("FICHAS_TECNICAS", "Fichas técnicas", "technical_sheets", "Justech-AI/FICHAS_TECNICAS"),
]

GENERAL_REPOSITORY_KEYS = frozenset({
    "02_PLANTILLAS_DGCP",
    "02_PLANTILLAS",
    "03_PROVEEDORES_ENTRADAS",
    "03_PROVEEDORES_PROCESADOS",
    "LICITACIONES",
    "SALIDAS",
    "FICHAS_TECNICAS",
    "CLIENTES",
    "COTIZACIONES",
})

COMPANY_REPOSITORY_KEYS = frozenset({
    "00_DATOS_EMPRESAS",
    "01_DOCUMENTOS_LEGALES",
})

logger = logging.getLogger(__name__)


class RepositorySyncService:
    def __init__(
        self,
        db: AsyncSession,
        tenant_id: uuid.UUID,
        *,
        user_id: uuid.UUID | None = None,
    ):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id

    async def list_bindings(self) -> list[dict]:
        result = await self.db.execute(
            select(IntegrationRepositoryBinding)
            .where(IntegrationRepositoryBinding.tenant_id == self.tenant_id)
            .order_by(IntegrationRepositoryBinding.folder_key)
        )
        rows = {r.folder_key: r for r in result.scalars().all()}
        out = []
        for key, label, repo_type, default_path in FOLDER_DEFAULTS:
            row = rows.get(key)
            if row:
                out.append(self._binding_dict(row))
            else:
                out.append({
                    "id": None,
                    "folder_key": key,
                    "label": label,
                    "repository_type": repo_type,
                    "provider": "onedrive",
                    "folder_path": default_path,
                    "status": "not_configured",
                    "auto_sync": False,
                    "indexed_files": 0,
                    "sync_interval_minutes": 30,
                })
        return out

    async def upsert_binding(self, payload: dict) -> dict:
        result = await self.db.execute(
            select(IntegrationRepositoryBinding).where(
                IntegrationRepositoryBinding.tenant_id == self.tenant_id,
                IntegrationRepositoryBinding.folder_key == payload["folder_key"],
            )
        )
        row = result.scalar_one_or_none()
        if not row:
            repo_type = payload.get("repository_type") or self._type_for_key(payload["folder_key"])
            row = IntegrationRepositoryBinding(
                tenant_id=self.tenant_id,
                folder_key=payload["folder_key"],
                label=payload.get("label") or payload["folder_key"],
                repository_type=repo_type,
            )
            self.db.add(row)
        row.label = payload.get("label") or row.label
        row.provider = payload.get("provider") or row.provider
        row.graph_item_id = payload.get("graph_item_id") or row.graph_item_id
        row.drive_id = payload.get("drive_id") or row.drive_id
        row.folder_path = payload.get("folder_path") or row.folder_path
        row.web_url = payload.get("web_url") or row.web_url
        row.auto_sync = bool(payload.get("auto_sync", row.auto_sync))
        row.company_key = payload.get("company_key")
        if payload.get("repository_type"):
            row.repository_type = payload["repository_type"]
        if payload.get("sync_interval_minutes"):
            row.sync_interval_minutes = int(payload["sync_interval_minutes"])
        row.status = "configured" if row.graph_item_id or row.folder_path else "pending"
        await self.db.commit()
        await self.db.refresh(row)
        return self._binding_dict(row)

    async def sync_binding(
        self,
        binding_id: uuid.UUID,
        *,
        trigger: str = "manual",
        use_delta: bool = True,
    ) -> dict:
        if not self.user_id:
            return {"ok": False, "message": "Usuario requerido para sincronizar con Graph"}

        binding = await self._get_binding(binding_id)
        job = RepositorySyncJob(
            tenant_id=self.tenant_id,
            binding_id=binding.id,
            trigger=trigger,
            status="running",
        )
        self.db.add(job)
        await self.db.flush()

        try:
            m365 = M365RepositoryService(self.db, self.tenant_id, self.user_id)
            sync_res = await m365.sync_binding(binding, use_delta=use_delta)
            job.files_synced = sync_res.synced
            job.files_new = getattr(sync_res, "files_new", 0)
            job.files_updated = getattr(sync_res, "files_updated", 0)
            job.files_deleted = getattr(sync_res, "files_deleted", 0)

            post = await self._post_process(binding)
            job.records_indexed = post.get("records_indexed", 0)
            job.details = {"sync": sync_res.message, "post_process": post}
            job.status = "completed" if sync_res.ok else "failed"
            job.error_message = None if sync_res.ok else sync_res.message
            job.completed_at = datetime.now(UTC)

            binding.last_sync_at = datetime.now(UTC)
            if sync_res.synced > 0:
                binding.indexed_files = sync_res.synced
            elif binding.indexed_files == 0:
                from sqlalchemy import func, select
                from app.models.m365_repository import M365RepositoryFile

                count = await self.db.scalar(
                    select(func.count()).select_from(M365RepositoryFile).where(
                        M365RepositoryFile.tenant_id == self.tenant_id,
                        M365RepositoryFile.binding_id == binding.id,
                        M365RepositoryFile.is_deleted.is_(False),
                        M365RepositoryFile.is_folder.is_(False),
                    )
                )
                binding.indexed_files = int(count or 0)
            binding.status = "synced" if sync_res.ok else "error"
            binding.last_error = None if sync_res.ok else sync_res.message
            if getattr(sync_res, "delta_link", None):
                binding.delta_link = sync_res.delta_link

            await self.db.commit()
            return {
                "ok": sync_res.ok,
                "job_id": str(job.id),
                "indexed": sync_res.synced,
                "records_indexed": job.records_indexed,
                "message": sync_res.message,
                "post_process": post,
            }
        except Exception as exc:
            await self.db.rollback()
            logger.exception(
                "[M365_SYNC] binding=%s folder=%s failed: %s",
                binding_id,
                binding.folder_key if binding else "?",
                exc,
            )
            job.status = "failed"
            job.error_message = str(exc)
            job.completed_at = datetime.now(UTC)
            binding.status = "error"
            binding.last_error = str(exc)
            await self.db.commit()
            return {"ok": False, "message": str(exc), "job_id": str(job.id)}

    async def sync_all_auto(self) -> list[dict]:
        if not self.user_id:
            return []
        result = await self.db.execute(
            select(IntegrationRepositoryBinding).where(
                IntegrationRepositoryBinding.tenant_id == self.tenant_id,
                IntegrationRepositoryBinding.auto_sync.is_(True),
                IntegrationRepositoryBinding.status.in_(("configured", "synced", "error")),
            )
        )
        bindings = list(result.scalars().all())
        out = []
        now = datetime.now(UTC)
        for binding in bindings:
            if binding.last_sync_at:
                interval = timedelta(minutes=binding.sync_interval_minutes or 30)
                if binding.last_sync_at + interval > now:
                    continue
            out.append(await self.sync_binding(binding.id, trigger="scheduled"))
        return out

    async def list_sync_jobs(self, *, limit: int = 50) -> list[dict]:
        result = await self.db.execute(
            select(RepositorySyncJob)
            .where(RepositorySyncJob.tenant_id == self.tenant_id)
            .order_by(RepositorySyncJob.started_at.desc())
            .limit(limit)
        )
        return [
            {
                "id": str(j.id),
                "binding_id": str(j.binding_id) if j.binding_id else None,
                "trigger": j.trigger,
                "status": j.status,
                "files_synced": j.files_synced,
                "files_new": j.files_new,
                "records_indexed": j.records_indexed,
                "error_message": j.error_message,
                "started_at": j.started_at,
                "completed_at": j.completed_at,
                "details": j.details,
            }
            for j in result.scalars().all()
        ]

    async def _post_process(self, binding: IntegrationRepositoryBinding) -> dict:
        rtype = binding.repository_type or self._type_for_key(binding.folder_key)
        if rtype == "company_data":
            return await CompanyProfileSyncService(
                self.db, self.tenant_id, user_id=self.user_id
            ).sync_from_binding(binding.id)
        if rtype == "price_inbox":
            return await SupplierPriceFileService(self.db, self.tenant_id, self.user_id).process_inbox(binding.id)
        if rtype == "legal_documents":
            return await LegalDocumentSyncService(self.db, self.tenant_id).sync_from_binding(binding.id)
        if rtype == "dgcp_templates":
            return {"message": "Plantillas DGCP indexadas en repositorio M365", "records_indexed": 0}
        return {"message": "Sincronización de archivos completada", "records_indexed": 0}

    async def _get_binding(self, binding_id: uuid.UUID) -> IntegrationRepositoryBinding:
        result = await self.db.execute(
            select(IntegrationRepositoryBinding).where(
                IntegrationRepositoryBinding.id == binding_id,
                IntegrationRepositoryBinding.tenant_id == self.tenant_id,
            )
        )
        row = result.scalar_one_or_none()
        if not row:
            raise ValueError("Repositorio no encontrado")
        return row

    @staticmethod
    def _type_for_key(folder_key: str) -> str:
        for key, _, repo_type, _ in FOLDER_DEFAULTS:
            if key == folder_key:
                return repo_type
        return "general"

    @staticmethod
    def _binding_dict(row: IntegrationRepositoryBinding) -> dict:
        return {
            "id": row.id,
            "folder_key": row.folder_key,
            "label": row.label,
            "repository_type": row.repository_type,
            "provider": row.provider,
            "graph_item_id": row.graph_item_id,
            "drive_id": row.drive_id,
            "folder_path": row.folder_path,
            "web_url": row.web_url,
            "auto_sync": row.auto_sync,
            "sync_interval_minutes": row.sync_interval_minutes,
            "last_sync_at": row.last_sync_at,
            "indexed_files": row.indexed_files,
            "status": row.status,
            "last_error": row.last_error,
            "company_key": row.company_key,
        }

    @staticmethod
    def content_hash(name: str, size: int | None, modified: datetime | None) -> str:
        raw = f"{name}|{size}|{modified.isoformat() if modified else ''}"
        return hashlib.sha256(raw.encode()).hexdigest()[:64]
