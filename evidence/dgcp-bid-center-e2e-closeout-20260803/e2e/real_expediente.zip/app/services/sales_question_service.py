"""Interpretación de preguntas de ventas Odoo — read-only."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum

from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.assistant import AssistantCard, AssistantLink, AssistantQueryResponse
from app.schemas.odoo import OdooSaleHistoryItem
from app.services.business_answer_builder import build_business_answer, from_sales_report, links_to_dict
from app.services.business_entity_normalizer import (
    NormalizedCustomer,
    NormalizedProduct,
    format_variants_list,
    normalize_customer,
    normalize_product,
)
from app.services.business_terms import (
    clean_entity,
    detect_product_in_text,
    expand_customer_terms,
    expand_product_terms,
    matches_product_name,
    normalize_question,
)
from app.services.odoo_service import OdooService
from app.services.sales_report_builder import (
    build_sales_report,
    format_date_es,
)

SALES_SIGNALS = (
    "vendido", "vendidos", "vendida", "vendidas", "vendimos", "vendió", "vendio",
    "hemos vendido", "le hemos vendido", "se le vendió", "se le vendio",
    "se han vendido", "compraron", "compró", "compro",
    "ha comprado", "han comprado", "vendido a", "vendida a",
    "cantidad", "cuántas", "cuantas", "cuántos", "cuantos", "cuánto hemos",
    "cuanto hemos", "cuánto le hemos", "cuanto le hemos",
    "monto vendido", "clientes compraron", "quién compró",
    "quien compro", "quién ha comprado", "quien ha comprado", "último precio",
    "ultimo precio", "en cuánto vendimos", "en cuanto vendimos",
)


class SalesIntent(str, Enum):
    NONE = "none"
    SALES_QUANTITY = "sales_quantity_query"
    SALES_AMOUNT = "sales_amount_query"
    BUYERS = "buyers_query"
    TOP_BUYER = "top_buyer_query"
    TOP_CUSTOMER = "sales_top_customer"
    TOP_PRODUCT = "sales_top_product"
    LAST_PRICE = "last_price_query"
    SALES_TO_CUSTOMER = "sales_to_customer_query"
    CUSTOMER_SALES_LIST = "customer_sales_list_query"
    CUSTOMER_SALES_AMOUNT = "customer_sales_amount_query"
    INSUFFICIENT = "insufficient"


@dataclass
class ParsedSalesQuestion:
    intent: SalesIntent
    product_label: str | None
    search_terms: list[str]
    customer_label: str | None = None
    customer_terms: list[str] = field(default_factory=list)
    product_filter_terms: list[str] = field(default_factory=list)
    product_variants: list[str] = field(default_factory=list)
    customer_variants: list[str] = field(default_factory=list)
    year_filter: int | None = None
    metric: str = "amount"
    group_by: str | None = None


class SalesQuestionService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.odoo = OdooService(db, tenant_id, user_id=user_id)

    @staticmethod
    def parse_product_lookup(question: str) -> ParsedSalesQuestion | None:
        detected_label, detected_terms = detect_product_in_text(normalize_question(question))
        if not detected_label or not detected_terms:
            return None
        norm = normalize_product(detected_label)
        terms = norm.search_terms if norm else detected_terms
        product_filter = norm.filter_terms if norm else terms
        product_variants = norm.variants_display if norm else terms[:8]
        product_label = norm.label if norm else detected_label
        return ParsedSalesQuestion(
            SalesIntent.SALES_QUANTITY,
            product_label,
            terms,
            product_filter_terms=product_filter,
            product_variants=product_variants,
        )

    async def answer_product_lookup(
        self,
        question: str,
        *,
        source_labels: list[str] | None = None,
    ) -> AssistantQueryResponse | None:
        parsed = self.parse_product_lookup(question)
        if not parsed:
            return None

        labels = source_labels or ["odoo"]
        health = await self.odoo.health()
        if not health.connected:
            return None

        lines, resolved_customer = await self._fetch_lines(parsed)
        lines = self._filter_by_year(lines, parsed.year_filter)
        if not lines:
            return None

        report = build_sales_report(
            lines=lines,
            product_label=parsed.product_label or "productos",
            company_name=health.active_company_name,
            customer_label=resolved_customer,
            intent=parsed.intent.value,
        )
        answer = self._answer_from_report(parsed, report, resolved_customer)
        links = self._product_links(lines)
        structured = from_sales_report(report, intent="sales_query", source="odoo")
        structured["links"] = links_to_dict(links)

        return AssistantQueryResponse(
            question=question,
            answer=answer,
            sources=labels,
            query_type="sales_query",
            structured_data=structured,
            links=links,
            data={
                "intent": parsed.intent.value,
                "product_label": parsed.product_label,
                "customer_label": resolved_customer,
                "search_terms": parsed.search_terms,
                "year_filter": parsed.year_filter,
                "line_count": len(lines),
                "order_count": len({ln.order_name for ln in lines}),
                "lines": len(lines),
            },
        )

    @staticmethod
    def has_sales_signal(question: str) -> bool:
        lowered = question.lower()
        return any(sig in lowered for sig in SALES_SIGNALS)

    @staticmethod
    def parse(question: str) -> ParsedSalesQuestion:
        q = normalize_question(question)
        lowered = q.lower()

        if not SalesQuestionService.has_sales_signal(question):
            return ParsedSalesQuestion(SalesIntent.NONE, None, [])

        metric = SalesQuestionService._detect_metric(lowered)

        # --- Ranking global por cliente (sin producto explícito) ---
        if SalesQuestionService._is_top_customer_query(lowered):
            product_raw = SalesQuestionService._extract_product_from_ranking(q, lowered)
            product_label, terms, product_filter, product_variants = (
                SalesQuestionService._normalize_product(product_raw)
            )
            return ParsedSalesQuestion(
                SalesIntent.TOP_CUSTOMER if not product_raw else SalesIntent.TOP_BUYER,
                product_label if product_raw else None,
                terms,
                product_filter_terms=product_filter,
                product_variants=product_variants,
                year_filter=SalesQuestionService._extract_year(lowered),
                metric=metric,
                group_by="customer",
            )

        # --- Producto más vendido ---
        if SalesQuestionService._is_top_product_query(lowered):
            return ParsedSalesQuestion(
                SalesIntent.TOP_PRODUCT,
                "productos",
                [],
                year_filter=SalesQuestionService._extract_year(lowered),
                metric=metric,
                group_by="product",
            )

        product_raw: str | None = None
        customer_raw: str | None = None
        intent = SalesIntent.INSUFFICIENT

        customer_product_patterns = (
            r"(?i)(.+?)\s+le\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)(.+?)\s+se\s+le\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)(.+?)\s+vendid[oa]\s+a\s+(.+?)\s*$",
        )
        customer_qty_patterns = (
            r"(?i)cu[aá]ntos+\s+(.+?)\s+le\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)cu[aá]ntos+\s+(.+?)\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)cu[aá]ntos+\s+(.+?)\s+vendid[oa]s?\s+a\s+(.+?)\s*$",
            r"(?i)cu[aá]ntas+\s+(.+?)\s+le\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
        )
        customer_list_patterns = (
            r"(?i)(?:qué|que)\s+le\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)(?:qué|que)\s+(?:le\s+)?(?:se\s+)?vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)(?:ventas|historial)\s+(?:de|del|a|para)\s+(.+?)\s*$",
        )
        customer_amount_patterns = (
            r"(?i)cu[aá]nto\s+le\s+hemos\s+vendid[oa]\s+a\s+(.+?)\s*$",
            r"(?i)cu[aá]nto\s+(?:le\s+)?vendimos\s+a\s+(.+?)\s*$",
        )
        quantity_patterns = (
            r"(?i)cu[aá]ntas?\s+(.+?)\s+(?:hemos\s+)?vendid[oa]s?\s*$",
            r"(?i)cu[aá]ntas?\s+(.+?)\s+se\s+han\s+vendid[oa]s?\s*$",
            r"(?i)cu[aá]ntos?\s+(.+?)\s+vendimos\s*$",
            r"(?i)cu[aá]ntos?\s+(.+?)\s+hemos\s+vendid[oa]s?\s*$",
        )
        amount_patterns = (
            r"(?i)cu[aá]nto\s+hemos\s+vendid[oa]\s+en\s+(.+?)\s*$",
            r"(?i)monto\s+vendid[oa]\s+en\s+(.+?)\s*$",
            r"(?i)total\s+vendid[oa]\s+en\s+(.+?)\s*$",
        )
        buyer_patterns = (
            r"(?i)(?:qué|que)\s+clientes\s+compraron\s+(.+?)\s*$",
            r"(?i)qui[eé]n(?:es)?\s+ha(?:n)?\s+comprado\s+(.+?)\s*$",
            r"(?i)(?:qué|que)\s+clientes\s+han\s+comprado\s+(.+?)\s*$",
        )
        top_buyer_patterns = (
            r"(?i)qui[eé]n(?:es)?\s+ha(?:n)?\s+comprado\s+m[aá]s\s+(.+?)\s*$",
            r"(?i)qui[eé]n\s+compr[oó]\s+m[aá]s\s+(.+?)\s*$",
            r"(?i)(?:qué|que)\s+cliente\s+compr[oó]\s+m[aá]s\s+(.+?)\s*$",
            r"(?i)(?:a\s+qui[eé]n|a\s+qu[eé]\s+cliente)\s+le\s+hemos\s+vendid[oa]\s+m[aá]s\s+(.+?)\s*$",
        )
        last_price_patterns = (
            r"(?i)en\s+cu[aá]nto\s+vendimos\s+(?:la\s+[uú]ltima\s+|la\s+ultima\s+|la\s+|el\s+|esta\s+|este\s+)?(.+?)\s*$",
            r"(?i)cu[aá]l\s+fue\s+el\s+[uú]ltimo\s+precio\s+(?:de\s+|del\s+)?(.+?)\s*$",
            r"(?i)[uú]ltimo\s+precio\s+(?:de\s+|del\s+)?(.+?)\s*$",
        )

        for pat in customer_list_patterns:
            m = re.search(pat, q)
            if m:
                customer_raw = m.group(1).strip()
                intent = SalesIntent.CUSTOMER_SALES_LIST
                break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in customer_amount_patterns:
                m = re.search(pat, q)
                if m:
                    customer_raw = m.group(1).strip()
                    intent = SalesIntent.CUSTOMER_SALES_AMOUNT
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in customer_qty_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    customer_raw = m.group(2).strip()
                    intent = SalesIntent.SALES_TO_CUSTOMER
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in customer_product_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    customer_raw = m.group(2).strip()
                    if not re.match(r"(?i)^(qué|que|cu[aá]nto|cu[aá]ntas?|cu[aá]ntos?)$", product_raw):
                        intent = SalesIntent.SALES_TO_CUSTOMER
                        break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in quantity_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.SALES_QUANTITY
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in amount_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.SALES_AMOUNT
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in top_buyer_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.TOP_BUYER
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in buyer_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.BUYERS
                    break

        if intent == SalesIntent.INSUFFICIENT:
            for pat in last_price_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.LAST_PRICE
                    break

        informal_quantity_patterns = (
            r"(?i)(?:hemos\s+)?vendid[oa]s?\s+(.+?)\s*$",
            r"(?i)vendimos\s+(.+?)\s*$",
        )
        if intent == SalesIntent.INSUFFICIENT:
            for pat in informal_quantity_patterns:
                m = re.search(pat, q)
                if m:
                    product_raw = m.group(1).strip()
                    intent = SalesIntent.SALES_QUANTITY
                    break

        informal_customer_product = r"(?i)(.+?)\s+a\s+(.+?)\s*$"
        if intent == SalesIntent.INSUFFICIENT and " a " in lowered:
            m = re.search(informal_customer_product, q)
            if m:
                prod = m.group(1).strip()
                cust = m.group(2).strip()
                if not re.match(r"(?i)^(qué|que|cu[aá]nto|cu[aá]ntas?|cu[aá]ntos?)$", prod):
                    product_raw = prod
                    customer_raw = cust
                    intent = SalesIntent.SALES_TO_CUSTOMER

        if intent == SalesIntent.INSUFFICIENT:
            detected_label, detected_terms = detect_product_in_text(q)
            if detected_label and detected_terms:
                norm = normalize_product(detected_label)
                terms = norm.search_terms if norm else detected_terms
                product_filter = norm.filter_terms if norm else terms
                product_variants = norm.variants_display if norm else terms[:8]
                product_label = norm.label if norm else detected_label
                return ParsedSalesQuestion(
                    SalesIntent.SALES_QUANTITY,
                    product_label,
                    terms,
                    product_filter_terms=product_filter,
                    product_variants=product_variants,
                )

        if intent == SalesIntent.INSUFFICIENT and SalesQuestionService.has_sales_signal(q):
            detected_label, detected_terms = detect_product_in_text(q)
            if detected_label and detected_terms and detected_label.lower() not in {
                "cliente", "clientes", "producto", "productos", "ventas", "pedido", "pedidos",
            }:
                return ParsedSalesQuestion(
                    SalesIntent.SALES_QUANTITY,
                    detected_label,
                    detected_terms,
                )
            return ParsedSalesQuestion(SalesIntent.INSUFFICIENT, None, [])

        product_label = clean_entity(product_raw)
        customer_label = clean_entity(customer_raw)

        norm_product = normalize_product(product_label) if product_label else None
        norm_customer = normalize_customer(customer_label) if customer_label else None

        terms = norm_product.search_terms if norm_product else (expand_product_terms(product_label) if product_label else [])
        customer_terms = norm_customer.search_terms if norm_customer else (expand_customer_terms(customer_label) if customer_label else [])
        product_filter = norm_product.filter_terms if norm_product else terms
        product_variants = norm_product.variants_display if norm_product else terms[:8]
        customer_variants = norm_customer.variants_display if norm_customer else customer_terms[:6]

        if norm_customer:
            customer_label = norm_customer.label
        if norm_product:
            product_label = norm_product.label

        if intent in (SalesIntent.CUSTOMER_SALES_LIST, SalesIntent.CUSTOMER_SALES_AMOUNT) and not customer_label:
            return ParsedSalesQuestion(SalesIntent.INSUFFICIENT, None, [])

        if intent == SalesIntent.SALES_TO_CUSTOMER and (not customer_label or not product_label):
            return ParsedSalesQuestion(SalesIntent.INSUFFICIENT, product_label, terms)

        if intent in (SalesIntent.SALES_QUANTITY, SalesIntent.SALES_AMOUNT, SalesIntent.BUYERS, SalesIntent.LAST_PRICE, SalesIntent.TOP_BUYER):
            if not terms:
                return ParsedSalesQuestion(SalesIntent.INSUFFICIENT, product_label, [])

        year_filter = SalesQuestionService._extract_year(lowered)

        label = product_label or ("ventas" if customer_label else "producto")
        return ParsedSalesQuestion(
            intent,
            label,
            terms,
            customer_label,
            customer_terms,
            product_filter,
            product_variants,
            customer_variants,
            year_filter,
            metric=metric,
        )

    @staticmethod
    def _detect_metric(lowered: str) -> str:
        if any(k in lowered for k in ("por cantidad", "por unidades", "más unidades", "mas unidades")):
            return "quantity"
        if any(k in lowered for k in ("por monto", "por importe", "más dinero", "mas dinero")):
            return "amount"
        return "amount"

    @staticmethod
    def _extract_year(lowered: str) -> int | None:
        if re.search(r"\beste\s+a[nñ]o\b", lowered):
            from datetime import datetime, timezone
            return datetime.now(timezone.utc).year
        ym = re.search(r"\ben\s+(20\d{2})\b", lowered)
        if ym:
            return int(ym.group(1))
        return None

    @staticmethod
    def _is_top_customer_query(lowered: str) -> bool:
        patterns = (
            r"(?i)(?:cu[aá]l|que)\s+cliente\s+(?:le\s+)?(?:nos\s+)?(?:hemos\s+)?(?:vendid[oa]|comprado)\s+m[aá]s",
            r"(?i)(?:a\s+qui[eé]n|a\s+qu[eé]\s+cliente)\s+le\s+hemos\s+vendid[oa]\s+m[aá]s(?:\s|$|\?)",
            r"(?i)qui[eé]n\s+(?:nos\s+)?(?:ha\s+)?comprado\s+m[aá]s(?:\s|$|\?)",
            r"(?i)cliente\s+que\s+m[aá]s\s+(?:ha\s+)?comprado",
            r"(?i)(?:cu[aá]l|que)\s+cliente\s+(?:nos\s+)?(?:ha\s+)?comprado\s+m[aá]s",
            r"(?i)qu[eé]\s+cliente\s+le\s+hemos\s+vendid[oa]\s+m[aá]s",
        )
        return any(re.search(p, lowered) for p in patterns)

    @staticmethod
    def _is_top_product_query(lowered: str) -> bool:
        return bool(
            re.search(r"(?i)(?:cu[aá]l|que)\s+(?:fue\s+)?(?:el\s+)?producto\s+m[aá]s\s+vendid[oa]", lowered)
            or re.search(r"(?i)productos?\s+m[aá]s\s+vendid[oa]s?", lowered)
        )

    @staticmethod
    def _extract_product_from_ranking(question: str, lowered: str) -> str | None:
        patterns = (
            r"(?i)(?:cu[aá]l|que)\s+cliente\s+(?:le\s+)?(?:nos\s+)?(?:hemos\s+)?(?:vendid[oa]|comprado)\s+m[aá]s\s+(.+?)\s*$",
            r"(?i)(?:a\s+qui[eé]n|a\s+qu[eé]\s+cliente)\s+le\s+hemos\s+vendid[oa]\s+m[aá]s\s+(.+?)\s*$",
            r"(?i)qui[eé]n\s+(?:nos\s+)?(?:ha\s+)?comprado\s+m[aá]s\s+(.+?)\s*$",
        )
        for pat in patterns:
            m = re.search(pat, question.strip())
            if m:
                raw = clean_entity(m.group(1))
                if raw and raw.lower() not in {"cliente", "clientes", "ventas", "general"}:
                    return raw
        return None

    @staticmethod
    def _normalize_product(product_raw: str | None) -> tuple[str | None, list[str], list[str], list[str]]:
        if not product_raw:
            return None, [], [], []
        product_label = clean_entity(product_raw)
        norm_product = normalize_product(product_label) if product_label else None
        terms = norm_product.search_terms if norm_product else expand_product_terms(product_label or "")
        product_filter = norm_product.filter_terms if norm_product else terms
        product_variants = norm_product.variants_display if norm_product else terms[:8]
        if norm_product:
            product_label = norm_product.label
        return product_label, terms, product_filter, product_variants

    @staticmethod
    def parse_with_context(question: str, ctx) -> ParsedSalesQuestion:
        """Re-parse usando entidades de la conversación activa."""
        from app.services.conversation_follow_up_resolver import resolve_follow_up

        resolution = resolve_follow_up(question, ctx)
        effective = resolution.question if resolution.was_follow_up else question
        parsed = SalesQuestionService.parse(effective)
        if parsed.intent != SalesIntent.INSUFFICIENT:
            return parsed

        from app.services.conversation_follow_up_resolver import enrich_sales_parse_with_context

        product_label, product_terms, customer_label, customer_terms, year = enrich_sales_parse_with_context(
            question, ctx
        )
        if not product_label and not customer_label:
            return parsed

        lowered = question.lower()
        if re.search(r"(?i)compr[oó]\s+m[aá]s|vendid[oa]\s+m[aá]s|cliente\s+le\s+hemos", lowered):
            if product_label and product_terms:
                intent = SalesIntent.TOP_BUYER
            else:
                intent = SalesIntent.TOP_CUSTOMER
        elif re.search(r"(?i)compr[oó]\s+m[aá]s|comprado\s+m[aá]s", lowered):
            intent = SalesIntent.TOP_BUYER
        elif any(w in lowered for w in ("precio", "cuánto vendimos", "cuanto vendimos", "en cuánto", "en cuanto")):
            intent = SalesIntent.LAST_PRICE
        elif any(
            w in lowered
            for w in ("cliente", "quién", "quien", "quiénes", "quienes", "a quién", "a quien")
        ):
            intent = SalesIntent.BUYERS
        elif any(w in lowered for w in ("cuánto", "cuanto", "cuántas", "cuantas", "cuántos", "cuantos")):
            intent = SalesIntent.SALES_QUANTITY
        else:
            intent = SalesIntent.SALES_QUANTITY

        norm_product = normalize_product(product_label) if product_label else None
        norm_customer = normalize_customer(customer_label) if customer_label else None
        terms = norm_product.search_terms if norm_product else expand_product_terms(product_label or "")
        customer_terms_out = norm_customer.search_terms if norm_customer else expand_customer_terms(customer_label)
        product_filter = norm_product.filter_terms if norm_product else terms
        product_variants = norm_product.variants_display if norm_product else terms[:8]
        customer_variants = norm_customer.variants_display if norm_customer else customer_terms_out[:6]
        if norm_customer:
            customer_label = norm_customer.label
        if norm_product:
            product_label = norm_product.label

        return ParsedSalesQuestion(
            intent,
            product_label or "producto",
            terms,
            customer_label,
            customer_terms_out,
            product_filter,
            product_variants,
            customer_variants,
            year,
            metric=SalesQuestionService._detect_metric(lowered),
        )

    @staticmethod
    def _needs_fuzzy_customer_resolve(label: str, terms: list[str]) -> bool:
        normalized = label.lower().replace("-", " ").strip()
        fuzzy_markers = ("farma", "farmatrix", "farmtrix", "trix", "dbg", "capital")
        if any(m in normalized for m in fuzzy_markers):
            return True
        if normalized in {"ademi", "la sociedad"} or (
            "ademi" in normalized and "banco" not in normalized
        ):
            return True
        return False

    @staticmethod
    def _filter_by_year(lines: list[OdooSaleHistoryItem], year: int | None) -> list[OdooSaleHistoryItem]:
        if not year:
            return lines
        filtered: list[OdooSaleHistoryItem] = []
        prefix = str(year)
        for ln in lines:
            if ln.order_date and str(ln.order_date).startswith(prefix):
                filtered.append(ln)
        return filtered

    @staticmethod
    def _top_buyer_summary(
        lines: list[OdooSaleHistoryItem],
        *,
        metric: str = "amount",
    ) -> tuple[str | None, float, Decimal | None]:
        if metric == "quantity":
            totals: dict[str, float] = {}
            for ln in lines:
                partner = ln.partner_name or "Cliente"
                totals[partner] = totals.get(partner, 0.0) + float(ln.quantity or 0)
            if not totals:
                return None, 0.0, None
            top = max(totals.items(), key=lambda x: x[1])
            return top[0], top[1], None

        totals: dict[str, Decimal] = {}
        for ln in lines:
            partner = ln.partner_name or "Cliente"
            subtotal = ln.subtotal if ln.subtotal is not None else (
                (ln.unit_price or Decimal("0")) * Decimal(str(ln.quantity or 0))
            )
            totals[partner] = totals.get(partner, Decimal("0")) + subtotal
        if not totals:
            return None, 0.0, None
        top = max(totals.items(), key=lambda x: x[1])
        return top[0], float(top[1]), top[1]

    @staticmethod
    def _matches_line(line: OdooSaleHistoryItem, parsed: ParsedSalesQuestion) -> bool:
        return matches_product_name(
            line.product_name or "",
            parsed.search_terms,
            filter_terms=parsed.product_filter_terms or None,
        )

    async def _fetch_lines(self, parsed: ParsedSalesQuestion) -> tuple[list[OdooSaleHistoryItem], str | None]:
        resolved_customer: str | None = parsed.customer_label

        if parsed.customer_label:
            lines, partner_name = await self.odoo.search_sales_by_partner_name(
                parsed.customer_label,
                limit=500,
                search_terms=parsed.customer_terms or None,
            )
            if partner_name:
                resolved_customer = partner_name
            if parsed.search_terms:
                lines = [ln for ln in lines if self._matches_line(ln, parsed)]
            return lines, resolved_customer

        lines_resp = await self.odoo.search_sales_by_product_terms(parsed.search_terms, limit=500)
        matched = [ln for ln in lines_resp.items if self._matches_line(ln, parsed)]
        if matched:
            return matched, None
        if lines_resp.items:
            return lines_resp.items, None
        return [], None

    @staticmethod
    def _not_found_response(question: str, parsed: ParsedSalesQuestion) -> AssistantQueryResponse:
        product_variants = format_variants_list(parsed.product_variants or parsed.search_terms, limit=5)
        customer_part = ""
        if parsed.customer_label:
            customer_variants = format_variants_list(parsed.customer_variants or parsed.customer_terms, limit=3)
            customer_part = (
                f" para el cliente «{parsed.customer_label}» "
                f"(variantes: {customer_variants})"
            )
        answer = (
            f"No confirmé ventas en Odoo para {product_variants}{customer_part}.\n\n"
            "Sugerencias: prueba el nombre canónico del cliente o la búsqueda empresarial."
        )
        structured = build_business_answer(
            intent="sales_query",
            source="odoo",
            summary=answer.split("\n\n")[0],
            metrics=[
                {"label": "Variantes producto", "value": str(len(parsed.product_variants or parsed.search_terms))},
                {"label": "Fuente", "value": "Odoo"},
            ],
            warnings=[f"Variantes buscadas: {product_variants}"],
        )
        return AssistantQueryResponse(
            question=question,
            answer=answer,
            sources=["odoo"],
            query_type="sales_query",
            structured_data=structured,
            data={
                "product_label": parsed.product_label,
                "customer_label": parsed.customer_label,
                "search_terms": parsed.search_terms,
                "product_variants": parsed.product_variants,
                "customer_variants": parsed.customer_variants,
                "lines": 0,
            },
        )

    async def answer_product_disambiguation(
        self,
        question: str,
        *,
        source_labels: list[str] | None = None,
        conversation_context=None,
    ) -> AssistantQueryResponse | None:
        """Consultas cortas de producto (ej. «papel 350») — ventas o variantes."""
        parsed = self.parse_product_lookup(question)
        if not parsed:
            detected_label, detected_terms = detect_product_in_text(normalize_question(question))
            if not detected_label:
                return None
            norm = normalize_product(detected_label)
            parsed = ParsedSalesQuestion(
                SalesIntent.SALES_QUANTITY,
                norm.label if norm else detected_label,
                norm.search_terms if norm else detected_terms,
                product_filter_terms=norm.filter_terms if norm else detected_terms,
                product_variants=norm.variants_display if norm else detected_terms[:8],
            )

        labels = source_labels or ["Odoo"]
        health = await self.odoo.health()
        if not health.connected:
            return None

        lines, _ = await self._fetch_lines(parsed)
        if lines:
            return await self.answer(question, source_labels=labels, conversation_context=conversation_context)

        variants = parsed.product_variants or parsed.search_terms
        if not variants:
            return None
        listed = "\n".join(f"• {v}" for v in variants[:6])
        return AssistantQueryResponse(
            question=question,
            answer=(
                f"Encontré {len(variants)} variante(s) relacionadas con «{parsed.product_label}»:\n\n"
                f"{listed}\n\n¿A cuál te refieres?"
            ),
            sources=labels + ["semantic_resolver"],
            query_type="product_disambiguation",
            data={"product_label": parsed.product_label, "variants": variants[:12]},
        )

    async def answer(
        self,
        question: str,
        *,
        source_labels: list[str] | None = None,
        conversation_context=None,
    ) -> AssistantQueryResponse | None:
        parsed = self.parse(question)
        if parsed.intent == SalesIntent.INSUFFICIENT and conversation_context is not None:
            parsed = self.parse_with_context(question, conversation_context)
        if parsed.intent == SalesIntent.NONE:
            return None

        labels = source_labels or ["Odoo"]

        if parsed.intent == SalesIntent.INSUFFICIENT:
            return None

        health = await self.odoo.health()
        if not health.connected:
            return AssistantQueryResponse(
                question=question,
                answer="Odoo no está conectado. No puedo consultar el historial de ventas.",
                sources=labels,
                query_type="not_connected",
            )

        if parsed.intent == SalesIntent.LAST_PRICE:
            return await self._answer_last_price(question, parsed, labels, health.active_company_name)

        if parsed.intent == SalesIntent.TOP_CUSTOMER:
            return await self._answer_top_customer(
                question, parsed, labels, health.active_company_name
            )

        if parsed.intent == SalesIntent.TOP_PRODUCT:
            return await self._answer_top_product(
                question, parsed, labels, health.active_company_name
            )

        customer_resolver_msg: str | None = None
        if parsed.customer_label and self._needs_fuzzy_customer_resolve(
            parsed.customer_label, parsed.customer_terms
        ):
            from app.services.customer_entity_resolver import CustomerEntityResolver

            resolution = await CustomerEntityResolver(
                self.db, self.tenant_id, self.user_id
            ).resolve(parsed.customer_label)
            customer_resolver_msg = resolution.message
            if resolution.needs_confirmation:
                opts = "\n".join(
                    f"• {c.partner_name} ({int(c.confidence * 100)}%)"
                    for c in resolution.candidates[:5]
                    if c.partner_name
                )
                return AssistantQueryResponse(
                    question=question,
                    answer=f"{resolution.message}\n\n{opts}\n\nIndica el nombre exacto para continuar.",
                    sources=labels,
                    query_type="sales_query",
                    data={"needs_customer_confirmation": True, "candidates": [
                        {"name": c.partner_name, "id": c.partner_id} for c in resolution.candidates[:5]
                    ]},
                )
            if resolution.best and resolution.best.partner_name:
                parsed.customer_label = resolution.best.partner_name
                parsed.customer_terms = resolution.best.variants or parsed.customer_terms
                if not parsed.customer_variants and resolution.best.variants:
                    parsed.customer_variants = resolution.best.variants[:6]

        lines, resolved_customer = await self._fetch_lines(parsed)
        lines = self._filter_by_year(lines, parsed.year_filter)
        customer_display = resolved_customer or parsed.customer_label

        if parsed.intent == SalesIntent.TOP_BUYER:
            if not lines:
                return self._not_found_response(question, parsed)
            top_name, top_val, top_amount = self._top_buyer_summary(lines, metric=parsed.metric)
            year_note = f" en {parsed.year_filter}" if parsed.year_filter else ""
            if parsed.metric == "quantity":
                answer = (
                    f"Para «{parsed.product_label}»{year_note}, el cliente que más compró por cantidad fue "
                    f"«{top_name}» con {top_val:g} unidades."
                )
                metric_label = f"{top_val:g} unidades"
            else:
                answer = (
                    f"Para «{parsed.product_label}»{year_note}, el cliente al que más le hemos vendido es "
                    f"«{top_name}», con RD${top_amount:,.2f} en ventas."
                )
                metric_label = f"RD${top_amount:,.2f}" if top_amount else str(top_val)
            structured = build_business_answer(
                intent="sales_top_customer",
                source="odoo",
                summary=answer,
                metrics=[
                    {"label": "Cliente top", "value": top_name or "—"},
                    {"label": "Métrica", "value": metric_label},
                    {"label": "Producto", "value": parsed.product_label or "—"},
                ],
            )
            return await self._finalize_sales_response(
                question=question,
                parsed=parsed,
                answer=answer,
                structured=structured,
                lines=lines,
                labels=labels,
                query_type="sales_top_customer",
            )

        if not lines:
            return self._not_found_response(question, parsed)

        report = build_sales_report(
            lines=lines,
            product_label=parsed.product_label or "productos",
            company_name=health.active_company_name,
            customer_label=customer_display,
            intent=parsed.intent.value,
        )

        answer = self._answer_from_report(parsed, report, customer_display)
        links = self._product_links(lines)
        structured = from_sales_report(report, intent="sales_query", source="odoo")
        structured["links"] = links_to_dict(links)
        if customer_resolver_msg and not customer_resolver_msg.endswith("?"):
            warnings = list(structured.get("warnings") or [])
            warnings.insert(0, customer_resolver_msg)
            structured["warnings"] = warnings[:5]

        actions: list = []
        if customer_display:
            from app.schemas.assistant import AssistantAction
            from app.services.assistant_actions import build_customer_suggested_actions

            actions = [AssistantAction(**a) for a in build_customer_suggested_actions(customer_display)]

        return AssistantQueryResponse(
            question=question,
            answer=answer,
            sources=["odoo"],
            query_type="sales_query",
            structured_data=structured,
            links=links,
            actions=actions if customer_display else [],
            data={
                "intent": parsed.intent.value,
                "product_label": parsed.product_label,
                "customer_label": customer_display,
                "search_terms": parsed.search_terms,
                "year_filter": parsed.year_filter,
                "line_count": len(lines),
                "order_count": len({ln.order_name for ln in lines}),
            },
        )

    async def _answer_top_customer(
        self,
        question: str,
        parsed: ParsedSalesQuestion,
        labels: list[str],
        company_name: str | None,
    ) -> AssistantQueryResponse:
        product_terms = parsed.search_terms if parsed.search_terms else None
        aggregates = await self.odoo.aggregate_sales_by_customer(
            product_terms=product_terms,
            year=parsed.year_filter,
            metric=parsed.metric,
            limit=8,
        )
        if not aggregates:
            scope = f" para «{parsed.product_label}»" if product_terms else ""
            return AssistantQueryResponse(
                question=question,
                answer=f"No encontré ventas en Odoo{scope} para calcular el cliente top.",
                sources=labels,
                query_type="sales_top_customer",
            )

        top = aggregates[0]
        year_note = f" en {parsed.year_filter}" if parsed.year_filter else ""
        scope = f" para «{parsed.product_label}»" if product_terms else ""
        last_date = format_date_es(top.last_order_date) if top.last_order_date else "—"

        if parsed.metric == "quantity":
            answer = (
                f"El cliente que más compró{scope}{year_note} es {top.partner_name}, "
                f"con {top.total_quantity:g} unidades en {top.order_count} pedido(s). "
                f"Última compra: {last_date}."
            )
        else:
            answer = (
                f"El cliente al que más le hemos vendido{scope}{year_note} es {top.partner_name}, "
                f"con RD${top.total_amount:,.2f} en ventas, {top.total_quantity:g} unidades "
                f"en {top.order_count} pedido(s). Última compra: {last_date}."
            )

        rows = []
        for agg in aggregates[:6]:
            rows.append([
                agg.partner_name,
                f"RD${agg.total_amount:,.2f}",
                f"{agg.total_quantity:g}",
                str(agg.order_count),
                format_date_es(agg.last_order_date) if agg.last_order_date else "—",
            ])

        top_products_note = ""
        if top.top_products:
            prods = ", ".join(f"{p['name']} ({p['quantity']:g})" for p in top.top_products[:3])
            top_products_note = f" Principales productos: {prods}."

        structured = build_business_answer(
            intent="sales_top_customer",
            source="odoo",
            summary=answer + top_products_note,
            metrics=[
                {"label": "Cliente top", "value": top.partner_name},
                {"label": "Monto vendido", "value": f"RD${top.total_amount:,.2f}"},
                {"label": "Cantidad", "value": f"{top.total_quantity:g}"},
                {"label": "Pedidos", "value": str(top.order_count)},
                {"label": "Empresa", "value": company_name or "—"},
            ],
            tables=[{
                "title": "Ranking de clientes",
                "columns": ["Cliente", "Monto vendido", "Cantidad", "Pedidos", "Última compra"],
                "rows": rows,
            }],
        )

        facts = {
            "intent": "sales_top_customer",
            "group_by": "customer",
            "metric": parsed.metric,
            "product_filter": parsed.product_label if product_terms else None,
            "year": parsed.year_filter,
            "company": company_name,
            "top_customer": top.model_dump(mode="json"),
            "ranking": [a.model_dump(mode="json") for a in aggregates[:6]],
        }

        return await self._finalize_sales_response(
            question=question,
            parsed=parsed,
            answer=answer + top_products_note,
            structured=structured,
            lines=[],
            labels=labels,
            query_type="sales_top_customer",
            facts=facts,
            customer_label=top.partner_name,
        )

    async def _answer_top_product(
        self,
        question: str,
        parsed: ParsedSalesQuestion,
        labels: list[str],
        company_name: str | None,
    ) -> AssistantQueryResponse:
        aggregates = await self.odoo.aggregate_sales_by_product(
            year=parsed.year_filter,
            metric=parsed.metric,
            limit=8,
        )
        if not aggregates:
            return AssistantQueryResponse(
                question=question,
                answer="No encontré ventas en Odoo para calcular el producto más vendido.",
                sources=labels,
                query_type="sales_top_product",
            )

        top = aggregates[0]
        year_note = f" en {parsed.year_filter}" if parsed.year_filter else ""
        if parsed.metric == "quantity":
            answer = (
                f"El producto más vendido{year_note} es {top.product_name}, "
                f"con {top.total_quantity:g} unidades en {top.order_count} pedido(s)."
            )
        else:
            answer = (
                f"El producto más vendido{year_note} es {top.product_name}, "
                f"con RD${top.total_amount:,.2f} en ventas ({top.total_quantity:g} unidades)."
            )

        rows = [[
            a.product_name,
            f"RD${a.total_amount:,.2f}",
            f"{a.total_quantity:g}",
            str(a.order_count),
        ] for a in aggregates[:6]]

        structured = build_business_answer(
            intent="sales_top_product",
            source="odoo",
            summary=answer,
            metrics=[
                {"label": "Producto top", "value": top.product_name},
                {"label": "Monto", "value": f"RD${top.total_amount:,.2f}"},
                {"label": "Cantidad", "value": f"{top.total_quantity:g}"},
            ],
            tables=[{
                "title": "Ranking de productos",
                "columns": ["Producto", "Monto vendido", "Cantidad", "Pedidos"],
                "rows": rows,
            }],
        )

        facts = {
            "intent": "sales_top_product",
            "group_by": "product",
            "metric": parsed.metric,
            "top_product": top.model_dump(mode="json"),
            "ranking": [a.model_dump(mode="json") for a in aggregates[:6]],
        }

        return await self._finalize_sales_response(
            question=question,
            parsed=parsed,
            answer=answer,
            structured=structured,
            lines=[],
            labels=labels,
            query_type="sales_top_product",
            facts=facts,
            product_label=top.product_name,
        )

    async def _finalize_sales_response(
        self,
        *,
        question: str,
        parsed: ParsedSalesQuestion,
        answer: str,
        structured: dict,
        lines: list[OdooSaleHistoryItem],
        labels: list[str],
        query_type: str,
        facts: dict | None = None,
        customer_label: str | None = None,
        product_label: str | None = None,
    ) -> AssistantQueryResponse:
        from app.config import settings
        from app.services.hermes_client import HermesClient

        final_answer = answer
        sources = list(dict.fromkeys(["odoo"] + labels))

        payload_facts = facts or {
            "intent": parsed.intent.value,
            "product_label": parsed.product_label,
            "customer_label": customer_label,
            "year_filter": parsed.year_filter,
            "metric": parsed.metric,
        }

        if settings.hermes_enabled:
            hermes = HermesClient()
            if hermes.is_available():
                result = await hermes.interpret_question(
                    question=question,
                    context={"intent": query_type, "source": "odoo"},
                    facts=payload_facts,
                )
                if result and result.summary and len(result.summary) >= 20:
                    final_answer = result.summary
                    sources = list(dict.fromkeys(["hermes", "odoo"] + labels))

        links = self._product_links(lines) if lines else []
        if customer_label:
            links.insert(0, AssistantLink(label=customer_label, url="/odoo", type="customer"))

        return AssistantQueryResponse(
            question=question,
            answer=final_answer,
            sources=sources,
            query_type=query_type,
            structured_data=structured,
            links=links,
            data={
                "intent": parsed.intent.value,
                "product_label": product_label or parsed.product_label,
                "customer_label": customer_label,
                "search_terms": parsed.search_terms,
                "year_filter": parsed.year_filter,
                "metric": parsed.metric,
                "group_by": parsed.group_by,
                "line_count": len(lines),
                "last_result_type": query_type,
                "last_source": "odoo",
            },
        )

    @staticmethod
    def _answer_from_report(
        parsed: ParsedSalesQuestion,
        report: dict,
        customer_display: str | None,
    ) -> str:
        summary = report.get("summary", "")
        if parsed.intent == SalesIntent.SALES_TO_CUSTOMER and customer_display and parsed.product_label:
            return f"Sí. {summary}"
        return summary

    async def _answer_last_price(
        self,
        question: str,
        parsed: ParsedSalesQuestion,
        labels: list[str],
        company_name: str | None,
    ) -> AssistantQueryResponse:
        product_term = " ".join(parsed.search_terms[:3])
        result = await self.odoo.last_price(product_name=product_term)
        if not result.unit_price:
            lines_resp = await self.odoo.search_sales_by_product_terms(parsed.search_terms, limit=50)
            lines = [ln for ln in lines_resp.items if self._matches_line(ln, parsed)]
            if not lines:
                return AssistantQueryResponse(
                    question=question,
                    answer=f"No encontré ventas previas de «{parsed.product_label}» en Odoo.",
                    sources=["odoo"],
                    query_type="sales_query",
                )
            last = lines[0]
            return AssistantQueryResponse(
                question=question,
                answer=(
                    f"Última venta de «{last.product_name}»: {last.unit_price} "
                    f"a {last.partner_name} ({format_date_es(last.order_date)})."
                ),
                sources=["odoo"],
                query_type="sales_query",
                cards=[self._card_from_lines(parsed.product_label, [last], company_name, last_price=last.unit_price)],
                data={"last_line": last.model_dump(mode="json")},
            )

        return AssistantQueryResponse(
            question=question,
            answer=(
                f"Último precio de «{result.product_name or parsed.product_label}»: {result.unit_price} "
                f"({result.partner_name or 'cliente'}, {format_date_es(str(result.order_date) if result.order_date else None)})."
            ),
            sources=["odoo"],
            query_type="sales_query",
            cards=[
                AssistantCard(
                    title="Último precio vendido",
                    subtitle=parsed.product_label,
                    fields={
                        "Precio": str(result.unit_price),
                        "Producto": result.product_name or parsed.product_label or "—",
                        "Cliente": result.partner_name or "—",
                        "Pedido": result.order_name or "—",
                        "Fecha": str(result.order_date) if result.order_date else "—",
                        "Empresa": company_name or "—",
                        "Fuente": "Odoo",
                    },
                )
            ],
            data=result.model_dump(mode="json"),
        )

    @staticmethod
    def _card_from_lines(
        label: str,
        lines: list[OdooSaleHistoryItem],
        company_name: str | None,
        *,
        total_qty: float | None = None,
        last_price: Decimal | None = None,
    ) -> AssistantCard:
        orders = {ln.order_name for ln in lines if ln.order_name}
        fields = {
            "Métrica": f"{total_qty:g} unidades" if total_qty is not None else (str(last_price) if last_price else "—"),
            "Líneas de venta": str(len(lines)),
            "Pedidos": str(len(orders)),
            "Empresa": company_name or "—",
            "Fuente": "Odoo",
        }
        return AssistantCard(title=f"Resumen — {label}", subtitle="Ventas históricas", fields=fields)

    @staticmethod
    def _product_links(lines: list[OdooSaleHistoryItem]) -> list[AssistantLink]:
        links: list[AssistantLink] = []
        seen: set[int] = set()
        for ln in lines:
            if ln.product_id and ln.product_id not in seen:
                seen.add(ln.product_id)
                links.append(
                    AssistantLink(label=ln.product_name, url=f"/odoo/products/{ln.product_id}", type="producto")
                )
            if len(links) >= 5:
                break
        return links
