"""Normalización de filtros de fuente para Enterprise Search."""

from __future__ import annotations

ALL_ENTERPRISE_SOURCES: frozenset[str] = frozenset({
    "odoo",
    "dgcp",
    "jaios",
    "documents",
    "knowledge",
    "prices",
    "suppliers",
    "ingram",
    "omega",
    "intcomex",
    "cecomsa",
    "tecnosinergia",
    "cenicsa",
    "tecnomarket",
    "m365",
})

DISTRIBUTOR_SOURCES: frozenset[str] = frozenset({
    "ingram", "omega", "intcomex", "cecomsa", "tecnosinergia", "cenicsa", "tecnomarket",
})

PRICE_RELATED_SOURCES: frozenset[str] = frozenset({"prices", *DISTRIBUTOR_SOURCES})


def normalize_source_filters(
    sources: list[str] | None,
    *,
    legacy_source: str | None = None,
) -> list[str] | None:
    """None = todas las fuentes; lista = subconjunto activo."""
    if legacy_source and legacy_source.strip():
        key = legacy_source.strip().lower()
        return [key] if key in ALL_ENTERPRISE_SOURCES else None

    if sources is None:
        return None

    if len(sources) == 0:
        return []

    cleaned: list[str] = []
    for raw in sources:
        key = raw.strip().lower()
        if not key or key == "all":
            return None
        if key in ALL_ENTERPRISE_SOURCES and key not in cleaned:
            cleaned.append(key)

    if not cleaned:
        return []
    if len(cleaned) >= len(ALL_ENTERPRISE_SOURCES):
        return None
    return cleaned


def source_active(source_filters: list[str] | None, source: str) -> bool:
    return source_filters is None or source in source_filters


def any_source_active(source_filters: list[str] | None, names: set[str]) -> bool:
    return source_filters is None or bool(names & set(source_filters))


def index_db_sources(source_filters: list[str] | None) -> list[str] | None:
    """Mapea filtros UI → columnas SearchIndexEntry.source."""
    if source_filters is None:
        return None
    mapped: list[str] = []
    for sf in source_filters:
        if sf == "odoo":
            continue
        if sf in PRICE_RELATED_SOURCES:
            if "prices" not in mapped:
                mapped.append("prices")
        elif sf == "m365":
            if "m365" not in mapped:
                mapped.append("m365")
        elif sf in ("dgcp", "jaios", "documents", "knowledge", "suppliers"):
            if sf not in mapped:
                mapped.append(sf)
    return mapped or None


def cache_source_key(source_filters: list[str] | None) -> str:
    if source_filters is None:
        return ""
    return ",".join(sorted(source_filters))
