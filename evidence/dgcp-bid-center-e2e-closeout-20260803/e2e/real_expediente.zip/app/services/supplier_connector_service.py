"""Orquestación conectores proveedor live — Ingram scraper/API."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession

from app.schemas.prices import PriceProductResponse, SupplierLiveSearchResponse
from app.services.cecomsa_config_resolver import resolve_cecomsa_config
from app.services.ingram_config_resolver import resolve_ingram_config
from app.services.ingram_mfa_service import IngramMfaService
from app.services.ingram_session_service import IngramSessionService
from app.services.omega_config_resolver import resolve_omega_config
from app.services.omega_session_service import OmegaSessionService
from app.services.search_cache_service import SearchCacheService
from integrations.suppliers.cecomsa_connector import CecomsaConnector
from integrations.suppliers.ingram_connector import IngramConnector
from integrations.suppliers.omega_connector import OmegaConnector


class SupplierConnectorService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID):
        self.db = db
        self.tenant_id = tenant_id
        self._cache = SearchCacheService()

    async def ingram_connector(self) -> IngramConnector:
        cfg = await resolve_ingram_config(self.db, self.tenant_id)
        session = await IngramSessionService().get_session(self.tenant_id)
        cookies = (session or {}).get("cookies") or []
        token = (session or {}).get("session_token") or ""
        return IngramConnector(
            cfg,
            tenant_id=str(self.tenant_id),
            portal_cookies=cookies,
            session_token=token,
        )

    async def search_ingram(self, query: str, *, limit: int = 20, use_cache: bool = True) -> SupplierLiveSearchResponse:
        cfg = await resolve_ingram_config(self.db, self.tenant_id)
        params = {"q": query, "limit": limit}

        if use_cache:
            cached = await self._cache.get_slice(
                self.tenant_id, slice_key="ingram_live", params=params
            )
            if cached:
                return SupplierLiveSearchResponse.model_validate(cached)

        connector = await self.ingram_connector()

        if not cfg.enabled:
            return SupplierLiveSearchResponse(
                provider="ingram",
                query=query,
                items=[],
                total=0,
                status="disabled",
                message="Conector Ingram deshabilitado",
                verification_required=False,
            )

        rows = await connector.search_products(query, limit=limit)
        items = [self._to_price_product(r) for r in rows]
        verification = any(
            (r.raw or {}).get("verification_required") or r.source.endswith("_scraper") for r in rows
        ) or cfg.demo_mode

        if rows:
            status = "ok"
            message = f"{len(rows)} resultado(s) live"
        elif connector._last_error:
            status = "error"
            message = connector._last_error
        elif not connector._portal_cookies and not connector._session_token:
            status = "awaiting_mfa"
            message = "Ingrese el código de Authenticator en Integraciones de Proveedores."
        else:
            status = "empty"
            message = "Sin resultados Ingram live"

        resp = SupplierLiveSearchResponse(
            provider="ingram",
            query=query,
            items=items,
            total=len(items),
            status=status,
            message=message,
            verification_required=verification,
            data_source="live_scraper" if verification else "ingram_api",
            cached=False,
        )

        if use_cache and items:
            await self._cache.set_slice(
                self.tenant_id,
                slice_key="ingram_live",
                params=params,
                payload=resp.model_dump(mode="json"),
                ttl_seconds=cfg.cache_ttl_seconds,
            )

        return resp

    async def ingram_status(self) -> dict:
        connector = await self.ingram_connector()
        cfg = await resolve_ingram_config(self.db, self.tenant_id)
        session_svc = IngramSessionService()
        session_info = await session_svc.session_status(self.tenant_id)
        health = await connector.health_check()
        return {
            **health,
            **session_info,
            "provider": "ingram",
            "enabled": cfg.enabled,
            "configured": cfg.configured,
            "demo_mode": cfg.demo_mode,
            "integration_type": connector.integration_type,
            "source": cfg.source,
            "portal_url": cfg.portal_url,
        }

    async def ingram_mfa_start(self) -> dict:
        return await IngramMfaService(self.db, self.tenant_id).start_mfa()

    async def ingram_mfa_verify(self, pass_code: str) -> dict:
        return await IngramMfaService(self.db, self.tenant_id).verify_mfa(pass_code)

    async def ingram_mfa_disconnect(self) -> dict:
        return await IngramMfaService(self.db, self.tenant_id).disconnect()

    async def omega_connector(self) -> OmegaConnector:
        cfg = await resolve_omega_config(self.db, self.tenant_id)
        session = await OmegaSessionService().get_session(self.tenant_id)
        cookies = session.get("cookies") if session else None
        return OmegaConnector(cfg, tenant_id=str(self.tenant_id), store_cookies=cookies)

    async def omega_login(self) -> dict:
        cfg = await resolve_omega_config(self.db, self.tenant_id)
        if not cfg.has_credentials:
            return {
                "ok": False,
                "status": "missing_credentials",
                "message": "Configure email y contraseña Omega en Configuración → Integraciones.",
                "session_active": False,
            }

        connector = await self.omega_connector()
        result = await connector.login(fresh=True)
        session_svc = OmegaSessionService()
        if result.get("ok"):
            await session_svc.save_session(
                self.tenant_id,
                cookies=result.get("cookies") or connector.session_cookies,
                username=cfg.username,
            )
        else:
            await session_svc.clear_session(self.tenant_id)

        return {
            **result,
            "session_active": bool(result.get("ok")),
            "provider": "omega",
        }

    async def omega_disconnect(self) -> dict:
        await OmegaSessionService().clear_session(self.tenant_id)
        return {
            "ok": True,
            "status": "disconnected",
            "message": "Sesión Omega cerrada",
            "session_active": False,
            "provider": "omega",
        }

    async def search_omega(self, query: str, *, limit: int = 20, use_cache: bool = True) -> SupplierLiveSearchResponse:
        cfg = await resolve_omega_config(self.db, self.tenant_id)
        params = {"q": query, "limit": limit}

        if use_cache:
            cached = await self._cache.get_slice(self.tenant_id, slice_key="omega_live", params=params)
            if cached:
                return SupplierLiveSearchResponse.model_validate(cached)

        connector = await self.omega_connector()
        if not cfg.enabled:
            return SupplierLiveSearchResponse(
                provider="omega",
                query=query,
                items=[],
                total=0,
                status="disabled",
                message="Conector Omega deshabilitado",
                verification_required=False,
            )

        rows = await connector.search_products(query, limit=limit)
        if cfg.has_credentials and connector.session_cookies:
            await OmegaSessionService().save_session(
                self.tenant_id,
                cookies=connector.session_cookies,
                username=cfg.username,
            )
        items = [self._to_price_product(r, supplier="Omega Tech", label="live_omega") for r in rows]
        if cfg.has_credentials:
            status = "authenticated" if connector._authenticated and rows else ("auth_failed" if connector._auth_error else "authenticated")
            message = connector._auth_error or (f"{len(rows)} resultado(s) autenticado(s)" if rows else "Sin resultados")
        else:
            status = "connected" if rows else "empty"
            message = (
                f"{len(rows)} resultado(s) autenticado(s)"
                if rows and cfg.is_vip_portal
                else (f"{len(rows)} resultado(s) público(s)" if rows else "Sin resultados en Omega")
            )
        if cfg.has_credentials and not rows and connector._auth_error:
            status = "auth_failed"
            message = connector._auth_error
        resp = SupplierLiveSearchResponse(
            provider="omega",
            query=query,
            items=items,
            total=len(items),
            status=status,
            message=message,
            verification_required=True,
            data_source="live_scraper",
            cached=False,
        )
        if use_cache and items:
            await self._cache.set_slice(
                self.tenant_id,
                slice_key="omega_live",
                params=params,
                payload=resp.model_dump(mode="json"),
                ttl_seconds=cfg.cache_ttl_seconds,
            )
        return resp

    async def omega_status(self) -> dict:
        connector = await self.omega_connector()
        cfg = await resolve_omega_config(self.db, self.tenant_id)
        session_info = await OmegaSessionService().session_status(self.tenant_id)
        health = await connector.health_check()
        return {
            **health,
            **session_info,
            "provider": "omega",
            "enabled": cfg.enabled,
            "configured": cfg.configured,
            "has_credentials": cfg.has_credentials,
            "demo_mode": cfg.demo_mode,
            "integration_type": connector.integration_type,
            "source": cfg.source,
            "store_url": cfg.store_url,
            "username_hint": cfg.username[:3] + "***" if cfg.username else None,
        }

    async def sync_omega_catalog(self) -> dict:
        cfg = await resolve_omega_config(self.db, self.tenant_id)
        if not cfg.enabled:
            return {"ok": False, "status": "disabled", "items": [], "message": "Omega deshabilitado"}
        connector = await self.omega_connector()
        result = await connector.sync_catalog()
        if cfg.has_credentials and connector.session_cookies:
            await OmegaSessionService().save_session(
                self.tenant_id,
                cookies=connector.session_cookies,
                username=cfg.username,
            )
        products = result.get("products") or []
        items = [
            self._to_price_product(r, supplier="Omega Tech", label="omega_catalog") for r in products
        ]
        return {
            **result,
            "status": "ok" if result.get("ok") else "error",
            "items": items,
            "message": f"{len(items)} producto(s) indexados" if items else result.get("message"),
        }

    async def cecomsa_connector(self) -> CecomsaConnector:
        cfg = await resolve_cecomsa_config(self.db, self.tenant_id)
        return CecomsaConnector(cfg, tenant_id=str(self.tenant_id))

    async def cecomsa_status(self) -> dict:
        connector = await self.cecomsa_connector()
        cfg = await resolve_cecomsa_config(self.db, self.tenant_id)
        health = await connector.health_check()
        return {
            **health,
            "provider": "cecomsa",
            "enabled": cfg.enabled,
            "configured": True,
            "demo_mode": cfg.demo_mode,
            "integration_type": connector.integration_type,
            "source": cfg.source,
            "store_url": cfg.store_url,
        }

    async def search_cecomsa(self, query: str, *, limit: int = 20, use_cache: bool = True) -> SupplierLiveSearchResponse:
        cfg = await resolve_cecomsa_config(self.db, self.tenant_id)
        params = {"q": query, "limit": limit}
        if use_cache:
            cached = await self._cache.get_slice(self.tenant_id, slice_key="cecomsa_live", params=params)
            if cached:
                return SupplierLiveSearchResponse.model_validate(cached)

        connector = await self.cecomsa_connector()
        if not cfg.enabled:
            return SupplierLiveSearchResponse(
                provider="cecomsa",
                query=query,
                items=[],
                total=0,
                status="disabled",
                message="Conector Cecomsa deshabilitado",
                verification_required=False,
            )

        rows = await connector.search_products(query, limit=limit)
        items = [self._to_price_product(r, supplier="Cecomsa", label="live_cecomsa") for r in rows]
        status = "ok" if rows else ("error" if connector._last_error else "empty")
        message = connector._last_error or (f"{len(rows)} resultado(s) Cecomsa" if rows else "Sin resultados Cecomsa")
        resp = SupplierLiveSearchResponse(
            provider="cecomsa",
            query=query,
            items=items,
            total=len(items),
            status=status,
            message=message,
            verification_required=True,
            data_source="live_scraper",
            cached=False,
        )
        if use_cache and items:
            await self._cache.set_slice(
                self.tenant_id,
                slice_key="cecomsa_live",
                params=params,
                payload=resp.model_dump(mode="json"),
                ttl_seconds=cfg.cache_ttl_seconds,
            )
        return resp

    async def sync_cecomsa_catalog(self) -> dict:
        cfg = await resolve_cecomsa_config(self.db, self.tenant_id)
        if not cfg.enabled:
            return {"ok": False, "status": "disabled", "items": [], "message": "Cecomsa deshabilitado"}
        connector = await self.cecomsa_connector()
        result = await connector.sync_catalog()
        products = result.get("products") or []
        items = [
            self._to_price_product(r, supplier="Cecomsa", label="cecomsa_catalog") for r in products
        ]
        return {
            **result,
            "status": "ok" if result.get("ok") else "error",
            "items": items,
            "message": f"{len(items)} producto(s) indexados" if items else result.get("message"),
        }

    @staticmethod
    def _to_price_product(row, *, supplier: str = "Ingram Micro", label: str = "live_ingram") -> PriceProductResponse:
        now = datetime.now(UTC)
        raw = row.raw or {}
        return PriceProductResponse(
            id=uuid.uuid4(),
            supplier=supplier,
            manufacturer=raw.get("vendor") or raw.get("brand"),
            brand=raw.get("vendor") or raw.get("brand"),
            sku=row.sku,
            mpn=raw.get("mpn") or raw.get("part_number"),
            model=None,
            description=row.name,
            category="live",
            product_type="general",
            excluded_from_laptop=False,
            is_cotizable=True,
            price_review_status="ok",
            classification_label=label,
            processor=None,
            ram_gb=None,
            storage_gb=None,
            storage_type=None,
            display=None,
            operating_system=None,
            price=row.price,
            preferred_price=row.price,
            preferred_price_field="live",
            currency=row.currency or "USD",
            stock=row.stock,
            in_transit=None,
            warranty=None,
            source_filename=f"{supplier.lower().split()[0]}:{row.source}",
            source_sheet="live",
            source_row=None,
            source_file_date=row.updated_at or now,
            source_file_date_estimated=False,
            file_id=uuid.uuid4(),
            indexed_at=now,
        )
