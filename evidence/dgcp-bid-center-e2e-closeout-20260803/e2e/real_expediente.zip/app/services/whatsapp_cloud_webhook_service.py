"""Webhook Meta WhatsApp Cloud API → Bandeja Inteligente Hermes."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.tenant import Tenant
from app.schemas.observation import ObservationIngestRequest
from app.services.hermes_observation_service import HermesObservationService
from app.services.integration_settings_service import IntegrationSettingsService

logger = logging.getLogger(__name__)


class WhatsAppCloudWebhookService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def verify_token(self, mode: str | None, token: str | None, challenge: str | None) -> str | None:
        if mode != "subscribe" or not token or not challenge:
            return None
        verify = await self._resolve_verify_token()
        if token == verify:
            return challenge
        return None

    async def process_payload(self, body: dict) -> dict:
        processed = 0
        skipped = 0
        for entry in body.get("entry", []):
            for change in entry.get("changes", []):
                if change.get("field") != "messages":
                    continue
                value = change.get("value", {})
                metadata = value.get("metadata", {})
                phone_number_id = metadata.get("phone_number_id")
                tenant_id = await self._resolve_tenant_id(phone_number_id)
                if tenant_id is None:
                    skipped += 1
                    continue

                contacts = {c.get("wa_id"): c for c in value.get("contacts", [])}
                for msg in value.get("messages", []):
                    if msg.get("type") != "text":
                        skipped += 1
                        continue
                    text = (msg.get("text") or {}).get("body") or ""
                    if not text.strip():
                        skipped += 1
                        continue
                    wa_id = msg.get("from", "")
                    contact = contacts.get(wa_id, {})
                    wamid = msg.get("id") or ""
                    ts = msg.get("timestamp")
                    received_at = (
                        datetime.fromtimestamp(int(ts), tz=UTC) if ts else datetime.now(UTC)
                    )
                    try:
                        await HermesObservationService(self.db, tenant_id, user_id=None).ingest(
                            ObservationIngestRequest(
                                channel="whatsapp",
                                direction="inbound",
                                subject="",
                                body=text,
                                from_address=wa_id,
                                from_name=contact.get("profile", {}).get("name"),
                                received_at=received_at,
                                source_ref=f"whatsapp_cloud:{wamid}",
                                source_meta={
                                    "provider": "whatsapp_cloud",
                                    "phone_number_id": phone_number_id,
                                    "wa_id": wa_id,
                                    "message_type": msg.get("type"),
                                },
                                analyze=True,
                            )
                        )
                        processed += 1
                    except Exception:
                        logger.exception("WhatsApp Cloud ingest failed for wamid=%s", wamid)
                        skipped += 1

        return {"status": "processed", "processed": processed, "skipped": skipped}

    async def _resolve_verify_token(self) -> str:
        slug = settings.whatsapp_default_tenant_slug
        tenant = await self._tenant_by_slug(slug)
        if tenant:
            detail = await IntegrationSettingsService(self.db, tenant.id, actor_id=None).get_integration(
                "whatsapp_cloud"
            )
            for field in detail.get("fields", []):
                if field.get("key") == "verify_token" and field.get("value"):
                    return str(field["value"])
        return settings.whatsapp_cloud_verify_token

    async def _resolve_tenant_id(self, phone_number_id: str | None) -> uuid.UUID | None:
        if phone_number_id:
            result = await self.db.execute(select(Tenant).where(Tenant.status == "active"))
            for tenant in result.scalars().all():
                detail = await IntegrationSettingsService(self.db, tenant.id, actor_id=None).get_integration(
                    "whatsapp_cloud"
                )
                for field in detail.get("fields", []):
                    if field.get("key") == "phone_number_id" and str(field.get("value") or "") == phone_number_id:
                        return tenant.id
        tenant = await self._tenant_by_slug(settings.whatsapp_default_tenant_slug)
        return tenant.id if tenant else None

    async def _tenant_by_slug(self, slug: str) -> Tenant | None:
        result = await self.db.execute(select(Tenant).where(Tenant.slug == slug, Tenant.status == "active"))
        return result.scalar_one_or_none()
