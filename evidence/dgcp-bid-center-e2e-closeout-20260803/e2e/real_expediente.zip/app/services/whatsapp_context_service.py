"""Contexto CRM + búsqueda profunda para conversaciones WhatsApp."""

from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.whatsapp import WhatsappChat, WhatsappMessage
from app.schemas.communications import (
    WhatsappContextPreviewResponse,
    WhatsappDeepContextSearchResponse,
)
from app.services.communications_intelligence_service import CommunicationsIntelligenceService
from app.services.enterprise_search_service import EnterpriseSearchService
from app.services.price_intelligence_service import PriceIntelligenceService, PriceSearchFilters
from app.services.unified_contact_service import UnifiedContactService
from app.services.whatsapp_message_classifier import CLASSIFICATION_LABELS


def _phone_from_jid(jid: str) -> str:
    return (jid or "").split("@")[0].split(":")[0]


class WhatsappContextService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID) -> None:
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self._intel = CommunicationsIntelligenceService(db, tenant_id, user_id)

    async def _get_chat(self, chat_id: uuid.UUID) -> WhatsappChat | None:
        q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.id == chat_id,
                WhatsappChat.tenant_id == self.tenant_id,
            )
        )
        return q.scalar_one_or_none()

    async def _load_transcript(self, chat: WhatsappChat, limit: int = 30) -> str:
        q = await self.db.execute(
            select(WhatsappMessage)
            .where(WhatsappMessage.chat_id == chat.id)
            .order_by(WhatsappMessage.wa_timestamp_ms.desc().nullslast())
            .limit(limit)
        )
        rows = list(reversed(q.scalars().all()))
        lines = []
        for m in rows:
            who = "Yo" if m.from_me else (chat.name or "Contacto")
            lines.append(f"{who}: {m.body or f'[{m.media_type}]'}")
        return "\n".join(lines)

    async def context_preview(self, chat_id: uuid.UUID) -> WhatsappContextPreviewResponse | None:
        chat = await self._get_chat(chat_id)
        if chat is None:
            return None

        intel = await self._intel.get_chat_intelligence(chat_id)
        ai = chat.ai_classification or {}
        cls = ai.get("classification") or (intel.classification if intel else None)
        entities = (intel.entities if intel else {}) or ai.get("entities") or {}

        phone = chat.phone_number or _phone_from_jid(chat.remote_jid)
        contact_name = chat.name or entities.get("contact_name") or phone
        company_name = entities.get("company") or ""

        matched_contact = None
        try:
            contacts = await UnifiedContactService(self.db, self.tenant_id, self.user_id).list_contacts(
                search=phone, limit=5, sync=False
            )
            for c in contacts.items:
                if phone and c.primary_phone and phone in c.primary_phone.replace(" ", ""):
                    matched_contact = c
                    company_name = company_name or c.company_name or ""
                    contact_name = contact_name or c.display_name
                    break
        except Exception:
            pass

        recommendations: list[str] = []
        if cls in ("cliente", "oportunidad", "cotizacion", "rfq_request"):
            recommendations.append("Revisar historial comercial antes de responder.")
        if cls in ("licitacion",):
            recommendations.append("Verificar expedientes DGCP relacionados.")
        if intel and intel.suggested_reply:
            recommendations.append("Hay una respuesta sugerida lista para revisar.")

        return WhatsappContextPreviewResponse(
            chat_id=chat_id,
            contact_name=contact_name,
            phone_number=phone,
            is_group=chat.is_group,
            company_name=company_name or None,
            related_company_id=chat.related_company_id,
            classification=cls,
            classification_label=CLASSIFICATION_LABELS.get(cls or "", ""),
            summary=intel.summary if intel else chat.ai_summary,
            suggested_reply=intel.suggested_reply if intel else chat.ai_suggested_reply,
            entities=entities,
            matched_contact_id=matched_contact.id if matched_contact else None,
            opportunities=[],
            quotes=[],
            sales=[],
            emails=[],
            documents=[],
            price_history=[],
            recommendations=recommendations,
            deep_search_available=True,
        )

    async def deep_context_search(
        self,
        chat_id: uuid.UUID,
        *,
        sources: list[str] | None = None,
    ) -> WhatsappDeepContextSearchResponse | None:
        chat = await self._get_chat(chat_id)
        if chat is None:
            return None

        preview = await self.context_preview(chat_id)
        assert preview is not None

        src = set(sources or ["all"])
        if "all" in src:
            src = {"prices", "documents", "email", "enterprise", "quotes", "sales"}

        transcript = await self._load_transcript(chat)
        query_terms = " ".join(
            filter(
                None,
                [
                    preview.contact_name,
                    preview.company_name,
                    " ".join(preview.entities.get("products") or []) if isinstance(preview.entities.get("products"), list) else "",
                    transcript[-400:],
                ],
            )
        ).strip() or preview.contact_name or preview.phone_number or "cliente"

        prices: list[dict[str, Any]] = []
        documents: list[dict[str, Any]] = []
        emails: list[dict[str, Any]] = []
        sales: list[dict[str, Any]] = []
        quotes: list[dict[str, Any]] = []
        opportunities: list[dict[str, Any]] = []
        recommendation = ""

        if "prices" in src:
            try:
                svc = PriceIntelligenceService(self.db, self.tenant_id)
                hits = await svc.search(PriceSearchFilters(q=query_terms[:120], limit=8))
                for h in hits.items[:8]:
                    prices.append(
                        {
                            "product": h.product_name or h.description,
                            "supplier": h.supplier_name,
                            "price": str(h.unit_price) if h.unit_price is not None else None,
                            "currency": h.currency,
                        }
                    )
            except Exception:
                pass

        if "enterprise" in src or "documents" in src or "quotes" in src or "sales" in src:
            try:
                search = EnterpriseSearchService(self.db, self.tenant_id, self.user_id)
                res = await search.search(query_terms[:120], limit_per_group=5)
                for group in res.groups:
                    gname = (group.name or "").lower()
                    for item in group.items[:5]:
                        row = {"title": item.title, "subtitle": item.subtitle, "url": item.url}
                        if "price" in gname or "precio" in gname:
                            prices.append(row)
                        elif "document" in gname or "doc" in gname:
                            documents.append(row)
                        elif "odoo" in gname or "venta" in gname or "sale" in gname:
                            sales.append(row)
                        elif "cotiz" in gname or "quote" in gname:
                            quotes.append(row)
                        elif "dgcp" in gname or "licit" in gname:
                            opportunities.append(row)
            except Exception:
                pass

        if "email" in src:
            try:
                search = EnterpriseSearchService(self.db, self.tenant_id, self.user_id)
                res = await search.search(f"outlook {query_terms[:80]}", limit_per_group=5)
                for group in res.groups:
                    if "mail" in (group.name or "").lower() or "outlook" in (group.name or "").lower():
                        for item in group.items[:5]:
                            emails.append(
                                {
                                    "subject": item.title,
                                    "from": item.subtitle,
                                    "url": item.url,
                                }
                            )
            except Exception:
                pass

        parts: list[str] = []
        if sales:
            parts.append(f"Se encontraron {len(sales)} referencias de ventas.")
        if quotes:
            parts.append(f"Hay {len(quotes)} cotizaciones relacionadas.")
        if prices:
            parts.append(f"Precios actuales disponibles en {len(prices)} fuentes.")
        if emails:
            parts.append(f"Correos relacionados: {len(emails)}.")
        if opportunities:
            parts.append(f"Oportunidades/licitaciones: {len(opportunities)}.")
        if not parts:
            recommendation = "No se encontró historial externo; responde con la información de esta conversación."
        else:
            recommendation = (
                "Preparar respuesta comercial con precio actualizado, revisar margen y validar disponibilidad antes de enviar."
            )

        return WhatsappDeepContextSearchResponse(
            chat_id=chat_id,
            contact_name=preview.contact_name,
            company_name=preview.company_name,
            query_used=query_terms[:200],
            sales=sales[:10],
            quotes=quotes[:10],
            prices=prices[:12],
            emails=emails[:8],
            documents=documents[:8],
            opportunities=opportunities[:8],
            recommendation=recommendation,
            summary=" ".join(parts),
        )
