"""Límites de sesiones WhatsApp por plan del tenant."""

from __future__ import annotations

PLAN_WHATSAPP_LIMITS: dict[str, int] = {
    "starter": 1,
    "business": 3,
    "enterprise": 10,
    "pro": 3,
}


def whatsapp_session_limit(plan: str | None) -> int:
    if not plan:
        return PLAN_WHATSAPP_LIMITS["starter"]
    return PLAN_WHATSAPP_LIMITS.get(plan.lower().strip(), 1)
