"""Servicio WhatsApp Web — sesiones multicuenta por usuario."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import forbidden, not_found
from app.models.business_company import BusinessCompany
from app.models.tenant import Tenant
from app.models.whatsapp import WhatsappChat, WhatsappMessage, WhatsappSession
from app.schemas.communications import (
    WhatsappChatListResponse,
    WhatsappChatResponse,
    WhatsappConversationListResponse,
    WhatsappMessageListResponse,
    WhatsappMessageResponse,
    WhatsappSessionLimitsResponse,
    WhatsappSessionListResponse,
    WhatsappSessionResponse,
    WhatsappSyncResponse,
)
from app.services.whatsapp_message_classifier import CLASSIFICATION_LABELS
from app.services.whatsapp_plan_limits import whatsapp_session_limit
from integrations.whatsapp.bridge_client import WhatsAppBridgeClient


def _dt_from_ms(ms: int | None) -> datetime | None:
    if not ms:
        return None
    return datetime.fromtimestamp(ms / 1000, tz=UTC)


def _jid_to_phone(jid: str) -> str:
    return (jid or "").split("@")[0].split(":")[0]


class WhatsappService:
    def __init__(self, db: AsyncSession, tenant_id: uuid.UUID, user_id: uuid.UUID) -> None:
        self.db = db
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.bridge = WhatsAppBridgeClient()

    async def list_sessions(self) -> WhatsappSessionListResponse:
        q = await self.db.execute(
            select(WhatsappSession)
            .where(
                WhatsappSession.tenant_id == self.tenant_id,
                WhatsappSession.user_id == self.user_id,
                WhatsappSession.is_active.is_(True),
            )
            .order_by(WhatsappSession.created_at.desc())
        )
        rows = q.scalars().all()
        return WhatsappSessionListResponse(items=[WhatsappSessionResponse.model_validate(r) for r in rows])

    async def get_session_limits(self) -> WhatsappSessionLimitsResponse:
        tenant = await self.db.get(Tenant, self.tenant_id)
        plan = tenant.plan if tenant else "starter"
        limit = whatsapp_session_limit(plan)
        count_q = await self.db.execute(
            select(func.count())
            .select_from(WhatsappSession)
            .where(
                WhatsappSession.tenant_id == self.tenant_id,
                WhatsappSession.user_id == self.user_id,
                WhatsappSession.is_active.is_(True),
            )
        )
        active = int(count_q.scalar() or 0)
        return WhatsappSessionLimitsResponse(
            plan=plan,
            limit=limit,
            active_count=active,
            can_create=active < limit,
        )

    async def create_session(self, label: str, account_type: str) -> WhatsappSessionResponse:
        limits = await self.get_session_limits()
        if not limits.can_create:
            raise forbidden(
                "Has alcanzado el límite de sesiones WhatsApp para tu plan actual."
            )
        bridge_id = str(uuid.uuid4())
        row = WhatsappSession(
            tenant_id=self.tenant_id,
            user_id=self.user_id,
            bridge_session_id=bridge_id,
            label=label,
            account_type=account_type,
            connection_status="connecting",
        )
        self.db.add(row)
        await self.db.flush()

        try:
            status = await self.bridge.create_session(bridge_id)
            row.connection_status = status.get("status", "connecting")
            row.qr_image = status.get("qr_image")
            row.phone_number = status.get("phone")
            row.push_name = status.get("push_name")
            row.last_error = status.get("last_error")
        except Exception as exc:
            row.connection_status = "error"
            row.last_error = str(exc)

        await self.db.commit()
        await self.db.refresh(row)
        return WhatsappSessionResponse.model_validate(row)

    async def _get_session(self, session_id: uuid.UUID) -> WhatsappSession | None:
        q = await self.db.execute(
            select(WhatsappSession).where(
                WhatsappSession.id == session_id,
                WhatsappSession.tenant_id == self.tenant_id,
                WhatsappSession.user_id == self.user_id,
            )
        )
        return q.scalar_one_or_none()

    async def refresh_session(self, session_id: uuid.UUID) -> WhatsappSessionResponse | None:
        row = await self._get_session(session_id)
        if row is None:
            return None
        try:
            status = await self.bridge.get_status(row.bridge_session_id)
            row.connection_status = status.get("status", row.connection_status)
            row.qr_image = status.get("qr_image") or row.qr_image
            row.phone_number = status.get("phone") or row.phone_number
            row.push_name = status.get("push_name") or row.push_name
            row.last_error = status.get("last_error")
            if row.connection_status == "connected" and row.connected_at is None:
                row.connected_at = datetime.now(UTC)
        except Exception as exc:
            row.last_error = str(exc)
        await self.db.commit()
        await self.db.refresh(row)
        return WhatsappSessionResponse.model_validate(row)

    async def disconnect_session(self, session_id: uuid.UUID, logout: bool = True) -> bool:
        row = await self._get_session(session_id)
        if row is None:
            return False
        try:
            await self.bridge.disconnect(row.bridge_session_id, logout=logout)
        except Exception:
            pass
        row.connection_status = "disconnected"
        row.qr_image = None
        row.is_active = False
        await self.db.commit()
        return True

    async def update_session(self, session_id: uuid.UUID, label: str) -> WhatsappSessionResponse | None:
        row = await self._get_session(session_id)
        if row is None:
            return None
        row.label = label.strip()
        await self.db.commit()
        await self.db.refresh(row)
        return WhatsappSessionResponse.model_validate(row)

    async def delete_session(self, session_id: uuid.UUID) -> bool:
        row = await self._get_session(session_id)
        if row is None:
            return False
        try:
            await self.bridge.disconnect(row.bridge_session_id, logout=True)
        except Exception:
            pass
        row.connection_status = "disconnected"
        row.qr_image = None
        row.is_active = False
        await self.db.commit()
        return True

    async def full_sync(self, session_id: uuid.UUID) -> WhatsappSyncResponse:
        row = await self._get_session(session_id)
        if row is None:
            raise not_found("Sesión no encontrada")
        if row.connection_status != "connected":
            return WhatsappSyncResponse(
                status="skipped",
                message="La sesión no está conectada.",
            )
        chats_synced = 0
        contacts_synced = 0
        try:
            remote = await self.bridge.list_chats(row.bridge_session_id)
            for item in remote:
                await self._upsert_chat(row, item)
                chats_synced += 1
            await self.db.flush()
        except Exception as exc:
            await self.db.commit()
            return WhatsappSyncResponse(status="error", message=str(exc))

        try:
            from app.services.unified_contact_service import UnifiedContactService

            sync_res = await UnifiedContactService(self.db, self.tenant_id, self.user_id).sync_contacts(
                limit_per_source=80
            )
            contacts_synced = sync_res.total
        except Exception:
            pass

        await self.db.commit()
        return WhatsappSyncResponse(
            status="ok",
            chats_synced=chats_synced,
            contacts_synced=contacts_synced,
            message=f"Sincronizadas {chats_synced} conversaciones.",
        )

    async def sync_chats(self, session_id: uuid.UUID) -> WhatsappChatListResponse:
        row = await self._get_session(session_id)
        if row is None:
            return WhatsappChatListResponse(items=[])
        try:
            remote = await self.bridge.list_chats(row.bridge_session_id)
        except Exception:
            remote = []

        for item in remote:
            await self._upsert_chat(row, item)

        await self.db.commit()
        return await self.list_chats(session_id)

    async def _upsert_chat(self, session: WhatsappSession, data: dict) -> WhatsappChat:
        jid = data["remote_jid"]
        ts = _dt_from_ms(data.get("conversation_timestamp"))
        phone = data.get("phone") or _jid_to_phone(jid)
        is_group = bool(data.get("is_group") or jid.endswith("@g.us"))

        for attempt in range(2):
            q = await self.db.execute(
                select(WhatsappChat).where(
                    WhatsappChat.session_id == session.id,
                    WhatsappChat.remote_jid == jid,
                )
            )
            chat = q.scalar_one_or_none()
            if chat is not None:
                self._apply_chat_fields(chat, data, ts, phone, is_group)
                return chat
            chat = WhatsappChat(
                tenant_id=session.tenant_id,
                session_id=session.id,
                remote_jid=jid,
                name=data.get("name"),
                phone_number=phone,
                profile_picture_url=data.get("profile_picture_url"),
                is_group=is_group,
                unread_count=int(data.get("unread_count") or 0),
                last_message_at=ts,
            )
            self._infer_contact_type(chat)
            self.db.add(chat)
            try:
                await self.db.flush()
                return chat
            except IntegrityError:
                await self.db.rollback()
                if attempt == 1:
                    raise

        raise RuntimeError("whatsapp chat upsert failed")

    @staticmethod
    def _apply_chat_fields(
        chat: WhatsappChat,
        data: dict,
        ts: datetime | None,
        phone: str | None,
        is_group: bool,
    ) -> None:
        if data.get("name"):
            chat.name = data.get("name")
        chat.phone_number = phone or chat.phone_number
        if data.get("profile_picture_url"):
            chat.profile_picture_url = data.get("profile_picture_url")
        chat.is_group = is_group
        chat.unread_count = int(data.get("unread_count") or chat.unread_count)
        if ts:
            chat.last_message_at = ts
        WhatsappService._infer_contact_type(chat)

    @staticmethod
    def _infer_contact_type(chat: WhatsappChat) -> None:
        if chat.is_group:
            return
        ai = chat.ai_classification or {}
        cls = ai.get("classification")
        if cls == "proveedor":
            chat.contact_type = "supplier"
        elif cls in ("cliente", "oportunidad", "cobro"):
            chat.contact_type = "client"

    async def list_chats(self, session_id: uuid.UUID) -> WhatsappChatListResponse:
        q = await self.db.execute(
            select(WhatsappChat)
            .where(
                WhatsappChat.tenant_id == self.tenant_id,
                WhatsappChat.session_id == session_id,
            )
            .order_by(WhatsappChat.last_message_at.desc().nullslast())
        )
        rows = q.scalars().all()
        return WhatsappChatListResponse(items=[await self._chat_response(r) for r in rows])

    async def list_conversations(
        self,
        session_id: uuid.UUID | None = None,
        *,
        filter: str = "all",
        search: str = "",
    ) -> WhatsappConversationListResponse:
        q = select(WhatsappChat).where(WhatsappChat.tenant_id == self.tenant_id)
        if session_id:
            q = q.where(WhatsappChat.session_id == session_id)
        if filter == "unread":
            q = q.where(WhatsappChat.unread_count > 0)
        elif filter == "favorites":
            q = q.where(WhatsappChat.is_favorite.is_(True))
        elif filter == "groups":
            q = q.where(WhatsappChat.is_group.is_(True))
        elif filter == "clients":
            q = q.where(WhatsappChat.contact_type == "client")
        elif filter == "suppliers":
            q = q.where(WhatsappChat.contact_type == "supplier")
        if search.strip():
            term = f"%{search.strip().lower()}%"
            q = q.where(
                func.lower(WhatsappChat.name).like(term)
                | func.lower(WhatsappChat.phone_number).like(term)
                | func.lower(WhatsappChat.remote_jid).like(term)
            )
        q = q.order_by(WhatsappChat.last_message_at.desc().nullslast())
        rows = (await self.db.execute(q)).scalars().all()
        items = [await self._chat_response(r) for r in rows]
        return WhatsappConversationListResponse(items=items, total=len(items))

    async def get_conversation(self, conversation_id: uuid.UUID) -> WhatsappChatResponse | None:
        q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.id == conversation_id,
                WhatsappChat.tenant_id == self.tenant_id,
            )
        )
        chat = q.scalar_one_or_none()
        if chat is None:
            return None
        return await self._chat_response(chat)

    async def set_favorite(self, conversation_id: uuid.UUID, is_favorite: bool) -> WhatsappChatResponse | None:
        q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.id == conversation_id,
                WhatsappChat.tenant_id == self.tenant_id,
            )
        )
        chat = q.scalar_one_or_none()
        if chat is None:
            return None
        chat.is_favorite = is_favorite
        await self.db.commit()
        await self.db.refresh(chat)
        return await self._chat_response(chat)

    async def _chat_response(self, chat: WhatsappChat) -> WhatsappChatResponse:
        ai = chat.ai_classification or {}
        cls = ai.get("classification")
        company_name = None
        if chat.related_company_id:
            company = await self.db.get(BusinessCompany, chat.related_company_id)
            company_name = company.name if company else None
        return WhatsappChatResponse(
            id=chat.id,
            session_id=chat.session_id,
            remote_jid=chat.remote_jid,
            name=chat.name,
            phone_number=chat.phone_number or _jid_to_phone(chat.remote_jid),
            profile_picture_url=chat.profile_picture_url,
            is_group=chat.is_group,
            is_favorite=bool(chat.is_favorite),
            unread_count=chat.unread_count,
            last_message_preview=chat.last_message_preview,
            last_message_at=chat.last_message_at,
            labels=list(chat.labels or []),
            contact_type=chat.contact_type,
            related_company_id=chat.related_company_id,
            related_company_name=company_name,
            ai_classification=cls,
            ai_classification_label=ai.get("label") or CLASSIFICATION_LABELS.get(cls or "", ""),
            ai_priority=chat.ai_priority,
        )

    async def list_messages(
        self, session_id: uuid.UUID, remote_jid: str, limit: int = 50, sync: bool = True
    ) -> WhatsappMessageListResponse:
        row = await self._get_session(session_id)
        if row is None:
            return WhatsappMessageListResponse(items=[])

        if sync and row.connection_status == "connected":
            try:
                remote = await self.bridge.list_messages(row.bridge_session_id, remote_jid, limit=limit)
                for item in remote:
                    await self._persist_message(row, item)
                await self.db.commit()
            except Exception:
                pass

        q = await self.db.execute(
            select(WhatsappMessage)
            .where(
                WhatsappMessage.tenant_id == self.tenant_id,
                WhatsappMessage.session_id == session_id,
                WhatsappMessage.remote_jid == remote_jid,
            )
            .order_by(WhatsappMessage.wa_timestamp_ms.desc().nullslast())
            .limit(limit)
        )
        rows = list(reversed(q.scalars().all()))
        return WhatsappMessageListResponse(items=[WhatsappMessageResponse.model_validate(r) for r in rows])

    async def list_messages_by_conversation(
        self, conversation_id: uuid.UUID, limit: int = 50, sync: bool = True
    ) -> WhatsappMessageListResponse:
        q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.id == conversation_id,
                WhatsappChat.tenant_id == self.tenant_id,
            )
        )
        chat = q.scalar_one_or_none()
        if chat is None:
            return WhatsappMessageListResponse(items=[])
        return await self.list_messages(chat.session_id, chat.remote_jid, limit=limit, sync=sync)

    async def send_message_to_conversation(
        self, conversation_id: uuid.UUID, text: str, quoted_message_id: str | None = None
    ) -> WhatsappMessageResponse | None:
        q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.id == conversation_id,
                WhatsappChat.tenant_id == self.tenant_id,
            )
        )
        chat = q.scalar_one_or_none()
        if chat is None:
            return None
        return await self.send_message(chat.session_id, chat.remote_jid, text, quoted_message_id)

    async def send_document(
        self,
        session_id: uuid.UUID,
        remote_jid: str,
        *,
        filename: str,
        mimetype: str,
        content_base64: str,
        caption: str | None = None,
    ) -> WhatsappMessageResponse | None:
        row = await self._get_session(session_id)
        if row is None:
            return None
        result = await self.bridge.send_document(
            row.bridge_session_id,
            remote_jid,
            filename=filename,
            mimetype=mimetype,
            content_base64=content_base64,
            caption=caption,
        )
        preview = caption or f"📎 {filename}"
        msg = await self._persist_message(
            row,
            {
                "wa_message_id": result.get("wa_message_id") or str(uuid.uuid4()),
                "remote_jid": remote_jid,
                "from_me": True,
                "timestamp": result.get("timestamp") or int(datetime.now(UTC).timestamp() * 1000),
                "body": preview,
                "media_type": "document",
                "media_mime": mimetype,
                "content_type": "documentMessage",
            },
        )
        chat = await self._upsert_chat(row, {"remote_jid": remote_jid, "name": None})
        chat.last_message_preview = preview[:512]
        chat.last_message_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(msg)
        return WhatsappMessageResponse.model_validate(msg)

    async def send_message(
        self,
        session_id: uuid.UUID,
        remote_jid: str,
        text: str,
        quoted_message_id: str | None = None,
    ) -> WhatsappMessageResponse | None:
        row = await self._get_session(session_id)
        if row is None:
            return None
        result = await self.bridge.send_text(row.bridge_session_id, remote_jid, text, quoted_message_id)
        msg = await self._persist_message(
            row,
            {
                "wa_message_id": result.get("wa_message_id") or str(uuid.uuid4()),
                "remote_jid": remote_jid,
                "from_me": True,
                "timestamp": result.get("timestamp") or int(datetime.now(UTC).timestamp() * 1000),
                "body": text,
                "content_type": "conversation",
            },
        )
        chat = await self._upsert_chat(row, {"remote_jid": remote_jid, "name": None})
        chat.last_message_preview = text[:512]
        chat.last_message_at = datetime.now(UTC)
        await self.db.commit()
        await self.db.refresh(msg)
        return WhatsappMessageResponse.model_validate(msg)

    async def handle_webhook(self, bridge_session_id: str, event: str, payload: dict) -> None:
        q = await self.db.execute(
            select(WhatsappSession).where(
                WhatsappSession.bridge_session_id == bridge_session_id,
                WhatsappSession.is_active.is_(True),
            )
        )
        session = q.scalar_one_or_none()
        if session is None:
            return

        if event == "qr":
            session.connection_status = "qr_pending"
            session.qr_image = payload.get("qr_image")
        elif event == "connected":
            session.connection_status = "connected"
            session.phone_number = payload.get("phone")
            session.push_name = payload.get("push_name")
            session.qr_image = None
            session.connected_at = datetime.now(UTC)
            session.last_error = None
            try:
                remote = await self.bridge.list_chats(session.bridge_session_id)
                for item in remote:
                    await self._upsert_chat(session, item)
            except Exception:
                pass
            try:
                from app.services.unified_contact_service import UnifiedContactService

                await UnifiedContactService(self.db, session.tenant_id, session.user_id).sync_contacts(
                    limit_per_source=80
                )
            except Exception:
                pass
        elif event == "disconnected":
            session.connection_status = "disconnected" if not payload.get("should_reconnect") else "reconnecting"
            session.last_error = payload.get("error")
        elif event == "chat":
            await self._upsert_chat(session, payload)
        elif event == "message":
            msg = await self._persist_message(session, payload)
            chat = await self._upsert_chat(session, {"remote_jid": payload.get("remote_jid"), "name": None})
            preview = payload.get("body") or f"[{payload.get('media_type') or 'media'}]"
            chat.last_message_preview = preview[:512]
            chat.last_message_at = _dt_from_ms(payload.get("timestamp")) or datetime.now(UTC)
            if msg.chat_id is None:
                msg.chat_id = chat.id
            if not payload.get("from_me"):
                chat.unread_count = (chat.unread_count or 0) + 1
                await self.db.flush()
                from app.services.communications_intelligence_service import CommunicationsIntelligenceService

                intel = CommunicationsIntelligenceService(self.db, session.tenant_id, session.user_id)
                await intel.auto_analyze_chat(session.id, chat.id)
                try:
                    from app.services.hermes_observation_service import HermesObservationService

                    await HermesObservationService(
                        self.db, session.tenant_id, session.user_id
                    ).ingest_from_whatsapp(session, msg, chat, payload)
                except Exception:
                    import logging

                    logging.getLogger(__name__).exception(
                        "Hermes observation hook failed (non-blocking)"
                    )

        await self.db.commit()

    async def _persist_message(self, session: WhatsappSession, data: dict) -> WhatsappMessage:
        wa_id = data.get("wa_message_id")
        if not wa_id:
            wa_id = str(uuid.uuid4())
        q = await self.db.execute(
            select(WhatsappMessage).where(
                WhatsappMessage.session_id == session.id,
                WhatsappMessage.wa_message_id == wa_id,
            )
        )
        existing = q.scalar_one_or_none()
        if existing:
            return existing

        chat_q = await self.db.execute(
            select(WhatsappChat).where(
                WhatsappChat.session_id == session.id,
                WhatsappChat.remote_jid == data.get("remote_jid"),
            )
        )
        chat = chat_q.scalar_one_or_none()

        tenant_id = session.tenant_id
        msg = WhatsappMessage(
            tenant_id=tenant_id,
            session_id=session.id,
            chat_id=chat.id if chat else None,
            wa_message_id=wa_id,
            remote_jid=data.get("remote_jid") or "",
            from_me=bool(data.get("from_me")),
            body=data.get("body"),
            media_type=data.get("media_type"),
            media_mime=data.get("media_mime"),
            content_type=data.get("content_type"),
            wa_timestamp_ms=data.get("timestamp"),
        )
        self.db.add(msg)
        return msg
