#!/usr/bin/env python3
"""Auditoría operativa API — DGII-CCC-PEEX-2026-0005."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/api/v1"
OPP = sys.argv[2] if len(sys.argv) > 2 else "ae07d012-4b67-4622-8507-bff9060c632b"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}


def req(method, path, token, body=None, raw=False):
    url = BASE + path
    h = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=120) as resp:
            raw_bytes = resp.read(800000)
            if raw:
                return resp.status, raw_bytes
            return resp.status, raw_bytes.decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(12000).decode(errors="replace")


def main():
    findings: list[dict] = []
    passes: list[str] = []

    def check(name, ok, detail, severity="info"):
        (passes if ok else findings).append({"name": name, "ok": ok, "detail": detail, "severity": severity})

    c, b = req("POST", "/auth/login", None, LOGIN)
    tok = json.loads(b)["access_token"]

    endpoints = {
        "opp": f"/dgcp/opportunities/{OPP}",
        "dashboard": "/dgcp/dashboard",
        "list": "/dgcp/opportunities?limit=150",
        "offer_prep": f"/dgcp/opportunities/{OPP}/offer-preparation-center",
        "hermes": f"/dgcp/opportunities/{OPP}/document-analysis",
        "checklist": f"/dgcp/opportunities/{OPP}/checklist",
        "forms": f"/dgcp/opportunities/{OPP}/forms/required",
        "autofill": ("POST", f"/dgcp/opportunities/{OPP}/forms/autofill-preview", {"form_key": "sncc_f033"}),
        "tech_sheets": f"/dgcp/opportunities/{OPP}/technical-sheets",
        "product_intel": f"/dgcp/opportunities/{OPP}/product-intelligence",
        "consolidated": ("POST", f"/dgcp/opportunities/{OPP}/offer-preparation-center/consolidated-offer", {}),
        "updates": f"/dgcp/opportunities/{OPP}/process-updates",
        "updates_dash": "/dgcp/process-updates/dashboard",
        "bid_pkg": f"/dgcp/opportunities/{OPP}/bid-package",
        "process_docs": f"/dgcp/opportunities/{OPP}/process-documents",
        "matches": f"/dgcp/opportunities/{OPP}/document-matches",
        "requirements": f"/dgcp/opportunities/{OPP}/requirements",
        "expediente_status": f"/dgcp/opportunities/{OPP}/bid-package/status",
    }

    data: dict = {}
    for key, spec in endpoints.items():
        if isinstance(spec, tuple):
            method, path, body = spec
            code, body_s = req(method, path, tok, body)
        else:
            code, body_s = req("GET", spec, tok)
        try:
            data[key] = json.loads(body_s) if code == 200 else {"_error": body_s[:300], "_code": code}
        except json.JSONDecodeError:
            data[key] = {"_raw": body_s[:300], "_code": code}

    opp = data["opp"]
    check("Proceso DGII-0005", opp.get("code") == "DGII-CCC-PEEX-2026-0005", f"code={opp.get('code')} status={opp.get('status')}")
    check("Dashboard", data["dashboard"].get("_code", 200) == 200, f"total={data['dashboard'].get('total_opportunities')}")
    found = any(i.get("id") == OPP for i in data["list"].get("items", []))
    check("Lista procesos incluye DGII", found, "en listado limit=150")

    opc = data["offer_prep"]
    pct = opc.get("executive_summary", {}).get("overall_preparation_pct")
    check("Estado General carga", opc.get("enabled") and pct is not None, f"pct={pct} areas={len(opc.get('areas',[]))}")
    check("Preparación no es 0% con avance", pct and pct > 0, f"pct={pct}", "high" if not pct else "info")

    hermes = data["hermes"]
    check("Hermes completed", hermes.get("status") == "completed", f"status={hermes.get('status')}")

    chk = data["checklist"]
    check("Checklist", chk.get("total", 0) > 0, f"total={chk.get('total')}")

    forms = data["forms"]
    req_forms = forms.get("required_forms") or []
    check("Formularios requeridos", len(req_forms) >= 3, f"count={len(req_forms)}")

    auto = data["autofill"]
    check("Autollenado", auto.get("generate_enabled") is not False, f"fields={len(auto.get('fields') or [])}")

    ts = data["tech_sheets"]
    sheets = ts.get("items") or []
    check("Fichas técnicas", ts.get("enabled") and len(sheets) > 0, f"items={len(sheets)}")

    sid = sheets[0]["id"] if sheets else None
    pdf_ok = False
    pdf_size = 0
    if sid:
        code, pdf_bytes = req("GET", f"/dgcp/opportunities/{OPP}/technical-sheets/{sid}/export?fmt=pdf", tok, raw=True)
        pdf_ok = code == 200 and len(pdf_bytes) > 500
        pdf_size = len(pdf_bytes)
    check("PDF ficha export", pdf_ok, f"size={pdf_size}")

    cons = data["consolidated"]
    content = (cons.get("content") or "").lower()
    check("Consolidado BORRADOR", cons.get("status") == "borrador", f"status={cons.get('status')}")
    check("Sin oferta económica auto", "oferta económica" not in content and "precio unitario" not in content[:2000], "content scan")

    upd = data["updates"]
    check("Actualizaciones", upd.get("enabled"), f"pending={upd.get('meta',{}).get('pending_count')}")

    bid = data["bid_pkg"]
    check("Bid package prep_pct alineado", abs(float(bid.get("preparation_pct") or 0) - float(pct or 0)) < 1, f"bid={bid.get('preparation_pct')} opc={pct}")

    # Coherence checks
    chk_items = chk.get("items") or []
    form_keys = {f.get("requirement_key") for f in req_forms}
    chk_form_keys = {i.get("requirement_key") for i in chk_items if "sncc" in (i.get("requirement_key") or "").lower()}
    overlap = form_keys & chk_form_keys
    check("Coherencia formularios vs checklist SNCC", len(overlap) >= 2, f"overlap={overlap}")

    hermes_docs = set((hermes.get("required_documents") or []) + (hermes.get("summary") or "").split())
    check("Hermes tiene summary", bool(hermes.get("summary")), hermes.get("summary", "")[:80])

    pi = data["product_intel"]
    check("Inteligencia técnica", pi.get("enabled"), f"items={len(pi.get('items') or [])}")

    print("=== AUDITORÍA API DGII-0005 ===\n")
    print(f"PASS: {len(passes)}  FINDINGS: {len(findings)}\n")
    for p in passes:
        print(f"  PASS  {p['name']}: {p['detail']}")
    for f in findings:
        print(f"  FAIL  [{f.get('severity','?')}] {f['name']}: {f['detail']}")
    return 0 if not findings else 1


if __name__ == "__main__":
    raise SystemExit(main())
