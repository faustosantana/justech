#!/usr/bin/env python3
"""Ejecución nocturna — autollenado QA de TODAS las plantillas M365 DGCP."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from sqlalchemy import select

from app.db.session import AsyncSessionLocal
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.tenant import Tenant
from app.models.user import User
from app.services.document_autofill.dgcp_autofill_batch_service import DgcpAutofillBatchService

REPORT_PATH = Path("/docs/DGCP_AUTOFILL_ALL_TEMPLATES_REPORT.md")
REPORT_PATH_FALLBACK = Path(__file__).resolve().parent.parent.parent / "docs" / "DGCP_AUTOFILL_ALL_TEMPLATES_REPORT.md"


def _write_report(content: str) -> Path:
    for path in (REPORT_PATH, REPORT_PATH_FALLBACK):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return path
        except OSError:
            continue
    raise OSError("No se pudo escribir el reporte")


PREVIOUS_BATCH = Path(
    "/var/jaios/expedientes/8ebfa281-cd3c-4017-8e47-c572a79d84b2/_autofill_qa_20260616_131540/batch_summary.json"
)


def load_previous_status() -> dict[str, str]:
    if not PREVIOUS_BATCH.is_file():
        return {}
    data = json.loads(PREVIOUS_BATCH.read_text(encoding="utf-8"))
    return {r["template_key"]: r["status"] for r in data.get("results", [])}


async def main() -> int:
    async with AsyncSessionLocal() as db:
        tenant = (await db.execute(select(Tenant).where(Tenant.slug == "justech"))).scalar_one_or_none()
        if not tenant:
            print("ERROR: tenant justech no encontrado", file=sys.stderr)
            return 1

        user = (
            await db.execute(select(User).where(User.email == "admin@justech.do"))
        ).scalar_one_or_none()

        opp = (
            await db.execute(
                select(DGCPOpportunity)
                .where(DGCPOpportunity.tenant_id == tenant.id)
                .order_by(DGCPOpportunity.created_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if not opp:
            print("ERROR: sin oportunidades DGCP", file=sys.stderr)
            return 1

        batch = DgcpAutofillBatchService(db, tenant.id, user.id if user else None)
        templates = await batch.list_all_templates()
        print(f"Iniciando batch: {len(templates)} plantillas | oportunidad={opp.code}")

        previous_status = load_previous_status()
        results = await batch.run_all(
            opp,
            company="justech",
            user_email=user.email if user else None,
        )

        report = DgcpAutofillBatchService.render_markdown_report(
            results,
            output_dir=str(batch.output_root),
            previous_status=previous_status or None,
        )
        report_path = _write_report(report)

        passed = sum(1 for r in results if r.status == "READY_FOR_SIGNATURE")
        draft = sum(1 for r in results if r.status == "DRAFT_OK")
        blocked = sum(1 for r in results if r.status == "BLOCKED")
        failed = sum(1 for r in results if r.status == "FAILED")

        print(f"\nCompletado: READY={passed} DRAFT={draft} BLOCKED={blocked} FAILED={failed}")
        print(f"Reporte: {report_path}")
        print(f"QA output: {batch.output_root}")
        return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
