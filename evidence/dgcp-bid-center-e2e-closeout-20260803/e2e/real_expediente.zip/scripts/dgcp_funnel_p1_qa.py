#!/usr/bin/env python3
"""Validación embudo operativo P1 — flujo completo API."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://jaios.justech.do/api/v1"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}

DGII_CODE = "DGII-CCC-PEEX-2026-0005"
RESIDE_CODE = "RESIDE-DAF-CD-2026-0037"


def req(method: str, path: str, token: str, body=None):
    url = BASE + path
    headers = {"Accept": "application/json", "Content-Type": "application/json", "Authorization": f"Bearer {token}"}
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")


def find_by_code(token: str, code: str) -> dict | None:
    _, data = req("GET", f"/dgcp/opportunities?search={code}&include_expired=true&limit=5", token)
    for item in data.get("items", []):
        if item.get("code") == code:
            return item
    return None


def action(token: str, opp_id: str, act: str) -> tuple[int, dict]:
    return req("POST", f"/dgcp/opportunities/{opp_id}/actions", token, {"action": act})


def main() -> int:
    print(f"=== P1 Funnel QA ===\n{BASE}\n")
    _, login = req("POST", "/auth/login", "", LOGIN)
    token = login["access_token"]

    results: list[tuple[str, str, str]] = []

    def check(name: str, ok: bool, detail: str = ""):
        results.append((name, "PASS" if ok else "FAIL", detail))
        print(f"{'PASS' if ok else 'FAIL'} {name}" + (f" — {detail}" if detail else ""))

    # Proceso nuevo sin interés — buscar detected
    _, nuevas = req("GET", "/dgcp/opportunities?funnel_stage=nuevas&limit=5", token)
    nuevo = next((o for o in nuevas.get("items", []) if o.get("status") == "detected"), None)
    check("Lista funnel nuevas", len(nuevas.get("items", [])) >= 0, f"{len(nuevas.get('items', []))} items")
    if nuevo:
        check("Nuevo tiene primary marcar_interes", nuevo.get("primary_action") == "marcar_interes")
        check("Nuevo no puede adjudicar", "marcar_adjudicada" not in (nuevo.get("available_actions") or []))

    dgii = find_by_code(token, DGII_CODE)
    reside = find_by_code(token, RESIDE_CODE)
    check("DGII encontrado", dgii is not None, dgii.get("id", "") if dgii else "")
    check("RESIDE encontrado", reside is not None, reside.get("id", "") if reside else "")

    if dgii:
        check("DGII tiene funnel_stage_label", bool(dgii.get("funnel_stage_label")))
        check("DGII tiene next_recommended_action", bool(dgii.get("next_recommended_action")))

    # Flujo completo en proceso de prueba temporal si existe nuevo
    test = nuevo or dgii
    if test:
        oid = test["id"]
        # Reset to detected for flow test only if discarded/lost - skip destructive on prod DGII
        # Use search for a low-value process
        _, all_items = req("GET", "/dgcp/opportunities?search=JAIOS-QA&include_expired=true&limit=5", token)
        qa = next((o for o in all_items.get("items", []) if "QA" in o.get("code", "")), None)
        if qa and qa.get("status") not in ("submitted", "awarded", "lost"):
            oid = qa["id"]
            steps = [
                ("marcar_interes", "interesadas"),
                ("iniciar_preparacion", "en_preparacion"),
                ("marcar_listo_presentar", "listas_para_presentar"),
                ("marcar_presentada", "presentadas"),
            ]
            for act, expected_stage in steps:
                code, updated = action(token, oid, act)
                ok = code == 200 and updated.get("funnel_stage") == expected_stage
                check(f"Acción {act} → {expected_stage}", ok, updated.get("status_label", str(code)))
            # Adjudicada solo después de presentada
            code, adj = action(token, oid, "marcar_adjudicada")
            check("Adjudicada tras presentada", code == 200 and adj.get("funnel_stage") == "adjudicadas")
            # Bandeja expedientes
            _, exp = req("GET", f"/dgcp/opportunities?funnel_stage=adjudicadas&search={qa.get('code','')[:20]}", token)
            check("Visible en bandeja adjudicadas", any(i["id"] == oid for i in exp.get("items", [])))
        else:
            check("Flujo E2E QA process", False, "sin proceso QA disponible")

    # Validar bloqueo adjudicar desde preparación
    if reside and reside.get("funnel_stage") == "en_preparacion":
        code, _ = action(token, reside["id"], "marcar_adjudicada")
        check("RESIDE bloquea adjudicar desde preparación", code == 409)

    print("\n=== TABLA PASS/FAIL ===")
    for name, status, detail in results:
        print(f"| {status} | {name} | {detail} |")

    fails = sum(1 for _, s, _ in results if s == "FAIL")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
