#!/usr/bin/env python3
"""QA DGCP estabilización — URL pública HTTPS (NPM)."""

from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://jaios.justech.do/api/v1"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}

LIMITS = {
    "detail": 2.0,
    "commercial-context": 5.0,
    "intelligence": 2.0,
    "checklist": 5.0,
    "requirements": 5.0,
    "alerts": 3.0,
}


def req(method: str, path: str, token: str | None = None, body=None, timeout=90):
    url = BASE + path
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    t0 = time.time()
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            elapsed = time.time() - t0
            body_bytes = resp.read(80000)
            return resp.status, body_bytes.decode(errors="replace"), elapsed
    except urllib.error.HTTPError as e:
        elapsed = time.time() - t0
        return e.code, e.read(8000).decode(errors="replace"), elapsed
    except Exception as e:
        elapsed = time.time() - t0
        return "ERR", str(e), elapsed


def main() -> int:
    print(f"=== DGCP Public HTTPS QA ===\nBase: {BASE}\n")

    code, body, _ = req("POST", "/auth/login", None, LOGIN, timeout=30)
    if code != 200:
        print(f"FAIL login HTTP {code}: {body[:300]}")
        return 1
    tok = json.loads(body)["access_token"]
    print("PASS login\n")

    global_checks = [
        ("health", "GET", "/health", None, 5.0),
        ("autofill-templates", "GET", "/dgcp/autofill-templates", None, 10.0),
        ("m365-connection", "GET", "/m365/connection", None, 5.0),
        ("documents-dashboard", "GET", "/documents/dashboard", None, 5.0),
        ("documents-repositories", "GET", "/documents/repositories", None, 5.0),
    ]

    fails = 0
    errors_5xx = []

    for name, method, path, _, limit in global_checks:
        c, b, t = req(method, path, tok, timeout=60)
        ok = c == 200 and t <= limit
        if c in (500, 502, 503, 504):
            errors_5xx.append((name, c, path, b[:200]))
        if not ok:
            fails += 1
        print(f"{'PASS' if ok else 'FAIL'} GLOBAL {name}: HTTP {c} in {t:.2f}s (limit {limit}s)")

    # document access — use first knowledge asset from dashboard if available
    c_dash, b_dash, _ = req("GET", "/documents/dashboard", tok)
    asset_id = None
    if c_dash == 200:
        try:
            dash = json.loads(b_dash)
            for key in ("recent", "items", "alerts"):
                items = dash.get(key)
                if isinstance(items, list) and items:
                    asset_id = items[0].get("knowledge_asset_id") or items[0].get("id")
                    if asset_id:
                        break
        except json.JSONDecodeError:
            pass

    if not asset_id:
        c_k, b_k, _ = req("GET", "/knowledge/assets?limit=1", tok)
        if c_k == 200:
            try:
                items = json.loads(b_k).get("items") or []
                if items:
                    asset_id = items[0].get("id")
            except json.JSONDecodeError:
                pass

    if asset_id:
        c, b, t = req("GET", f"/documents/access?knowledge_asset_id={asset_id}", tok)
        ok = c in (200, 302) and t <= 5.0
        if c in (500, 502, 503, 504):
            errors_5xx.append(("document-access", c, f"/documents/access?...", b[:200]))
        if not ok:
            fails += 1
        print(f"{'PASS' if ok else 'FAIL'} GLOBAL document-access: HTTP {c} in {t:.2f}s asset={asset_id[:8]}...")
    else:
        print("SKIP GLOBAL document-access: no knowledge asset found")

    code, body, _ = req("GET", "/dgcp/opportunities?limit=10", tok, timeout=60)
    if code != 200:
        print(f"FAIL opportunities list HTTP {code}")
        return 1
    try:
        items = json.loads(body).get("items") or []
    except json.JSONDecodeError as e:
        print(f"FAIL opportunities JSON parse: {e}")
        return 1

    if len(items) < 10:
        print(f"WARN only {len(items)} opportunities returned")

    print(f"\n--- Per-opportunity ({min(10, len(items))} processes) ---\n")

    opp_fails = 0
    for opp in items[:10]:
        oid = opp["id"]
        code_label = opp.get("code", oid[:8])
        row_fails = 0

        checks = [
            ("detail", f"/dgcp/opportunities/{oid}"),
            ("commercial-context", f"/dgcp/opportunities/{oid}/commercial-context"),
            ("intelligence", f"/dgcp/opportunities/{oid}/intelligence"),
            ("alerts", f"/dgcp/opportunities/{oid}/alerts"),
            ("checklist", f"/dgcp/opportunities/{oid}/checklist"),
            ("requirements", f"/dgcp/opportunities/{oid}/requirements"),
            ("process-documents", f"/dgcp/opportunities/{oid}/process-documents"),
        ]

        parts = [code_label]
        for name, path in checks:
            limit = LIMITS.get(name, 10.0)
            c, b, t = req("GET", path, tok, timeout=60)
            if name == "alerts":
                ok = c == 200 and c not in (404, 500, 502, 503, 504)
            elif name in ("checklist", "requirements", "process-documents"):
                ok = c == 200
            else:
                ok = c == 200 and t <= limit
            if c in (500, 502, 503, 504):
                errors_5xx.append((f"{code_label}/{name}", c, path, b[:200]))
            if not ok:
                row_fails += 1
            parts.append(f"{name}={c}({t:.1f}s)")

        status = "PASS" if row_fails == 0 else "FAIL"
        if row_fails:
            opp_fails += 1
            fails += 1
        print(f"{status} | {' | '.join(parts)}")

    print(f"\n=== SUMMARY ===")
    print(f"Opportunities: {10 - opp_fails}/10 PASS")
    print(f"Total failures: {fails}")
    if errors_5xx:
        print(f"\n5xx ERRORS ({len(errors_5xx)}):")
        for label, c, path, snippet in errors_5xx:
            print(f"  {label}: HTTP {c} {path}")
            print(f"    {snippet[:120]}")
        return 1
    return 0 if fails == 0 and opp_fails == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
