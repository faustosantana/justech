#!/usr/bin/env python3
"""QA estabilización DGCP — Fase P4."""

from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://jaios.justech.do/api/v1"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}


def req(method, path, token, body=None, timeout=60):
    url = BASE + path
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        t0 = time.time()
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            elapsed = time.time() - t0
            return resp.status, resp.read(50000).decode(errors="replace"), elapsed
    except urllib.error.HTTPError as e:
        elapsed = time.time() - t0
        return e.code, e.read(5000).decode(errors="replace"), elapsed


def main() -> int:
    code, body, _ = req("POST", "/auth/login", None, LOGIN)
    if code != 200:
        print("FAIL login", code, body[:200])
        return 1
    tok = json.loads(body)["access_token"]

    code, body, _ = req("GET", "/dgcp/opportunities?limit=10", tok)
    items = json.loads(body).get("items") or [] if code == 200 else []
    if not items:
        print("FAIL no opportunities")
        return 1

    fails = 0
    print(f"Testing {min(10, len(items))} opportunities on {BASE}\n")

    for opp in items[:10]:
        oid = opp["id"]
        code = opp.get("code", oid[:8])

        c1, _, t1 = req("GET", f"/dgcp/opportunities/{oid}", tok)
        c2, _, t2 = req("GET", f"/dgcp/opportunities/{oid}/commercial-context", tok)
        c3, _, _ = req("GET", f"/dgcp/opportunities/{oid}/intelligence", tok)
        c4, _, _ = req("GET", f"/dgcp/opportunities/{oid}/checklist", tok)
        c5, _, _ = req("GET", f"/dgcp/opportunities/{oid}/alerts", tok)

        ok = c1 == 200 and c2 == 200 and c3 == 200 and c4 in (200, 404) and c5 == 200
        fast = t1 < 2.0 and t2 < 5.0
        status = "PASS" if ok and fast else "FAIL"
        if status == "FAIL":
            fails += 1
        print(
            f"{status} {code}: detail={c1} ctx={c2}({t2:.1f}s) intel={c3} "
            f"checklist={c4} alerts={c5} detail_t={t1:.1f}s"
        )

    print(f"\nSUMMARY: {10 - fails}/10 pass, failures={fails}")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
