#!/usr/bin/env python3
"""Auditoría documental, duplicados y porcentajes — JAIOS QA."""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import func, select, text

# Expected document_type per field/requirement with filename keywords for validation
EMPRESA_FIELD_EXPECTED: dict[str, dict] = {
    "tss": {"document_type": "tss", "keywords": ("tss", "seguro social")},
    "dgii": {"document_type": "dgii", "keywords": ("dgii", "impuestos", "obligaciones")},
    "mipyme": {"document_type": "mipyme", "keywords": ("mipyme", "mipymes", "micro", "pequeña")},
    "registro_mercantil": {"document_type": "registro_mercantil", "keywords": ("registro", "mercantil", "rm")},
    "proveedor_estado": {"document_type": "proveedor_estado", "keywords": ("rpe", "proveedor", "estado")},
    "certificacion_bancaria": {"document_type": "certificacion_bancaria", "keywords": ("banc", "certificacion bancaria", "certificación bancaria")},
    "datos_bancarios": {"document_type": "certificacion_bancaria", "keywords": ("banc", "certificacion bancaria", "datos bancarios")},
    "poderes": {"document_type": "poderes", "keywords": ("poder",)},
    "acta_asamblea": {"document_type": "acta_asamblea", "keywords": ("acta", "asamblea")},
    "estatutos": {"document_type": "estatutos", "keywords": ("estatuto",)},
    "cedula_representante": {"document_type": "cedula_representante", "keywords": ("cedula", "cédula", "identidad")},
}

DGCP_REQUIREMENT_EXPECTED: dict[str, dict] = {
    "certificacion_tss": {"document_type": "tss", "keywords": ("tss", "seguro social")},
    "certificacion_dgii": {"document_type": "dgii", "keywords": ("dgii", "impuestos", "obligaciones")},
    "certificacion_mipyme": {"document_type": "mipyme", "keywords": ("mipyme", "mipymes")},
    "registro_mercantil": {"document_type": "registro_mercantil", "keywords": ("registro", "mercantil")},
    "rpe_vigente": {"document_type": "proveedor_estado", "keywords": ("rpe", "proveedor")},
    "proveedor_estado": {"document_type": "proveedor_estado", "keywords": ("rpe", "proveedor")},
    "certificacion_bancaria": {"document_type": "certificacion_bancaria", "keywords": ("banc", "certificacion bancaria")},
    "oferta_tecnica": {"document_type": "oferta_tecnica", "keywords": ("tecnica", "técnica", "propuesta", "oferta")},
    "oferta_economica": {"document_type": "oferta_economica", "keywords": ("economica", "económica", "precio", "cotizacion", "acta", "asamblea")},
    "sncc_f042": {"document_type": "sncc", "keywords": ("f042", "f.042", "sncc", "oferente", "informacion")},
}

TENANT_ID = uuid.UUID("8ebfa281-cd3c-4017-8e47-c572a79d84b2")
COMPANY_ID = uuid.UUID("5ed03b8e-757a-4a96-b0f7-27c657dffcb4")
DGCP_OPP_ID = uuid.UUID("6b1f81e8-22e7-44de-98aa-e633e9909b5b")


def _norm(s: str | None) -> str:
    return (s or "").lower().replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")


def filename_matches(doc_type: str, filename: str, keywords: tuple[str, ...]) -> bool:
    fn = _norm(filename)
    if any(k in fn for k in keywords):
        return True
    # document_type in filename is weak signal
    dt = _norm(doc_type).replace("_", " ")
    if dt and dt in fn.replace("_", " "):
        return True
    return False


def type_matches(expected_type: str, actual_type: str | None) -> bool:
    if not actual_type:
        return False
    e, a = _norm(expected_type), _norm(actual_type)
    if e == a:
        return True
    # aliases
    aliases = {
        "proveedor_estado": ("rpe", "certificacion_proveedor_estado"),
        "tss": ("certificacion_tss",),
        "dgii": ("certificacion_dgii",),
        "mipyme": ("certificacion_mipyme",),
    }
    for alt in aliases.get(e, ()):
        if a == alt or alt in a:
            return True
    return False


async def main() -> None:
    from app.db.session import AsyncSessionLocal
    from app.models.document_link import DocumentLink
    from app.models.knowledge import KnowledgeAsset
    from app.models.m365_repository import M365RepositoryFile
    from app.models.licitador_company_profile import LicitadorCompanyProfile
    from app.services.company_profile_field_service import CompanyProfileFieldService, FIELD_DEFINITIONS
    from app.services.dgcp_bid_package_service import DGCPBidPackageService
    from app.models.dgcp_opportunity import DGCPOpportunity

    user_id = None
    async with AsyncSessionLocal() as db:
        # --- Empresas completion ---
        profile = (
            await db.execute(
                select(LicitadorCompanyProfile).where(
                    LicitadorCompanyProfile.id == COMPANY_ID,
                    LicitadorCompanyProfile.tenant_id == TENANT_ID,
                )
            )
        ).scalar_one_or_none()

        field_svc = CompanyProfileFieldService(db, TENANT_ID, user_id=user_id)
        completion = await field_svc.get_completion(COMPANY_ID)

        req_rows: list[dict] = []
        for f in completion.fields:
            if f.kind not in ("document", "hybrid") or f.status in ("missing",):
                if f.field_key in EMPRESA_FIELD_EXPECTED and f.document_name:
                    pass  # still audit if has doc name while missing status
                if not f.document_id and not f.document_name:
                    continue
            exp = EMPRESA_FIELD_EXPECTED.get(f.field_key) or FIELD_DEFINITIONS.get(f.field_key, {})
            expected_type = exp.get("document_type") if isinstance(exp, dict) else None
            if not expected_type and isinstance(exp, dict):
                expected_type = exp.get("document_type")
            if f.field_key in FIELD_DEFINITIONS:
                expected_type = expected_type or FIELD_DEFINITIONS[f.field_key].get("document_type")

            asset = None
            if f.document_id:
                asset = await db.get(KnowledgeAsset, uuid.UUID(f.document_id))

            actual_type = asset.document_type if asset else None
            filename = f.document_name or (asset.filename if asset else "")
            meta_fk = (asset.metadata_ or {}).get("field_key") if asset else None

            keywords = tuple()
            if f.field_key in EMPRESA_FIELD_EXPECTED:
                keywords = EMPRESA_FIELD_EXPECTED[f.field_key]["keywords"]
            elif expected_type:
                keywords = (expected_type.replace("_", " "),)

            type_ok = type_matches(expected_type, actual_type) if expected_type and actual_type else None
            name_ok = filename_matches(expected_type or f.field_key, filename, keywords) if filename else None
            fk_ok = (meta_fk == f.field_key) if meta_fk else None

            if expected_type or f.document_id:
                correct = bool(type_ok and (name_ok is not False) and (fk_ok is not False))
                if f.status == "missing":
                    correct = False
                req_rows.append(
                    {
                        "scope": "empresa",
                        "requirement": f.field_key,
                        "label": f.label,
                        "expected_document_type": expected_type,
                        "associated_document": filename or "—",
                        "actual_document_type": actual_type,
                        "metadata_field_key": meta_fk,
                        "status": f.status,
                        "type_match": type_ok,
                        "filename_match": name_ok,
                        "field_key_metadata_match": fk_ok,
                        "correct": correct if f.status not in ("missing",) else "N/A (sin documento)",
                    }
                )

        # --- DGCP checklist ---
        opp = await db.get(DGCPOpportunity, DGCP_OPP_ID)
        dgcp_svc = DGCPBidPackageService(db, TENANT_ID, user_id=user_id)
        checklist_resp = await dgcp_svc.get_checklist(DGCP_OPP_ID)

        dgcp_rows: list[dict] = []
        for item in checklist_resp.items:
            key = item.requirement_key
            exp = DGCP_REQUIREMENT_EXPECTED.get(key, {})
            expected_type = exp.get("document_type", key)
            title = item.document_title or "—"
            keywords = exp.get("keywords", (key.replace("_", " "),))

            asset_type = None
            if item.knowledge_asset_id:
                asset = await db.get(KnowledgeAsset, uuid.UUID(str(item.knowledge_asset_id)))
                if asset:
                    asset_type = asset.document_type

            type_ok = type_matches(expected_type, asset_type) if asset_type and key not in ("sncc_f042", "oferta_economica", "oferta_tecnica") else None
            name_ok = filename_matches(expected_type, title, keywords) if title != "—" else None

            # SNCC forms: filename match is primary
            if key.startswith("sncc_"):
                type_ok = True
                name_ok = filename_matches("sncc", title, keywords)

            if key == "oferta_economica":
                # economic offer may be acta or quotation — flag if clearly wrong category
                name_ok = any(k in _norm(title) for k in keywords) if title != "—" else None

            has_doc = bool(item.document_title or item.knowledge_asset_id)
            if not has_doc:
                correct = "N/A (sin documento)"
            elif name_ok is False or (type_ok is False):
                correct = False
            elif item.display_status == "Faltante":
                correct = False
            else:
                correct = True

            dgcp_rows.append(
                {
                    "scope": "dgcp",
                    "requirement": key,
                    "label": item.requirement,
                    "expected_document_type": expected_type,
                    "associated_document": title,
                    "actual_document_type": asset_type,
                    "display_status": item.display_status,
                    "status": item.status,
                    "type_match": type_ok,
                    "filename_match": name_ok,
                    "correct": correct,
                }
            )

        # --- Duplicates ---
        assets = list(
            (
                await db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == TENANT_ID,
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalars().all()
        )

        by_path: dict[str, list] = defaultdict(list)
        by_hash: dict[str, list] = defaultdict(list)
        by_graph: dict[str, list] = defaultdict(list)
        by_type_company: dict[tuple, list] = defaultdict(list)

        for a in assets:
            by_path[a.relative_path].append(a)
            if a.content_hash:
                by_hash[a.content_hash].append(a)
            gid = (a.metadata_ or {}).get("graph_item_id")
            if gid:
                by_graph[str(gid)].append(a)
            if a.company_key and a.document_type:
                by_type_company[(a.company_key, a.document_type)].append(a)

        dup_path = {p: ids for p, ids in ((p, [str(x.id) for x in xs]) for p, xs in by_path.items()) if len(ids) > 1}
        dup_hash = {h: ids for h, ids in ((h, [str(x.id) for x in xs]) for h, xs in by_hash.items()) if len(ids) > 1}
        dup_graph = {g: ids for g, ids in ((g, [str(x.id) for x in xs]) for g, xs in by_graph.items()) if len(ids) > 1}
        dup_type_co = {
            f"{k[0]}:{k[1]}": [{"id": str(x.id), "filename": x.filename, "path": x.relative_path} for x in xs]
            for k, xs in by_type_company.items()
            if len(xs) > 1
        }

        links = list(
            (
                await db.execute(select(DocumentLink).where(DocumentLink.tenant_id == TENANT_ID))
            ).scalars().all()
        )
        asset_ids = {str(a.id) for a in assets}
        orphan_links = [
            {
                "id": str(l.id),
                "entity_type": l.entity_type,
                "requirement_id": l.requirement_id,
                "file_name": l.file_name,
                "item_id": l.item_id,
            }
            for l in links
            if l.raw_payload_json and l.raw_payload_json.get("knowledge_asset_id")
            and str(l.raw_payload_json.get("knowledge_asset_id")) not in asset_ids
        ]

        m365_files = list(
            (
                await db.execute(
                    select(M365RepositoryFile).where(
                        M365RepositoryFile.tenant_id == TENANT_ID,
                        M365RepositoryFile.is_deleted.is_(False),
                        M365RepositoryFile.is_folder.is_(False),
                    )
                )
            ).scalars().all()
        )
        m365_by_graph: dict[str, list] = defaultdict(list)
        for f in m365_files:
            if f.graph_item_id:
                m365_by_graph[f.graph_item_id].append(f)
        dup_m365_graph = {g: [str(x.id) for x in xs] for g, xs in m365_by_graph.items() if len(xs) > 1}

        # Percentages
        pct_empresas = {
            "formula": "completeness_score = floor(complete_count / total_fields * 100)",
            "total_fields": completion.fields_total,
            "fields_complete": completion.fields_complete,
            "completeness_score": completion.completeness_score,
            "calculated": int((completion.fields_complete / completion.fields_total) * 100)
            if completion.fields_total
            else 0,
            "note": "fields_complete incluye representantes validados; puede diferir del contador interno complete_count",
        }

        mandatory = [i for i in checklist_resp.items if i.mandatory]
        from app.services.dgcp_compliance_engine import DGCPComplianceEngine, COMPLIANT_STATUSES

        comp = DGCPComplianceEngine()

        def counts_compliant(item) -> bool:
            st = item.status
            if st not in COMPLIANT_STATUSES:
                return False
            if st == "no_aplica":
                return True
            return comp.has_document_evidence({}, item.model_dump())

        compliant = sum(1 for i in mandatory if counts_compliant(i))
        prep_calc = round((compliant / len(mandatory)) * 100, 1) if mandatory else 0

        pct_dgcp = {
            "formula": "preparation_pct = round(compliant_mandatory / total_mandatory * 100, 1); cap 99.9 si hay bloqueantes",
            "total_mandatory": len(mandatory),
            "compliant_count": compliant,
            "preparation_pct_api": checklist_resp.preparation_pct if hasattr(checklist_resp, "preparation_pct") else None,
            "calculated_raw": prep_calc,
            "display_counts": {
                "cumplidos": sum(1 for i in checklist_resp.items if i.display_status == "Cumplido"),
                "faltantes": sum(1 for i in checklist_resp.items if i.display_status == "Faltante"),
                "pendiente_completar": sum(1 for i in checklist_resp.items if "completar" in (i.display_status or "").lower()),
            },
        }

        bindings = (
            await db.execute(
                text(
                    "SELECT id, label, indexed_files, folder_key FROM jaios.integration_repository_bindings "
                    "WHERE tenant_id = :tid ORDER BY label"
                ),
                {"tid": str(TENANT_ID)},
            )
        ).mappings().all()
        actual_counts = {}
        for b in bindings:
            cnt = await db.scalar(
                select(func.count())
                .select_from(M365RepositoryFile)
                .where(
                    M365RepositoryFile.tenant_id == TENANT_ID,
                    M365RepositoryFile.binding_id == b["id"],
                    M365RepositoryFile.is_deleted.is_(False),
                    M365RepositoryFile.is_folder.is_(False),
                )
            )
            actual_counts[str(b["label"])] = {
                "binding_indexed_files": b["indexed_files"],
                "actual_m365_rows": int(cnt or 0),
                "match": b["indexed_files"] == int(cnt or 0),
            }

        out = {
            "generated_at": datetime.now(UTC).isoformat(),
            "tenant_id": str(TENANT_ID),
            "requirement_audit": req_rows + dgcp_rows,
            "duplication": {
                "knowledge_assets_total": len(assets),
                "duplicate_relative_path": dup_path,
                "duplicate_content_hash": {k: v for k, v in list(dup_hash.items())[:20]},
                "duplicate_graph_item_id": dup_graph,
                "duplicate_company_document_type": dup_type_co,
                "orphan_document_links": orphan_links[:50],
                "duplicate_m365_repository_graph_id": dup_m365_graph,
            },
            "percentages": {
                "empresas": pct_empresas,
                "dgcp": pct_dgcp,
                "documentos_hub_bindings": actual_counts,
            },
        }

        out_path = Path("/tmp/document_audit.json")
        out_path.write_text(json.dumps(out, indent=2, default=str))
        print(out_path.read_text())


if __name__ == "__main__":
    asyncio.run(main())
