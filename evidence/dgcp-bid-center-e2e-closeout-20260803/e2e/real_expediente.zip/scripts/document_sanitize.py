#!/usr/bin/env python3
"""Saneamiento documental — desvincular matches incorrectos, deduplicar assets, recalcular %."""

from __future__ import annotations

import asyncio
import copy
import json
import uuid
from collections import defaultdict
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import select, text

from app.services.document_requirement_validator import (
    validate_asset_for_requirement,
    validate_sncc_compliance,
)

TENANT_ID = uuid.UUID("8ebfa281-cd3c-4017-8e47-c572a79d84b2")
COMPANY_ID = uuid.UUID("5ed03b8e-757a-4a96-b0f7-27c657dffcb4")
DGCP_OPP_ID = uuid.UUID("6b1f81e8-22e7-44de-98aa-e633e9909b5b")

DOC_FIELDS = (
    "document_id",
    "knowledge_asset_id",
    "process_document_id",
    "document_title",
    "match_source",
    "relative_path",
    "valid_until",
    "vigency_status",
    "validity_analysis",
    "match_score",
    "odoo_quotation_id",
)


def _clear_item_document(item: dict, *, label: str | None = None) -> None:
    for k in DOC_FIELDS:
        item.pop(k, None)
    item["status"] = "faltante"
    item["notes"] = f"Solicitar o registrar: {label or item.get('requirement', 'documento')}"
    item.pop("display_status", None)
    item["risk"] = "Requisito obligatorio sin documento asociado" if item.get("mandatory", True) else None


def _asset_sort_key(asset) -> tuple:
    return (
        asset.analyzed_at or asset.synced_at or asset.created_at,
        asset.created_at,
    )


async def main() -> None:
    from app.db.session import AsyncSessionLocal
    from app.models.dgcp_bid_package import DGCPBidPackage
    from app.models.knowledge import KnowledgeAsset
    from app.models.licitador_company_profile import LicitadorCompanyProfile
    from app.services.company_profile_field_service import CompanyProfileFieldService
    from app.services.dgcp_bid_package_service import DGCPBidPackageService
    from app.services.dgcp_compliance_engine import DGCPComplianceEngine

    report: dict = {
        "generated_at": datetime.now(UTC).isoformat(),
        "before": {},
        "actions": [],
        "after": {},
    }

    async with AsyncSessionLocal() as db:
        # --- BEFORE metrics ---
        field_svc = CompanyProfileFieldService(db, TENANT_ID)
        completion_before = await field_svc.get_completion(COMPANY_ID)
        report["before"]["empresas"] = {
            "fields_complete": completion_before.fields_complete,
            "fields_total": completion_before.fields_total,
            "completeness_score": completion_before.completeness_score,
        }

        pkg = (
            await db.execute(
                select(DGCPBidPackage).where(DGCPBidPackage.opportunity_id == DGCP_OPP_ID)
            )
        ).scalar_one_or_none()
        if not pkg:
            raise SystemExit("DGCP bid package not found")

        checklist_before = copy.deepcopy(pkg.checklist or [])
        bid_before = pkg.bid_package or {}
        report["before"]["dgcp"] = {
            "preparation_pct": bid_before.get("preparation_pct"),
            "checklist": [
                {
                    "requirement_key": i.get("requirement_key"),
                    "document_title": i.get("document_title"),
                    "status": i.get("status"),
                    "display_status": i.get("display_status"),
                }
                for i in checklist_before
            ],
        }

        binding_row = (
            await db.execute(
                text(
                    "SELECT indexed_files FROM jaios.integration_repository_bindings "
                    "WHERE id = 'd648ecab-63cd-4be5-9e89-1142004d0532'"
                )
            )
        ).scalar()
        assets_before = (
            await db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == TENANT_ID,
                    KnowledgeAsset.is_active.is_(True),
                )
            )
        ).scalars().all()
        report["before"]["hub_legal_indexed"] = binding_row
        report["before"]["knowledge_assets_active"] = len(assets_before)

        # --- 1. Sanitize DGCP checklist ---
        checklist = copy.deepcopy(pkg.checklist or [])
        comp = DGCPComplianceEngine()

        for item in checklist:
            key = item.get("requirement_key") or ""
            title = item.get("document_title")
            asset = None
            kid = item.get("knowledge_asset_id")
            if kid:
                asset = await db.get(KnowledgeAsset, uuid.UUID(str(kid)))

            if key.startswith("sncc_"):
                sncc_ok = validate_sncc_compliance(
                    filename=title or (asset.filename if asset else None),
                    status=item.get("status"),
                    completable=bool(item.get("completable")),
                )
                if item.get("status") in ("encontrado_vigente", "validado_manual") or not sncc_ok.ok:
                    item["status"] = "requiere_completado"
                    item["notes"] = "Formulario / plantilla — requiere completado"
                    item.pop("display_status", None)
                    report["actions"].append(
                        {"action": "sncc_requiere_completado", "requirement": key, "title": title}
                    )
                continue

            if not kid and not item.get("document_id") and not item.get("process_document_id"):
                continue

            vr = validate_asset_for_requirement(
                key,
                filename=asset.filename if asset else title,
                title=asset.title if asset else title,
                document_type=asset.document_type if asset else None,
                asset=asset,
            )
            if not vr.ok:
                prev = {"requirement": key, "document": title, "reason": vr.reason}
                _clear_item_document(item, label=item.get("requirement"))
                report["actions"].append({"action": "dgcp_unlink", **prev})

        # Sync document_matches
        matches = copy.deepcopy(pkg.document_matches or [])
        match_by_key = {m.get("requirement_key"): m for m in matches}
        for item in checklist:
            key = item.get("requirement_key")
            if item.get("status") == "faltante" and key in match_by_key:
                m = match_by_key[key]
                for k in DOC_FIELDS:
                    m.pop(k, None)
                m["status"] = "faltante"
                m["match_score"] = 0.0
                m["notes"] = item.get("notes")

        pkg.checklist = checklist
        pkg.document_matches = list(match_by_key.values())

        from app.models.dgcp_opportunity import DGCPOpportunity

        opp = await db.get(DGCPOpportunity, DGCP_OPP_ID)
        bid_resp = comp.build_bid_package(opp, checklist)
        pkg.bid_package = bid_resp.model_dump(mode="json")

        # Sanitize stored items metadata
        pkg.checklist = [comp.sanitize_stored_checklist_item(i) for i in checklist]

        # --- 2. Deduplicate assets ---
        all_assets = list(
            (
                await db.execute(
                    select(KnowledgeAsset).where(
                        KnowledgeAsset.tenant_id == TENANT_ID,
                        KnowledgeAsset.is_active.is_(True),
                    )
                )
            ).scalars().all()
        )

        def group_key(asset: KnowledgeAsset) -> str | None:
            meta = asset.metadata_ or {}
            gid = meta.get("graph_item_id")
            if gid:
                return f"graph:{gid}"
            web = meta.get("web_url")
            if web:
                return f"web:{web}"
            drive = meta.get("drive_id") or meta.get("parent_drive_id")
            item_id = meta.get("item_id") or meta.get("graph_item_id")
            if drive and item_id:
                return f"drive:{drive}:{item_id}"
            if asset.filename and asset.file_size and asset.source_modified_at:
                return f"file:{asset.filename}:{asset.file_size}:{asset.source_modified_at.isoformat()}"
            if asset.relative_path:
                return f"path:{asset.relative_path}"
            return None

        groups: dict[str, list] = defaultdict(list)
        for a in all_assets:
            gk = group_key(a)
            if gk:
                groups[gk].append(a)

        canonical_map: dict[str, str] = {}
        for gk, members in groups.items():
            if len(members) < 2:
                continue
            members.sort(key=_asset_sort_key, reverse=True)
            canonical = members[0]
            for dup in members[1:]:
                canonical_map[str(dup.id)] = str(canonical.id)
                dup.is_active = False
                meta = dup.metadata_ or {}
                meta["dedup_merged_into"] = str(canonical.id)
                meta["dedup_at"] = datetime.now(UTC).isoformat()
                dup.metadata_ = meta
                report["actions"].append(
                    {
                        "action": "dedup_deactivate",
                        "duplicate_id": str(dup.id),
                        "canonical_id": str(canonical.id),
                        "filename": dup.filename,
                        "group": gk,
                    }
                )

        # Rewrite checklist asset ids after dedup
        if canonical_map:
            for item in pkg.checklist or []:
                kid = item.get("knowledge_asset_id")
                if kid and str(kid) in canonical_map:
                    item["knowledge_asset_id"] = canonical_map[str(kid)]
            for m in pkg.document_matches or []:
                kid = m.get("knowledge_asset_id")
                if kid and str(kid) in canonical_map:
                    m["knowledge_asset_id"] = canonical_map[str(kid)]

        # --- 3. Fix empresa assets missing company_key on MIPYME etc ---
        profile = await db.get(LicitadorCompanyProfile, COMPANY_ID)
        if profile:
            for a in all_assets:
                if a.is_active and not a.company_key:
                    path = (a.relative_path or "").upper()
                    if "JUSTECH" in path or profile.company_key in (a.relative_path or "").lower():
                        a.company_key = profile.company_key
                        meta = a.metadata_ or {}
                        if meta.get("field_key") and not validate_asset_for_requirement(
                            meta["field_key"],
                            filename=a.filename,
                            title=a.title,
                            document_type=a.document_type,
                            asset=a,
                        ).ok:
                            meta.pop("field_key", None)
                            a.metadata_ = meta
                            report["actions"].append(
                                {"action": "empresa_clear_invalid_field_key", "asset": a.filename}
                            )
                        else:
                            report["actions"].append(
                                {"action": "empresa_set_company_key", "asset": a.filename}
                            )

        await db.commit()

        # --- AFTER metrics ---
        completion_after = await field_svc.get_completion(COMPANY_ID)
        report["after"]["empresas"] = {
            "fields_complete": completion_after.fields_complete,
            "fields_total": completion_after.fields_total,
            "completeness_score": completion_after.completeness_score,
        }

        pkg_after = (
            await db.execute(
                select(DGCPBidPackage).where(DGCPBidPackage.opportunity_id == DGCP_OPP_ID)
            )
        ).scalar_one()
        bid_after = pkg_after.bid_package or {}
        report["after"]["dgcp"] = {
            "preparation_pct": bid_after.get("preparation_pct"),
            "checklist": [
                {
                    "requirement_key": i.get("requirement_key"),
                    "document_title": i.get("document_title"),
                    "status": i.get("status"),
                    "display_status": i.get("display_status"),
                }
                for i in (pkg_after.checklist or [])
            ],
        }

        binding_after = (
            await db.execute(
                text(
                    "SELECT indexed_files FROM jaios.integration_repository_bindings "
                    "WHERE id = 'd648ecab-63cd-4be5-9e89-1142004d0532'"
                )
            )
        ).scalar()
        assets_after = (
            await db.execute(
                select(KnowledgeAsset).where(
                    KnowledgeAsset.tenant_id == TENANT_ID,
                    KnowledgeAsset.is_active.is_(True),
                )
            )
        ).scalars().all()
        report["after"]["hub_legal_indexed"] = binding_after
        report["after"]["knowledge_assets_active"] = len(assets_after)
        report["dedup_deactivated"] = sum(1 for a in report["actions"] if a["action"] == "dedup_deactivate")

    out_path = Path(__file__).resolve().parent.parent / "docs" / "sanitize_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    asyncio.run(main())
