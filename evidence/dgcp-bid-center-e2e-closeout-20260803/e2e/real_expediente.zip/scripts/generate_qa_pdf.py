#!/usr/bin/env python3
"""Genera PDF del QA Report desde docs/QA_REPORT.md."""

from __future__ import annotations

import re
import sys
from pathlib import Path

from fpdf import FPDF

ROOT = Path(__file__).resolve().parents[1].parent
if not (ROOT / "docs").exists():
    ROOT = Path(__file__).resolve().parents[2]
MD_PATH = ROOT / "docs" / "QA_REPORT.md"
OUT_PATH = ROOT / "docs" / "QA_REPORT.pdf"


class QAPdf(FPDF):
    def header(self) -> None:
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(100, 100, 100)
        self.cell(0, 6, _sanitize("JAIOS - QA Report Capa Inteligente (Fases 1-5)"), align="R")
        self.ln(4)

    def footer(self) -> None:
        self.set_y(-12)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(100, 100, 100)
        self.cell(0, 8, _sanitize(f"Pagina {self.page_no()}/{{nb}}"), align="C")


def _sanitize(text: str) -> str:
    replacements = {
        "✅": "[OK]",
        "❌": "[NO]",
        "—": "-",
        "–": "-",
        "→": "->",
        "«": '"',
        "»": '"',
        "…": "...",
        "•": "-",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.encode("latin-1", errors="replace").decode("latin-1")


def _break_long_tokens(text: str, max_len: int = 72) -> str:
    out: list[str] = []
    for line in text.splitlines():
        words = line.split(" ")
        buf: list[str] = []
        for word in words:
            if len(word) > max_len:
                if buf:
                    out.append(" ".join(buf))
                    buf = []
                for j in range(0, len(word), max_len):
                    out.append(word[j : j + max_len])
            else:
                buf.append(word)
                if sum(len(w) for w in buf) + len(buf) - 1 > max_len:
                    out.append(" ".join(buf[:-1]))
                    buf = [word]
        if buf:
            out.append(" ".join(buf))
    return "\n".join(out)


def _multi(pdf: QAPdf, text: str, h: float = 5, indent: float = 0, style: str = "") -> None:
    pdf.set_x(pdf.l_margin + indent)
    w = pdf.w - pdf.l_margin - pdf.r_margin - indent
    if style:
        pdf.set_font("Helvetica", style, pdf.font_size_pt)
    pdf.multi_cell(w, h, _sanitize(_break_long_tokens(text)))


def _is_table_row(line: str) -> bool:
    s = line.strip()
    return s.startswith("|") and s.endswith("|") and "|" in s[1:-1]


def _parse_table_row(line: str) -> list[str]:
    return [c.strip() for c in line.strip().strip("|").split("|")]


def _is_separator_row(cells: list[str]) -> bool:
    return all(re.fullmatch(r":?-+:?", c.replace(" ", "")) or c == "" for c in cells)


def render_table(pdf: QAPdf, rows: list[list[str]]) -> None:
    if not rows:
        return
    cols = len(rows[0])
    widths = []
    page_w = pdf.w - pdf.l_margin - pdf.r_margin
    if cols == 2:
        widths = [page_w * 0.35, page_w * 0.65]
    elif cols == 3:
        widths = [page_w * 0.28, page_w * 0.12, page_w * 0.60]
    elif cols == 4:
        widths = [page_w * 0.22, page_w * 0.12, page_w * 0.22, page_w * 0.44]
    else:
        widths = [page_w / cols] * cols

    pdf.set_font("Helvetica", "B", 8)
    pdf.set_fill_color(240, 240, 245)
    header = rows[0]
    row_h = 6
    for i, cell in enumerate(header):
        pdf.cell(widths[i], row_h, _sanitize(cell)[:48], border=1, fill=True)
    pdf.ln()

    pdf.set_font("Helvetica", "", 8)
    for row in rows[1:]:
        if pdf.get_y() > pdf.h - 20:
            pdf.add_page()
            pdf.set_font("Helvetica", "B", 8)
            for i, cell in enumerate(header):
                pdf.cell(widths[i], row_h, _sanitize(cell)[:48], border=1, fill=True)
            pdf.ln()
            pdf.set_font("Helvetica", "", 8)
        for i, cell in enumerate(row):
            w = widths[i] if i < len(widths) else widths[-1]
            pdf.cell(w, row_h, _sanitize(cell)[:56], border=1)
        pdf.ln()
    pdf.ln(2)


def render_markdown(pdf: QAPdf, content: str) -> None:
    lines = content.splitlines()
    i = 0
    in_code = False
    code_lines: list[str] = []
    table_rows: list[list[str]] = []

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped.startswith("```"):
            if in_code:
                pdf.set_font("Courier", "", 8)
                pdf.set_fill_color(248, 248, 252)
                block = _break_long_tokens("\n".join(code_lines), 68)
                _multi(pdf, block, h=4.5)
                pdf.ln(2)
                code_lines = []
                in_code = False
            else:
                in_code = True
            i += 1
            continue

        if in_code:
            code_lines.append(line)
            i += 1
            continue

        if _is_table_row(line):
            cells = _parse_table_row(line)
            if _is_separator_row(cells):
                i += 1
                continue
            table_rows.append(cells)
            i += 1
            if i >= len(lines) or not _is_table_row(lines[i]):
                render_table(pdf, table_rows)
                table_rows = []
            continue

        if table_rows:
            render_table(pdf, table_rows)
            table_rows = []

        if stripped == "---":
            pdf.ln(2)
            pdf.set_draw_color(200, 200, 200)
            pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
            pdf.ln(4)
            i += 1
            continue

        if stripped.startswith("# "):
            pdf.ln(4)
            pdf.set_font("Helvetica", "B", 16)
            pdf.set_text_color(20, 40, 80)
            pdf.multi_cell(pdf.w - pdf.l_margin - pdf.r_margin, 8, _sanitize(stripped[2:]))
            pdf.set_text_color(0, 0, 0)
            pdf.ln(2)
        elif stripped.startswith("## "):
            if pdf.get_y() > 240:
                pdf.add_page()
            pdf.ln(3)
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(30, 60, 110)
            pdf.multi_cell(pdf.w - pdf.l_margin - pdf.r_margin, 7, _sanitize(stripped[3:]))
            pdf.set_text_color(0, 0, 0)
            pdf.ln(1)
        elif stripped.startswith("### "):
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 10)
            pdf.multi_cell(pdf.w - pdf.l_margin - pdf.r_margin, 6, _sanitize(stripped[4:]))
        elif stripped.startswith("- "):
            pdf.set_font("Helvetica", "", 9)
            _multi(pdf, "- " + stripped[2:], indent=4)
        elif re.match(r"^\d+\.\s", stripped):
            pdf.set_font("Helvetica", "", 9)
            _multi(pdf, stripped, indent=4)
        elif stripped.startswith("**") and stripped.endswith("**"):
            pdf.set_font("Helvetica", "B", 9)
            _multi(pdf, stripped.strip("*"))
        elif stripped:
            pdf.set_font("Helvetica", "", 9)
            text = re.sub(r"\*\*(.+?)\*\*", r"\1", stripped)
            text = re.sub(r"`(.+?)`", r"\1", text)
            _multi(pdf, text)
        else:
            pdf.ln(2)

        i += 1

    if table_rows:
        render_table(pdf, table_rows)


def main() -> int:
    md_path = Path(sys.argv[1]) if len(sys.argv) > 1 else MD_PATH
    out_path = Path(sys.argv[2]) if len(sys.argv) > 2 else OUT_PATH

    if not md_path.exists():
        print(f"Error: no existe {md_path}", file=sys.stderr)
        return 1

    content = md_path.read_text(encoding="utf-8")

    pdf = QAPdf()
    pdf.alias_nb_pages()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_margins(18, 18, 18)

    render_markdown(pdf, content)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    pdf.output(str(out_path))
    print(f"PDF generado: {out_path} ({out_path.stat().st_size // 1024} KB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
