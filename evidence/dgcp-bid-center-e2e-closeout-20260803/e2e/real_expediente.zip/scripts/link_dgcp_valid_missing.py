#!/usr/bin/env python3
"""Vincula faltantes DGCP solo si el documento pasa validación estricta."""

from __future__ import annotations

import asyncio
import uuid

TENANT_ID = uuid.UUID("8ebfa281-cd3c-4017-8e47-c572a79d84b2")
OPP_ID = uuid.UUID("6b1f81e8-22e7-44de-98aa-e633e9909b5b")
ADMIN_EMAIL = "admin@justech.do"

# Candidatos conocidos (requirement_key -> knowledge_asset_id)
CANDIDATES: dict[str, uuid.UUID] = {
    "registro_mercantil": uuid.UUID("7d931a71-d396-43f7-9869-7ea278cc144a"),
}


async def main() -> None:
    from sqlalchemy import select

    from app.db.session import AsyncSessionLocal
    from app.models.dgcp_bid_package import DGCPBidPackage
    from app.models.user import User
    from app.schemas.dgcp_bid import DGCPAssociateDocumentRequest
    from app.services.dgcp_bid_package_service import DGCPBidPackageService

    async with AsyncSessionLocal() as db:
        admin = (
            await db.execute(select(User).where(User.email == ADMIN_EMAIL))
        ).scalar_one()
        svc = DGCPBidPackageService(db, TENANT_ID, admin.id)

        pkg = (
            await db.execute(
                select(DGCPBidPackage).where(DGCPBidPackage.opportunity_id == OPP_ID)
            )
        ).scalar_one()

        linked: list[str] = []
        skipped: list[str] = []

        for item in pkg.checklist or []:
            key = item.get("requirement_key") or ""
            if item.get("status") not in ("faltante", "pendiente"):
                continue
            asset_id = CANDIDATES.get(key)
            if not asset_id:
                skipped.append(f"{key}: sin candidato")
                continue
            item_id = uuid.UUID(str(item["id"]))
            try:
                await svc.associate_checklist_document(
                    OPP_ID,
                    item_id,
                    DGCPAssociateDocumentRequest(knowledge_asset_id=asset_id),
                )
                linked.append(f"{key} -> {asset_id}")
            except Exception as exc:
                skipped.append(f"{key}: {exc}")

        await db.commit()
        print("LINKED:", linked or "none")
        print("SKIPPED:", skipped or "none")


if __name__ == "__main__":
    asyncio.run(main())
