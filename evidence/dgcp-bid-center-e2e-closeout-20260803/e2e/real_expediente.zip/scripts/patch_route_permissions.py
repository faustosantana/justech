#!/usr/bin/env python3
"""Inyecta dependencies= en decoradores @router — PR-1.3b."""

from __future__ import annotations

import re
import sys
from pathlib import Path

API = Path(__file__).resolve().parent.parent / "app" / "api" / "v1"

CONFIG: dict[str, tuple[str, str, list[str]]] = {
    "dgcp.py": ("DGCP_VIEW", "DGCP_MUTATE", []),
    "odoo.py": ("ODOO_VIEW", "ODOO_MUTATE", ["/health"]),
    "m365.py": ("M365_VIEW", "M365_MUTATE", ["/oauth/callback", "/webhooks/"]),
    "m365_operative.py": ("M365_VIEW", "M365_MUTATE", ["/webhooks/"]),
    "documents.py": ("DOCS_VIEW", "DOCS_MUTATE", ["/public/", "/health"]),
    "assistant.py": ("ASSISTANT_VIEW", "ASSISTANT_MUTATE", []),
    "hermes.py": ("ASSISTANT_VIEW", "ASSISTANT_MUTATE", ["/health"]),
}


def collect_decorator(lines: list[str], start: int) -> tuple[list[str], int]:
    dec = [lines[start]]
    i = start + 1
    while i < len(lines) and not dec[-1].rstrip().endswith(")"):
        dec.append(lines[i])
        i += 1
    return dec, i


def should_skip(dec_text: str, skip_fragments: list[str]) -> bool:
    if "dependencies=" in dec_text:
        return True
    return any(frag in dec_text for frag in skip_fragments)


def patch_content(content: str, view: str, mutate: str, skip: list[str]) -> tuple[str, int]:
    if "from app.api.permission_deps import" in content:
        return content, 0

    lines = content.splitlines()
    out: list[str] = []
    count = 0
    i = 0

    while i < len(lines):
        line = lines[i]
        m = re.match(r"@router\.(get|post|put|patch|delete)\(", line)
        if m:
            dec_lines, next_i = collect_decorator(lines, i)
            dec_text = "\n".join(dec_lines)
            if should_skip(dec_text, skip):
                out.extend(dec_lines)
                i = next_i
                continue

            dep = view if m.group(1) == "get" else mutate
            if len(dec_lines) == 1:
                s = dec_lines[0].rstrip()
                dec_lines = [s[:-1] + f", dependencies={dep})" if s.endswith(")") else s]
            else:
                last = dec_lines[-1].rstrip()
                dec_lines[-1] = (last[:-1] + f", dependencies={dep})") if last.endswith(")") else last
            out.extend(dec_lines)
            count += 1
            i = next_i
            continue
        out.append(line)
        i += 1

    text = "\n".join(out)
    import_line = f"from app.api.permission_deps import {view}, {mutate}\n"
    anchor = "from app.api.deps import"
    pos = text.find(anchor)
    if pos >= 0:
        end = text.find("\n", pos) + 1
        text = text[:end] + import_line + text[end:]
    else:
        text = import_line + text
    return text, count


def main() -> int:
    total = 0
    for fname, (view, mutate, skip) in CONFIG.items():
        path = API / fname
        new, n = patch_content(path.read_text(), view, mutate, skip)
        if n:
            path.write_text(new)
            print(f"{fname}: {n} routes")
            total += n
        else:
            print(f"{fname}: skipped")
    print(f"total: {total}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
