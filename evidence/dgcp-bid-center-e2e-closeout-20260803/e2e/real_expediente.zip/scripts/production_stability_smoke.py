#!/usr/bin/env python3
"""Smoke test global producción — Fase 2 estabilidad."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass

BASE = sys.argv[1] if len(sys.argv) > 1 else "https://jaios.justech.do/api/v1"
FRONT = BASE.replace("/api/v1", "")

ADMIN = ("admin@justech.do", "JaiosAdmin2026!")
USER = ("marieli@justech.do", "JaiosTeam2026!")


@dataclass
class Result:
    module: str
    check: str
    status: str
    code: int | str
    detail: str


def req(method: str, url: str, token: str | None = None, tenant: str | None = None, body: dict | None = None, timeout=45):
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if tenant:
        headers["X-Tenant-ID"] = tenant
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            return resp.status, resp.read(8000).decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(2000).decode(errors="replace")


def login(email: str, password: str):
    code, body = req("POST", f"{BASE}/auth/login", body={"email": email, "password": password, "tenant_slug": "justech"})
    if code != 200:
        return None, None, f"login {code}"
    d = json.loads(body)
    return d["access_token"], d.get("tenant_id"), None


def page(path: str):
    url = f"{FRONT}{path}"
    r = urllib.request.Request(url, headers={"Accept": "text/html"})
    try:
        with urllib.request.urlopen(r, timeout=30) as resp:
            html = resp.read(2000).decode(errors="replace")
            dev = '"b":"development"' in html or "webpack.js?v=" in html
            return resp.status, "DEV_MODE" if dev else "prod_or_static", html[:120]
    except urllib.error.HTTPError as e:
        return e.code, "error", e.read(200).decode(errors="replace")[:120]


def main():
    results: list[Result] = []
    sessions = {}
    for role, creds in [("admin", ADMIN), ("usuario", USER)]:
        tok, tid, err = login(*creds)
        if err:
            results.append(Result("Auth", role, "FAIL", err, ""))
            continue
        sessions[role] = (tok, tid)
        results.append(Result("Auth", role, "PASS", 200, tid[:8] if tid else ""))

    admin_tok, admin_tid = sessions.get("admin", (None, None))
    user_tok, user_tid = sessions.get("usuario", (None, None))

    api_checks = [
        ("Dashboard", "health", "GET", "/health", None, (200,)),
        ("Dashboard", "executive", "GET", "/dashboard/executive", "admin", (200,)),
        ("Empresas", "companies", "GET", "/companies", "admin", (200,)),
        ("Licitaciones", "dgcp list", "GET", "/dgcp/opportunities?limit=3", "admin", (200,)),
        ("Licitaciones", "dgcp dashboard", "GET", "/dgcp/dashboard", "admin", (200,)),
        ("Licitaciones", "autofill templates", "GET", "/dgcp/autofill-templates", "admin", (200,)),
        ("Documentos", "dashboard", "GET", "/documents/dashboard", "admin", (200,)),
        ("Documentos", "repositories", "GET", "/documents/repositories", "admin", (200,)),
        ("M365", "connection", "GET", "/m365/connection", "admin", (200,)),
        ("M365", "health", "GET", "/m365/health", "admin", (200, 503)),
        ("M365", "repo files", "GET", "/m365/repository/files?limit=2", "admin", (200, 503)),
        ("Hermes", "intelligence", "GET", "/hermes/intelligence-center?limit=3", "admin", (200,)),
        ("Hermes", "assistant", "POST", "/assistant/query", "admin", (200,), {"question": "Responde OK"}),
        ("Comercial", "commercial search", "GET", "/commercial-search?q=dell&limit=3", "admin", (200,)),
        ("Comercial", "sync status", "GET", "/commercial-search/sync/status", "admin", (200,)),
        ("Odoo", "health", "GET", "/odoo/health", "admin", (200, 503)),
        ("Odoo", "customers", "GET", "/odoo/customers?limit=1", "usuario", (200, 503)),
        ("Config", "admin access admin", "GET", "/admin/access", "admin", (200,)),
        ("Config", "admin access user", "GET", "/admin/access", "usuario", (200,)),
        ("PR-1.2", "platform-access admin", "GET", "/users/me/platform-access", "admin", (200,)),
        ("PR-1.2", "platform-access user", "GET", "/users/me/platform-access", "usuario", (200,)),
        ("PR-1.1", "config blocked user", "GET", "/admin/users", "usuario", (403,)),
        ("Autofill", "canonical fields", "GET", "/dgcp/autofill-canonical-fields", "admin", (200,)),
    ]

    for mod, label, method, path, role, expect, *rest in api_checks:
        body = rest[0] if rest else None
        tok, tid = sessions.get(role or "admin", (None, None)) if role else (None, None)
        code, snippet = req(method, f"{BASE}{path}", tok, tid, body)
        ok = code in expect
        results.append(Result(mod, label, "PASS" if ok else "FAIL", code, f"expect {expect} | {snippet[:80]}"))

    ui_routes = [
        ("Dashboard", "/dashboard"),
        ("Dashboard", "/"),
        ("Licitaciones", "/dgcp"),
        ("Licitaciones", "/apps/licitaciones"),
        ("Documentos", "/documentos"),
        ("M365", "/m365/operativo"),
        ("Hermes", "/apps/agentes-ia"),
        ("Comercial", "/inteligencia/busqueda-comercial"),
        ("Config", "/configuracion"),
        ("Login", "/login"),
    ]
    for mod, path in ui_routes:
        code, mode, snippet = page(path)
        ok = code == 200 and mode != "DEV_MODE"
        sev = "WARN" if code == 200 and mode == "DEV_MODE" else ("PASS" if ok else "FAIL")
        results.append(Result(f"UI-{mod}", path, sev, code, mode if sev != "PASS" else "OK"))

    # Deploy markers
    if admin_tok:
        code, body = req("GET", f"{BASE}/users/me/platform-access", admin_tok, admin_tid)
        if code == 200:
            apps = json.loads(body).get("apps") or []
            hidden = [a for a in apps if "solicitudes" in (a.get("href") or "").lower()]
            results.append(Result("PR-1.5", "no placeholder compras", "PASS" if not hidden else "FAIL", len(apps), str(len(apps))))
        code, body = req("GET", f"{BASE}/dgcp/autofill-templates", admin_tok, admin_tid)
        if code == 200:
            n = len(json.loads(body).get("items") or [])
            results.append(Result("Autofill", "templates indexed", "PASS" if n >= 50 else "WARN", n, f"{n} templates"))

    failed = [r for r in results if r.status == "FAIL"]
    warn = [r for r in results if r.status == "WARN"]
    passed = [r for r in results if r.status == "PASS"]

    out_path = "/opt/jaios-app/docs/qa-evidence/production-stability-smoke.json"
    with open(out_path, "w") as f:
        json.dump([r.__dict__ for r in results], f, indent=2)

    print(f"SMOKE: {len(passed)} PASS, {len(warn)} WARN, {len(failed)} FAIL -> {out_path}")
    for r in failed + warn:
        print(f"  {r.status} | {r.module} | {r.check} | {r.code} | {r.detail[:100]}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
