"""QA E2E — autollenado Carta de Presentación con datos Justech."""

from __future__ import annotations

import asyncio
import hashlib
import zipfile
from io import BytesIO
from pathlib import Path

from sqlalchemy import select

from app.db.session import AsyncSessionLocal
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.tenant import Tenant
from app.services.document_autofill.template_analysis_service import TemplateAnalysisService
from app.services.dgcp_form_autofill_service import DGCPFormAutofillService


async def main() -> None:
    async with AsyncSessionLocal() as db:
        tenant = (
            await db.execute(select(Tenant).where(Tenant.slug == "justech"))
        ).scalar_one_or_none()
        if not tenant:
            raise SystemExit("Tenant justech no encontrado")

        opp = (
            await db.execute(
                select(DGCPOpportunity)
                .where(DGCPOpportunity.tenant_id == tenant.id)
                .order_by(DGCPOpportunity.created_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if not opp:
            raise SystemExit("Sin oportunidades DGCP")

        svc = DGCPFormAutofillService(db, tenant.id)
        analysis_svc = TemplateAnalysisService()
        analysis_svc.ensure_docx_templates()
        template_path = analysis_svc.resolve_template_path("CARTA.PRESENTACION")
        assert template_path and template_path.is_file(), "Plantilla carta no encontrada"
        before_hash = hashlib.sha256(template_path.read_bytes()).hexdigest()

        preview = await svc.autofill_preview(opp, form_type="CARTA.PRESENTACION", company="justech")
        print(f"OK preview: {len(preview.fields)} campos, missing={preview.missing}")
        assert any(f.key == "razon_social" for f in preview.fields), "Campo razon_social no detectado"

        pdf = await svc.document_preview_pdf(opp, form_type="CARTA.PRESENTACION", company="justech")
        assert pdf[:4] == b"%PDF", "PDF inválido"
        print(f"OK preview PDF: {len(pdf)} bytes")

        generated = await svc.generate_controlled_copy(opp, form_type="CARTA.PRESENTACION", company="justech")
        assert generated.pdf_path, "Sin pdf_path en expediente"
        assert Path(generated.pdf_path).is_file(), "PDF no persistido"
        assert Path(generated.docx_path or "").is_file() or generated.docx_path, "DOCX copia"
        print(f"OK generado: {generated.filename} -> {generated.pdf_path}")

        after_hash = hashlib.sha256(template_path.read_bytes()).hexdigest()
        assert before_hash == after_hash, "Plantilla original fue modificada"

        if generated.docx_path and Path(generated.docx_path).is_file():
            with zipfile.ZipFile(BytesIO(Path(generated.docx_path).read_bytes())) as zf:
                xml = zf.read("word/document.xml").decode("utf-8")
            assert "{{" not in xml or "Justech" in xml or "justech" in xml.lower(), "Placeholders sin rellenar"
            print("OK docx copia sin placeholders crudos visibles")

        print("QA E2E autollenado: PASSED")


if __name__ == "__main__":
    asyncio.run(main())
