"""QA E2E — SNCC F.042 real desde M365 + LibreOffice."""

from __future__ import annotations

import asyncio
import hashlib
import json
from pathlib import Path

from sqlalchemy import select

from app.db.session import AsyncSessionLocal
from app.models.dgcp_opportunity import DGCPOpportunity
from app.models.m365_repository import M365RepositoryFile
from app.models.tenant import Tenant
from app.models.user import User
from app.services.document_autofill.libreoffice_converter import is_libreoffice_available
from app.services.document_autofill.m365_template_resolver import M365TemplateResolver
from app.services.dgcp_form_autofill_service import DGCPFormAutofillService


async def main() -> None:
    if not is_libreoffice_available():
        raise SystemExit("LibreOffice no disponible — reconstruya el contenedor backend")

    async with AsyncSessionLocal() as db:
        tenant = (await db.execute(select(Tenant).where(Tenant.slug == "justech"))).scalar_one_or_none()
        if not tenant:
            raise SystemExit("Tenant justech no encontrado")

        user = (
            await db.execute(select(User).where(User.email == "admin@justech.do", User.is_active.is_(True)))
        ).scalar_one_or_none()

        opp = (
            await db.execute(
                select(DGCPOpportunity)
                .where(DGCPOpportunity.tenant_id == tenant.id)
                .order_by(DGCPOpportunity.created_at.desc())
                .limit(1)
            )
        ).scalar_one_or_none()
        if not opp:
            raise SystemExit("Sin oportunidades DGCP")

        resolver = M365TemplateResolver(db, tenant.id, user.id if user else None)
        ref = await resolver.resolve("SNCC.F042")
        if not ref:
            count = (
                await db.execute(
                    select(M365RepositoryFile).where(
                        M365RepositoryFile.tenant_id == tenant.id,
                        M365RepositoryFile.name.ilike("%f042%"),
                    )
                )
            ).scalars().all()
            raise SystemExit(
                f"Plantilla SNCC F.042 no encontrada en M365 index ({len(count)} candidatos parciales). "
                "Sincronice 02_PLANTILLAS_DGCP."
            )

        print(f"OK plantilla M365: {ref.name} ({ref.resolver})")
        print(f"   web_url={ref.web_url}")
        print(f"   m365_file_id={ref.m365_file_id}")

        before = await resolver.download_bytes(ref)
        before_hash = hashlib.sha256(before).hexdigest()

        svc = DGCPFormAutofillService(db, tenant.id, user_id=user.id if user else None)
        preview = await svc.autofill_preview(opp, form_type="SNCC.F042", company="justech")
        print(f"OK preview: {len(preview.fields)} campos, source={preview.template_source_type}, engine={preview.pdf_engine}")
        assert preview.template_source_type == "m365", "Debe usar plantilla M365, no local"
        assert preview.pdf_engine == "libreoffice", "PDF debe generarse con LibreOffice"

        pdf = await svc.document_preview_pdf(opp, form_type="SNCC.F042", company="justech")
        assert pdf[:4] == b"%PDF"
        print(f"OK preview PDF: {len(pdf)} bytes")

        generated = await svc.generate_controlled_copy(opp, form_type="SNCC.F042", company="justech")
        assert generated.pdf_path and Path(generated.pdf_path).is_file()
        print(f"OK expediente: {generated.pdf_path}")

        after = await resolver.download_bytes(ref)
        after_hash = hashlib.sha256(after).hexdigest()
        assert before_hash == after_hash, "Plantilla M365 original fue modificada"

        audit_path = Path(generated.pdf_path).with_name(
            Path(generated.pdf_path).stem + "_audit.json"
        )
        if audit_path.is_file():
            audit = json.loads(audit_path.read_text())
            assert audit.get("template_source_type") == "m365"
            assert audit.get("pdf_engine") == "libreoffice"
            assert audit.get("m365_template", {}).get("graph_item_id")
            print(f"OK auditoría: usuario={audit.get('generated_by_email')}, missing={audit.get('missing')}")

        print("QA E2E SNCC F.042 M365 + LibreOffice: PASSED")


if __name__ == "__main__":
    asyncio.run(main())
