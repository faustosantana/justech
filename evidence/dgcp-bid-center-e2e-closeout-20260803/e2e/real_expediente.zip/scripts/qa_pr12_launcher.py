#!/usr/bin/env python3
"""QA PR-1.2 — platform-access + matriz visibilidad launcher."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/api/v1"

USERS = {
    "admin": ("admin@justech.do", "JaiosAdmin2026!"),
    "usuario": ("marieli@justech.do", "JaiosTeam2026!"),
}

# Apps visibles según ROLE_PERMISSIONS (PR-1.2)
EXPECTED_APPS = {
    "admin": {
        "must_include": [
            "configuracion", "licitaciones", "documentos", "ventas", "calendario", "agentes-ia", "precios",
        ],
        "must_exclude": [],
    },
    "usuario": {
        "must_include": ["licitaciones", "documentos", "ventas", "calendario", "comunicaciones", "tareas"],
        "must_exclude": ["configuracion"],
    },
}


def req(method: str, path: str, token: str | None = None, tenant: str | None = None, body: dict | None = None):
    url = f"{BASE}{path}"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if tenant:
        headers["X-Tenant-ID"] = tenant
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            return resp.status, json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, e.read(300).decode(errors="replace")


def login(email: str, password: str):
    code, body = req("POST", "/auth/login", body={"email": email, "password": password, "tenant_slug": "justech"})
    if code != 200:
        return None, None, f"login failed {code}: {body}"
    return body["access_token"], body.get("tenant_id"), None


def visible_apps(access: dict) -> set[str]:
    perms = set(access.get("permissions") or [])
    role = access.get("role", "")
    apps: set[str] = set()

    if access.get("can_view_admin"):
        apps.add("configuracion")
    if "view_documents" in perms:
        apps.update({"documentos", "empresas-grupo"})
    if "view_dgcp" in perms:
        apps.add("licitaciones")
    if "view_m365" in perms:
        apps.add("calendario")
    if "view_assistant" in perms:
        apps.add("agentes-ia")
    if access.get("can_view_prices"):
        apps.add("precios")
    if access.get("can_view_suppliers"):
        apps.add("proveedores")
    if "view_odoo" in perms:
        apps.update({"crm", "ventas", "compras", "inventario", "facturacion", "clientes"})
    if "view_modules" in perms:
        apps.update({"comunicaciones", "tareas", "reportes"})
    return apps


def main():
    failures = 0
    for role, (email, pw) in USERS.items():
        tok, tid, err = login(email, pw)
        if err:
            print(f"FATAL {role}: {err}")
            sys.exit(1)

        code, body = req("GET", "/users/me/platform-access", tok, tid)
        if code != 200:
            print(f"FAIL {role}: platform-access {code}")
            failures += 1
            continue

        access = body
        if "can_view_admin" not in access:
            print(f"FAIL {role}: falta can_view_admin en platform-access")
            failures += 1

        expected_admin = role == "admin"
        if access.get("can_view_admin") != expected_admin:
            print(f"FAIL {role}: can_view_admin={access.get('can_view_admin')} expected={expected_admin}")
            failures += 1

        has_mutate_dgcp = "mutate_dgcp" in (access.get("permissions") or [])
        expected_mutate = role == "admin"
        if has_mutate_dgcp != expected_mutate:
            print(f"FAIL {role}: mutate_dgcp={has_mutate_dgcp} expected={expected_mutate}")
            failures += 1

        apps = visible_apps(access)
        spec = EXPECTED_APPS.get(role, {})
        for app_id in spec.get("must_include", []):
            if app_id not in apps:
                print(f"FAIL {role}: falta app {app_id} (visible={sorted(apps)})")
                failures += 1
        for app_id in spec.get("must_exclude", []):
            if app_id in apps:
                print(f"FAIL {role}: no debería ver {app_id}")
                failures += 1

        print(f"OK {role}: role={access.get('role')} apps={len(apps)} can_view_admin={access.get('can_view_admin')} mutate_dgcp={has_mutate_dgcp}")

    if failures:
        print(f"\n{failures} fallo(s)")
        sys.exit(1)
    print("\nQA PR-1.2 platform-access OK")


if __name__ == "__main__":
    main()
