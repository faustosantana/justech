#!/usr/bin/env python3
"""QA PR-1.3b post-deploy — matriz rol × endpoint."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/api/v1"
OPP = "6b1f81e8-22e7-44de-98aa-e633e9909b5b"
ACTA = "20a5977c-77e6-420e-90d4-ed196feef10a"

USERS = {
    "admin": ("admin@justech.do", "JaiosAdmin2026!"),
    "usuario": ("marieli@justech.do", "JaiosTeam2026!"),
}


def req(method: str, path: str, token: str | None = None, tenant: str | None = None, body: dict | None = None):
    url = f"{BASE}{path}"
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if tenant:
        headers["X-Tenant-ID"] = tenant
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=60) as resp:
            return resp.status, resp.read(500).decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(300).decode(errors="replace")


def login(email: str, password: str):
    code, body = req("POST", "/auth/login", body={"email": email, "password": password, "tenant_slug": "justech"})
    if code != 200:
        return None, None, f"login failed {code}: {body[:120]}"
    d = json.loads(body)
    return d["access_token"], d.get("tenant_id"), None


def main():
    sessions = {}
    for role, (email, pw) in USERS.items():
        tok, tid, err = login(email, pw)
        if err:
            print(f"FATAL {role}: {err}")
            sys.exit(1)
        sessions[role] = (tok, tid)
        print(f"OK login {role} tenant={tid[:8]}...")

    tests = [
        # module, label, method, path, role, expect, body
        ("DGCP", "dashboard", "GET", "/dgcp/dashboard", "admin", 200, None),
        ("DGCP", "dashboard", "GET", "/dgcp/dashboard", "usuario", 200, None),
        ("DGCP", "opportunities list", "GET", "/dgcp/opportunities?limit=1", "usuario", 200, None),
        ("DGCP", "opp detail", "GET", f"/dgcp/opportunities/{OPP}", "admin", 200, None),
        ("DGCP", "checklist read", "GET", f"/dgcp/opportunities/{OPP}/checklist", "usuario", 200, None),
        ("DGCP", "create opp blocked", "POST", "/dgcp/opportunities", "usuario", 403, {"title": "QA", "company": "justech", "status": "nueva"}),
        ("DGCP", "create opp admin", "POST", "/dgcp/opportunities", "admin", (200, 201, 400, 422), {"title": "QA perm admin", "company": "justech", "status": "nueva"}),
        ("Odoo", "config read", "GET", "/odoo/config", "usuario", (200, 503), None),
        ("Odoo", "customers read", "GET", "/odoo/customers?limit=1", "usuario", (200, 503), None),
        ("Odoo", "create customer blocked", "POST", "/odoo/customers", "usuario", 403, {"name": "QA Block"}),
        ("Odoo", "quotations search", "GET", "/odoo/quotations/search?limit=1", "admin", (200, 503), None),
        ("Documents", "access ACTA admin", "GET", f"/documents/access?knowledge_asset_id={ACTA}", "admin", (200, 302), None),
        ("Documents", "access ACTA user", "GET", f"/documents/access?knowledge_asset_id={ACTA}", "usuario", (200, 302), None),
        ("Documents", "dashboard", "GET", "/documents/dashboard", "admin", 200, None),
        ("Documents", "repositories", "GET", "/documents/repositories", "usuario", 200, None),
        ("Documents", "access no auth", "GET", f"/documents/access?knowledge_asset_id={ACTA}", None, 401, None),
        ("M365", "connection admin", "GET", "/m365/connection", "admin", 200, None),
        ("M365", "connection user", "GET", "/m365/connection", "usuario", 200, None),
        ("M365", "doc search", "GET", "/m365/documents/search?q=acta&limit=3", "usuario", (200, 503), None),
        ("M365", "repo files", "GET", "/m365/repository/files?limit=3", "admin", (200, 503), None),
        ("Hermes", "assistant query", "POST", "/assistant/query", "usuario", 200, {"question": "Responde solo: OK QA"}),
        ("Hermes", "intelligence center", "GET", "/hermes/intelligence-center?limit=3", "admin", 200, None),
        ("Hermes", "knowledge search", "POST", "/hermes/search/knowledge", "usuario", (200, 503), {"query": "justech", "hits": 3}),
        ("Public", "form representatives", "GET", "/documents/public/profile-form/invalid-token-qa/representatives", None, (400, 404), None),
        ("Public", "form submit", "POST", "/documents/public/profile-form/invalid-token-qa", None, (400, 422), {}),
    ]

    results = []
    passed = failed = 0
    for mod, label, method, path, role, expect, body in tests:
        token, tenant = (None, None) if role is None else sessions[role]
        code, snippet = req(method, path, token, tenant, body)
        ok_codes = expect if isinstance(expect, tuple) else (expect,)
        ok = code in ok_codes
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        results.append((status, mod, role or "public", label, method, path, code, expect, snippet[:100]))
        print(f"{status} | {mod} | {role or 'public'} | {label} | {code} (expect {expect})")

    print(f"\nSUMMARY: {passed} pass, {failed} fail, base={BASE}")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
