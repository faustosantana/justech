#!/usr/bin/env python3
"""E2E validation — DGII-CCC-PEEX-2026-0005 (Licitaciones módulo completo)."""

from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/api/v1"
OPP_ID = sys.argv[2] if len(sys.argv) > 2 else "ae07d012-4b67-4622-8507-bff9060c632b"
OPP_CODE = "DGII-CCC-PEEX-2026-0005"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}


def req(method: str, path: str, token: str | None = None, body=None, timeout=120):
    url = BASE + path
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            raw = resp.read(500000)
            return resp.status, raw.decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(8000).decode(errors="replace")
    except Exception as e:
        return "ERR", str(e)


def main() -> int:
    results: list[tuple[int, str, str, str]] = []
    fails = 0

    def record(n: int, name: str, ok: bool, detail: str):
        nonlocal fails
        status = "PASS" if ok else "FAIL"
        if not ok:
            fails += 1
        results.append((n, name, status, detail))
        print(f"{status} #{n:02d} {name}: {detail}")

    code, body = req("POST", "/auth/login", None, LOGIN)
    if code != 200:
        print(f"FATAL login HTTP {code}: {body[:300]}")
        return 1
    tok = json.loads(body)["access_token"]

    # 1 Dashboard alertas actualizaciones
    c, b = req("GET", "/dgcp/process-updates/dashboard", tok)
    dash = json.loads(b) if c == 200 else {}
    ok1 = c == 200 and dash.get("enabled") and dash.get("total_pending", 0) > 0
    record(1, "Dashboard alertas actualizaciones", ok1, f"HTTP {c} pending={dash.get('total_pending')} critical={dash.get('total_critical')}")

    # 2 Proceso abre
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}", tok)
    opp = json.loads(b) if c == 200 else {}
    ok2 = c == 200 and OPP_CODE in (opp.get("code") or "")
    record(2, "Proceso DGII-0005 abre", ok2, f"HTTP {c} code={opp.get('code')}")

    # 3 Estado General de Oferta
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/offer-preparation-center", tok)
    opc = json.loads(b) if c == 200 else {}
    ok3 = c == 200 and opc.get("enabled") and "overall_pct" in opc
    record(3, "Estado General de Oferta", ok3, f"HTTP {c} pct={opc.get('overall_pct')} status={opc.get('overall_status')}")

    # 4 Hermes document-analysis completed
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/document-analysis", tok)
    hermes = json.loads(b) if c == 200 else {}
    ok4 = c == 200 and hermes.get("status") == "completed"
    record(4, "Hermes document-analysis completed", ok4, f"HTTP {c} status={hermes.get('status')}")

    # 5 Checklist dinámico consistente
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/checklist", tok)
    chk = json.loads(b) if c == 200 else {}
    ok5 = c == 200 and chk.get("total", 0) > 0 and isinstance(chk.get("items"), list)
    record(5, "Checklist dinámico consistente", ok5, f"HTTP {c} total={chk.get('total')} mandatory={chk.get('mandatory_count')}")

    # 6 Formularios requeridos
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/forms/required", tok)
    forms = json.loads(b) if c == 200 else {}
    ok6 = c == 200 and len(forms.get("items") or forms.get("forms") or []) > 0
    form_count = len(forms.get("items") or forms.get("forms") or [])
    record(6, "Formularios requeridos", ok6, f"HTTP {c} count={form_count}")

    # 7 Autollenado
    c, b = req("POST", f"/dgcp/opportunities/{OPP_ID}/forms/autofill-preview", tok, {"form_key": "sncc_f033"})
    auto = json.loads(b) if c == 200 else {}
    ok7 = c == 200 and auto.get("generate_enabled") is not False
    record(7, "Autollenado funciona", ok7, f"HTTP {c} generate_enabled={auto.get('generate_enabled')} fields={len(auto.get('fields') or [])}")

    # 8 Fichas técnicas
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/technical-sheets", tok)
    ts = json.loads(b) if c == 200 else {}
    items = ts.get("items") or []
    ok8 = c == 200 and ts.get("enabled") and len(items) > 0
    record(8, "Fichas técnicas funcionan", ok8, f"HTTP {c} enabled={ts.get('enabled')} items={len(items)}")

    # 9 PDF ficha export
    sheet_id = items[0]["id"] if items else None
    ok9 = False
    detail9 = "no sheet"
    if sheet_id:
        c, b = req("POST", f"/dgcp/opportunities/{OPP_ID}/technical-sheets/{sheet_id}/export", tok, {"format": "pdf"})
        ok9 = c == 200 and len(b) > 500
        detail9 = f"HTTP {c} bytes={len(b)} sheet={sheet_id[:8]}"
    record(9, "PDF ficha exporta", ok9, detail9)

    # 10 Oferta consolidada BORRADOR
    c, b = req("POST", f"/dgcp/opportunities/{OPP_ID}/offer-preparation-center/consolidated-offer", tok, {})
    cons = json.loads(b) if c == 200 else {}
    ok10 = c == 200 and cons.get("status") == "borrador"
    record(10, "Oferta consolidada BORRADOR", ok10, f"HTTP {c} status={cons.get('status')} sections={len(cons.get('sections') or [])}")

    # 11 Actualizaciones — 5 simulados
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/process-updates", tok)
    upd = json.loads(b) if c == 200 else {}
    pending_before = upd.get("meta", {}).get("pending_count", 0)
    updates = upd.get("updates") or []
    ok11 = c == 200 and upd.get("enabled") and len(updates) >= 5 and pending_before >= 5
    record(11, "Actualizaciones 5 simulados", ok11, f"HTTP {c} updates={len(updates)} pending={pending_before}")

    # 12 Marcar una como revisada
    pending_item = next((u for u in updates if u.get("review_status") == "pendiente"), None)
    ok12 = False
    detail12 = "no pending update"
    if pending_item:
        uid = pending_item["id"]
        c, b = req("POST", f"/dgcp/opportunities/{OPP_ID}/process-updates/{uid}/review", tok, {"note": "QA E2E revisado"})
        rev = json.loads(b) if c == 200 else {}
        ok12 = c == 200 and rev.get("review_status") == "revisado"
        detail12 = f"HTTP {c} id={uid[:8]} status={rev.get('review_status')}"
    record(12, "Marcar actualización revisada", ok12, detail12)

    # 13 Contador baja
    c, b = req("GET", f"/dgcp/opportunities/{OPP_ID}/process-updates", tok)
    upd2 = json.loads(b) if c == 200 else {}
    pending_after = upd2.get("meta", {}).get("pending_count", 0)
    ok13 = c == 200 and pending_after == pending_before - 1
    record(13, "Contador baja", ok13, f"before={pending_before} after={pending_after}")

    # 14 No reanaliza automáticamente
    c_h, b_h = req("GET", f"/dgcp/opportunities/{OPP_ID}/document-analysis", tok)
    hermes2 = json.loads(b_h) if c_h == 200 else {}
    c_b, b_b = req("GET", f"/dgcp/opportunities/{OPP_ID}/bid-package", tok)
    pkg = json.loads(b_b) if c_b == 200 else {}
    analyzed_at = pkg.get("analyzed_at")
    hermes_status = hermes2.get("status")
    # Hermes should still be completed, analyzed_at unchanged (no auto re-run)
    ok14 = hermes_status == "completed" and analyzed_at is not None
    record(14, "No reanaliza automáticamente", ok14, f"hermes={hermes_status} analyzed_at={analyzed_at}")

    print(f"\n=== SUMMARY {len(results) - fails}/{len(results)} PASS ===")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
