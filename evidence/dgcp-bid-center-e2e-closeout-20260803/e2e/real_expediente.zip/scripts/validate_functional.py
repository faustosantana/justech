#!/usr/bin/env python3
"""Validación funcional Fases 1–5 — ejecutar dentro del contenedor backend."""

from __future__ import annotations

import asyncio
import json
import sys

from httpx import ASGITransport, AsyncClient

from app.main import app

ADMIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}


async def main() -> int:
    results: list[tuple[str, bool, str]] = []
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        # Health
        r = await client.get("/api/v1/health")
        results.append(("health", r.status_code == 200, r.text[:120]))

        # Auth
        login = await client.post("/api/v1/auth/login", json=ADMIN)
        if login.status_code != 200:
            results.append(("auth/login", False, login.text[:200]))
            _print(results)
            return 1
        token = login.json()["access_token"]
        tenant_id = login.json().get("tenant_id") or login.json().get("membership", {}).get("tenant_id")
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Tenant-ID": str(tenant_id) if tenant_id else "",
        }
        results.append(("auth/login", True, "OK"))

        # Fase 1 — Commercial search
        r = await client.get("/api/v1/commercial-search/sync/status", headers=headers)
        results.append(("commercial-search/sync/status", r.status_code == 200, f"items={r.json().get('total_items') if r.status_code==200 else r.text[:80]}"))

        r = await client.get("/api/v1/commercial-search?q=laptop+dell", headers=headers)
        ok = r.status_code == 200
        body = r.json() if ok else {}
        results.append(("commercial-search", ok, f"total={body.get('total')} index={body.get('index_available')}"))

        # Odoo sync (read-only index)
        r = await client.post("/api/v1/commercial-search/sync", headers=headers, json={"full_reindex": False})
        sync_ok = r.status_code == 200
        sync_body = r.json() if sync_ok else {}
        indexed = sum(x.get("indexed", 0) for x in sync_body.get("results", []))
        results.append(("commercial-search/sync", sync_ok, f"status={sync_body.get('status')} indexed={indexed}"))

        if sync_ok and indexed > 0:
            r2 = await client.get("/api/v1/commercial-search?q=laptop", headers=headers)
            results.append(("commercial-search post-sync", r2.status_code == 200, f"total={r2.json().get('total')}"))

        # Fase 2 — DGCP
        r = await client.get("/api/v1/dgcp/opportunities?limit=5", headers=headers)
        results.append(("dgcp/opportunities", r.status_code == 200, f"count={len(r.json().get('items',[])) if r.status_code==200 else 0}"))

        test_code = "QA-MANUAL-TEST-001"
        r = await client.post(
            "/api/v1/dgcp/opportunities",
            headers=headers,
            json={
                "code": test_code,
                "institution": "Entidad QA Test",
                "title": "Proceso QA validación funcional",
                "amount": "100000",
                "currency": "DOP",
                "deadline": "2026-12-31",
                "source": "manual",
                "description": "Creado por script QA",
            },
        )
        if r.status_code == 201:
            opp_id = r.json()["id"]
            results.append(("dgcp/create manual", True, f"id={opp_id[:8]}…"))
            r_ctx = await client.get(f"/api/v1/dgcp/opportunities/{opp_id}/commercial-context", headers=headers)
            results.append(("dgcp/commercial-context", r_ctx.status_code == 200, f"recs={len(r_ctx.json().get('recommendations',[])) if r_ctx.status_code==200 else r_ctx.text[:60]}"))
        elif r.status_code == 409:
            results.append(("dgcp/create manual", True, "already exists (409)"))
            items = (await client.get("/api/v1/dgcp/opportunities?limit=50", headers=headers)).json().get("items", [])
            existing = next((i for i in items if i.get("code") == test_code), None)
            if existing:
                r_ctx = await client.get(f"/api/v1/dgcp/opportunities/{existing['id']}/commercial-context", headers=headers)
                results.append(("dgcp/commercial-context", r_ctx.status_code == 200, "OK"))
        else:
            results.append(("dgcp/create manual", False, r.text[:120]))

        # Fase 3 — Templates
        r = await client.get("/api/v1/document-templates", headers=headers)
        tpl_ok = r.status_code == 200
        tpl_count = len(r.json().get("items", [])) if tpl_ok else 0
        results.append(("document-templates", tpl_ok, f"count={tpl_count}"))

        r = await client.get("/api/v1/document-templates/sncc-f042/missing-fields?company=justech", headers=headers)
        mf = r.json() if r.status_code == 200 else {}
        results.append(("document-templates/missing-fields", r.status_code == 200, mf.get("hermes_message", r.text[:80])[:100]))

        # Fase 4 — Hermes center
        r = await client.get("/api/v1/hermes/intelligence-center?limit=10", headers=headers)
        cards = r.json().get("cards", []) if r.status_code == 200 else []
        results.append(("hermes/intelligence-center", r.status_code == 200, f"cards={len(cards)}"))

        # Odoo health (no write)
        r = await client.get("/api/v1/odoo/health", headers=headers)
        odoo = r.json() if r.status_code == 200 else {}
        results.append(("odoo/health", r.status_code == 200, f"connected={odoo.get('connected')}"))

        # Existing endpoints still work
        r = await client.get("/api/v1/search?q=test&limit=3", headers=headers)
        results.append(("search (legacy)", r.status_code == 200, "OK" if r.status_code == 200 else r.text[:60]))

    _print(results)
    failed = [n for n, ok, _ in results if not ok]
    return 1 if failed else 0


def _print(results: list[tuple[str, bool, str]]) -> None:
    print("\n=== VALIDACIÓN FUNCIONAL JAIOS ===\n")
    for name, ok, detail in results:
        status = "PASS" if ok else "FAIL"
        print(f"  [{status}] {name}: {detail}")
    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n  Total: {passed}/{len(results)} passed\n")


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
