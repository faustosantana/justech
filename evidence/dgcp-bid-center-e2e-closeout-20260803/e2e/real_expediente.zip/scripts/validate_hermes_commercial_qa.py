#!/usr/bin/env python3
"""QA calidad comercial Hermes — 8 preguntas obligatorias."""

from __future__ import annotations

import asyncio
import re
import sys
import time

from httpx import ASGITransport, AsyncClient

from app.main import app

ADMIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}

CASES = [
    {
        "q": "cuántas laptops hay de menos de 800 dólares",
        "checks": [
            lambda a: "800" in a,
            lambda a: "Excluí" in a or "accesorios" in a.lower(),
            lambda a: "memoria" not in a.lower() or "excluí" in a.lower(),
            lambda a: "**Resumen:**" in a,
        ],
    },
    {
        "q": "laptops dell i7 menos de 1000 dolares",
        "checks": [
            lambda a: "1000" in a,
            lambda a: "dell" in a.lower() or "Dell" in a,
            lambda a: "adaptador" not in a.lower() or "excluí" in a.lower(),
        ],
    },
    {
        "q": "dime de las listas de precios mejor",
        "checks": [
            lambda a: "indexados" in a.lower() or "productos" in a.lower(),
            lambda a: "proveedor" in a.lower(),
            lambda a: "categoría" in a.lower() or "laptops" in a.lower(),
            lambda a: "¿qué quieres" not in a.lower()[:80],
        ],
    },
    {
        "q": "qué proveedores tienen laptops",
        "checks": [
            lambda a: "proveedor" in a.lower() or "supplier" in a.lower(),
            lambda a: "laptop" in a.lower(),
        ],
    },
    {
        "q": "busca switches cisco vendidos anteriormente",
        "checks": [
            lambda a: "switch" in a.lower() or "cisco" in a.lower(),
            lambda a: "odoo" in a.lower() or "historial" in a.lower() or "registro" in a.lower(),
        ],
    },
    {
        "q": "cuál fue el último precio vendido de laptop hp",
        "checks": [
            lambda a: "último" in a.lower() or "precio" in a.lower(),
            lambda a: "hp" in a.lower() or "HP" in a,
            lambda a: "**Resumen:**" in a,
        ],
    },
    {
        "q": "qué productos hay indexados hoy",
        "checks": [
            lambda a: "indexados" in a.lower() or "productos" in a.lower(),
            lambda a: re.search(r"\d+", a) is not None,
        ],
    },
    {
        "q": "por qué no hay listas hoy",
        "checks": [
            lambda a: "hoy" in a.lower(),
            lambda a: "index" in a.lower() or "listas" in a.lower() or "última" in a.lower(),
        ],
    },
]


async def main() -> int:
    transport = ASGITransport(app=app)
    results: list[tuple[str, bool, str]] = []

    async with AsyncClient(transport=transport, base_url="http://test", timeout=180.0) as client:
        login = await client.post("/api/v1/auth/login", json=ADMIN)
        if login.status_code != 200:
            print("AUTH FAIL", login.text[:200])
            return 1
        token = login.json()["access_token"]
        tenant_id = login.json().get("tenant_id") or login.json().get("membership", {}).get("tenant_id")
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Tenant-ID": str(tenant_id) if tenant_id else "",
        }

        for case in CASES:
            q = case["q"]
            started = time.perf_counter()
            r = await client.post(
                "/api/v1/assistant/query",
                headers=headers,
                json={
                    "question": q,
                    "current_module": "/inteligencia/centro-hermes",
                    "conversation_id": "00000000-0000-4000-8000-000000000qa2",
                },
            )
            elapsed = int((time.perf_counter() - started) * 1000)
            ok = r.status_code == 200
            body = r.json() if ok else {}
            answer = (body.get("answer") or r.text[:200]) if ok else r.text[:200]
            generic_err = "El servidor no pudo completar" in answer
            checks_ok = all(fn(answer) for fn in case["checks"]) if ok else False
            passed = ok and not generic_err and len(answer.strip()) > 30 and checks_ok
            tools = (
                (body.get("structured_data") or {})
                .get("hermes_diagnostic", {})
                .get("tools_used", [])
            )
            detail = f"tools={tools} {elapsed}ms checks={checks_ok}"
            results.append((q, passed, detail))
            print(f"[{'PASS' if passed else 'FAIL'}] {q[:55]}")
            print(f"       {detail}")
            if not passed:
                print(f"       answer: {answer[:350]}…")

    passed_n = sum(1 for _, ok, _ in results if ok)
    print(f"\nCommercial QA: {passed_n}/{len(results)} passed")
    return 0 if passed_n == len(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
