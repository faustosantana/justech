#!/usr/bin/env python3
"""Validación E2E Hermes — pliego PDF real + Analyze Requirements."""

from __future__ import annotations

import io
import json
import sys
import urllib.error
import urllib.request

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000/api/v1"
OPP = sys.argv[2] if len(sys.argv) > 2 else "ae07d012-4b67-4622-8507-bff9060c632b"
LOGIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}


def build_pliego_pdf() -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter)
    y = 750
    lines = [
        "PLIEGO DE CONDICIONES — PROCESO DGII-CCC-PEEX-2026-0005",
        "Dirección General de Impuestos Internos (DGII)",
        "Objeto: Adquisición de Switches y Routers por Obsolescencia y Servicios profesionales.",
        "",
        "SECCIÓN III — DOCUMENTACIÓN A PRESENTAR POR EL OFERENTE",
        "",
        "1. Registro en el Portal de Compras y Contrataciones Públicas (RPE) vigente.",
        "2. Certificación de cumplimiento de obligaciones tributarias emitida por la DGII.",
        "3. Registro Mercantil vigente.",
        "4. Formulario SNCC F.042 — Información del Oferente.",
        "5. Formulario SNCC F.033 — Declaración Jurada del Oferente.",
        "6. Formulario SNCC F.047 — Declaración sobre integridad.",
        "7. Garantía de Seriedad de Oferta equivalente al 5% del monto estimado.",
        "8. Certificado de no inhabilitación para contratar con el Estado.",
        "9. Oferta económica en formulario SNCC correspondiente.",
        "",
        "CONDICIONES Y RIESGOS:",
        "- Plazo de entrega: 60 días calendario desde la adjudicación.",
        "- Las ofertas deben presentarse en idioma español.",
        "- El incumplimiento documental será causal de descalificación.",
    ]
    for line in lines:
        c.drawString(50, y, line[:110])
        y -= 16
        if y < 60:
            c.showPage()
            y = 750
    c.save()
    return buf.getvalue()


def req(method: str, path: str, token: str | None = None, body=None, files=None, timeout=300):
    url = BASE + path
    headers: dict[str, str] = {"Accept": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = None
    if files:
        boundary = "----jaioshermesboundary"
        filename, content, mime = files
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
        parts = [
            f"--{boundary}\r\n",
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n',
            f"Content-Type: {mime}\r\n\r\n",
        ]
        body_bytes = (
            "".join(parts).encode()
            + content
            + f"\r\n--{boundary}--\r\n".encode()
        )
        data = body_bytes
    elif body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode()
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read()
            return resp.status, json.loads(raw.decode()) if raw else {}
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode()) if e.fp else {"error": str(e)}


def main() -> int:
    print(f"=== Hermes Pliego E2E ===\nBase: {BASE}\nOpportunity: {OPP}\n")

    code, login = req("POST", "/auth/login", body=LOGIN, timeout=60)
    if code != 200:
        print(f"FAIL login HTTP {code}: {login}")
        return 1
    tok = login["access_token"]
    print("PASS login\n")

    pdf = build_pliego_pdf()
    print(f"Generated pliego PDF: {len(pdf)} bytes\n")

    code, upload = req(
        "POST",
        f"/dgcp/opportunities/{OPP}/process-documents/upload?doc_role=pliego",
        tok,
        files=("Pliego_DGII-0005.pdf", pdf, "application/pdf"),
    )
    if code != 200 or not upload.get("text_extracted"):
        print(f"FAIL upload HTTP {code}: {json.dumps(upload, ensure_ascii=False)[:500]}")
        return 1
    print(f"PASS upload — text_length={upload.get('text_length')} doc_role={upload['process_document'].get('doc_role')}\n")

    code, analyzed = req("POST", f"/dgcp/opportunities/{OPP}/requirements/analyze", tok, body={}, timeout=300)
    if code != 200:
        print(f"FAIL analyze HTTP {code}: {json.dumps(analyzed, ensure_ascii=False)[:800]}")
        return 1
    print("PASS analyze requirements\n")

    code, doc_analysis = req("GET", f"/dgcp/opportunities/{OPP}/document-analysis", tok)
    code2, requirements = req("GET", f"/dgcp/opportunities/{OPP}/requirements", tok)
    code3, checklist = req("GET", f"/dgcp/opportunities/{OPP}/checklist", tok)
    code4, forms = req("GET", f"/dgcp/opportunities/{OPP}/forms/required", tok)
    code5, proc_docs = req("GET", f"/dgcp/opportunities/{OPP}/process-documents", tok)

    hermes_status = doc_analysis.get("status")
    print("--- HERMES ---")
    print(f"status: {hermes_status}")
    print(f"confidence: {doc_analysis.get('confidence')}")
    print(f"summary: {(doc_analysis.get('summary') or '')[:300]}")
    print(f"fallback_used: {doc_analysis.get('fallback_used')}")

    print("\n--- REQUISITOS EXTRAÍDOS ---")
    all_reqs = []
    for section in ("mandatory_documents", "technical", "legal", "financial", "administrative"):
        items = requirements.get(section) or []
        all_reqs.extend(items)
        print(f"{section}: {len(items)}")
    for r in all_reqs[:15]:
        print(f"  • [{r.get('key')}] {r.get('label')} (source={r.get('source')})")

    print("\n--- FORMULARIOS SNCC ---")
    sncc = requirements.get("sncc_forms") or []
    print(f"sncc_forms en requirements: {sncc}")
    req_forms = [f.get("form_type") for f in forms.get("required_forms") or []]
    print(f"required_forms en autollenado: {req_forms}")

    print("\n--- CHECKLIST ---")
    items = checklist.get("items") or []
    print(f"total items: {len(items)}")
    for item in items[:12]:
        print(f"  • {item.get('requirement')} — {item.get('status')} (form={item.get('form_type')})")

    print("\n--- EVIDENCIA ---")
    evidence = doc_analysis.get("evidence") or []
    print(f"evidence records: {len(evidence)}")
    for ev in evidence[:8]:
        print(f"  • {ev.get('requirement_key')}: {ev.get('fragmento', '')[:80]}…")

    print("\n--- RIESGOS ---")
    risks_pkg = analyzed.get("analysis_warnings") or []
    risks_hermes = doc_analysis.get("risks") or []
    for w in risks_pkg:
        print(f"  • [warning] {w}")
    for r in risks_hermes[:6]:
        if isinstance(r, dict):
            print(f"  • [{r.get('nivel')}] {r.get('descripcion')}")
        else:
            print(f"  • {r}")

    print("\n--- DOCUMENTOS PROCESO ---")
    for d in proc_docs.get("items") or []:
        print(f"  • {d.get('title')} | {d.get('display_status')} | has_text={d.get('has_text')} | role={d.get('doc_role')}")

    checks = [
        ("Hermes status=completed", hermes_status == "completed"),
        ("Requisitos extraídos", len(all_reqs) >= 5),
        ("Checklist generado", len(items) >= 5),
        ("Evidencia asociada", len(evidence) >= 1),
        ("Riesgos identificados", len(risks_hermes) >= 1 or len(risks_pkg) >= 1),
        ("SNCC detectados", len(sncc) >= 1 or any("SNCC" in f for f in req_forms)),
        ("Pliego con texto", any(d.get("has_text") for d in proc_docs.get("items") or [])),
    ]
    print("\n=== RESUMEN ===")
    fails = 0
    for label, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'} {label}")
        if not ok:
            fails += 1
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
