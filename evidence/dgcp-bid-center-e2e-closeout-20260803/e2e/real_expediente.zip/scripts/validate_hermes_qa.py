#!/usr/bin/env python3
"""QA Hermes copilot — preguntas obligatorias."""

from __future__ import annotations

import asyncio
import sys
import time

from httpx import ASGITransport, AsyncClient

from app.main import app

ADMIN = {"email": "admin@justech.do", "password": "JaiosAdmin2026!", "tenant_slug": "justech"}

QUESTIONS = [
    "qué tenemos para hoy",
    "qué tengo pendiente hoy",
    "cuántas laptops hay de menos de 800 dólares",
    "busca ventas anteriores de laptops Dell",
    "qué licitaciones vencen esta semana",
    "qué cotizaciones están sin seguimiento",
    "qué clientes esperan respuesta",
    "resume oportunidades importantes de hoy",
]


async def main() -> int:
    transport = ASGITransport(app=app)
    results: list[tuple[str, bool, str, int]] = []

    async with AsyncClient(transport=transport, base_url="http://test", timeout=180.0) as client:
        login = await client.post("/api/v1/auth/login", json=ADMIN)
        if login.status_code != 200:
            print("AUTH FAIL", login.text[:200])
            return 1
        token = login.json()["access_token"]
        tenant_id = login.json().get("tenant_id") or login.json().get("membership", {}).get("tenant_id")
        headers = {
            "Authorization": f"Bearer {token}",
            "X-Tenant-ID": str(tenant_id) if tenant_id else "",
        }

        ctx = await client.get("/api/v1/company-context", headers=headers)
        scope = ctx.json().get("scope_label", "?") if ctx.status_code == 200 else "?"
        print(f"Company context: {scope}\n")

        for q in QUESTIONS:
            started = time.perf_counter()
            r = await client.post(
                "/api/v1/assistant/query",
                headers=headers,
                json={
                    "question": q,
                    "current_module": "/inteligencia/centro-hermes",
                    "conversation_id": "00000000-0000-4000-8000-000000000qa1",
                },
            )
            elapsed = int((time.perf_counter() - started) * 1000)
            ok = r.status_code == 200
            body = r.json() if ok else {}
            answer = (body.get("answer") or r.text[:120]) if ok else r.text[:120]
            qtype = body.get("query_type", "?")
            tools = (
                (body.get("structured_data") or {})
                .get("hermes_diagnostic", {})
                .get("tools_used", [])
            )
            generic_err = "El servidor no pudo completar" in answer
            ok = ok and not generic_err and qtype != "error" and len(answer.strip()) > 20
            detail = f"type={qtype} tools={tools} {elapsed}ms len={len(answer)}"
            results.append((q, ok, detail, elapsed))
            print(f"[{'PASS' if ok else 'FAIL'}] {q[:50]}")
            print(f"       {detail}")
            if not ok:
                print(f"       answer: {answer[:200]}…")

    passed = sum(1 for _, ok, _, _ in results if ok)
    print(f"\nTotal: {passed}/{len(results)} passed")
    slow = [q for q, _, _, ms in results if ms > 90000]
    if slow:
        print(f"Slow (>{90}s): {len(slow)}")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
