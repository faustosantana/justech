#!/usr/bin/env python3
"""Valida registry de módulos JAIOS — contentKeys y rutas críticas."""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / "frontend/src/lib/modules/registry.ts"
RENDER = ROOT / "frontend/src/lib/modules/render-section-content.tsx"

# contentKeys que deben existir en render-section-content
REQUIRED_KEYS = {
    "empresas-grupo:list",
    "suppliers:directory",
    "precios:alertas",
    "documentos:entities",
    "odoo:tab",
    "prices:search",
    "documentos:precios",
    "licitaciones:procesos",
    "placeholder",
}

# Secciones que NO deben usar empresas:list (empresas internas mal etiquetadas)
FORBIDDEN_EMPRESAS_LIST = [
    ("proveedores", "directorio"),
    ("precios", "proveedores"),
    ("documentos", "proveedores"),
]


def main() -> int:
    reg_text = REGISTRY.read_text(encoding="utf-8")
    render_text = RENDER.read_text(encoding="utf-8")
    errors: list[str] = []

    if "empresas-grupo" not in reg_text:
        errors.append("Falta módulo empresas-grupo en registry")

    if 'contentKey: "empresas:list"' in reg_text:
        errors.append('Aún existe contentKey "empresas:list" en registry (debe ser empresas-grupo:list o suppliers:directory)')

    for app_id, section_id in FORBIDDEN_EMPRESAS_LIST:
        pattern = rf'id: "{section_id}".*?contentKey: "empresas:list"'
        if re.search(pattern, reg_text, re.DOTALL):
            errors.append(f"{app_id}/{section_id} aún usa empresas:list")

    for key in REQUIRED_KEYS:
        if key not in render_text and key != "placeholder":
            # placeholder handled by generic check
            if f'"{key}"' not in render_text and f"key === \"{key}\"" not in render_text:
                if key == "odoo:tab":
                    if "odoo:tab" not in render_text:
                        errors.append(f"render-section-content no maneja {key}")
                elif key != "odoo:tab":
                    errors.append(f"render-section-content no maneja {key}")

    if "SuppliersDirectorySection" not in render_text:
        errors.append("Falta SuppliersDirectorySection en renderer")

    if "CompanyExpedienteView" not in (ROOT / "frontend/src/components/modules/empresas-grupo/company-expediente-view.tsx").read_text():
        errors.append("Falta CompanyExpedienteView")

    perfil_route = ROOT / "frontend/src/app/(platform)/apps/[appId]/perfil/[id]/page.tsx"
    if not perfil_route.exists():
        errors.append("Falta ruta /apps/[appId]/perfil/[id]")

    if errors:
        print("MODULE REGISTRY QA: FAIL")
        for e in errors:
            print(f"  - {e}")
        return 1

    print("MODULE REGISTRY QA: PASS")
    print(f"  Registry: {REGISTRY.name}")
    print(f"  Renderer: {RENDER.name}")
    print(f"  Módulo empresas-grupo: OK")
    print(f"  suppliers:directory: OK")
    print(f"  precios:alertas: OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
