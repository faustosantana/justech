#!/usr/bin/env python3
"""Valida URLs y configuración de producción — sin localhost en rutas públicas."""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

FORBIDDEN_IN_PROD = (
    "onedrive.live.com",
    "login.live.com",
    "outlook.live.com",
)

LOCALHOST_PATTERNS = (
    re.compile(r"https?://localhost[:/]", re.I),
    re.compile(r"https?://127\.0\.0\.1[:/]", re.I),
)

SOURCE_GLOBS = ("frontend/src/**/*.tsx", "frontend/src/**/*.ts", "backend/app/**/*.py")
SKIP_PATHS = ("node_modules", ".next", "e2e", "tests", "docs", "scripts/generate")


def _iter_sources() -> list[Path]:
    files: list[Path] = []
    for base in (ROOT / "frontend" / "src", ROOT / "backend" / "app"):
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if path.suffix not in (".ts", ".tsx", ".py"):
                continue
            if any(s in str(path) for s in SKIP_PATHS):
                continue
            files.append(path)
    return files


def check_env() -> list[str]:
    issues: list[str] = []
    required = {
        "PUBLIC_APP_URL": os.environ.get("PUBLIC_APP_URL", ""),
        "FRONTEND_URL": os.environ.get("FRONTEND_URL", ""),
        "BACKEND_PUBLIC_URL": os.environ.get("BACKEND_PUBLIC_URL", ""),
    }
    for key, val in required.items():
        if not val:
            issues.append(f"ENV missing: {key}")
        elif "localhost" in val or "127.0.0.1" in val:
            issues.append(f"ENV {key} uses localhost: {val}")
    api = os.environ.get("NEXT_PUBLIC_API_URL", "")
    if api and ("localhost" in api or "127.0.0.1" in api):
        issues.append(f"ENV NEXT_PUBLIC_API_URL uses localhost: {api}")
    return issues


def scan_sources() -> list[str]:
    issues: list[str] = []
    for path in _iter_sources():
        text = path.read_text(encoding="utf-8", errors="ignore")
        rel = path.relative_to(ROOT)
        for forbidden in FORBIDDEN_IN_PROD:
            if forbidden in text and "CONSUMER_HOSTS" not in text and "m365-urls" not in str(rel):
                if f'"{forbidden}"' in text or f"'{forbidden}'" in text or f"https://{forbidden}" in text:
                    issues.append(f"{rel}: references {forbidden}")
        for pat in LOCALHOST_PATTERNS:
            for m in pat.finditer(text):
                line = text[: m.start()].count("\n") + 1
                # Allow fallbacks only in api.ts / m365.ts with env chain
                if "process.env" in text[max(0, m.start() - 80) : m.start() + 40]:
                    continue
                if str(rel).endswith("api.ts") and "fallback" in text[max(0, m.start() - 120) : m.start()]:
                    continue
                issues.append(f"{rel}:{line}: hardcoded {m.group(0)}")
    return issues


def main() -> int:
    env_issues = check_env()
    source_issues = scan_sources()
    print("=== JAIOS Production URL Audit ===")
    if env_issues:
        print("\nEnvironment:")
        for i in env_issues:
            print(f"  FAIL {i}")
    else:
        print("\nEnvironment: PASS")
    if source_issues:
        print("\nSource scan:")
        for i in source_issues[:40]:
            print(f"  WARN {i}")
        if len(source_issues) > 40:
            print(f"  ... and {len(source_issues) - 40} more")
    else:
        print("\nSource scan: PASS (no consumer Microsoft URLs in app code)")
    failed = bool(env_issues)
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
