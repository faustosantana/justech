#!/usr/bin/env python3
"""QA E2E — Fichas técnicas Fase 6.1 (requiere DGCP_TECH_SHEETS=true)."""

from __future__ import annotations

import asyncio
import os
import sys
import uuid

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.config import settings
from app.services.dgcp_technical_product_detection_service import DGCPTechnicalProductDetectionService


async def main() -> int:
    from decimal import Decimal

    from app.models.dgcp_bid_package import DGCPBidPackage
    from app.models.dgcp_opportunity import DGCPOpportunity

    opp_id = os.environ.get("QA_OPPORTUNITY_ID", "ae07d012-4b67-4622-8507-bff9060c632b")
    print(f"=== QA Fichas Técnicas — opportunity {opp_id} ===")
    print(f"DGCP_TECH_SHEETS={settings.dgcp_tech_sheets}")

    opp = DGCPOpportunity(
        id=uuid.UUID(opp_id),
        tenant_id=uuid.uuid4(),
        code="DGII-CCC-PEEX-2026-0005",
        institution="DGII",
        title="Adquisición de Switches y Routers",
        amount=Decimal("1"),
        description="",
        full_info={},
        raw_payload={},
    )
    pkg = DGCPBidPackage(
        tenant_id=opp.tenant_id,
        opportunity_id=opp.id,
        manifest={
            "hermes_document_analysis": {
                "status": "completed",
                "summary": "Fichas técnicas requeridas por producto.",
                "items_detected": [
                    {"name": "Switch 48 puertos PoE", "quantity": "5"},
                    {"name": "Router empresarial"},
                ],
                "required_documents": ["Ficha técnica"],
            }
        },
        requirements={"technical": [{"key": "ficha_tecnica", "label": "Ficha técnica"}]},
    )
    corpus = (
        "Ficha técnica por producto ofertado.\n"
        "Switch 48 puertos PoE\nRouter empresarial\nUPS 1500VA\nAccess Point WiFi 6"
    )
    svc = DGCPTechnicalProductDetectionService()
    items, requires, msg = svc.detect(opp, pkg, process_corpus=corpus)
    print(f"requires={requires} count={len(items)} msg={msg}")
    for i, item in enumerate(items, 1):
        print(f"  {i}. {item['required_product_name']} [{item['status']}]")
    if not settings.dgcp_tech_sheets:
        print("WARN: flag OFF — endpoints devolverán error hasta activar DGCP_TECH_SHEETS=true")
    return 0 if requires and items else 1


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
