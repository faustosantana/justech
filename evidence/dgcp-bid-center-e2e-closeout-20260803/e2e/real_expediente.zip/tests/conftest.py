"""Fixtures pytest — pool DB, aislamiento DGCP async, oportunidades livianas."""

from __future__ import annotations

from dataclasses import dataclass

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from tests.dgcp_test_helpers import (
    clear_dgcp_analysis_state,
    create_light_opportunity,
    dgcp_admin_login,
    install_fake_hermes,
)


@pytest.fixture(autouse=True)
async def _dispose_db_engine_after_test():
    yield
    from app.db.session import engine

    await engine.dispose()


def pytest_configure(config):
    config.addinivalue_line("markers", "slow: tests E2E pesados (Hermes real, >60s)")
    config.addinivalue_line("markers", "integration: tests HTTP contra app ASGI")
    config.addinivalue_line("markers", "dgcp_heavy: usa proceso real pesado (evitar en CI rápido)")


@pytest.fixture
async def dgcp_admin_headers() -> dict[str, str]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        headers = await dgcp_admin_login(client)
    if not headers:
        pytest.skip("Login no disponible")
    return headers


@dataclass
class LightDGCPOpportunity:
    id: str
    code: str


@pytest.fixture
async def light_dgcp_opportunity(dgcp_admin_headers: dict[str, str]) -> LightDGCPOpportunity:
    """Oportunidad única liviana por test — sin DGII-0005 ni locks previos."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opp_id, code = await create_light_opportunity(client, dgcp_admin_headers)
    await clear_dgcp_analysis_state(opp_id)
    yield LightDGCPOpportunity(id=opp_id, code=code)
    await clear_dgcp_analysis_state(opp_id)


@pytest.fixture
def mock_hermes_fast(monkeypatch):
    """Hermes mock — sin llamadas al servicio real."""
    install_fake_hermes(monkeypatch)


@pytest.fixture
def disable_hermes_primary(monkeypatch):
    """Evita que Hermes Copilot intercepte consultas DGCP en tests de assistant."""
    monkeypatch.setattr(
        "app.services.hermes_copilot_service.HermesCopilotService.is_primary",
        staticmethod(lambda: False),
    )
