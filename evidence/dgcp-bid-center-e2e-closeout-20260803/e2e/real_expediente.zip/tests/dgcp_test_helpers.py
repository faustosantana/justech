"""Helpers compartidos para tests DGCP — aislamiento, oportunidades livianas, jobs async."""

from __future__ import annotations

import uuid
from datetime import date, timedelta
from typing import Any

from httpx import AsyncClient, Response
from sqlalchemy import select
from sqlalchemy.orm.attributes import flag_modified

from app.db.session import AsyncSessionLocal
from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_analysis_job_service import (
    MANIFEST_KEY,
    REDIS_ACTIVE_PREFIX,
    REDIS_PREFIX,
)

INTEREST_STATUSES = frozenset({"interested", "to_bid", "won", "lost"})

# No reutilizar en tests de integración repetidos
HEAVY_OPPORTUNITY_CODES = frozenset({"DGII-CCC-PEEX-2026-0005"})
HEAVY_CODE_PREFIXES = ("DGII-CCC-", "DGII-")


def is_heavy_opportunity(item: dict[str, Any]) -> bool:
    code = (item.get("code") or "").upper()
    if code in HEAVY_OPPORTUNITY_CODES:
        return True
    return any(code.startswith(p) for p in HEAVY_CODE_PREFIXES)


async def dgcp_admin_login(client: AsyncClient) -> dict[str, str] | None:
    login = await client.post(
        "/api/v1/auth/login",
        json={
            "email": "admin@justech.do",
            "password": "JaiosAdmin2026!",
            "tenant_slug": "justech",
        },
    )
    if login.status_code != 200:
        return None
    return {"Authorization": f"Bearer {login.json()['access_token']}"}


async def create_light_opportunity(
    client: AsyncClient,
    headers: dict[str, str],
    *,
    suffix: str | None = None,
) -> tuple[str, str]:
    """Crea oportunidad QA liviana (sin pliego DGII ni corpus pesado)."""
    token = suffix or uuid.uuid4().hex[:10]
    code = f"JAIOS-QA-LIGHT-{token}"
    payload = {
        "code": code,
        "institution": "MINISTERIO QA JAIOS",
        "title": "Adquisición liviana QA — RPE y SNCC F.042",
        "amount": "10000.00",
        "currency": "DOP",
        "deadline": (date.today() + timedelta(days=120)).isoformat(),
        "description": (
            "Pliego corto de prueba. Se requiere RPE vigente, certificación DGII "
            "y formulario SNCC F.042. Oferta técnica y económica."
        ),
        "company": "justech",
        "status": "detected",
        "source": "manual",
    }
    response = await client.post("/api/v1/dgcp/opportunities", headers=headers, json=payload)
    assert response.status_code == 201, response.text
    body = response.json()
    return body["id"], code


async def ensure_operational_interest(
    client: AsyncClient,
    opp_id: str,
    headers: dict[str, str],
) -> None:
    opp = await client.get(f"/api/v1/dgcp/opportunities/{opp_id}", headers=headers)
    assert opp.status_code == 200, opp.text
    if opp.json().get("status") not in INTEREST_STATUSES:
        action = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/actions",
            headers=headers,
            json={"action": "mostrar_interes"},
        )
        assert action.status_code == 200, action.text


async def _tenant_id_for_opportunity(opportunity_id: uuid.UUID) -> uuid.UUID | None:
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(DGCPOpportunity.tenant_id).where(DGCPOpportunity.id == opportunity_id)
        )
        return result.scalar_one_or_none()


async def clear_dgcp_analysis_state(opportunity_id: str | uuid.UUID) -> None:
    """Limpia locks Redis y manifest analysis_job para evitar contención entre tests."""
    opp_uuid = uuid.UUID(str(opportunity_id))
    tenant_id = await _tenant_id_for_opportunity(opp_uuid)

    try:
        from app.core.redis_client import get_redis

        redis = await get_redis()
        if tenant_id:
            await redis.delete(f"{REDIS_ACTIVE_PREFIX}:{tenant_id}:{opp_uuid}")
            pattern = f"{REDIS_PREFIX}:{tenant_id}:{opp_uuid}:*"
            cursor = 0
            while True:
                cursor, keys = await redis.scan(cursor=cursor, match=pattern, count=50)
                if keys:
                    await redis.delete(*keys)
                if cursor == 0:
                    break
        else:
            opp_str = str(opp_uuid)
            for prefix in (REDIS_ACTIVE_PREFIX, REDIS_PREFIX):
                cursor = 0
                pattern = f"{prefix}:*:{opp_str}*"
                while True:
                    cursor, keys = await redis.scan(cursor=cursor, match=pattern, count=50)
                    if keys:
                        await redis.delete(*keys)
                    if cursor == 0:
                        break
    except Exception:
        pass

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(DGCPBidPackage).where(DGCPBidPackage.opportunity_id == opp_uuid)
        )
        pkg = result.scalar_one_or_none()
        if pkg and isinstance(pkg.manifest, dict) and MANIFEST_KEY in pkg.manifest:
            manifest = dict(pkg.manifest)
            manifest.pop(MANIFEST_KEY, None)
            pkg.manifest = manifest
            flag_modified(pkg, "manifest")
            await db.commit()


async def analyze_with_interest(
    client: AsyncClient,
    opp_id: str,
    headers: dict[str, str],
    *,
    force: bool = False,
    async_job: bool = False,
    wait_timeout_s: float = 90.0,
) -> Response:
    """Analiza con interés operativo. Por defecto sync (rápido en oportunidades livianas)."""
    await ensure_operational_interest(client, opp_id, headers)
    await clear_dgcp_analysis_state(opp_id)

    params: list[str] = []
    if force:
        params.append("force=true")
    if async_job:
        params.append("async=true")
    elif force:
        # La API usa async=force por defecto; tests livianos necesitan sync explícito.
        params.append("async=false")
    suffix = f"?{'&'.join(params)}" if params else ""

    response = await client.post(
        f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze{suffix}",
        headers=headers,
    )
    if response.status_code == 202 and async_job:
        return await _wait_analysis_job(
            client, opp_id, headers, response.json()["job_id"], timeout_s=wait_timeout_s
        )
    if response.status_code == 409:
        detail = response.json().get("detail") or {}
        if detail.get("analysis_already_running") and detail.get("job_id"):
            if async_job:
                return await _wait_analysis_job(
                    client, opp_id, headers, detail["job_id"], timeout_s=wait_timeout_s
                )
            await clear_dgcp_analysis_state(opp_id)
            return response
        if detail.get("already_analyzed") and not force:
            response = await client.post(
                f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=false",
                headers=headers,
            )
            if response.status_code == 202 and async_job:
                return await _wait_analysis_job(
                    client, opp_id, headers, response.json()["job_id"], timeout_s=wait_timeout_s
                )
    return response


async def _wait_analysis_job(
    client: AsyncClient,
    opp_id: str,
    headers: dict[str, str],
    job_id: str,
    *,
    timeout_s: float = 90.0,
) -> Response:
    import asyncio
    import json
    import time

    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        status = await client.get(
            f"/api/v1/dgcp/opportunities/{opp_id}/analysis-jobs/{job_id}",
            headers=headers,
        )
        if status.status_code != 200:
            return status
        body = status.json()
        if body.get("status") == "completed":
            result = body.get("result") or {}
            return Response(
                status_code=200,
                content=json.dumps(result).encode(),
                headers={"content-type": "application/json"},
            )
        if body.get("status") == "error":
            return status
        await asyncio.sleep(0.75)
    raise TimeoutError(f"Analysis job {job_id} did not complete within {timeout_s}s")


async def find_opportunity_for_expediente_test(
    client: AsyncClient,
    headers: dict[str, str],
) -> str | None:
    """Oportunidad sin expediente preparado — excluye procesos pesados DGII."""
    list_res = await client.get("/api/v1/dgcp/opportunities?limit=50", headers=headers)
    if list_res.status_code != 200:
        return None
    items = list_res.json().get("items") or []

    for item in items:
        if is_heavy_opportunity(item):
            continue
        if item.get("status") in ("detected", "to_review"):
            return item["id"]

    for item in items:
        if is_heavy_opportunity(item):
            continue
        if item.get("status") != "interested":
            continue
        opp_id = item["id"]
        exp = await client.get(
            f"/api/v1/dgcp/opportunities/{opp_id}/bid-package/status",
            headers=headers,
        )
        if exp.status_code != 200:
            continue
        body = exp.json()
        if body.get("expediente_status") == "sin_preparar" and (body.get("preparation_pct") or 0) == 0:
            return opp_id

    return None


def install_fake_hermes(monkeypatch) -> None:
    """Evita llamadas Hermes reales en tests de integración."""
    from tests.test_dgcp_hermes_document_analysis import _FakeHermes

    from app.services.dgcp_hermes_document_analysis_service import DGCPHermesDocumentAnalysisService

    class _FastHermesService(DGCPHermesDocumentAnalysisService):
        def __init__(self, *, client=None):
            super().__init__(client=_FakeHermes())

    monkeypatch.setattr(
        "app.services.dgcp_hermes_document_analysis_service.DGCPHermesDocumentAnalysisService",
        _FastHermesService,
    )
    monkeypatch.setattr("app.config.settings.dgcp_hermes_document_analysis", True)
    monkeypatch.setattr("app.config.settings.hermes_enabled", True)
