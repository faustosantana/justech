"""Tests — Capa 1 clasificador de intención del Copiloto."""

import pytest

from app.schemas.assistant import AssistantQueryRequest
from app.services.assistant_intent_classifier import (
    AssistantIntentClassifier,
    AssistantTopIntent,
)
from app.services.business_intent_router import BusinessIntent, BusinessIntentRouter
from app.services.business_terms import detect_product_in_text


@pytest.mark.parametrize(
    "question",
    [
        "hola",
        "Hola",
        "HOLA!",
        "buenos días",
        "buenas tardes",
        "gracias",
        "cómo estás",
        "qué tal",
    ],
)
def test_general_chat_not_commercial(question):
    result = AssistantIntentClassifier.classify(question)
    assert result.intent == AssistantTopIntent.GENERAL_CHAT
    parsed = BusinessIntentRouter.classify(question)
    assert parsed.intent != BusinessIntent.PRICE


def test_hola_is_not_product():
    label, terms = detect_product_in_text("hola")
    assert label is None


def test_commercial_search_laptops():
    q = "Necesito 20 laptops Dell i5"
    result = AssistantIntentClassifier.classify(q)
    assert result.intent == AssistantTopIntent.COMMERCIAL_SEARCH
    assert result.product_label is not None


def test_commercial_search_price_query():
    q = "¿Quién me sale mejor laptop 16GB 512GB?"
    result = AssistantIntentClassifier.classify(q)
    assert result.intent == AssistantTopIntent.COMMERCIAL_SEARCH


def test_erp_sales_not_commercial():
    q = "¿Cuántas laptops hemos vendido?"
    result = AssistantIntentClassifier.classify(q)
    assert result.intent == AssistantTopIntent.ERP


def test_dgcp_intent():
    q = "hay licitaciones de impresoras?"
    result = AssistantIntentClassifier.classify(q)
    assert result.intent == AssistantTopIntent.DGCP


def test_repository_intent():
    q = "¿Dónde está el RPE de Justech?"
    result = AssistantIntentClassifier.classify(q)
    assert result.intent == AssistantTopIntent.REPOSITORY


def test_help_intent():
    result = AssistantIntentClassifier.classify("¿Qué puedes hacer?")
    assert result.intent == AssistantTopIntent.HELP


def test_unknown_does_not_trigger_commercial():
    result = AssistantIntentClassifier.classify("xyz random text")
    assert result.intent == AssistantTopIntent.UNKNOWN


def test_record_context_on_dgcp_screen():
    payload = AssistantQueryRequest(
        question="¿Cuánto es el precio promedio de venta de este equipo?",
        record_type="dgcp",
        current_record_id="00000000-0000-0000-0000-000000000001",
    )
    result = AssistantIntentClassifier.classify(payload.question, payload)
    assert result.intent == AssistantTopIntent.RECORD_CONTEXT


def test_papel_350_still_commercial():
    parsed = BusinessIntentRouter.classify("papel 350")
    assert parsed.intent == BusinessIntent.PRICE
    result = AssistantIntentClassifier.classify("papel 350")
    assert result.intent == AssistantTopIntent.COMMERCIAL_SEARCH
