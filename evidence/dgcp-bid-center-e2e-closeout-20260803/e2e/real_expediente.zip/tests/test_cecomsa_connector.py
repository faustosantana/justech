"""Tests conector Cecomsa — tienda Odoo."""

import pytest
from decimal import Decimal

from integrations.suppliers.cecomsa_connector import CecomsaConnector
from integrations.suppliers.config import CecomsaConnectorConfig

SHOP_SAMPLE_HTML = """
<h6 class="o_wsale_products_item_title">
<a content="HP LAPTOP PROBOOK 450 G10" href="/shop/lap001">HP LAPTOP PROBOOK 450 G10</a>
</h6>
<span class="text-muted small d-block cecomsa-product-code" itemprop="sku">
    CÓDIGO: LAP001
</span>
<div itemprop="offers" class="product_price">
<span class="h6 text-primary mb-0">RD$ <span class="oe_currency_value">45,990.00</span></span>
<span itemprop="price" style="display:none;">45990.00</span>
</div>
<h6 class="o_wsale_products_item_title">
<a content="DELL MONITOR 27" href="/shop/mon002">DELL MONITOR 27 ULTRASHARP</a>
</h6>
<span class="cecomsa-product-code">CÓDIGO: MON002</span>
<span itemprop="price" style="display:none;">12500.00</span>
2256 items found.
"""


def test_cecomsa_parse_shop_html():
    conn = CecomsaConnector(CecomsaConnectorConfig())
    rows = conn._parse_shop_html(SHOP_SAMPLE_HTML, limit=10)
    assert len(rows) == 2
    assert rows[0].sku == "LAP001"
    assert rows[0].price == Decimal("45990.00")
    assert rows[0].source == "cecomsa_shop_scraper"


def test_cecomsa_extract_total_items():
    conn = CecomsaConnector(CecomsaConnectorConfig())
    assert conn._extract_total_items(SHOP_SAMPLE_HTML) == 2256


@pytest.mark.asyncio
async def test_cecomsa_demo_search():
    cfg = CecomsaConnectorConfig(enabled=True, demo_mode=True)
    conn = CecomsaConnector(cfg)
    rows = await conn.search_products("hp", limit=5)
    assert len(rows) >= 1


@pytest.mark.asyncio
async def test_cecomsa_demo_sync_catalog():
    cfg = CecomsaConnectorConfig(enabled=True, demo_mode=True)
    conn = CecomsaConnector(cfg)
    result = await conn.sync_catalog()
    assert result["ok"] is True
    assert result["total"] >= 1
    assert result["mode"] == "demo"
