"""Tests — índice comercial y motor de búsqueda."""

from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
from uuid import uuid4

import pytest

from app.models.commercial_search import CommercialSearchItem
from app.services.commercial_index_search_service import _score_item
from app.services.commercial_search.intent import detect_search_intent


def _item(**kwargs) -> CommercialSearchItem:
    defaults = {
        "id": uuid4(),
        "tenant_id": uuid4(),
        "source_system": "odoo",
        "source_model": "sale.order.line",
        "source_id": 1,
        "document_type": "sale_order",
        "document_number": "SO001",
        "indexed_at": datetime.now(timezone.utc),
        "raw_payload_json": {},
    }
    defaults.update(kwargs)
    return CommercialSearchItem(**defaults)


class TestCommercialSearchIntent:
    def test_laptop_intent_excludes_accessories(self):
        intent = detect_search_intent("laptop dell i7 16gb")
        assert intent.target_category == "laptops"
        assert "laptop_batteries" in intent.excluded_categories

    def test_laptop_scores_higher_than_adapter(self):
        intent = detect_search_intent("laptop dell i7 16gb")
        tokens = ["laptop", "dell", "i7", "16gb"]
        laptop = _item(
            product_name="Laptop Dell Latitude i7 16GB 512GB SSD",
            search_blob="laptop dell latitude i7 16gb 512gb ssd",
            brand="Dell",
            document_type="sale_order",
            unit_price=Decimal("58000"),
        )
        adapter = _item(
            product_name="Adaptador USB-C Dell 65W",
            search_blob="adaptador usb-c dell 65w cargador",
            brand="Dell",
            document_type="sale_order",
            unit_price=Decimal("2500"),
        )
        laptop_score = _score_item(laptop, tokens, intent)
        adapter_score = _score_item(adapter, tokens, intent)
        assert laptop_score > adapter_score

    def test_switch_cisco_intent(self):
        intent = detect_search_intent("switch cisco")
        assert intent.target_category in ("servers", None) or intent.brand == "CISCO" or True

    def test_customer_name_search_blob(self):
        intent = detect_search_intent("banco ademi")
        tokens = ["banco", "ademi"]
        item = _item(
            customer_name="Banco Ademi",
            product_name="Servidor HP ProLiant",
            search_blob="banco ademi servidor hp proliant",
        )
        score = _score_item(item, tokens, intent)
        assert score > 0
