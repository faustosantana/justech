"""Tests — filtro producto principal vs accesorio."""

from __future__ import annotations

from app.services.commercial_product_filter import (
    is_valid_laptop_record,
    is_valid_primary_product,
)
from app.services.commercial_search.intent import detect_search_intent


class TestLaptopFilter:
    def test_valid_laptop(self):
        assert is_valid_laptop_record(product_name="Laptop Dell Latitude 15 i7 16GB 512GB")

    def test_excludes_ram(self):
        assert not is_valid_laptop_record(
            product_name="Memoria RAM 16GB DDR4 para laptop Dell"
        )

    def test_excludes_cdrom(self):
        assert not is_valid_laptop_record(product_name="CD-ROM portátil externo USB")

    def test_excludes_charger(self):
        assert not is_valid_laptop_record(product_name="Cargador Dell 65W para laptop")

    def test_primary_product_with_intent(self):
        intent = detect_search_intent("laptops de menos de 800 dolares", main_products_only=True)
        assert intent.target_category == "laptops"
        assert is_valid_primary_product(
            product_name="Laptop HP 15 i3 8GB",
            intent=intent,
        )
        assert not is_valid_primary_product(
            product_name="Memoria RAM 8GB Sodimm laptop",
            intent=intent,
        )
