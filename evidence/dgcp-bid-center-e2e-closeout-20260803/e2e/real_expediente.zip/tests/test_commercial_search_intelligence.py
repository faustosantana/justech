"""Tests — motor de inteligencia comercial."""

from __future__ import annotations

import pytest

from app.services.commercial_search.classifier import classify_product
from app.services.commercial_search.engine import CommercialSearchEngine, CommercialSearchOptions
from app.services.commercial_search.intent import detect_search_intent
from app.schemas.prices import PriceProductResponse
from datetime import datetime, timezone
from decimal import Decimal
from uuid import uuid4


def _product(description: str, *, product_type: str = "general", brand: str | None = None, price: str = "500") -> PriceProductResponse:
    return PriceProductResponse(
        id=uuid4(),
        supplier="Test",
        manufacturer=None,
        brand=brand,
        sku="SKU1",
        mpn=None,
        model=None,
        description=description,
        category=None,
        product_type=product_type,
        excluded_from_laptop=False,
        is_cotizable=True,
        price_review_status="ok",
        classification_label="producto general",
        stock_source_column=None,
        processor=None,
        ram_gb=16 if "16GB" in description else None,
        storage_gb=512 if "512GB" in description else None,
        storage_type=None,
        display=None,
        operating_system=None,
        price=Decimal(price),
        preferred_price=Decimal(price),
        preferred_price_field="price",
        price_regular=None,
        price_rebate=None,
        price_discount=None,
        prices_original={},
        currency="USD",
        stock=5,
        in_transit=None,
        stock_text_original=None,
        warranty=None,
        source_filename="test.xlsx",
        source_sheet="Sheet1",
        source_row=1,
        source_file_date=datetime.now(timezone.utc),
        source_file_date_estimated=False,
        file_id=uuid4(),
        indexed_at=datetime.now(timezone.utc),
    )


class TestSearchIntent:
    def test_laptop_intent(self):
        intent = detect_search_intent("laptop")
        assert intent.target_category == "laptops"
        assert "laptop_batteries" in intent.excluded_categories
        assert any("bateria" in t for t in intent.excluded_terms)

    def test_battery_laptop_intent(self):
        intent = detect_search_intent("batería laptop dell")
        assert intent.target_category == "laptop_batteries"
        assert "laptops" in intent.excluded_categories
        assert intent.brand == "Dell"

    def test_cartridge_intent(self):
        intent = detect_search_intent("cartucho HP 667")
        assert intent.target_category == "cartridges"
        assert intent.brand == "HP"

    def test_printer_intent(self):
        intent = detect_search_intent("impresora HP")
        assert intent.target_category == "printers"
        assert "cartridges" in intent.excluded_categories

    def test_monitor_intent(self):
        intent = detect_search_intent("monitor 24")
        assert intent.target_category == "monitors"
        assert intent.display_inches == 24


class TestProductClassifier:
    def test_laptop_real(self):
        r = classify_product(description="DELL LATITUDE 5440 16GB 512GB SSD NOTEBOOK")
        assert r.category == "laptops"
        assert r.is_main_product

    def test_battery_not_laptop(self):
        r = classify_product(description="BATERIA PARA LAPTOP DELL LATITUDE")
        assert r.category == "laptop_batteries"
        assert not r.is_main_product

    def test_charger_not_laptop(self):
        r = classify_product(description="CARGADOR PARA LAPTOP HP 65W")
        assert r.category == "chargers"

    def test_stand_not_laptop(self):
        r = classify_product(description="BASE PLEGABLE PARA LAPTOP")
        assert r.category == "laptop_stands"


class TestCommercialSearchEngine:
    def test_laptop_excludes_accessories(self):
        items = [
            _product("DELL LATITUDE 5440 16GB 512GB NOTEBOOK", product_type="laptop"),
            _product("BATERIA PARA LAPTOP DELL"),
            _product("CARGADOR PARA LAPTOP HP 65W"),
            _product("BASE PLEGABLE PARA LAPTOP"),
            _product("ADAPTADOR PARA CARGADOR DE LAPTOP"),
            _product("HP PROBOOK 450 G10 16GB 512GB", product_type="laptop"),
        ]
        result = CommercialSearchEngine().process("laptop", items, limit=10)
        descriptions = [s.product.description for s in result.items]
        assert any("LATITUDE" in d or "PROBOOK" in d for d in descriptions)
        assert not any("BATERIA" in d for d in descriptions)
        assert not any("CARGADOR" in d for d in descriptions)
        assert not any("BASE" in d for d in descriptions)
        assert result.excluded_count >= 3

    def test_battery_laptop_dell_includes_batteries(self):
        items = [
            _product("BATERIA PARA LAPTOP DELL LATITUDE", brand="Dell"),
            _product("DELL LATITUDE 5440 NOTEBOOK", product_type="laptop", brand="Dell"),
        ]
        result = CommercialSearchEngine().process("batería laptop dell", items, limit=10)
        descriptions = [s.product.description for s in result.items]
        assert any("BATERIA" in d for d in descriptions)
        assert not any("NOTEBOOK" in d and "BATERIA" not in d for d in descriptions)

    def test_cartridge_hp_667(self):
        items = [
            _product("CARTUCHO HP 667 NEGRO", brand="HP"),
            _product("CARTUCHO HP 667 COLOR", brand="HP"),
            _product("IMPRESORA HP LASERJET PRO", brand="HP", product_type="general"),
            _product("HP PROBOOK 450 NOTEBOOK", product_type="laptop", brand="HP"),
        ]
        result = CommercialSearchEngine().process("cartucho HP 667", items, limit=10)
        descriptions = [s.product.description for s in result.items]
        assert all("CARTUCHO" in d for d in descriptions)
        assert not any("IMPRESORA" in d for d in descriptions)
        assert not any("PROBOOK" in d for d in descriptions)

    def test_printer_hp(self):
        items = [
            _product("IMPRESORA HP LASERJET PRO M404", brand="HP"),
            _product("CARTUCHO HP 667", brand="HP"),
            _product("TONER HP 85A", brand="HP"),
            _product("CABLE USB IMPRESORA", brand="HP"),
        ]
        result = CommercialSearchEngine().process("impresora HP", items, limit=10)
        descriptions = [s.product.description for s in result.items]
        assert any("IMPRESORA" in d for d in descriptions)
        assert not any("CARTUCHO" in d for d in descriptions)

    def test_monitor_24(self):
        items = [
            _product('MONITOR DELL 24 PULGADAS FULL HD'),
            _product("CABLE HDMI 2M"),
            _product("BASE PARA MONITOR"),
            _product('MONITOR LG 27" 4K'),
        ]
        result = CommercialSearchEngine().process("monitor 24", items, limit=10)
        descriptions = [s.product.description for s in result.items]
        assert any("24" in d for d in descriptions)
        assert not any("CABLE" in d for d in descriptions)

    def test_no_results_message(self):
        items = [
            _product("BATERIA PARA LAPTOP DELL"),
            _product("CARGADOR PARA LAPTOP HP"),
        ]
        result = CommercialSearchEngine().process("laptop", items, limit=10)
        assert len(result.items) == 0
        assert result.excluded_count >= 2
        assert any("confiables" in w for w in result.warnings)
