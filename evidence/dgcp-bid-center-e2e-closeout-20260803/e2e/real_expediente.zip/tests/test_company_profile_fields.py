"""Tests — campos de perfil empresarial."""

from app.services.company_profile_field_service import (
    FIELD_DEFINITIONS,
    ONEDRIVE_ROOTS,
    PROFILE_FORM_FIELDS,
    CompanyProfileFieldService,
)


def test_field_definitions_cover_profile_form():
    for key in PROFILE_FORM_FIELDS:
        assert key in FIELD_DEFINITIONS


def test_text_fields_are_text_kind():
    for key in ("razon_social", "rnc", "telefono", "correo"):
        assert FIELD_DEFINITIONS[key]["kind"] == "text"


def test_hybrid_fields():
    for key in ("cedula_representante", "datos_bancarios", "proveedor_estado"):
        assert FIELD_DEFINITIONS[key]["kind"] == "hybrid"


def test_document_fields_have_onedrive_path():
    for key in ("registro_mercantil", "dgii", "firma", "sello"):
        defn = FIELD_DEFINITIONS[key]
        assert defn["kind"] == "document"
        assert defn.get("onedrive") in ONEDRIVE_ROOTS


def test_validate_rnc():
    from app.services.company_profile_field_service import _validate_field_value

    assert _validate_field_value("rnc", "131793916") == "131793916"
    try:
        _validate_field_value("rnc", "abc")
        assert False, "should raise"
    except ValueError:
        pass


def test_validate_correo():
    from app.services.company_profile_field_service import _validate_field_value

    assert _validate_field_value("correo", "test@justech.do") == "test@justech.do"
    try:
        _validate_field_value("correo", "invalid")
        assert False
    except ValueError:
        pass


def test_onedrive_folder_paths():
    svc = CompanyProfileFieldService.__new__(CompanyProfileFieldService)
    legal = svc._onedrive_folder("justech", "legal")
    assert legal == "Justech-AI/01_DOCUMENTOS_LEGALES/JUSTECH"
    identity = svc._onedrive_folder("just_office", "identity")
    assert identity == "Justech-AI/IDENTIDAD_CORPORATIVA/JUST_OFFICE"
    profile = svc._onedrive_folder("mf_plug_safe", "profile")
    assert profile == "Justech-AI/00_DATOS_EMPRESAS/PLUG_SAFE"


def test_text_only_profile_columns_exclude_cedula():
    from app.services.company_profile_field_service import TEXT_ONLY_PROFILE_COLUMNS

    assert "cedula_representante" in TEXT_ONLY_PROFILE_COLUMNS
    assert "registro_mercantil" not in TEXT_ONLY_PROFILE_COLUMNS
