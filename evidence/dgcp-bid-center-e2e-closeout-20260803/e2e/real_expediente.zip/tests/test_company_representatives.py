"""Tests — representantes reales vs placeholders."""

from app.services.company_representative_service import is_registered_representative_name


def test_accepts_real_names():
    assert is_registered_representative_name("Fausto Ramón Santana Jiménez")
    assert is_registered_representative_name("María Pérez")


def test_rejects_generic_placeholders():
    for name in (
        "",
        "   ",
        "Rep",
        "Representante",
        "Representante legal",
        "Otro representante",
        "Representante 2",
        "Socio 1",
        "Firmante adicional",
    ):
        assert not is_registered_representative_name(name), name
