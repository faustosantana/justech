"""Tests — fuente única perfil empresarial."""

from app.services.corporate_repository_unified_service import CorporateRepositoryUnifiedService


def test_canonical_field_for_rpe_aliases():
    assert CorporateRepositoryUnifiedService.canonical_field_for_type("rpe") == "proveedor_estado"
    assert CorporateRepositoryUnifiedService.canonical_field_for_type("proveedor_estado") == "proveedor_estado"
    assert CorporateRepositoryUnifiedService.canonical_field_for_type("certificacion_dgii") == "dgii"
    assert CorporateRepositoryUnifiedService.canonical_field_for_type("certificacion_tss") == "tss"


def test_static_profile_justech():
    prof = CorporateRepositoryUnifiedService.static_profile("justech")
    assert prof.get("rnc") == "131828061"
    assert "Justech" in prof.get("razon_social", "")


def test_unified_status_missing():
    svc = CorporateRepositoryUnifiedService.__new__(CorporateRepositoryUnifiedService)
    status, badge, vig = svc._unified_status_from_asset("dgii", None)
    assert status == "missing"
    assert badge == "Falta"


def test_extract_rpe_number_from_text():
    text = "Registro Proveedor del Estado RPE: 12345678 vigente hasta 2027"
    assert CorporateRepositoryUnifiedService.extract_rpe_number(text) == "12345678"


def test_extract_rpe_number_none_when_missing():
    assert CorporateRepositoryUnifiedService.extract_rpe_number("") is None
    assert CorporateRepositoryUnifiedService.extract_rpe_number("sin datos") is None


def test_resolve_rpe_display_pending():
    normalized = {"rpe_display": "Documento detectado, número pendiente"}
    assert (
        CorporateRepositoryUnifiedService.resolve_rpe_display(normalized)
        == "Documento detectado, número pendiente"
    )
