"""Tests — jobs asincrónicos de análisis DGCP."""

from __future__ import annotations

import asyncio
import uuid

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from app.services.dgcp_analysis_job_service import (
    DGCPAnalysisJobService,
    STAGE_LABELS,
)
from tests.conftest import LightDGCPOpportunity
from tests.dgcp_test_helpers import clear_dgcp_analysis_state, ensure_operational_interest


def test_stage_labels_cover_progress_stages():
    expected = {"preparing", "reading_documents", "hermes", "checklist", "expediente", "completed", "error"}
    assert expected <= set(STAGE_LABELS.keys())


def test_job_service_stage_progress_mapping():
    svc = DGCPAnalysisJobService(None, uuid.uuid4())  # type: ignore[arg-type]
    assert svc._to_response({
        "job_id": str(uuid.uuid4()),
        "opportunity_id": str(uuid.uuid4()),
        "status": "in_progress",
        "stage": "hermes",
        "progress_pct": 45,
        "force": True,
        "started_at": "2026-06-10T12:00:00+00:00",
        "updated_at": "2026-06-10T12:00:05+00:00",
    }).stage_label == "Análisis Hermes"


@pytest.mark.integration
@pytest.mark.asyncio
async def test_analyze_async_returns_202(light_dgcp_opportunity: LightDGCPOpportunity, dgcp_admin_headers):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        await ensure_operational_interest(client, light_dgcp_opportunity.id, dgcp_admin_headers)
        await clear_dgcp_analysis_state(light_dgcp_opportunity.id)

        response = await client.post(
            f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/requirements/analyze?async=true&force=true",
            headers=dgcp_admin_headers,
        )
        assert response.status_code == 202, response.text
        body = response.json()
        assert body["status"] == "in_progress"
        assert body["job_id"]

        status = await client.get(
            f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/analysis-status",
            headers=dgcp_admin_headers,
        )
        assert status.status_code == 200
        assert status.json()["has_active_job"] is True


@pytest.mark.integration
@pytest.mark.asyncio
async def test_double_start_returns_analysis_already_running(
    light_dgcp_opportunity: LightDGCPOpportunity,
    dgcp_admin_headers,
    mock_hermes_fast,
):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        await ensure_operational_interest(client, light_dgcp_opportunity.id, dgcp_admin_headers)
        await clear_dgcp_analysis_state(light_dgcp_opportunity.id)

        first = await client.post(
            f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/requirements/analyze?async=true&force=true",
            headers=dgcp_admin_headers,
        )
        assert first.status_code == 202, first.text

        second = await client.post(
            f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/requirements/analyze?async=true&force=true",
            headers=dgcp_admin_headers,
        )
        assert second.status_code == 409, second.text
        detail = second.json().get("detail") or {}
        assert detail.get("analysis_already_running") is True
        assert detail.get("job_id")


@pytest.mark.integration
@pytest.mark.asyncio
async def test_analysis_job_completes_with_stages(
    light_dgcp_opportunity: LightDGCPOpportunity,
    dgcp_admin_headers,
    mock_hermes_fast,
):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=120) as client:
        await ensure_operational_interest(client, light_dgcp_opportunity.id, dgcp_admin_headers)
        await clear_dgcp_analysis_state(light_dgcp_opportunity.id)

        started = await client.post(
            f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/requirements/analyze?async=true&force=true",
            headers=dgcp_admin_headers,
        )
        assert started.status_code == 202, started.text
        job_id = started.json()["job_id"]

        seen_stages: set[str] = set()
        for _ in range(90):
            job_res = await client.get(
                f"/api/v1/dgcp/opportunities/{light_dgcp_opportunity.id}/analysis-jobs/{job_id}",
                headers=dgcp_admin_headers,
            )
            assert job_res.status_code == 200
            job = job_res.json()
            seen_stages.add(job["stage"])
            if job["status"] == "completed":
                assert job.get("result")
                assert "checklist" in job["result"]
                break
            if job["status"] == "error":
                pytest.fail(job.get("error") or job.get("message"))
            await asyncio.sleep(0.75)
        else:
            pytest.fail(f"Job no completó a tiempo; stages={seen_stages}")

        assert "completed" in seen_stages
