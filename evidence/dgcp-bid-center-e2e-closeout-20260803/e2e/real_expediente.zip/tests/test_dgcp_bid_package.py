"""Tests — DGCP Requirements & Bid Package (Fase 7.1)."""

import asyncio

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_requirements_extractor import DGCPRequirementsExtractor
from tests.conftest import LightDGCPOpportunity
from tests.dgcp_test_helpers import analyze_with_interest, clear_dgcp_analysis_state, ensure_operational_interest


def _sample_opportunity() -> DGCPOpportunity:
    from datetime import date
    from decimal import Decimal
    import uuid

    return DGCPOpportunity(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        code="LPN-2024-TEST",
        institution="Ministerio Test",
        title="Adquisición de equipos informáticos",
        amount=Decimal("500000"),
        deadline=date(2026, 12, 31),
        description=(
            "Se requiere RPE vigente, certificación TSS, certificación DGII, "
            "registro mercantil, SNCC F.042, oferta técnica y oferta económica. "
            "Garantía de seriedad de oferta. Presentar muestras físicas."
        ),
        full_info={},
        raw_payload={},
    )


def test_requirements_extractor_finds_documents():
    opp = _sample_opportunity()
    result = DGCPRequirementsExtractor().extract(opp)
    keys = {d.key for d in result.mandatory_documents}
    assert "rpe" in keys
    assert "certificacion_tss" in keys
    assert "sncc_f042" in keys
    assert result.guarantees
    assert result.samples


def test_requirements_extractor_sncc_forms():
    opp = _sample_opportunity()
    opp.description = "Formularios SNCC F.033 y SNCC F.047 requeridos"
    result = DGCPRequirementsExtractor().extract(opp)
    keys = {d.key for d in result.mandatory_documents}
    assert "sncc_f033" in keys
    assert "sncc_f047" in keys
    assert any("33" in f for f in result.sncc_forms)
    assert any("47" in f for f in result.sncc_forms)


@pytest.mark.integration
@pytest.mark.asyncio
async def test_dgcp_bid_package_endpoints(light_dgcp_opportunity: LightDGCPOpportunity, dgcp_admin_headers):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opp_id = light_dgcp_opportunity.id

        analyze = await analyze_with_interest(client, opp_id, dgcp_admin_headers, force=True)
        assert analyze.status_code == 200, analyze.text
        body = analyze.json()
        assert "checklist" in body
        assert body["bid_package"]["preparation_pct"] >= 0

        checklist = await client.get(
            f"/api/v1/dgcp/opportunities/{opp_id}/checklist",
            headers=dgcp_admin_headers,
        )
        assert checklist.status_code == 200
        assert checklist.json()["total"] >= 1

        preview = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/forms/preview",
            headers=dgcp_admin_headers,
            json={"form_type": "SNCC.F042", "company": "justech"},
        )
        assert preview.status_code == 200
        assert preview.json()["generate_enabled"] is False


@pytest.mark.integration
@pytest.mark.asyncio
async def test_parallel_tab_load_without_auto_analyze_race(
    light_dgcp_opportunity: LightDGCPOpportunity,
    dgcp_admin_headers,
):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opp_id = light_dgcp_opportunity.id

        responses = await asyncio.gather(
            client.get(f"/api/v1/dgcp/opportunities/{opp_id}/requirements", headers=dgcp_admin_headers),
            client.get(f"/api/v1/dgcp/opportunities/{opp_id}/checklist", headers=dgcp_admin_headers),
            client.get(f"/api/v1/dgcp/opportunities/{opp_id}/bid-package", headers=dgcp_admin_headers),
            client.get(f"/api/v1/dgcp/opportunities/{opp_id}/document-matches", headers=dgcp_admin_headers),
        )
        assert all(r.status_code == 200 for r in responses), [r.text for r in responses]


@pytest.mark.integration
@pytest.mark.asyncio
async def test_concurrent_analyze_is_idempotent(
    light_dgcp_opportunity: LightDGCPOpportunity,
    dgcp_admin_headers,
    mock_hermes_fast,
):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=120) as client:
        opp_id = light_dgcp_opportunity.id

        await analyze_with_interest(client, opp_id, dgcp_admin_headers, force=True)

        duplicate = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze",
            headers=dgcp_admin_headers,
        )
        assert duplicate.status_code == 409, duplicate.text
        detail = duplicate.json().get("detail") or {}
        if isinstance(detail, dict):
            assert detail.get("already_analyzed") is True
            assert "analizado" in (detail.get("message") or "").lower()

        await clear_dgcp_analysis_state(opp_id)

        first = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=true",
            headers=dgcp_admin_headers,
        )
        assert first.status_code == 202, first.text

        forced = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=true",
            headers=dgcp_admin_headers,
        )
        assert forced.status_code in (200, 202, 409), forced.text

        responses = await asyncio.gather(
            client.post(
                f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=true",
                headers=dgcp_admin_headers,
            ),
            client.post(
                f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=true",
                headers=dgcp_admin_headers,
            ),
            client.post(
                f"/api/v1/dgcp/opportunities/{opp_id}/requirements/analyze?force=true&async=true",
                headers=dgcp_admin_headers,
            ),
        )
        codes = [r.status_code for r in responses]
        assert all(c in (202, 409) for c in codes), [r.text for r in responses]
        assert codes.count(409) >= 1
        assert codes.count(202) <= 1


@pytest.mark.integration
@pytest.mark.asyncio
async def test_assistant_dgcp_requirements_context(
    light_dgcp_opportunity: LightDGCPOpportunity,
    dgcp_admin_headers,
    disable_hermes_primary,
):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opp_id = light_dgcp_opportunity.id

        await analyze_with_interest(client, opp_id, dgcp_admin_headers, force=True)

        response = await client.post(
            "/api/v1/assistant/query",
            json={
                "question": "¿Qué porcentaje del expediente está listo?",
                "current_module": "/dgcp",
                "record_type": "dgcp",
                "current_record_id": opp_id,
            },
            headers=dgcp_admin_headers,
        )
        assert response.status_code == 200
        body = response.json()
        assert body["query_type"] == "dgcp_requirements_query"
        assert "expediente" in body["answer"].lower() or "%" in body["answer"]
