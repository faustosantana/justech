"""Tests — checklist dinámico DGCP (Fase 2)."""

from app.services.dgcp_compliance_engine import DGCPComplianceEngine
from app.services.dgcp_requirements_extractor import ExtractedRequirement, ExtractionResult


def test_dynamic_checklist_skips_baseline_when_corpus_present(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_dynamic_checklist", True)
    engine = DGCPComplianceEngine()
    extraction = ExtractionResult(
        combined_text="Pliego completo con requisitos",
        has_process_corpus=True,
        mandatory_documents=[
            ExtractedRequirement(key="rpe", label="RPE vigente", tipo="legal"),
        ],
    )
    all_reqs = engine.collect_all_requirements(extraction)
    keys = {r.key for r in all_reqs}
    assert "rpe" in keys
    assert "certificacion_tss" not in keys
    assert "oferta_tecnica" not in keys


def test_dynamic_checklist_applies_baseline_without_corpus(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_dynamic_checklist", True)
    engine = DGCPComplianceEngine()
    extraction = ExtractionResult(has_process_corpus=False)
    all_reqs = engine.collect_all_requirements(extraction)
    keys = {r.key for r in all_reqs}
    assert "certificacion_tss" in keys
    assert "oferta_tecnica" in keys


def test_unified_status_mapping():
    assert DGCPComplianceEngine.unified_status("encontrado_vigente") == "completado"
    assert DGCPComplianceEngine.unified_status("faltante") == "pendiente"
    assert DGCPComplianceEngine.unified_status("encontrado_vencido") == "vencido"
    assert DGCPComplianceEngine.unified_status("disponible") == "completado"


def test_checklist_response_includes_unified_status(monkeypatch):
    from uuid import uuid4

    from app.services.dgcp_bid_package_service import DGCPBidPackageService

    monkeypatch.setattr("app.config.settings.dgcp_unified_expediente", True)
    svc = DGCPBidPackageService(db=None, tenant_id=uuid4(), user_id=None)
    items = [
        {
            "id": str(uuid4()),
            "requirement_key": "rpe",
            "requirement": "RPE",
            "tipo": "legal",
            "mandatory": True,
            "status": "faltante",
        }
    ]
    resp = svc._checklist_response(uuid4(), items)
    assert resp.items[0].unified_status == "pendiente"
    assert resp.items[0].unified_status is not None
