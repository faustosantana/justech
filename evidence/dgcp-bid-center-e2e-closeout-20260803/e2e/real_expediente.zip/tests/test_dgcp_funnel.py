"""Tests for DGCP operational funnel transitions."""

import pytest
from fastapi import HTTPException

from app.services.dgcp_funnel import (
    FunnelStage,
    build_funnel_guidance,
    funnel_stage_for_status,
    normalize_action,
    validate_transition,
)


def test_funnel_stage_mapping():
    assert funnel_stage_for_status("detected") == FunnelStage.NUEVAS
    assert funnel_stage_for_status("interested") == FunnelStage.INTERESADAS
    assert funnel_stage_for_status("preparing") == FunnelStage.EN_PREPARACION
    assert funnel_stage_for_status("ready_to_submit") == FunnelStage.LISTAS_PARA_PRESENTAR
    assert funnel_stage_for_status("submitted") == FunnelStage.PRESENTADAS
    assert funnel_stage_for_status("suspended") == FunnelStage.SUSPENDIDAS
    assert funnel_stage_for_status("awarded") == FunnelStage.ADJUDICADAS
    assert funnel_stage_for_status("lost") == FunnelStage.NO_ADJUDICADAS
    assert funnel_stage_for_status("discarded") == FunnelStage.DESCARTADAS


def test_happy_path_transitions():
    assert validate_transition("detected", "marcar_interes") == "interested"
    assert validate_transition("interested", "iniciar_preparacion") == "preparing"
    assert validate_transition("preparing", "marcar_listo_presentar") == "ready_to_submit"
    assert validate_transition("ready_to_submit", "marcar_presentada") == "submitted"
    assert validate_transition("submitted", "marcar_adjudicada") == "awarded"
    assert validate_transition("submitted", "marcar_no_adjudicada") == "lost"


def test_legacy_action_aliases():
    assert normalize_action("mostrar_interes").value == "marcar_interes"
    assert normalize_action("licitar").value == "iniciar_preparacion"
    assert validate_transition("interested", "licitar") == "preparing"


def test_cannot_adjudicate_before_presented():
    with pytest.raises(HTTPException) as exc:
        validate_transition("preparing", "marcar_adjudicada")
    assert exc.value.status_code == 409


def test_descartar_from_any_active_stage():
    assert validate_transition("interested", "descartar") == "discarded"
    assert validate_transition("preparing", "descartar") == "discarded"
    assert validate_transition("submitted", "descartar") == "discarded"


def test_guidance_primary_action():
    g = build_funnel_guidance("ready_to_submit")
    assert g.primary_action == "marcar_presentada"
    assert g.funnel_stage == "listas_para_presentar"


def test_needs_review_label():
    g = build_funnel_guidance("detected", needs_review=True)
    assert "revisión" in g.status_label.lower()
