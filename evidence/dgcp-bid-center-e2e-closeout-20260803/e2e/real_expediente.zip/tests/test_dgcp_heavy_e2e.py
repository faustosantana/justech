"""E2E pesados — Hermes real contra proceso DGII (solo con -m slow)."""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from tests.dgcp_test_helpers import (
    HEAVY_OPPORTUNITY_CODES,
    analyze_with_interest,
    clear_dgcp_analysis_state,
    dgcp_admin_login,
    is_heavy_opportunity,
)


@pytest.mark.slow
@pytest.mark.dgcp_heavy
@pytest.mark.integration
@pytest.mark.asyncio
async def test_heavy_dgii_analyze_async_completes():
    """Análisis real contra DGII-0005 — no corre en suite rápida."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=360) as client:
        headers = await dgcp_admin_login(client)
        if not headers:
            pytest.skip("Login no disponible")

        list_res = await client.get("/api/v1/dgcp/opportunities?limit=50", headers=headers)
        items = list_res.json().get("items") or []
        opp = next((i for i in items if is_heavy_opportunity(i)), None)
        if not opp:
            pytest.skip(f"Proceso pesado no encontrado: {HEAVY_OPPORTUNITY_CODES}")

        opp_id = opp["id"]
        await clear_dgcp_analysis_state(opp_id)

        result = await analyze_with_interest(
            client,
            opp_id,
            headers,
            force=True,
            async_job=True,
            wait_timeout_s=300.0,
        )
        assert result.status_code == 200, result.text
        body = result.json()
        assert body.get("checklist", {}).get("total", 0) >= 1
