"""Tests — análisis documental Hermes DGCP (Fase 5)."""

from __future__ import annotations

import uuid
from decimal import Decimal

import pytest

from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.hermes import HermesAnalysisResult
from app.services.dgcp_hermes_document_analysis_service import DGCPHermesDocumentAnalysisService
from app.services.dgcp_requirements_extractor import ExtractedRequirement, ExtractionResult


class _FakeHermes:
    def __init__(self, tender: HermesAnalysisResult | None = None):
        self.tender = tender or HermesAnalysisResult(
            summary="Pliego requiere RPE, DGII y SNCC F.042.",
            confidence=0.82,
            required_documents=["RPE vigente", "Certificación DGII", "SNCC F.042"],
            next_actions=["Completar garantía de seriedad"],
        )

    def is_available(self) -> bool:
        return True

    async def analyze_tender(self, **kwargs):
        return self.tender

    async def analyze_document(self, **kwargs):
        return None


def _opportunity() -> DGCPOpportunity:
    return DGCPOpportunity(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        code="TEST-2026-0001",
        institution="MINERD",
        title="Equipos",
        amount=Decimal("100000"),
        description="",
        full_info={},
        raw_payload={},
    )


@pytest.mark.asyncio
async def test_hermes_enrich_adds_requirements(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_hermes_document_analysis", True)
    monkeypatch.setattr("app.config.settings.hermes_enabled", True)

    extraction = ExtractionResult(has_process_corpus=True)
    svc = DGCPHermesDocumentAnalysisService(client=_FakeHermes())  # type: ignore[arg-type]
    merged, meta = await svc.enrich_extraction(
        _opportunity(),
        extraction,
        process_corpus="El oferente debe presentar RPE y certificación DGII.",
        process_documents=[],
    )
    keys = {r.key for r in merged.mandatory_documents}
    assert meta["status"] == "completed"
    assert "rpe" in keys
    assert "certificacion_dgii" in keys
    assert "sncc_f042" in keys
    assert any("042" in form for form in merged.sncc_forms)


@pytest.mark.asyncio
async def test_hermes_enrich_skipped_without_corpus(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_hermes_document_analysis", True)
    svc = DGCPHermesDocumentAnalysisService(client=_FakeHermes())  # type: ignore[arg-type]
    merged, meta = await svc.enrich_extraction(
        _opportunity(),
        ExtractionResult(),
        process_corpus="",
        process_documents=[],
    )
    assert meta["status"] == "skipped"
    assert merged.mandatory_documents == []
