"""Tests API búsqueda histórica similar DGCP (on-demand)."""

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.fixture
async def auth_headers():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        login = await client.post(
            "/api/v1/auth/login",
            json={
                "email": "admin@justech.do",
                "password": "JaiosAdmin2026!",
                "tenant_slug": "justech",
            },
        )
        if login.status_code != 200:
            pytest.skip("Login no disponible en entorno de test")
        headers = {"Authorization": f"Bearer {login.json()['access_token']}"}
        if login.json().get("tenant_id"):
            headers["X-Tenant-ID"] = str(login.json()["tenant_id"])
        yield headers


@pytest.mark.asyncio
async def test_historical_similar_requires_auth():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get("/api/v1/dgcp/processes/00000000-0000-0000-0000-000000000001/historical-similar")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_get_historical_similar_cached_pending(auth_headers):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opps = await client.get("/api/v1/dgcp/opportunities?limit=1", headers=auth_headers)
        if opps.status_code != 200 or not opps.json().get("items"):
            pytest.skip("Sin oportunidades DGCP en test")
        opp_id = opps.json()["items"][0]["id"]
        response = await client.get(
            f"/api/v1/dgcp/processes/{opp_id}/historical-similar",
            headers=auth_headers,
        )
    assert response.status_code == 200
    body = response.json()
    assert "status" in body
    assert "matches" in body


@pytest.mark.asyncio
async def test_search_historical_similar_requires_interest(auth_headers):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opps = await client.get(
            "/api/v1/dgcp/opportunities?status=detected&limit=1",
            headers=auth_headers,
        )
        if opps.status_code != 200 or not opps.json().get("items"):
            pytest.skip("Sin oportunidad detected en test")
        opp_id = opps.json()["items"][0]["id"]
        response = await client.post(
            f"/api/v1/dgcp/processes/{opp_id}/historical-similar/search",
            headers=auth_headers,
            json={"refresh": False, "limit": 3},
        )
    assert response.status_code == 400
    assert "interés" in response.json()["detail"].lower() or "oferta" in response.json()["detail"].lower()


@pytest.mark.asyncio
async def test_bootstrap_expediente_context(auth_headers):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        opps = await client.get("/api/v1/dgcp/opportunities?limit=1", headers=auth_headers)
        if opps.status_code != 200 or not opps.json().get("items"):
            pytest.skip("Sin oportunidades DGCP en test")
        opp_id = opps.json()["items"][0]["id"]
        response = await client.post(
            f"/api/v1/dgcp/opportunities/{opp_id}/expediente-context/bootstrap",
            headers=auth_headers,
            json={"refresh": False},
        )
    assert response.status_code == 200
    body = response.json()
    assert "historical_status" in body
    assert "commercial_status" in body
    assert "enabled" in body

