"""Tests del motor de similitud para histórico DGCP."""

from app.services.dgcp_historical_similarity_engine import (
    build_query_tokens,
    core_query_tokens,
    display_keywords,
    has_keyword_overlap,
    institution_matches,
    score_award,
    similarity_level,
    tokenize,
)


def test_tokenize_laptop_synonyms():
    tokens = build_query_tokens("Compra de laptops Dell 16GB RAM 512GB")
    assert "laptop" in tokens or "laptops" in tokens
    assert "dell" in tokens


def test_score_same_institution_and_keywords():
    query_tokens = build_query_tokens("Compra de laptops Dell 16GB")
    score, reasons = score_award(
        query_tokens=query_tokens,
        query_institution="Ministerio de Educación",
        query_objeto=None,
        award_institution="Ministerio de Educación",
        award_objeto=None,
        award_search_text="adquisicion laptops dell portatil 16gb ram ministerio educacion",
        same_institution_required=True,
    )
    assert score >= 45
    assert any("institución" in r.lower() for r in reasons)
    assert similarity_level(score) in ("alta", "media")


def test_score_filters_different_institution_when_required():
    query_tokens = build_query_tokens("laptops dell")
    score, reasons = score_award(
        query_tokens=query_tokens,
        query_institution="MINERD",
        query_objeto=None,
        award_institution="Hospital General",
        award_objeto=None,
        award_search_text="laptops dell hospital",
        same_institution_required=True,
    )
    assert score == 0
    assert "Institución distinta" in reasons[0]


def test_similarity_levels():
    assert similarity_level(75) == "alta"
    assert similarity_level(50) == "media"
    assert similarity_level(25) == "baja"
    assert similarity_level(10) == "muy_baja"


def test_institution_matches_fuzzy():
    from app.services.dgcp_historical_similarity_engine import institution_matches_strict

    assert institution_matches_strict(
        "Hospital Provincial Dr. Francisco Antonio Gonzalvo",
        "Hospital Provincial Dr. Francisco Antonio Gonzalvo",
    )
    assert not institution_matches_strict("MINERD", "Ministerio de Educación")
    assert institution_matches_strict(
        "Dirección General Impuestos Internos",
        "Dirección General Impuestos Internos",
    )
    assert not institution_matches_strict(
        "Centro de Rehabilitación Psicosocial y Desarrollo Humano",
        "Programa Especial de Rehabilitación y Educación Especial PROPEEP",
    )


def test_toner_synonyms_expand():
    tokens = build_query_tokens("Compra de toners HP Canon")
    assert "toner" in tokens or "toners" in tokens
    assert "hp" in tokens or "canon" in tokens


def test_core_query_tokens_drop_generic_process_words():
    core = core_query_tokens(
        "Adquisición de laptops dirigido a MIPYMES para uso de la institución"
    )
    assert "laptop" in core or "laptops" in core
    assert "mipymes" not in core
    assert "dirigido" not in core
    assert "institucion" not in core


def test_has_keyword_overlap():
    tokens = core_query_tokens("Compra de electrodomésticos Samsung")
    assert has_keyword_overlap(tokens, "adquisicion electrodomesticos samsung nevera")
    assert not has_keyword_overlap(tokens, "compra de vehiculos toyota")


def test_display_keywords_prioritizes_product_terms():
    tokens = build_query_tokens("laptops dell mipymes institucion electrodomesticos")
    shown = display_keywords(tokens, limit=5)
    assert any(t in shown for t in ("laptop", "laptops", "electrodomesticos", "dell"))
    assert "mipymes" not in shown[:3]


def test_tokenize_strips_stopwords():
    tokens = tokenize("compra de la adquisicion de suministros")
    assert "compra" not in tokens
    assert "adquisicion" not in tokens


def test_score_similar_process_rejects_printer_for_switch_query():
    from app.services.dgcp_historical_similarity_engine import score_similar_process, strict_core_tokens

    query_core = strict_core_tokens(
        "Adquisición switches y routers Fortinet obsolescencia equipos de red"
    )
    assert "switches" in query_core or "switch" in query_core
    result = score_similar_process(
        query_texts=["Compra switches Fortinet FG-700G"],
        query_core=query_core,
        query_objeto="Adquisición de bienes",
        candidate_texts=["IMPRESORA EPSON ECOTANK L5590 bienes equipo equipos"],
        candidate_objeto="Adquisición de bienes",
    )
    assert result is None


def test_score_similar_process_accepts_networking_match():
    from app.services.dgcp_historical_similarity_engine import score_similar_process, strict_core_tokens

    query_core = strict_core_tokens("Compra switches routers Fortinet firewall")
    result = score_similar_process(
        query_texts=["Compra switches Fortinet FG-700G"],
        query_core=query_core,
        query_objeto="Renovación equipos de red",
        candidate_texts=["Switch Fortinet FG-400F 24 puertos firewall institucion"],
        candidate_objeto="Renovación equipos de red",
    )
    assert result is not None
    score, reasons, matched = result
    assert score >= 55
    assert any("networking" in r.lower() or "técnicas" in r.lower() for r in reasons)


def test_score_similar_process_rejects_gloves_for_medical_monitor_query():
    from app.services.dgcp_historical_similarity_engine import score_similar_process, strict_core_tokens

    query_core = strict_core_tokens("Monitoreo glucosa insumos enfermería centro")
    result = score_similar_process(
        query_texts=["Insumos monitoreo glucosa enfermería"],
        query_core=query_core,
        query_objeto="Adquisición de bienes",
        candidate_texts=["GUANTE DE NITRILO M C-100 bienes insumo enfermeria"],
        candidate_objeto="Adquisición de bienes",
    )
    assert result is None
