"""Tests — DGCP Premium+ intelligence (Fases A/B)."""

from __future__ import annotations

import uuid
from datetime import date, timedelta
from decimal import Decimal

from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_intelligence.expediente_intelligence import compute_expediente_intelligence
from app.services.dgcp_intelligence.premium_score_engine import compute_premium_score


def _opp(**kwargs) -> DGCPOpportunity:
    defaults = dict(
        id=uuid.uuid4(),
        tenant_id=uuid.uuid4(),
        code="LPN-TEST-001",
        institution="Ministerio Test",
        title="Adquisición equipos informáticos",
        amount=Decimal("2500000"),
        currency="DOP",
        probability=50,
        score=65,
        status="to_review",
        priority="high",
        company="justech",
        confidence_score=85,
        deadline=date.today() + timedelta(days=20),
        modalidad="Comparación de precios",
        full_info={},
        raw_payload={},
        risks=[],
    )
    defaults.update(kwargs)
    return DGCPOpportunity(**defaults)


def test_premium_score_high_for_strong_opportunity():
    opp = _opp()
    result = compute_premium_score(
        opp,
        similar_awards=4,
        product_availability_pct=80,
        document_completeness_pct=70,
    )
    assert result.total >= 45
    assert result.probability_band in ("alta", "media")
    assert "monto_estimado" in result.factors
    assert result.participation_recommendation in ("licitar", "revisar", "analizar", "descartar")


def test_premium_score_low_when_deadline_critical():
    opp = _opp(deadline=date.today() + timedelta(days=1), score=20)
    result = compute_premium_score(opp, document_completeness_pct=10)
    assert result.total <= 50
    assert any("días" in r["descripcion"].lower() for r in result.risks)


def test_expediente_traffic_light_green_when_complete():
    intel = compute_expediente_intelligence(
        opp_status="to_bid",
        real_expediente_status="listo_para_subir",
        validation={"missing_documents": [], "expired_documents": []},
        package_checklist=[{"requirement": "dgii", "status": "encontrado"}],
        premium_score=72,
        participation_recommendation="licitar",
    )
    assert intel.completeness_pct >= 50
    assert intel.traffic_light in ("green", "yellow")
    assert intel.stage_code in ("LISTA_ENVIO", "EN_PREPARACION", "ANALIZADA")


def test_expediente_traffic_light_red_when_discard():
    intel = compute_expediente_intelligence(
        opp_status="discarded",
        real_expediente_status=None,
        validation=None,
        package_checklist=[],
        premium_score=15,
        participation_recommendation="descartar",
    )
    assert intel.traffic_light == "red"
    assert intel.stage_code == "NO_PARTICIPAR"


def test_expediente_checklist_marks_missing_docs():
    intel = compute_expediente_intelligence(
        opp_status="interested",
        real_expediente_status=None,
        validation={"missing_documents": ["tss", "dgii"], "expired_documents": []},
        package_checklist=[],
        premium_score=55,
        participation_recommendation="revisar",
    )
    missing_labels = {c["label"] for c in intel.checklist_items if c["status"] == "missing"}
    assert "TSS" in missing_labels or "DGII" in missing_labels
    assert intel.completeness_pct < 100
