"""Tests — Centro de preparación de oferta (Fase 6.3)."""

from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_consolidated_technical_offer_service import DGCPConsolidatedTechnicalOfferService
from app.services.dgcp_offer_preparation_center_service import (
    DGCPOfferPreparationCenterService,
    EVIDENCIA_NO_DISPONIBLE,
)


def _opportunity(**kwargs) -> DGCPOpportunity:
    return DGCPOpportunity(
        id=kwargs.get("id", uuid.uuid4()),
        tenant_id=kwargs.get("tenant_id", uuid.uuid4()),
        code=kwargs.get("code", "DGII-CCC-PEEX-2026-0005"),
        institution=kwargs.get("institution", "DGII"),
        title=kwargs.get("title", "Adquisición de Switches y Routers"),
        amount=Decimal("500000"),
        currency="DOP",
        modalidad="Comparación de Precios",
        deadline=kwargs.get("deadline", date(2026, 12, 31)),
        status="interested",
        company="justech",
        description="Proceso de switches y routers",
        full_info={},
        raw_payload={},
        risks=[{"nivel": "alto", "descripcion": "Plazo ajustado"}],
    )


def _pkg(opp: DGCPOpportunity) -> DGCPBidPackage:
    return DGCPBidPackage(
        tenant_id=opp.tenant_id,
        opportunity_id=opp.id,
        bid_package={"preparation_pct": 72.5},
        checklist=[
            {"id": "1", "requirement_key": "rpe", "requirement": "RPE vigente", "status": "faltante", "mandatory": True},
            {"id": "2", "requirement_key": "sncc_f033", "requirement": "SNCC F.033", "status": "plantilla_disponible", "mandatory": True},
            {"id": "3", "requirement_key": "ficha_tecnica", "requirement": "Ficha técnica Switch", "status": "pendiente", "mandatory": True},
            {
                "id": "4",
                "requirement_key": "hermes_verificar_docs",
                "requirement": "Verificar disponibilidad de todos los documentos requeridos",
                "status": "faltante",
                "mandatory": True,
                "evidence_source": "hermes_llm",
            },
            {
                "id": "5",
                "requirement_key": "registro_mercantil",
                "requirement": "Registro Mercantil",
                "status": "encontrado_sin_analizar",
                "mandatory": True,
            },
            {"id": "6", "requirement_key": "tiempo_entrega", "requirement": "Tiempo de entrega", "status": "faltante", "mandatory": False},
        ],
        requirements={"guarantees": ["Garantía de seriedad 5%"]},
        requirement_risks=[
            {"nivel": "alto", "descripcion": "Expediente incompleto — 3 requisito(s) obligatorio(s) sin cumplir."},
            {"nivel": "medio", "descripcion": "Registro Mercantil: Documento encontrado — pendiente de lectura/análisis"},
            {"nivel": "alto", "descripcion": "RPE vigente: Documento obligatorio no encontrado"},
        ],
        manifest={
            "hermes_document_analysis": {
                "summary": "Proceso de equipos de red.",
                "risks": [{"nivel": "medio", "descripcion": "Especificaciones técnicas detalladas"}],
            },
            "technical_sheets": {
                "items": [
                    {"id": "s1", "required_product_name": "Switch", "status": "pendiente_producto"},
                    {"id": "s2", "required_product_name": "Router", "status": "requiere_revision"},
                ],
            },
            "product_intelligence": {
                "items": [
                    {"requirement": {"id": "r1", "nombre": "Switches"}, "compliance_matrix": None},
                ],
            },
        },
    )


def test_consolidated_offer_is_borrador():
    opp = _opportunity()
    pkg = _pkg(opp)
    content, sections, meta = DGCPConsolidatedTechnicalOfferService().build(opp, pkg, company_name="Justech SRL")
    assert meta["status"] == "borrador"
    assert "Portada" in sections
    assert "BORRADOR" in content
    assert opp.code in content
    assert "oferta económica" not in content.lower()


def test_classify_checklist_items():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    assert svc._classify_item({"requirement": "SNCC F.033 Carta"}) == "formularios"
    assert svc._classify_item({"requirement": "RPE vigente"}) == "legal"
    assert svc._classify_item({"requirement": "Ficha técnica Switch"}) == "fichas_tecnicas"


def test_area_status_thresholds():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    assert svc._area_status(100) == "listo"
    assert svc._area_status(75) == "parcial"
    assert svc._area_status(0) == "bloqueado"


def test_overall_pct_from_areas():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    from app.schemas.dgcp_offer_preparation import DGCPOfferPreparationArea

    areas = [
        DGCPOfferPreparationArea(key="evidencias", label="Evidencias", preparation_pct=100.0, status="listo"),
        DGCPOfferPreparationArea(key="oferta_tecnica", label="Oferta técnica", preparation_pct=16.7, status="parcial"),
        DGCPOfferPreparationArea(key="legal", label="Legal", preparation_pct=0.0, status="bloqueado"),
    ]
    assert svc._overall_pct_from_areas(areas) == 38.9


def test_compute_area_preparation_pct_from_manifest_cache():
    opp = _opportunity()
    pkg = _pkg(opp)
    pkg.manifest = {
        "offer_preparation_center": {"overall_preparation_pct": 14.6},
    }
    assert DGCPOfferPreparationCenterService.compute_area_preparation_pct(pkg) == 14.6


def test_offer_preparation_center_flag_off(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_offer_preparation_center", False)
    assert DGCPOfferPreparationCenterService.enabled() is False


def test_pending_critical_vs_minor():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    opp = _opportunity()
    pkg = _pkg(opp)
    critical, minor = svc._pending_items(list(pkg.checklist or []), pkg, pkg.manifest or {}, opp)

    critical_labels = {c.label for c in critical}
    minor_labels = {m.label for m in minor}

    assert "RPE vigente" in critical_labels
    assert "SNCC F.033" in critical_labels
    assert "Verificar disponibilidad de todos los documentos requeridos" not in critical_labels
    assert "Registro Mercantil" in minor_labels
    assert "Tiempo de entrega" in minor_labels
    assert any("Ficha técnica: Switch" in label for label in critical_labels)
    assert any("Ficha técnica: Router" in label for label in minor_labels)
    assert any("Matriz de cumplimiento" in label for label in critical_labels)


def test_dedupe_guarantee_and_sncc():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    from app.schemas.dgcp_offer_preparation import DGCPOfferPreparationPendingItem

    items = [
        DGCPOfferPreparationPendingItem(id="1", label="Garantía de seriedad", area="legal", severity="critico"),
        DGCPOfferPreparationPendingItem(id="2", label="Garantía de seriedad de oferta", area="legal", severity="critico"),
        DGCPOfferPreparationPendingItem(id="3", label="SNCC F.033", area="formularios", severity="critico"),
        DGCPOfferPreparationPendingItem(id="4", label="SNCC F.033 Carta", area="formularios", severity="critico"),
    ]
    deduped = svc._dedupe_pending(items)
    assert len(deduped) == 2


def test_risk_evidencia_fallback():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    assert svc._risk_evidencia(None) == EVIDENCIA_NO_DISPONIBLE
    assert svc._risk_evidencia("  fragmento pliego  ") == "fragmento pliego"


def test_consolidate_risks_includes_evidencia():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    opp = _opportunity()
    pkg = _pkg(opp)
    risks = svc._consolidate_risks(opp, pkg, pkg.manifest or {})
    assert risks
    assert all(r.evidencia for r in risks)
    assert not any("Documento encontrado — pendiente de lectura" in r.descripcion for r in risks)


def test_classify_checklist_pending_blocks_only_mandatory_missing():
    svc = DGCPOfferPreparationCenterService(None, uuid.uuid4())  # type: ignore[arg-type]
    assert svc._classify_checklist_pending({"requirement": "RPE", "status": "faltante", "mandatory": True}) == "critico"
    assert svc._classify_checklist_pending({"requirement": "RPE", "status": "encontrado_sin_analizar", "mandatory": True}) == "menor"
    assert svc._classify_checklist_pending({
        "requirement_key": "hermes_x",
        "requirement": "Preparar la oferta económica",
        "status": "faltante",
        "mandatory": True,
    }) is None
