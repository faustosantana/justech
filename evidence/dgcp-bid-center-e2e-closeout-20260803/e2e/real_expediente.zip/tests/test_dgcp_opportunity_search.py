"""Tests — búsqueda de oportunidades DGCP."""

from app.services.dgcp_service import DGCPService


def test_build_search_filter_returns_none_for_short_query():
    assert DGCPService.build_search_filter("") is None
    assert DGCPService.build_search_filter("a") is None


def test_build_search_filter_accepts_partial_code_tokens():
    clause = DGCPService.build_search_filter("RESIDE-DAF-CD-2026")
    assert clause is not None
