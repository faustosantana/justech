"""Tests — descubrimiento de documentos en portal DGCP."""

from __future__ import annotations

from app.services.dgcp_portal_document_service import DGCPPortalDocumentService


SAMPLE_HTML = """
<a onclick="javascript:getAction('/Public/Tendering/OpportunityDetail/DownloadFile' + '?' + 'documentFileId=' + '13021176' + '&mkey=abc',true);">Download</a>
<span>8.DGII-CCC-PEEX-2026-0005 Pliego de Bases de Condiciones.pdf</span>
<a onclick="javascript:getAction('/Public/Tendering/OpportunityDetail/DownloadFile' + '?' + 'documentFileId=' + '13021181' + '&mkey=abc',true);">Download</a>
<span>Anexo. DGII-CCC-PEEX-2026-0005 Borrador de Contrato.pdf</span>
<a onclick="javascript:getAction('/Public/Tendering/OpportunityDetail/DownloadFile' + '?' + 'documentFileId=' + '13021172' + '&mkey=abc',true);">Download</a>
<span>3. DGII-CCC-PEEX-2026-0005 Formulario de Estudios Previos.pdf</span>
"""


def test_discover_from_html_extracts_roles():
    svc = DGCPPortalDocumentService()
    refs = svc.discover_from_html(SAMPLE_HTML, process_code="DGII-CCC-PEEX-2026-0005")
    by_id = {r.portal_document_id: r for r in refs}
    assert "13021176" in by_id
    assert by_id["13021176"].doc_role == "pliego"
    assert by_id["13021181"].doc_role == "anexo"
    assert by_id["13021172"].doc_role == "formulario"


def test_notice_uid_from_url():
    url = "https://comunidad.comprasdominicana.gob.do/Public/Tendering/OpportunityDetail/Index?noticeUID=DO1.NTC.1731126"
    assert DGCPPortalDocumentService.notice_uid_from_url(url) == "DO1.NTC.1731126"
