"""Tests — Monitor de actualizaciones DGCP (Fase 6.4)."""

from __future__ import annotations

import uuid
from datetime import date
from decimal import Decimal

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.dgcp_process_updates import (
    DGCPProcessDocumentSnapshot,
    DGCPProcessSnapshot,
)
from app.services.dgcp_process_update_service import (
    DGCPProcessUpdateService,
    SIMULATE_SCENARIOS,
)


def _opportunity(**kwargs) -> DGCPOpportunity:
    return DGCPOpportunity(
        id=kwargs.get("id", uuid.uuid4()),
        tenant_id=kwargs.get("tenant_id", uuid.uuid4()),
        code=kwargs.get("code", "DGII-CCC-PEEX-2026-0005"),
        institution=kwargs.get("institution", "DGII"),
        title=kwargs.get("title", "Adquisición de Switches"),
        amount=Decimal("500000"),
        currency="DOP",
        modalidad="Comparación de Precios",
        deadline=kwargs.get("deadline", date(2026, 7, 3)),
        status="interested",
        company="justech",
        description="Proceso de equipos de red",
        dgcp_status=kwargs.get("dgcp_status", "Proceso publicado"),
        full_info={},
        raw_payload=kwargs.get("raw_payload", {}),
    )


def _snapshot(**kwargs) -> DGCPProcessSnapshot:
    defaults = {
        "snapshot_at": "2026-06-01T12:00:00+00:00",
        "snapshot_hash": "abc",
        "dgcp_status": "Proceso publicado",
        "deadline": "2026-07-03",
        "monto_estimado": 500000.0,
        "dates": {"fecha_enmienda": None},
        "description_hash": "desc1",
        "payload_hash": "pay1",
        "documents": [],
    }
    defaults.update(kwargs)
    return DGCPProcessSnapshot(**defaults)


def test_process_updates_flag_off(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_process_updates", False)
    assert DGCPProcessUpdateService.enabled() is False


def test_process_updates_flag_on(monkeypatch):
    monkeypatch.setattr("app.config.settings.dgcp_process_updates", True)
    assert DGCPProcessUpdateService.enabled() is True


def test_compare_status_change():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    old = _snapshot(dgcp_status="Proceso publicado")
    new = _snapshot(dgcp_status="Proceso en evaluación")
    updates = svc.compare_snapshots(old, new)
    assert len(updates) == 1
    assert updates[0].change_type == "estado_cambiado"
    assert updates[0].impact == "requiere_revision"


def test_compare_deadline_extension_is_critical():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    old = _snapshot(deadline="2026-07-03")
    new = _snapshot(deadline="2026-07-17")
    updates = svc.compare_snapshots(old, new)
    assert len(updates) == 1
    assert updates[0].change_type == "extension_plazo"
    assert updates[0].impact == "critico"
    assert "update_checklist" in updates[0].suggestions


def test_compare_enmienda_date():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    old = _snapshot(dates={"fecha_enmienda": None})
    new = _snapshot(dates={"fecha_enmienda": "2026-06-15"})
    updates = svc.compare_snapshots(old, new)
    assert len(updates) == 1
    assert updates[0].change_type == "enmienda"
    assert updates[0].impact == "critico"
    assert updates[0].requires_reanalysis is True
    assert "reanalyze_hermes" in updates[0].suggestions


def test_compare_new_document():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    doc = DGCPProcessDocumentSnapshot(
        id="d1",
        title="Circular aclaratoria N° 1",
        doc_role="circular",
        fingerprint="fp1",
    )
    old = _snapshot(documents=[])
    new = _snapshot(documents=[doc])
    updates = svc.compare_snapshots(old, new)
    assert len(updates) == 1
    assert updates[0].change_type == "circular"
    assert updates[0].affected_document == "Circular aclaratoria N° 1"


def test_compare_document_replaced():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    old_doc = DGCPProcessDocumentSnapshot(
        id="d1",
        title="Pliego de condiciones",
        doc_role="pliego",
        fingerprint="fp_old",
    )
    new_doc = DGCPProcessDocumentSnapshot(
        id="d1",
        title="Pliego de condiciones",
        doc_role="pliego",
        fingerprint="fp_new",
    )
    old = _snapshot(documents=[old_doc])
    new = _snapshot(documents=[new_doc])
    updates = svc.compare_snapshots(old, new)
    assert len(updates) == 1
    assert updates[0].change_type == "documento_reemplazado"
    assert updates[0].impact == "critico"
    assert updates[0].requires_reanalysis is True


def test_classify_adjudicacion():
    ctype, impact = DGCPProcessUpdateService._classify_status_change("Proceso adjudicado")
    assert ctype == "adjudicacion"
    assert impact == "critico"


def test_simulate_scenarios_defined():
    expected = {
        "nuevo_documento",
        "fecha_cambiada",
        "enmienda",
        "estado_cambiado",
        "documento_reemplazado",
    }
    assert expected == set(SIMULATE_SCENARIOS.keys())


def test_visible_updates_hides_simulate_in_production(monkeypatch):
    monkeypatch.setattr("app.config.settings.app_debug", False)
    monkeypatch.setattr("app.config.settings.app_env", "production")
    manifest = {
        "process_updates": [
            {"id": "1", "source": "portal", "review_status": "pendiente", "impact": "critico"},
            {"id": "2", "source": "simulate", "review_status": "pendiente", "impact": "informativo"},
        ]
    }
    visible = DGCPProcessUpdateService._visible_updates(manifest)
    assert len(visible) == 1
    assert visible[0]["source"] == "portal"
    meta = DGCPProcessUpdateService._meta_for_visible(manifest, visible)
    assert meta.pending_count == 1


def test_refresh_meta_pending_counts():
    manifest: dict = {}
    history = [
        {"review_status": "pendiente", "impact": "critico", "requires_reanalysis": True},
        {"review_status": "pendiente", "impact": "informativo", "requires_reanalysis": False},
        {"review_status": "revisado", "impact": "critico", "requires_reanalysis": True},
    ]
    DGCPProcessUpdateService._refresh_meta(manifest, history)
    meta = manifest["process_updates_meta"]
    assert meta["pending_count"] == 2
    assert meta["critical_count"] == 1
    assert meta["requires_reanalysis"] is True
    assert meta["notification_hook_ready"] is True


def test_build_snapshot_from_opportunity():
    svc = DGCPProcessUpdateService(None, uuid.uuid4())  # type: ignore[arg-type]
    opp = _opportunity(
        raw_payload={
            "fecha_enmienda": "2026-06-01",
            "fecha_fin_recepcion_ofertas": "2026-07-03",
        }
    )
    snap = svc.build_snapshot(opp, [], [])
    assert snap.dgcp_status == "Proceso publicado"
    assert snap.deadline == "2026-07-03"
    assert snap.dates.get("fecha_enmienda") == "2026-06-01"


def test_requires_reanalysis_sets_expediente_status():
    pkg = DGCPBidPackage(
        tenant_id=uuid.uuid4(),
        opportunity_id=uuid.uuid4(),
        expediente_status="en_preparacion",
        manifest={},
    )
    manifest: dict = {}
    history = [
        {
            "id": "u1",
            "review_status": "pendiente",
            "impact": "critico",
            "requires_reanalysis": True,
            "detected_at": "2026-06-10T12:00:00+00:00",
        }
    ]
    DGCPProcessUpdateService._refresh_meta(manifest, history)
    meta = DGCPProcessUpdateService._load_meta(manifest)
    assert meta.requires_reanalysis is True
    if meta.requires_reanalysis:
        pkg.expediente_status = "requiere_reanalisis"
    assert pkg.expediente_status == "requiere_reanalisis"
