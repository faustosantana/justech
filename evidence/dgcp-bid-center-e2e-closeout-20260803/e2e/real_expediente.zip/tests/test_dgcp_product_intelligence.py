"""Tests — inteligencia de productos DGCP (Fase 6.2)."""

from __future__ import annotations

import uuid
from decimal import Decimal

import pytest

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.services.dgcp_compliance_matrix_service import DGCPComplianceMatrixService
from app.services.dgcp_product_requirements_extractor_service import DGCPProductRequirementsExtractorService
from app.services.product_intelligence_repository_service import ProductIntelligenceRepositoryService


def _opportunity(**kwargs) -> DGCPOpportunity:
    return DGCPOpportunity(
        id=kwargs.get("id", uuid.uuid4()),
        tenant_id=kwargs.get("tenant_id", uuid.uuid4()),
        code=kwargs.get("code", "DGII-CCC-PEEX-2026-0005"),
        institution=kwargs.get("institution", "DGII"),
        title=kwargs.get("title", "Adquisición de Switches y Routers"),
        amount=Decimal("500000"),
        description="",
        full_info={},
        raw_payload={},
    )


def _pkg(opportunity: DGCPOpportunity) -> DGCPBidPackage:
    return DGCPBidPackage(
        tenant_id=opportunity.tenant_id,
        opportunity_id=opportunity.id,
        manifest={
            "hermes_document_analysis": {
                "status": "completed",
                "summary": "Proceso requiere switches 48 puertos PoE+ y routers empresariales.",
                "items_detected": [
                    {
                        "name": "Switch 48 puertos PoE",
                        "quantity": "10",
                        "notes": "Mínimo 48 puertos Gigabit PoE+, 740W, 4 SFP+, Layer 3, garantía 3 años",
                    },
                    {"name": "Router empresarial", "notes": "Throughput mínimo 1Gbps, Dual WAN"},
                ],
            }
        },
        requirements={"technical": [{"key": "ficha_tecnica", "label": "Ficha técnica por producto"}]},
    )


def test_requirements_extractor_finds_switches_and_routers():
    opp = _opportunity()
    pkg = _pkg(opp)
    corpus = (
        "Ficha técnica por producto.\n"
        "Switch administrable 48 puertos PoE+ 740W 4 SFP+ Layer 3 garantía 3 años.\n"
        "Router empresarial dual WAN throughput 1Gbps."
    )
    svc = DGCPProductRequirementsExtractorService()
    items, msg = svc.extract(opp, pkg, process_corpus=corpus)
    assert len(items) >= 2
    names = {i["nombre"].lower() for i in items}
    assert any("switch" in n for n in names)
    assert any("router" in n for n in names)
    switch = next(i for i in items if "switch" in i["nombre"].lower())
    assert len(switch["technical_requirements"]) >= 2
    assert "Se extrajeron" in msg


@pytest.mark.asyncio
async def test_compliance_matrix_never_cumple_without_technical_evidence():
    svc = DGCPComplianceMatrixService()
    requirement = {
        "nombre": "Switch 48 puertos",
        "technical_requirements": [{"text": "48 puertos Gigabit", "confidence": 0.8}],
    }
    commercial_candidate = {
        "name": "Switch Odoo",
        "model": "SW-48",
        "source": "comercial",
        "is_technical_source": False,
    }
    matrix, pct = await svc.build_matrix(requirement, commercial_candidate)
    assert pct == 0.0
    assert all(r["cumple"] == "requiere_revision" for r in matrix)
    assert "comercial" in (matrix[0].get("observacion") or "").lower()


@pytest.mark.asyncio
async def test_compliance_matrix_conservative_for_offline_candidate():
    svc = DGCPComplianceMatrixService()
    requirement = {
        "nombre": "Switch 48 puertos",
        "technical_requirements": [
            {"text": "48 puertos Gigabit", "confidence": 0.8},
            {"text": "PoE+ 740W", "confidence": 0.8},
        ],
    }
    candidate = {
        "name": "Cisco CBS350-48P-4G",
        "model": "CBS350-48P-4G",
        "manufacturer": "Cisco",
        "source": "internet",
        "is_technical_source": False,
        "confidence": 0.35,
    }
    matrix, pct = await svc.build_matrix(requirement, candidate)
    assert pct == 0.0
    assert len(matrix) == 2
    assert all(r["cumple"] == "requiere_revision" for r in matrix)


def test_product_intelligence_repository_classifies_vendor():
    assert ProductIntelligenceRepositoryService.classify_vendor("Cisco CBS350 datasheet") == "CISCO"
    assert ProductIntelligenceRepositoryService.classify_vendor("FortiGate 200F") == "FORTINET"
    assert ProductIntelligenceRepositoryService.classify_vendor("Generic device") == "OTROS"


def test_product_intelligence_service_flag_off_by_default(monkeypatch):
    from app.services.dgcp_product_intelligence_service import DGCPProductIntelligenceService

    monkeypatch.setattr("app.config.settings.dgcp_product_intelligence", False)
    assert DGCPProductIntelligenceService.enabled() is False
