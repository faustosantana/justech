"""Tests — fichas técnicas DGCP (Fase 6.1)."""

from __future__ import annotations

import uuid
from decimal import Decimal

import pytest

from app.models.dgcp_bid_package import DGCPBidPackage
from app.models.dgcp_opportunity import DGCPOpportunity
from app.schemas.dgcp_technical_sheet import DGCPTechSheetSelectProductRequest
from app.services.dgcp_technical_product_detection_service import DGCPTechnicalProductDetectionService
from app.services.dgcp_technical_sheet_generator_service import DGCPTechnicalSheetGeneratorService


def _opportunity(**kwargs) -> DGCPOpportunity:
    return DGCPOpportunity(
        id=kwargs.get("id", uuid.uuid4()),
        tenant_id=kwargs.get("tenant_id", uuid.uuid4()),
        code=kwargs.get("code", "DGII-CCC-PEEX-2026-0005"),
        institution=kwargs.get("institution", "DGII"),
        title=kwargs.get("title", "Adquisición de Switches y Routers"),
        amount=Decimal("500000"),
        description="",
        full_info={},
        raw_payload={},
    )


def _pkg(opportunity: DGCPOpportunity) -> DGCPBidPackage:
    return DGCPBidPackage(
        tenant_id=opportunity.tenant_id,
        opportunity_id=opportunity.id,
        manifest={
            "hermes_document_analysis": {
                "status": "completed",
                "summary": "Proceso requiere fichas técnicas por producto.",
                "items_detected": [
                    {"name": "Switch 48 puertos PoE", "quantity": "10", "notes": "Mínimo 48 puertos Gigabit PoE+"},
                    {"name": "Router empresarial", "notes": "Throughput mínimo 1Gbps"},
                ],
                "required_documents": ["Ficha técnica por producto", "Datasheet fabricante"],
            }
        },
        requirements={
            "technical": [
                {"key": "ficha_tecnica", "label": "Ficha técnica por producto ofertado"},
            ],
        },
        checklist=[{"requirement": "Ficha técnica", "status": "pendiente", "mandatory": True}],
    )


def test_detection_finds_products_from_hermes_and_corpus():
    opp = _opportunity()
    pkg = _pkg(opp)
    corpus = (
        "Se requiere ficha técnica por cada producto.\n"
        "Switch 48 puertos PoE — mínimo 48 puertos Gigabit.\n"
        "Router empresarial dual WAN.\n"
        "UPS 1500VA para rack.\n"
        "Access Point WiFi 6 — 802.11ax."
    )
    svc = DGCPTechnicalProductDetectionService()
    items, requires, message = svc.detect(opp, pkg, process_corpus=corpus)
    assert requires is True
    assert len(items) >= 3
    names = {i["required_product_name"].lower() for i in items}
    assert any("switch" in n for n in names)
    assert "Se detectaron" in message


def test_detection_empty_when_no_tech_requirements():
    opp = _opportunity(title="Servicio de limpieza general")
    pkg = DGCPBidPackage(
        tenant_id=opp.tenant_id,
        opportunity_id=opp.id,
        manifest={},
        requirements={"administrative": [{"key": "rpe", "label": "RPE vigente"}]},
    )
    svc = DGCPTechnicalProductDetectionService()
    items, requires, message = svc.detect(opp, pkg, process_corpus="Contrato de servicios generales.")
    assert items == []
    assert requires is False
    assert message == "No se detectaron fichas técnicas requeridas."


@pytest.mark.asyncio
async def test_generator_fallback_draft_without_hermes():
    opp = _opportunity()
    sheet = {
        "required_product_name": "Switch 48 puertos PoE",
        "required_specs": ["48 puertos Gigabit PoE+"],
        "source_fragment": "Switch 48 puertos PoE",
        "detection_source": "heuristic",
        "offered_product": {"brand": "Cisco", "model": "CBS350-48P-4G", "description": "Switch managed"},
    }
    gen = DGCPTechnicalSheetGeneratorService(client=type("C", (), {"is_available": lambda self: False})())  # type: ignore[arg-type]
    draft, confidence, missing, notes = await gen.generate_draft(opp, sheet)
    assert draft["header"]["process_code"] == opp.code
    assert draft["product"]["model"] == "CBS350-48P-4G"
    assert len(draft["compliance_matrix"]) >= 1
    assert confidence > 0
    assert "garantia" in missing or "datasheet" in missing
    assert notes


def test_export_markdown_contains_compliance_table():
    sheet = {"required_product_name": "Switch 48 puertos PoE"}
    draft = {
        "header": {"required_product": "Switch 48 puertos PoE", "offered_product": "CBS350-48P-4G"},
        "product": {"brand": "Cisco", "model": "CBS350-48P-4G"},
        "compliance_matrix": [
            {
                "pliego_requirement": "48 puertos PoE+",
                "offered_product": "CBS350-48P-4G",
                "complies": "requiere_revision",
                "observation": "Validar datasheet",
            }
        ],
        "warranty_support": {},
        "observations": [],
        "review_notes": ["Revisar garantía local"],
    }
    md = DGCPTechnicalSheetGeneratorService.export_markdown(sheet, draft)
    assert "Tabla de cumplimiento" in md or "Cumplimiento" in md
    assert "48 puertos PoE+" in md
    assert "requiere_revision" in md


def test_select_product_request_schema():
    req = DGCPTechSheetSelectProductRequest(
        brand="Cisco",
        model="CBS350-48P-4G",
        source="manual",
    )
    assert req.model == "CBS350-48P-4G"


@pytest.mark.asyncio
async def test_pdf_export_builds_bytes():
    from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService
    from app.services.corporate_branding_service import CorporateBrandingService, CorporateBrandingContext, BrandingAssetStatus

    class FakeBranding:
        async def resolve(self, company_key: str) -> CorporateBrandingContext:
            return CorporateBrandingContext(
                company_key=company_key,
                company_name="Justech",
                rnc="123456789",
                logo=BrandingAssetStatus("logo", "falta"),
                signature=BrandingAssetStatus("signature", "falta"),
                stamp=BrandingAssetStatus("stamp", "falta"),
            )

    opp = _opportunity()
    sheet = {"required_product_name": "Switch 48 puertos PoE", "product_images": []}
    draft = {
        "header": {"required_product": "Switch", "offered_product": "CBS350"},
        "product": {"brand": "Cisco", "model": "CBS350-48P-4G"},
        "compliance_matrix": [{
            "pliego_requirement": "48 puertos PoE+",
            "offered_product": "CBS350-48P-4G",
            "complies": "requiere_revision",
            "evidence": "—",
            "observation": "Validar",
        }],
        "warranty_support": {},
        "observations": [],
        "review_notes": ["Revisión humana"],
    }
    svc = DGCPTechnicalSheetPdfService(FakeBranding())  # type: ignore[arg-type]
    pdf = await svc.build_pdf(sheet=sheet, draft=draft, company_key="justech", opportunity=opp)
    assert pdf[:4] == b"%PDF"
    assert len(pdf) > 500


@pytest.mark.asyncio
async def test_pdf_embeds_product_image_from_local_path(tmp_path):
    from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService
    from app.services.corporate_branding_service import CorporateBrandingContext, BrandingAssetStatus

    class FakeBranding:
        async def resolve(self, company_key: str) -> CorporateBrandingContext:
            return CorporateBrandingContext(
                company_key=company_key,
                company_name="Justech",
                logo=BrandingAssetStatus("logo", "falta"),
                signature=BrandingAssetStatus("signature", "falta"),
                stamp=BrandingAssetStatus("stamp", "falta"),
            )

    png = tmp_path / "producto.png"
    import struct
    import zlib

    w, h = 8, 8
    def chunk(tag, data):
        crc = zlib.crc32(tag + data) & 0xFFFFFFFF
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)

    raw = b"".join(b"\x00" + bytes([200, 80, 40]) * w for _ in range(h))
    png.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 9))
        + chunk(b"IEND", b"")
    )
    opp = _opportunity()
    sheet = {
        "required_product_name": "Switches",
        "product_images": [{
            "id": "img-1",
            "label": "Switch QA",
            "source": "manual",
            "local_path": str(png),
            "filename": png.name,
            "mime_type": "image/png",
            "sort_order": 0,
        }],
    }
    draft = {
        "header": {"required_product": "Switches", "offered_product": "CBS350-48P-4G"},
        "product": {"brand": "Cisco", "model": "CBS350-48P-4G"},
        "compliance_matrix": [],
        "warranty_support": {},
        "observations": [],
        "review_notes": [],
    }
    svc = DGCPTechnicalSheetPdfService(FakeBranding())  # type: ignore[arg-type]
    pdf = await svc.build_pdf(sheet=sheet, draft=draft, company_key="justech", opportunity=opp)
    assert pdf[:4] == b"%PDF"
    assert b"Imagen pendiente" not in pdf


def test_pdf_shows_pending_when_no_images():
    from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService

    svc = DGCPTechnicalSheetPdfService(type("B", (), {})())  # type: ignore[arg-type]
    blocks = svc._product_images_gallery({"product_images": []})
    text = " ".join(getattr(b, "text", str(b)) for b in blocks)
    assert "Imagen pendiente" in text


@pytest.mark.asyncio
async def test_pdf_compliance_table_wraps_long_text():
    from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService
    from app.services.corporate_branding_service import CorporateBrandingContext, BrandingAssetStatus

    class FakeBranding:
        async def resolve(self, company_key: str) -> CorporateBrandingContext:
            return CorporateBrandingContext(
                company_key=company_key,
                company_name="Justech",
                rnc="123456789",
                logo=BrandingAssetStatus("logo", "falta", filename="logo.png"),
                signature=BrandingAssetStatus("signature", "falta", filename="firma_fausto.png"),
                stamp=BrandingAssetStatus("stamp", "falta", filename="sello_justech.png"),
            )

    long_req = (
        "documentación estricta y una garantía de seriedad del 5%. === Pliego Dgii-0005 (pliego) === "
        "Adquisición de Switches y Routers por Obsolescencia y Servicios profesionales con requisitos extendidos."
    )
    opp = _opportunity()
    sheet = {"required_product_name": "Switches", "product_images": []}
    draft = {
        "header": {"required_product": "Switches", "offered_product": "CBS350-48P-4G"},
        "product": {"brand": "Cisco", "model": "CBS350-48P-4G", "manufacturer": "Cisco"},
        "specifications": [{
            "requirement": "48 puertos Gigabit PoE+",
            "offered": "CBS350-48P-4G",
            "complies": "requiere_revision",
            "evidence": "Datasheet",
        }],
        "compliance_matrix": [{
            "pliego_requirement": long_req,
            "offered_product": "CBS350-48P-4G",
            "complies": "requiere_revision",
            "evidence": "Pliego adjunto",
            "observation": "Validar contra datasheet del fabricante y certificaciones FCC/CE",
        }],
        "warranty_support": {},
        "observations": [],
        "review_notes": [],
    }
    svc = DGCPTechnicalSheetPdfService(FakeBranding())  # type: ignore[arg-type]
    pdf = await svc.build_pdf(sheet=sheet, draft=draft, company_key="justech", opportunity=opp)
    assert pdf[:4] == b"%PDF"
    assert len(pdf) > 2000
    assert b"firma_fausto" not in pdf  # binary pdf shouldn't contain raw filename as plain success


@pytest.mark.asyncio
async def test_pdf_multiple_images_gallery(tmp_path):
    from app.services.dgcp_technical_sheet_pdf_service import DGCPTechnicalSheetPdfService
    from app.services.corporate_branding_service import CorporateBrandingContext, BrandingAssetStatus
    import struct
    import zlib

    class FakeBranding:
        async def resolve(self, company_key: str) -> CorporateBrandingContext:
            return CorporateBrandingContext(
                company_key=company_key,
                company_name="Justech",
                logo=BrandingAssetStatus("logo", "falta"),
                signature=BrandingAssetStatus("signature", "falta"),
                stamp=BrandingAssetStatus("stamp", "falta"),
            )

    def make_png(name: str, color: tuple[int, int, int]) -> Path:
        w, h = 12, 12
        def chunk(tag, data):
            crc = zlib.crc32(tag + data) & 0xFFFFFFFF
            return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", crc)
        raw = b"".join(b"\x00" + bytes(color) * w for _ in range(h))
        p = tmp_path / name
        p.write_bytes(
            b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9))
            + chunk(b"IEND", b"")
        )
        return p

    images = []
    for i, color in enumerate([(200, 80, 40), (40, 120, 200), (80, 180, 60)]):
        png = make_png(f"img{i}.png", color)
        images.append({
            "id": f"img-{i}",
            "label": f"Vista {i+1}",
            "local_path": str(png),
            "filename": png.name,
            "sort_order": i,
        })
    opp = _opportunity()
    sheet = {"required_product_name": "Switches", "product_images": images}
    draft = {
        "header": {"required_product": "Switches", "offered_product": "CBS350-48P-4G"},
        "product": {"brand": "Cisco", "model": "CBS350-48P-4G"},
        "compliance_matrix": [],
        "warranty_support": {},
        "observations": [],
        "review_notes": [],
    }
    svc = DGCPTechnicalSheetPdfService(FakeBranding())  # type: ignore[arg-type]
    pdf = await svc.build_pdf(sheet=sheet, draft=draft, company_key="justech", opportunity=opp)
    assert pdf.count(b"/Subtype /Image") >= 3


@pytest.mark.asyncio
async def test_enrich_branding_null_offered_product():
    from unittest.mock import AsyncMock, MagicMock, patch

    from app.services.corporate_branding_service import CorporateBrandingService
    from app.services.dgcp_technical_sheet_service import DGCPTechnicalSheetService

    raw = {
        "id": str(uuid.uuid4()),
        "required_product_name": "Switch 48 puertos",
        "status": "detectada",
        "offered_product": None,
        "product_images": [],
    }
    svc = DGCPTechnicalSheetService(MagicMock(), uuid.uuid4(), uuid.uuid4())
    branding_ctx = MagicMock()
    branding_ctx.to_dict.return_value = {
        "company_key": "justech",
        "company_name": "Justech",
        "logo": {"kind": "logo", "status": "ok"},
        "signature": {"kind": "signature", "status": "ok"},
        "stamp": {"kind": "stamp", "status": "ok"},
    }
    with patch.object(CorporateBrandingService, "resolve", new_callable=AsyncMock) as resolve:
        resolve.return_value = branding_ctx
        item = await svc._to_item_enriched(raw, company_key="justech")
    assert item.required_product_name == "Switch 48 puertos"
    assert item.offered_product is None
    assert item.product_images == []
