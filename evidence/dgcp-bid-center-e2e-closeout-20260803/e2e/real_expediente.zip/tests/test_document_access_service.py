"""Tests — acceso documental unificado."""

from __future__ import annotations

import uuid

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from app.models.knowledge import KnowledgeAsset
from app.services.document_access_service import resolve_canonical_knowledge_asset


@pytest.mark.asyncio
async def test_canonical_knowledge_asset_follows_dedup():
    tenant_id = uuid.uuid4()
    canonical_id = uuid.uuid4()
    duplicate_id = uuid.uuid4()
    canonical = KnowledgeAsset(
        id=canonical_id,
        tenant_id=tenant_id,
        filename="REGISTRO MERCANTIL.pdf",
        is_active=True,
    )
    duplicate = KnowledgeAsset(
        id=duplicate_id,
        tenant_id=tenant_id,
        filename="REGISTRO MERCANTIL.pdf",
        is_active=False,
        metadata_={"dedup_merged_into": str(canonical_id)},
    )

    class FakeDb:
        async def get(self, _model, key):
            if key == duplicate_id:
                return duplicate
            if key == canonical_id:
                return canonical
            return None

    asset, resolved = await resolve_canonical_knowledge_asset(
        FakeDb(), duplicate_id, tenant_id=tenant_id
    )
    assert asset.id == canonical_id
    assert resolved == canonical_id
