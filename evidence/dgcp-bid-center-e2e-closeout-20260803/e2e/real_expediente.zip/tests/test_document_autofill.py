"""Tests — autollenado documental con plantillas reales."""

from __future__ import annotations

import zipfile
from io import BytesIO
from pathlib import Path
from uuid import uuid4

import pytest

from app.services.document_autofill.docx_template_writer import MISSING_MARKER, fill_docx_bytes
from app.services.document_autofill.template_analysis_service import TemplateAnalysisService
from app.services.document_autofill.template_factory import ensure_all_templates


@pytest.fixture
def templates_root(tmp_path: Path) -> Path:
    ensure_all_templates(tmp_path)
    return tmp_path


def test_ensure_templates_creates_docx_files(templates_root: Path) -> None:
    paths = list(templates_root.rglob("*.docx"))
    assert len(paths) >= 5
    for path in paths:
        assert path.stat().st_size > 500


def test_analyze_detects_placeholders(templates_root: Path) -> None:
    svc = TemplateAnalysisService(templates_root=templates_root)
    analysis = svc.analyze("CARTA.PRESENTACION")
    keys = {f.key for f in analysis.fields}
    assert "razon_social" in keys
    assert "proceso_dgcp" in keys


def test_fill_docx_replaces_placeholders(templates_root: Path) -> None:
    svc = TemplateAnalysisService(templates_root=templates_root)
    template_bytes, _ = svc.read_template_bytes("SNCC.F042")
    filled = fill_docx_bytes(
        template_bytes,
        {
            "razon_social": "Justech S.R.L.",
            "rnc": "123456789",
            "direccion": "Santo Domingo",
            "representante_legal": "Fausto Santana",
            "telefono": "809-000-0000",
            "correo": "admin@justech.do",
            "proceso_dgcp": "TEST-001",
            "entidad_contratante": "MINERD",
            "fecha": "10/06/2026",
        },
    )
    with zipfile.ZipFile(BytesIO(filled)) as zf:
        xml = zf.read("word/document.xml").decode("utf-8")
    assert "Justech S.R.L." in xml
    assert "{{ razon_social }}" not in xml


def test_fill_docx_marks_missing_fields(templates_root: Path) -> None:
    svc = TemplateAnalysisService(templates_root=templates_root)
    template_bytes, _ = svc.read_template_bytes("SNCC.F042")
    filled = fill_docx_bytes(template_bytes, {"razon_social": "Justech S.R.L."})
    with zipfile.ZipFile(BytesIO(filled)) as zf:
        xml = zf.read("word/document.xml").decode("utf-8")
    assert MISSING_MARKER in xml


def test_original_template_unchanged(templates_root: Path) -> None:
    svc = TemplateAnalysisService(templates_root=templates_root)
    path = svc.resolve_template_path("SNCC.F042")
    assert path is not None
    before = path.read_bytes()
    fill_docx_bytes(before, {"razon_social": "Temporal QA"})
    after = path.read_bytes()
    assert before == after
