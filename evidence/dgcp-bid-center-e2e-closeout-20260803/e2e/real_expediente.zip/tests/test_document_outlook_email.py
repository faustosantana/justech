"""Tests — correo documental Outlook."""

from app.services.document_outlook_email_service import DocumentOutlookEmailService


def test_default_recipients():
    assert DocumentOutlookEmailService.notify_recipient() == "recepcion@justech.do"
    assert DocumentOutlookEmailService.escalation_recipient() == "fausto@justech.do"
