"""Tests — validación estricta requirement ↔ documento."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.services.document_requirement_validator import (
    validate_asset_for_requirement,
    validate_sncc_compliance,
)


def _asset(**kwargs):
    defaults = dict(
        is_active=True,
        relative_path="jaios/justech/01_documentos_legales/cert.pdf",
        folder_category="01_documentos_legales",
        vigency_status="vigente",
    )
    defaults.update(kwargs)
    return SimpleNamespace(**defaults)


def test_registro_mercantil_rejects_acta_rnc():
    vr = validate_asset_for_requirement(
        "registro_mercantil",
        filename="Acta RNC JUSTECH (1) (1).pdf",
        document_type="rnc",
        asset=_asset(),
    )
    assert not vr.ok
    assert vr.reason in ("document_type_incorrecto", "categoria_prohibida", "no_es_registro_mercantil")


def test_registro_mercantil_accepts_valid_file():
    vr = validate_asset_for_requirement(
        "registro_mercantil",
        filename="REGISTRO MERCANTIL.pdf",
        document_type="registro_mercantil",
        asset=_asset(),
    )
    assert vr.ok


def test_oferta_tecnica_rejects_dgii():
    vr = validate_asset_for_requirement(
        "oferta_tecnica",
        filename="DGII Certificacion de obligaciones al dia - JUSTECH.pdf",
        document_type="dgii",
        asset=_asset(),
    )
    assert not vr.ok


def test_certificacion_tss_requires_tss_keywords():
    vr = validate_asset_for_requirement(
        "certificacion_tss",
        filename="ACTA DE LA ASAMBLEA GENERAL ORDINARIA.pdf",
        document_type="acta_asamblea",
        asset=_asset(),
    )
    assert not vr.ok

    vr_ok = validate_asset_for_requirement(
        "certificacion_tss",
        filename="Certificación TSS - 14 05 26 - JUSTECH.pdf",
        document_type="tss",
        asset=_asset(),
    )
    assert vr_ok.ok


def test_rpe_accepts_proveedor_estado_with_rpe_keyword():
    vr = validate_asset_for_requirement(
        "rpe",
        filename="RPE Justech.pdf",
        document_type="proveedor_estado",
        asset=_asset(),
    )
    assert vr.ok


def test_sncc_not_complete_without_completado():
    vr = validate_sncc_compliance(
        filename="SNCC_F042_Informacion_Oferente.docx",
        status="encontrado_vigente",
        completable=False,
    )
    assert not vr.ok


def test_inaccessible_asset_rejected():
    vr = validate_asset_for_requirement(
        "dgii",
        filename="DGII.pdf",
        document_type="dgii",
        asset=_asset(relative_path="", is_active=False),
    )
    assert not vr.ok
    assert vr.reason == "asset_inaccesible"
