"""Tests — plantillas documentales y centro Hermes."""

from __future__ import annotations

from app.services.commercial_search.intent import detect_search_intent
from app.services.document_template_service import DEFAULT_TEMPLATES, FIELD_LABELS


class TestDocumentTemplates:
    def test_default_templates_cover_categories(self):
        categories = {t["category"] for t in DEFAULT_TEMPLATES}
        assert "dgcp" in categories
        assert "legal" in categories
        assert "commercial" in categories
        assert "internal" in categories

    def test_field_labels_exist(self):
        assert FIELD_LABELS["razon_social"] == "Nombre empresa"
        assert FIELD_LABELS["proceso_dgcp"] == "Código proceso"


class TestHermesIntelligence:
    def test_laptop_still_excludes_accessories(self):
        intent = detect_search_intent("laptop dell")
        assert intent.target_category == "laptops"
