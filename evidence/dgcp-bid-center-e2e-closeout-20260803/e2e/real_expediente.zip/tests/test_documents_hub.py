"""Tests — Hub Documentos y Repositorios."""

from app.services.document_pending_service import DocumentPendingService, LEGAL_LABELS
from app.services.documents_hub_service import DocumentsHubService
from app.services.licitador_dashboard_service import COMPANY_KEYS, EXPECTED_LEGAL


def test_company_keys_defined():
    assert len(COMPANY_KEYS) >= 4
    keys = {k for k, _ in COMPANY_KEYS}
    assert keys == {"justech", "just_office", "mf_plug_safe", "omni_solutions"}


def test_expected_legal_docs():
    assert "dgii" in EXPECTED_LEGAL
    assert "tss" in EXPECTED_LEGAL


def test_legal_labels_cover_expected():
    for doc in ("dgii", "tss", "registro_mercantil"):
        assert doc in LEGAL_LABELS


def test_pending_service_constants():
    assert DocumentPendingService.DEFAULT_RECIPIENT == "recepcion@justech.do"
    assert DocumentPendingService.ESCALATION_RECIPIENT == "fausto@justech.do"


def test_hub_service_recipient():
    assert DocumentsHubService.DEFAULT_RECIPIENT == "recepcion@justech.do"
