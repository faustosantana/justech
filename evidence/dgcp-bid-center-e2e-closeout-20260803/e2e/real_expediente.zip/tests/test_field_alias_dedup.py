"""Tests — deduplicación canónica de campos de autollenado."""

from __future__ import annotations

from dataclasses import dataclass

from app.services.document_autofill.field_alias_registry import (
    canonical_field_key,
    deduplicate_field_statuses,
    partition_fields_by_canonical,
)


@dataclass
class _Field:
    key: str
    label: str
    value: str | None = None
    source: str | None = None
    status: str = "pendiente"
    confidence: float = 0.0


def test_canonical_field_key_merges_expediente_variants():
    keys = [
        "no_del_expediente_de_compras",
        "no._del_expediente_de_compras_",
        "No. Del Expediente De Compras ",
    ]
    canon = {canonical_field_key(k) for k in keys}
    assert canon == {"proceso_dgcp"}


def test_canonical_field_key_merges_accent_variants():
    assert canonical_field_key("departamento_ó_unidad_funcional") == canonical_field_key(
        "departamento_o_unidad_funcional"
    )
    assert canonical_field_key("fecha_de_emisión_del_documento") == canonical_field_key(
        "fecha_de_emision_del_documento"
    )
    assert canonical_field_key("nombre_de_la_institución") == canonical_field_key(
        "nombre_de_la_institucion"
    )
    assert canonical_field_key("3212") == "rnc"
    assert canonical_field_key("3213") == "razon_social"


def test_deduplicate_prefers_completo_over_pendiente():
    fields = [
        _Field("departamento_o_unidad_funcional", "Depto", "DGII", status="completo", confidence=0.9),
        _Field("departamento_ó_unidad_funcional", "Depto acento", None, status="no_critico"),
        _Field("3212", "3212", "131828061", status="completo", confidence=0.98),
        _Field("fecha_de_emision_del_documento", "Fecha", "10/06/2026", status="completo"),
        _Field("fecha_de_emisión_del_documento", "Fecha acento", None, status="no_critico"),
    ]
    deduped = deduplicate_field_statuses(fields)
    keys = {f.key for f in deduped}
    assert "departamento_ó_unidad_funcional" not in keys or len(deduped) <= 4
    assert len(deduped) == 3
    by_key = {f.key: f for f in deduped}
    assert by_key["departamento_o_unidad_funcional"].status == "completo"
    assert by_key["3212"].value == "131828061"


def test_partition_fields_by_canonical():
    fields = [
        _Field("rnc", "RNC", "131828061", status="completo"),
        _Field("3212", "3212", "131828061", status="completo"),
        _Field("rpe", "RPE", None, status="no_critico"),
        _Field("cargo", "Cargo", None, status="no_critico"),
    ]
    completed, pending = partition_fields_by_canonical(fields)
    assert len(completed) == 1  # rnc and 3212 merge
    assert len(pending) == 2
    assert {f.key for f in pending} == {"rpe", "cargo"}
