"""Tests — mapeo aliases Word → campos canónicos."""

from app.services.document_autofill.field_alias_registry import (
    classify_pending,
    normalize_alias,
    suggest_canonical,
)


def test_normalize_alias():
    assert normalize_alias("No. Del Expediente de Compras ") == "no_del_expediente_de_compras"
    assert normalize_alias("Razón Social") == "razon_social"


def test_suggest_rnc():
    s = suggest_canonical("RNC")
    assert s.canonical == "rnc"
    assert s.status == "mapeado"
    assert s.confidence >= 0.9


def test_suggest_numeric_static():
    s = suggest_canonical("3212")
    assert s.canonical == "rnc"
    assert s.source == "static"


def test_suggest_expediente():
    s = suggest_canonical("No. Del Expediente De Compras")
    assert s.canonical == "proceso_dgcp"


def test_suggest_institucion():
    s = suggest_canonical("Nombre de la Institución")
    assert s.canonical == "entidad_contratante"


def test_suggest_indicar_empresa():
    s = suggest_canonical("Indicar Nombre de la empresa")
    assert s.canonical == "razon_social"
    assert s.status == "mapeado"


def test_classify_logo_non_critical():
    assert classify_pending(
        alias="Logo de la dependencia gubernamental",
        alias_normalized="logo_de_la_dependencia_gubernamental",
        canonical="logo_dependencia",
        status="pendiente",
        has_value=False,
    ) == "no_critico"


def test_classify_critical_rnc():
    assert classify_pending(
        alias="3212",
        alias_normalized="3212",
        canonical="rnc",
        status="pendiente",
        has_value=False,
    ) == "critico"


def test_classify_ignorable_format():
    assert classify_pending(
        alias="Código Oficial del Formato",
        alias_normalized="codigo_oficial_del_formato",
        canonical=None,
        status="pendiente",
        has_value=False,
    ) == "ignorado"
