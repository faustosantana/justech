"""Tests — cliente Hermes JAIOS."""

from unittest.mock import AsyncMock, patch

import pytest

from app.services.hermes_client import HermesClient
from app.schemas.hermes import HermesAnalysisResult


@pytest.mark.asyncio
async def test_hermes_client_disabled_returns_none():
    client = HermesClient(base_url="http://hermes:8000", api_token="x", enabled=False)
    assert client.is_available() is False
    result = await client.analyze_document(title="t", content="c")
    assert result is None


@pytest.mark.asyncio
async def test_hermes_client_parses_response():
    client = HermesClient(base_url="http://hermes:8000", api_token="tok", enabled=True)
    payload = HermesAnalysisResult(summary="ok", detected_type="cotizacion", confidence=0.8)

    class FakeResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return payload.model_dump()

    class FakeHttp:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def post(self, *args, **kwargs):
            return FakeResponse()

    with patch("app.services.hermes_client.httpx.AsyncClient", FakeHttp):
        result = await client.analyze_email_rfq(subject="test", body="body")
    assert result is not None
    assert result.summary == "ok"
