"""Tests — HermesQuestionService."""

from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch
from uuid import uuid4

import pytest

from app.schemas.assistant import AssistantQueryRequest
from app.schemas.hermes import HermesAnalysisResult
from app.schemas.odoo import OdooLastPriceResponse
from app.services.hermes_question_service import HermesQuestionService


@pytest.mark.asyncio
async def test_should_handle_dgcp_average_price():
    payload = AssistantQueryRequest(
        question="¿Cuánto es el precio promedio de venta de este equipo?",
        record_type="dgcp",
        current_record_id=str(uuid4()),
    )
    with patch("app.services.hermes_question_service.settings") as mock_settings:
        mock_settings.hermes_enabled = True
        assert HermesQuestionService.should_handle(payload.question, payload) is True


@pytest.mark.asyncio
async def test_should_not_handle_without_context():
    payload = AssistantQueryRequest(
        question="¿Cuánto es el precio promedio de venta de este equipo?",
    )
    with patch("app.services.hermes_question_service.settings") as mock_settings:
        mock_settings.hermes_enabled = True
        assert HermesQuestionService.should_handle(payload.question, payload) is False


@pytest.mark.asyncio
async def test_try_answer_uses_hermes_with_odoo_facts():
    tenant_id = uuid4()
    opp_id = uuid4()
    payload = AssistantQueryRequest(
        question="¿Cuánto es el precio promedio de venta de este equipo?",
        record_type="dgcp",
        current_record_id=str(opp_id),
    )

    mock_opp = MagicMock()
    mock_opp.title = "Adquisición laptops HP ProBook"
    mock_opp.description = "Equipos portátiles"
    mock_opp.objeto_proceso = None
    mock_opp.code = "DGCP-001"
    mock_opp.institution = "Ministerio X"
    mock_opp.amount = Decimal("500000")
    mock_opp.currency = "DOP"
    mock_opp.jaios_intelligence = {"premium_score": 72, "executive_summary": "Buena oportunidad."}

    mock_db = AsyncMock()
    mock_result = MagicMock()
    mock_result.scalar_one_or_none.return_value = mock_opp
    mock_db.execute = AsyncMock(return_value=mock_result)

    hermes_mock = AsyncMock()
    hermes_mock.interpret_question = AsyncMock(
        return_value=HermesAnalysisResult(
            summary="El precio promedio de venta es 45,200 DOP en 12 ventas.",
            confidence=0.85,
        )
    )

    svc = HermesQuestionService(mock_db, tenant_id, hermes=hermes_mock)
    svc.odoo.health = AsyncMock(return_value=MagicMock(connected=True))
    svc.odoo.last_price = AsyncMock(
        return_value=OdooLastPriceResponse(
            product_name="Laptop HP ProBook",
            average_price=Decimal("45200"),
            sales_count=12,
            min_price=Decimal("42000"),
            max_price=Decimal("48000"),
        )
    )

    with patch("app.services.hermes_question_service.settings") as mock_settings:
        mock_settings.hermes_enabled = True
        with patch.object(svc, "_gather_facts", new=AsyncMock(return_value={
            "odoo_sales": {
                "product_name": "Laptop HP ProBook",
                "average_price": 45200.0,
                "sales_count": 12,
            }
        })):
            with patch.object(svc, "_resolve_context", new=AsyncMock(return_value={
                "title": mock_opp.title,
                "code": mock_opp.code,
                "institution": mock_opp.institution,
                "product_query": "laptops hp probook",
            })):
                result = await svc.try_answer(payload.question, payload, ["jaios"])

    assert result is not None
    assert "45,200" in result.answer or "45200" in result.answer
    assert "hermes" in result.sources
    hermes_mock.interpret_question.assert_awaited_once()


@pytest.mark.asyncio
async def test_hermes_client_interpret_question():
    from app.services.hermes_client import HermesClient

    client = HermesClient(base_url="http://hermes:8000", api_token="tok", enabled=True)
    payload = HermesAnalysisResult(summary="Respuesta", confidence=0.9)

    class FakeResponse:
        def raise_for_status(self):
            return None

        def json(self):
            return payload.model_dump()

    class FakeHttp:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return None

        async def post(self, url, **kwargs):
            assert url.endswith("/interpret/question")
            assert kwargs["json"]["question"] == "test?"
            return FakeResponse()

    with patch("app.services.hermes_client.httpx.AsyncClient", FakeHttp):
        result = await client.interpret_question(question="test?", context={"a": 1}, facts={"b": 2})
    assert result is not None
    assert result.summary == "Respuesta"
