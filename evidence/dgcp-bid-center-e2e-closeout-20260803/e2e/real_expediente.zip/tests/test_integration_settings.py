"""Tests centro de configuración / integraciones."""

from app.services.credential_vault import encrypt_secret, mask_secret
from app.services.integration_settings_service import PROVIDER_CATALOG, IntegrationSettingsService


def test_mask_secret():
    assert mask_secret("abcdefghijklmnop") == "••••••••••••••••mnop"
    assert mask_secret("") == ""


def test_provider_catalog_has_core_integrations():
    assert "microsoft365" in PROVIDER_CATALOG
    assert "odoo" in PROVIDER_CATALOG
    assert "dgcp" in PROVIDER_CATALOG
    assert "openai" in PROVIDER_CATALOG
    assert "hermes" in PROVIDER_CATALOG


def test_credentials_ok_logic():
    svc = IntegrationSettingsService.__new__(IntegrationSettingsService)
    cfg = {"tenant_id": "x", "client_id": "y", "redirect_uri": "http://localhost/cb"}
    secrets = {"client_secret": encrypt_secret("secret-value-here")}
    assert svc._credentials_ok("microsoft365", cfg, secrets) is True
