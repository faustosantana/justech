"""Tests — acceso local vs OneDrive para knowledge assets."""

from __future__ import annotations

import uuid
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app
from app.models.knowledge import KnowledgeAsset
from app.services.knowledge_asset_access import (
    can_read_knowledge_asset_local,
    is_remote_knowledge_path,
    resolve_knowledge_asset_access,
)


def test_is_remote_knowledge_path():
    assert is_remote_knowledge_path("onedrive/Justech-AI/file.pdf")
    assert not is_remote_knowledge_path("jaios/justech/file.pdf")


def test_can_read_knowledge_asset_local_rejects_onedrive_path():
    assert not can_read_knowledge_asset_local("onedrive/Justech-AI/doc.pdf")


@pytest.mark.asyncio
async def test_resolve_knowledge_asset_access_external():
    tenant_id = uuid.uuid4()
    asset = KnowledgeAsset(
        id=uuid.uuid4(),
        tenant_id=tenant_id,
        filename="DGII.pdf",
        relative_path="onedrive/Justech-AI/01_DOCUMENTOS_LEGALES/JUSTECH/DGII.pdf",
        metadata_={"web_url": "https://justechdo-my.sharepoint.com/personal/f/doc.pdf"},
        is_active=True,
    )
    db = AsyncMock()
    db.get = AsyncMock(return_value=asset)
    db.execute = AsyncMock(return_value=MagicMock(scalar_one_or_none=MagicMock(return_value=None)))

    access = await resolve_knowledge_asset_access(db, asset.id, tenant_id=tenant_id)
    assert access is not None
    assert access.view_mode == "external"
    assert access.web_url.startswith("https://")
    assert access.local_api_path is None


@pytest.mark.asyncio
async def test_knowledge_file_requires_authentication():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        response = await client.get(f"/api/v1/knowledge/assets/{uuid.uuid4()}/file")
        assert response.status_code == 401


@pytest.mark.asyncio
async def test_knowledge_file_redirects_to_onedrive_when_no_local(monkeypatch):
    tenant_id = uuid.uuid4()
    asset_id = uuid.uuid4()
    asset = KnowledgeAsset(
        id=asset_id,
        tenant_id=tenant_id,
        filename="DGII.pdf",
        relative_path="onedrive/Justech-AI/DGII.pdf",
        metadata_={"web_url": "https://justechdo-my.sharepoint.com/personal/f/doc.pdf"},
        is_active=True,
    )

    async def fake_execute(*args, **kwargs):
        return MagicMock(scalar_one_or_none=MagicMock(return_value=asset))

    from app.api.v1 import knowledge as knowledge_api

    monkeypatch.setattr(knowledge_api, "require_tenant_context", lambda: MagicMock(tenant_id=tenant_id))
    monkeypatch.setattr(knowledge_api, "can_read_local_path", lambda _p: False)
    monkeypatch.setattr(
        knowledge_api,
        "resolve_knowledge_asset_web_url",
        AsyncMock(return_value="https://justechdo-my.sharepoint.com/personal/f/doc.pdf"),
    )

    class FakeDb:
        async def execute(self, *args, **kwargs):
            return await fake_execute()

        async def get(self, _model, key):
            return asset if key == asset_id else None

    async def fake_db():
        yield FakeDb()

    from app.api.deps import get_current_user, get_db

    user = SimpleNamespace(id=uuid.uuid4(), email="admin@test.do", full_name="Admin", is_superadmin=True)
    app.dependency_overrides[get_db] = fake_db
    app.dependency_overrides[get_current_user] = lambda: user

    transport = ASGITransport(app=app)
    try:
        async with AsyncClient(transport=transport, base_url="http://test", follow_redirects=False) as client:
            response = await client.get(f"/api/v1/knowledge/assets/{asset_id}/file")
            assert response.status_code == 302
            assert "sharepoint.com" in response.headers["location"]
    finally:
        app.dependency_overrides.clear()
