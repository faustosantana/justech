"""Tests — resolución plantillas M365 y conversión LibreOffice."""

from __future__ import annotations

import uuid
from io import BytesIO

import pytest
from docx import Document

from app.models.m365_repository import M365RepositoryFile
from app.services.document_autofill.libreoffice_converter import (
    docx_bytes_to_pdf_libreoffice,
    is_libreoffice_available,
)
from app.services.document_autofill.m365_template_resolver import (
    M365TemplateReference,
    M365TemplateResolver,
)


def _minimal_docx(text: str = "Test Justech SNCC F042") -> bytes:
    doc = Document()
    doc.add_paragraph(f"Razón social: {{{{ razon_social }}}}")
    doc.add_paragraph(text)
    buf = BytesIO()
    doc.save(buf)
    return buf.getvalue()


def test_m365_resolver_scores_sncc_f042_filename():
    resolver = M365TemplateResolver.__new__(M365TemplateResolver)
    row_generic = M365RepositoryFile(
        tenant_id=uuid.uuid4(),
        graph_item_id="item-low",
        name="documento_general.docx",
        parent_path="Justech-AI/02_PLANTILLAS",
        document_type="general",
        document_category="plantilla",
    )
    row_sncc = M365RepositoryFile(
        tenant_id=uuid.uuid4(),
        graph_item_id="item-f042",
        name="SNCC_F042_Informacion_Oferente.docx",
        parent_path="Justech-AI/02_PLANTILLAS/DGCP/PROVEEDORES_DEL_ESTADO",
        document_type="sncc_f042",
        document_category="formulario",
    )
    assert resolver._score_row("SNCC.F042", row_sncc) > resolver._score_row("SNCC.F042", row_generic)


def test_m365_resolver_excludes_copia():
    assert M365TemplateResolver._is_excluded("SNCC_F042_COPIA.docx")
    assert not M365TemplateResolver._is_excluded("SNCC_F042_Informacion_Oferente.docx")


def test_m365_reference_audit_dict():
    ref = M365TemplateReference(
        form_type="SNCC.F042",
        m365_file_id=uuid.uuid4(),
        graph_item_id="g1",
        drive_id="d1",
        source="onedrive",
        name="SNCC_F042.docx",
        web_url="https://example.com",
        parent_path="02_PLANTILLAS",
        content_hash="hash",
        template_version="v1",
        document_type="sncc_f042",
    )
    audit = ref.audit_dict()
    assert audit["graph_item_id"] == "g1"
    assert audit["drive_id"] == "d1"
    assert audit["web_url"] == "https://example.com"


@pytest.mark.skipif(not is_libreoffice_available(), reason="LibreOffice no instalado")
def test_libreoffice_docx_to_pdf():
    docx = _minimal_docx()
    pdf = docx_bytes_to_pdf_libreoffice(docx)
    assert pdf[:4] == b"%PDF"
    assert len(pdf) > 500
