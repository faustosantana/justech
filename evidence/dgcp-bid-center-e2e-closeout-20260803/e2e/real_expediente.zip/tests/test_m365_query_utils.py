"""Tests — utilidades búsqueda vs ruta M365."""

from integrations.microsoft365.query_utils import (
    escape_graph_search_query,
    is_path_like_query,
    normalize_folder_path,
)


def test_is_path_like_with_slashes():
    assert is_path_like_query("Justech-AI/01_DOCUMENTOS_LEGALES/JUSTECH")
    assert is_path_like_query("folder\\subfolder")


def test_is_path_like_semantic_query():
    assert not is_path_like_query("REGISTRO MERCANTIL")
    assert not is_path_like_query("Cedula Fausto")


def test_normalize_folder_path():
    assert normalize_folder_path("Justech-AI/01_DOCUMENTOS_LEGALES/JUSTECH/") == (
        "Justech-AI/01_DOCUMENTOS_LEGALES/JUSTECH"
    )


def test_escape_graph_search_query():
    assert escape_graph_search_query("O'Brien") == "O''Brien"
