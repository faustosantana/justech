"""Tests conector Omega — portal VIP y tienda legacy."""

import json
import httpx
import pytest
from decimal import Decimal
from unittest.mock import AsyncMock, patch

from integrations.suppliers.config import OmegaConnectorConfig
from integrations.suppliers.omega_connector import OmegaConnector, extract_webforms_state

TIENDA_SAMPLE_HTML = """
<ul>
<li class="product">
  <a href="#" class="add-to-cart-product" data-product="107524">
  <div class="product-thumb-info-content">
    <a href="/es/product/consul/107524"><h4>Dell - CARGADOR FUENTE PARA LAPTOP</h4></a>
    <span class="price"><span class="amount ">$1,726.44</span></span>
  </div>
</li>
<li class="product">
  <a href="#" data-product="89108">
  <div class="product-thumb-info-content">
    <a href="/es/product/consul/89108"><h4>HP - Laptop ProBook 450</h4></a>
    <span Class="amount">$899.00</span>
  </div>
</li>
</ul>
"""

VIP_SALE_JSON = json.dumps({
    "d": json.dumps({
        "sEcho": "1",
        "iTotalRecords": 2,
        "iTotalDisplayRecords": 2,
        "aaData": [
            {"DT_RowId": "107524", "0": "107524", "1": "HP-PB450", "2": "HP - Laptop ProBook 450", "3": "5", "4": "899.00", "5": "0", "6": "False", "7": "1"},
            {"DT_RowId": "89108", "0": "89108", "1": "DELL-LAT", "2": "Dell - Latitude 5440 16GB", "3": "2", "4": "1200.00", "5": "0", "6": "False", "7": "1"},
        ],
    })
})

VIP_LOGIN_HTML = """
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="VS123" />
<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="VSG" />
<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="EV" />
"""


@pytest.mark.asyncio
async def test_omega_parse_tienda_search_html():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://tienda.omega.com.do")
    conn = OmegaConnector(cfg)
    rows = conn._parse_tienda_search_html(TIENDA_SAMPLE_HTML, limit=10)
    assert len(rows) == 2
    assert rows[0].sku == "107524"
    assert rows[0].price == Decimal("1726.44")
    assert rows[1].sku == "89108"
    assert rows[0].source == "omega_tienda_scraper"


def test_omega_parse_vip_search_json():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    rows = conn._parse_vip_search_json(VIP_SALE_JSON, limit=10, branch_id="1")
    assert len(rows) == 2
    assert rows[0].sku == "107524"
    assert rows[0].price == Decimal("899.00")
    assert rows[0].stock == 5
    assert rows[0].source == "omega_vip_scraper"
    assert rows[0].raw.get("part_number") == "HP-PB450"


def test_omega_parse_vip_payload_returns_total():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    items, total_display, total_records = conn._parse_vip_search_payload(VIP_SALE_JSON, limit=None, branch_id="1")
    assert len(items) == 2
    assert total_display == 2
    assert total_records == 2


@pytest.mark.asyncio
async def test_omega_sync_catalog_requires_vip_credentials():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    result = await conn.sync_catalog()
    assert result["ok"] is False


def test_extract_webforms_state():
    state = extract_webforms_state(VIP_LOGIN_HTML)
    assert state["__VIEWSTATE"] == "VS123"
    assert state["__VIEWSTATEGENERATOR"] == "VSG"
    assert state["__EVENTVALIDATION"] == "EV"


def test_omega_vip_search_controls():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    html = (
        '<select id="MainContent_maincontent_BranchID">'
        '<option value="1" selected="selected">Main</option></select>'
        '<select id="CurrencyID"><option value="2" selected="selected">USD</option></select>'
        '<select id="TaxTypeID"><option value="1" selected="selected">ITBIS</option></select>'
        '<input value="6943960" id="OrderID" />'
    )
    assert conn._extract_vip_branch_id(html) == "1"
    assert conn._extract_vip_select_value(html, "CurrencyID") == "2"
    assert conn._extract_vip_select_value(html, "TaxTypeID") == "1"
    assert conn._extract_vip_order_id(html) == "6943960"


@pytest.mark.asyncio
async def test_omega_demo_search():
    cfg = OmegaConnectorConfig(enabled=True, demo_mode=True)
    conn = OmegaConnector(cfg)
    rows = await conn.search_products("dell laptop", limit=5)
    assert len(rows) >= 1
    assert rows[0].source == "omega_demo"


@pytest.mark.asyncio
async def test_omega_tienda_login_failed_detection():
    cfg = OmegaConnectorConfig(enabled=True, username="a@b.com", password="wrong")
    conn = OmegaConnector(cfg)
    html = '<div class="validation-summary-errors"><ul><li>Usuario incorrecto</li></ul></div>'
    assert conn._tienda_login_failed(html, "https://tienda.omega.com.do/es/account/login") is True


@pytest.mark.asyncio
async def test_omega_vip_login_failed_detection():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    html = '<span id="InvalidCredentialsMessage" style="color:Red;">Este usuario no tiene acceso al sistema.</span>'
    assert conn._vip_login_failed(html, "https://vip.omega.com.do/Login.aspx") is True


@pytest.mark.asyncio
async def test_omega_tienda_logged_in_detection():
    cfg = OmegaConnectorConfig(enabled=True)
    conn = OmegaConnector(cfg)
    logged_in = '<a href="/es/account/logout">Cerrar sesión</a>'
    logged_out = '<a href="/es/account/login" class="btn btn-block btn-primary login">Identificarse</a>'
    assert conn._is_logged_in_tienda_html(logged_in) is True
    assert conn._is_logged_in_tienda_html(logged_out) is False


@pytest.mark.asyncio
async def test_omega_vip_requires_credentials():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://vip.omega.com.do")
    conn = OmegaConnector(cfg)
    rows = await conn.search_products("HP", limit=5)
    assert rows == []
    assert conn._auth_error


@pytest.mark.asyncio
async def test_omega_tienda_login_mock_success():
    cfg = OmegaConnectorConfig(
        enabled=True,
        username="user@test.com",
        password="secret",
        store_url="https://tienda.omega.com.do",
    )
    conn = OmegaConnector(cfg)

    login_html = '<input name="__RequestVerificationToken" type="hidden" value="tok123" />'
    account_logged_in = '<a href="/es/account/logout">Cerrar sesión</a><span>Mi Cuenta</span>'

    with patch("httpx.AsyncClient") as client_cls:
        mock_client = AsyncMock()

        login_page = AsyncMock()
        login_page.text = login_html
        login_page.raise_for_status = lambda: None

        login_resp = AsyncMock()
        login_resp.text = account_logged_in
        login_resp.url = "https://tienda.omega.com.do/es/"
        login_resp.raise_for_status = lambda: None

        account_resp = AsyncMock()
        account_resp.text = account_logged_in
        account_resp.raise_for_status = lambda: None

        mock_client.get = AsyncMock(side_effect=[login_page, account_resp])
        mock_client.post = AsyncMock(return_value=login_resp)
        mock_client.cookies = httpx.Cookies()
        mock_client.cookies.set("session-id", "abc")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        client_cls.return_value = mock_client

        result = await conn.login(fresh=True)

    assert result["ok"] is True
    assert result["status"] == "logged_in"


@pytest.mark.asyncio
async def test_omega_vip_login_mock_success():
    cfg = OmegaConnectorConfig(
        enabled=True,
        username="vipuser",
        password="secret",
        store_url="https://vip.omega.com.do",
    )
    conn = OmegaConnector(cfg)

    sale_logged_in = '<select id="MainContent_maincontent_BranchID"><option selected="selected" value="1">Main</option></select>'

    with patch("httpx.AsyncClient") as client_cls:
        mock_client = AsyncMock()

        login_page = AsyncMock()
        login_page.text = VIP_LOGIN_HTML
        login_page.raise_for_status = lambda: None

        login_resp = AsyncMock()
        login_resp.text = sale_logged_in
        login_resp.url = "https://vip.omega.com.do/Sales/Sale.aspx"
        login_resp.raise_for_status = lambda: None

        sale_resp = AsyncMock()
        sale_resp.text = sale_logged_in
        sale_resp.url = "https://vip.omega.com.do/Sales/Sale.aspx"
        sale_resp.status_code = 200
        sale_resp.raise_for_status = lambda: None

        mock_client.get = AsyncMock(side_effect=[login_page, sale_resp])
        mock_client.post = AsyncMock(return_value=login_resp)
        mock_client.cookies = httpx.Cookies()
        mock_client.cookies.set("ASP.NET_SessionId", "abc")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        client_cls.return_value = mock_client

        result = await conn.login(fresh=True)

    assert result["ok"] is True
    assert result["status"] == "logged_in"


@pytest.mark.asyncio
async def test_omega_tienda_live_search_mock():
    cfg = OmegaConnectorConfig(enabled=True, store_url="https://tienda.omega.com.do")
    conn = OmegaConnector(cfg)

    with patch("httpx.AsyncClient") as client_cls:
        mock_client = AsyncMock()
        mock_resp = AsyncMock()
        mock_resp.text = TIENDA_SAMPLE_HTML
        mock_resp.raise_for_status = lambda: None
        mock_client.get = AsyncMock(return_value=mock_resp)
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=None)
        client_cls.return_value = mock_client

        rows = await conn._search_public_tienda("laptop", limit=5)

    assert len(rows) == 2
    assert rows[1].name.startswith("HP")
