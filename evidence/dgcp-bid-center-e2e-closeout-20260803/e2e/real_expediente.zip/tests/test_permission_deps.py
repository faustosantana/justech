"""Tests PR-1.3a — RequirePermission y app.core.permissions."""

from __future__ import annotations

import uuid
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.core.admin_permissions import has_permission
from app.core.permissions import (
    PermissionContext,
    build_permission_context,
    effective_permissions,
    evaluate_permission_requirement,
    has_action_permission,
    has_all_action_permissions,
    has_any_action_permission,
    permission_for_module,
    resolve_effective_role,
)
from app.models.user import User


def _ctx(role: str, *, is_superadmin: bool = False) -> PermissionContext:
    return PermissionContext(
        user=MagicMock(spec=User, is_superadmin=is_superadmin),
        tenant_id=uuid.uuid4(),
        role=role,
        permissions=effective_permissions(role, is_superadmin=is_superadmin),
        membership=None,
        is_superadmin=is_superadmin,
    )


def test_has_permission_compat_with_role_permissions():
    assert has_permission("licitaciones", "view_dgcp") is True
    assert has_permission("licitaciones", "mutate_dgcp") is True
    assert has_permission("licitaciones", "view_odoo") is False
    assert has_permission("facturacion", "view_dgcp") is False
    assert has_permission("facturacion", "view_odoo") is True
    assert has_permission("usuario", "mutate_dgcp") is False
    assert has_permission("usuario", "view_documents") is True
    assert has_permission("admin", "admin_users") is True
    assert has_permission("usuario", "admin_users") is False
    assert has_permission("ventas", "view_dgcp", is_superadmin=True) is True


def test_effective_permissions_superadmin_gets_all():
    perms = effective_permissions("usuario", is_superadmin=True)
    assert "admin_users" in perms
    assert "view_dgcp" in perms


def test_member_role_normalized_to_usuario():
    assert resolve_effective_role(jwt_role="member", membership_role=None) == "usuario"
    perms_usuario = effective_permissions("member")
    perms_explicit = effective_permissions("usuario")
    assert perms_usuario == perms_explicit


def test_membership_role_overrides_jwt():
    assert resolve_effective_role(jwt_role="ventas", membership_role="licitaciones") == "licitaciones"


def test_has_action_permission_by_role():
    licitaciones = _ctx("licitaciones")
    facturacion = _ctx("facturacion")
    assert has_action_permission(licitaciones, "view_dgcp") is True
    assert has_action_permission(facturacion, "view_dgcp") is False
    assert has_action_permission(facturacion, "view_m365") is True


def test_require_all_vs_any():
    ctx = _ctx("compras")
    assert has_all_action_permissions(ctx, "view_odoo", "view_prices") is True
    assert has_all_action_permissions(ctx, "view_odoo", "view_dgcp") is False
    assert has_any_action_permission(ctx, "view_odoo", "view_dgcp") is True


def test_module_permission_mapping():
    assert permission_for_module("dgcp") == "view_dgcp"
    assert permission_for_module("licitaciones") == "view_dgcp"
    assert permission_for_module("odoo") == "view_odoo"
    assert permission_for_module("m365") == "view_m365"
    assert permission_for_module("prices") == "view_prices"
    assert permission_for_module("precios") == "view_prices"
    assert permission_for_module("suppliers") == "view_supplier_integrations"


@pytest.mark.asyncio
async def test_evaluate_permission_requirement_denied():
    ctx = _ctx("facturacion")
    db = AsyncMock()
    allowed, reason, message = await evaluate_permission_requirement(
        db, ctx, permissions=("view_dgcp",)
    )
    assert allowed is False
    assert "Permiso insuficiente" in message
    assert "view_dgcp" in message


@pytest.mark.asyncio
async def test_evaluate_permission_requirement_granted():
    ctx = _ctx("licitaciones")
    db = AsyncMock()
    allowed, _, message = await evaluate_permission_requirement(
        db, ctx, permissions=("view_dgcp",)
    )
    assert allowed is True
    assert message == ""


@pytest.mark.asyncio
async def test_evaluate_module_dgcp_denied_for_facturacion():
    ctx = _ctx("facturacion")
    db = AsyncMock()
    allowed, _, message = await evaluate_permission_requirement(
        db, ctx, module="dgcp"
    )
    assert allowed is False
    assert "view_dgcp" in message or "dgcp" in message


@pytest.mark.asyncio
async def test_evaluate_require_any_permission():
    ctx = _ctx("facturacion")
    db = AsyncMock()
    allowed, _, _ = await evaluate_permission_requirement(
        db,
        ctx,
        permissions=("view_dgcp", "view_odoo"),
        require_all=False,
    )
    assert allowed is True


@pytest.mark.asyncio
async def test_build_permission_context_uses_membership_role(monkeypatch):
    tenant_id = uuid.uuid4()
    user_id = uuid.uuid4()
    user = MagicMock(spec=User)
    user.id = user_id
    user.is_superadmin = False

    membership = MagicMock()
    membership.role = "licitaciones"

    from app.core import tenant as tenant_mod
    from app.core import permissions as perm_mod

    monkeypatch.setattr(
        perm_mod,
        "require_tenant_context",
        lambda: tenant_mod.TenantContext(tenant_id=tenant_id, user_id=user_id, role="ventas"),
    )
    monkeypatch.setattr(
        perm_mod,
        "get_membership",
        AsyncMock(return_value=membership),
    )

    db = AsyncMock()
    ctx = await build_permission_context(db, user)
    assert ctx.role == "licitaciones"
    assert has_action_permission(ctx, "view_dgcp") is True
    assert has_action_permission(ctx, "view_odoo") is False


def test_require_permission_factory_is_callable():
    from app.api.deps import RequirePermission

    dep = RequirePermission("view_dgcp")
    assert callable(dep)


def test_require_permission_aliases_importable():
    from app.api.deps import RequireViewDgcp, RequireViewM365, RequireViewOdoo

    assert RequireViewDgcp is not None
    assert RequireViewOdoo is not None
    assert RequireViewM365 is not None
