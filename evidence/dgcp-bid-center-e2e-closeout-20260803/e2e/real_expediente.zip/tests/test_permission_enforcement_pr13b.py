"""Tests PR-1.3b — enforcement selectivo en routers."""

from __future__ import annotations

import pytest
from httpx import ASGITransport, AsyncClient

from app.core.admin_permissions import has_permission
from app.main import app
from app.scripts.seed import ADMIN_EMAIL, ADMIN_PASSWORD

MARIELI_EMAIL = "marieli@justech.do"
MARIELI_PASSWORD = "JaiosTeam2026!"
TENANT_SLUG = "justech"


@pytest.mark.parametrize(
    "role,permission,expected",
    [
        ("admin", "view_dgcp", True),
        ("admin", "mutate_dgcp", True),
        ("gerencia", "view_dgcp", True),
        ("gerencia", "mutate_dgcp", True),
        ("ventas", "view_dgcp", True),
        ("ventas", "mutate_dgcp", False),
        ("ventas", "view_odoo", True),
        ("ventas", "mutate_odoo", True),
        ("licitaciones", "view_dgcp", True),
        ("licitaciones", "mutate_dgcp", True),
        ("licitaciones", "view_odoo", False),
        ("licitaciones", "mutate_odoo", False),
        ("facturacion", "view_dgcp", False),
        ("facturacion", "view_odoo", True),
        ("facturacion", "mutate_odoo", False),
        ("usuario", "view_dgcp", True),
        ("usuario", "mutate_dgcp", False),
        ("usuario", "view_documents", True),
        ("usuario", "mutate_documents", True),
        ("usuario", "view_assistant", True),
        ("usuario", "mutate_assistant", True),
    ],
)
def test_role_permission_matrix(role: str, permission: str, expected: bool):
    assert has_permission(role, permission) is expected


async def _login(client: AsyncClient, email: str, password: str) -> dict | None:
    r = await client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": password, "tenant_slug": TENANT_SLUG},
    )
    if r.status_code != 200:
        return None
    token = r.json()["access_token"]
    tenant_id = r.json().get("tenant_id")
    headers = {"Authorization": f"Bearer {token}"}
    if tenant_id:
        headers["X-Tenant-ID"] = tenant_id
    return headers


@pytest.mark.asyncio
async def test_dgcp_unauthenticated_401():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        r = await client.get("/api/v1/dgcp/dashboard")
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_dgcp_admin_read_200():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, ADMIN_EMAIL, ADMIN_PASSWORD)
        if not headers:
            pytest.skip("Login admin no disponible")
        r = await client.get("/api/v1/dgcp/dashboard", headers=headers)
    assert r.status_code == 200


@pytest.mark.asyncio
async def test_dgcp_usuario_read_200():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.get("/api/v1/dgcp/opportunities", headers=headers, params={"limit": 1})
    assert r.status_code == 200


@pytest.mark.asyncio
async def test_dgcp_usuario_mutate_403():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.post(
            "/api/v1/dgcp/opportunities",
            headers=headers,
            json={
                "title": "Test permiso",
                "company": "justech",
                "status": "nueva",
            },
        )
    assert r.status_code == 403
    assert "Permiso insuficiente" in r.json()["detail"]


@pytest.mark.asyncio
async def test_odoo_unauthenticated_401():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        r = await client.get("/api/v1/odoo/summary")
    assert r.status_code == 401


@pytest.mark.asyncio
async def test_odoo_usuario_read_allowed():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.get("/api/v1/odoo/config", headers=headers)
    # 200 si Odoo configurado; 503/502 si no — pero no 403
    assert r.status_code != 403


@pytest.mark.asyncio
async def test_odoo_usuario_mutate_403():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.post(
            "/api/v1/odoo/customers",
            headers=headers,
            json={"name": "Cliente test permiso"},
        )
    assert r.status_code == 403


@pytest.mark.asyncio
async def test_documents_access_usuario_200_or_404():
    """DocumentAccessService GET /access — view_documents (no 403)."""
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.get(
            "/api/v1/documents/access",
            headers=headers,
            params={"knowledge_asset_id": "00000000-0000-0000-0000-000000000001"},
        )
    assert r.status_code != 403


@pytest.mark.asyncio
async def test_documents_public_no_auth_required():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        r = await client.get("/api/v1/documents/public/profile-form/invalid-token/representatives")
    assert r.status_code in (400, 404)
    assert r.status_code != 401


@pytest.mark.asyncio
async def test_assistant_usuario_query_not_403():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=120) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.post(
            "/api/v1/assistant/query",
            headers=headers,
            json={"question": "hola"},
        )
    assert r.status_code != 403


@pytest.mark.asyncio
async def test_m365_usuario_list_not_403():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test", timeout=60) as client:
        headers = await _login(client, MARIELI_EMAIL, MARIELI_PASSWORD)
        if not headers:
            pytest.skip("Login marieli no disponible")
        r = await client.get("/api/v1/m365/connection", headers=headers)
    assert r.status_code != 403
