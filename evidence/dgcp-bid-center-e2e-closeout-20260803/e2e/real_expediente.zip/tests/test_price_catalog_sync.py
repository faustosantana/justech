"""Tests — sincronización de catálogos de precios."""

from datetime import UTC, datetime

from app.services.price_catalog_snapshot_service import catalog_key
from app.services.price_catalog_sync_service import PriceCatalogSyncService


def test_catalog_key_stable():
    k1 = catalog_key("Omega Tech", "ABC123", None, "Laptop HP")
    k2 = catalog_key("Omega Tech", "ABC123", None, "Other desc")
    assert k1 == k2


def test_compute_next_run_daily():
    base = datetime(2026, 6, 10, 12, 0, tzinfo=UTC)
    nxt = PriceCatalogSyncService._compute_next_run(base, [1, 2, 3, 4, 5, 6, 7], 4)
    assert nxt.isoweekday() == 4  # jueves
    assert nxt.hour == 4


def test_compute_next_run_tuesday_friday():
    # Miércoles 2026-06-10 12:00 UTC → próximo viernes
    base = datetime(2026, 6, 10, 12, 0, tzinfo=UTC)
    nxt = PriceCatalogSyncService._compute_next_run(base, [2, 5], 10)
    assert nxt.isoweekday() == 5
    assert nxt.hour == 10


def test_is_due_when_past():
    from app.models.price_catalog_sync import PriceCatalogSyncSchedule
    import uuid

    schedule = PriceCatalogSyncSchedule(
        tenant_id=uuid.uuid4(),
        is_enabled=True,
        sync_days=[2, 5],
        sync_hour_utc=10,
        next_run_at=datetime(2020, 1, 1, tzinfo=UTC),
    )
    assert PriceCatalogSyncService.is_due(schedule, now=datetime(2026, 1, 1, tzinfo=UTC))
