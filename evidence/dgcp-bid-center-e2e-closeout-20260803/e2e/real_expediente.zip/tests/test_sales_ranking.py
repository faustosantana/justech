"""Tests — ranking de ventas Odoo (cliente/producto top)."""

import pytest

from app.services.conversation_follow_up_resolver import resolve_follow_up
from app.services.assistant_conversation_context import ConversationEntities
from app.services.sales_question_service import SalesIntent, SalesQuestionService


@pytest.mark.parametrize(
    "question,expected_intent",
    [
        ("¿Cuál cliente le hemos vendido más?", SalesIntent.TOP_CUSTOMER),
        ("¿A qué cliente le hemos vendido más?", SalesIntent.TOP_CUSTOMER),
        ("¿Quién nos ha comprado más?", SalesIntent.TOP_CUSTOMER),
        ("Cliente que más ha comprado", SalesIntent.TOP_CUSTOMER),
        ("¿Cuál fue el producto más vendido?", SalesIntent.TOP_PRODUCT),
        ("¿Quién compró más teclados?", SalesIntent.TOP_BUYER),
        ("¿A qué cliente le hemos vendido más laptops?", SalesIntent.TOP_BUYER),
    ],
)
def test_sales_ranking_intents(question, expected_intent):
    parsed = SalesQuestionService.parse(question)
    assert parsed.intent == expected_intent, f"Got {parsed.intent} for {question!r}"


def test_hola_not_product():
    from app.services.business_terms import detect_product_in_text

    assert detect_product_in_text("hola")[0] is None
    assert detect_product_in_text("¿Cuál cliente le hemos vendido más?")[0] is None


def test_top_customer_with_product_context():
    ctx = ConversationEntities(current_product="teclado", current_product_terms=["teclado"])
    res = resolve_follow_up("¿Cuál cliente le hemos vendido más?", ctx)
    assert res.was_follow_up is True
    assert "teclado" in res.question.lower()


def test_identity_intent():
    from app.services.assistant_intent_classifier import AssistantIntentClassifier, AssistantTopIntent

    result = AssistantIntentClassifier.classify("¿Quién eres?")
    assert result.intent == AssistantTopIntent.IDENTITY
