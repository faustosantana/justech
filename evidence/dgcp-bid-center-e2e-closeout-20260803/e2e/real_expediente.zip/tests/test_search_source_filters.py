"""Tests — filtros multi-fuente Enterprise Search."""

from app.services.search_source_filters import (
    normalize_source_filters,
    source_active,
    index_db_sources,
)


def test_normalize_all_when_empty():
    assert normalize_source_filters(None) is None


def test_normalize_explicit_empty():
    assert normalize_source_filters([]) == []


def test_normalize_subset():
    assert normalize_source_filters(["odoo", "dgcp"]) == ["odoo", "dgcp"]


def test_normalize_legacy_source():
    assert normalize_source_filters(None, legacy_source="omega") == ["omega"]


def test_normalize_all_keyword():
    assert normalize_source_filters(["all", "odoo"]) is None


def test_source_active():
    assert source_active(None, "odoo") is True
    assert source_active(["odoo"], "dgcp") is False
    assert source_active(["odoo", "dgcp"], "dgcp") is True


def test_index_db_sources_multi():
    assert set(index_db_sources(["prices", "omega", "documents"]) or []) == {"prices", "documents"}
