"""Tests — contexto de etapa del proceso."""

from app.services.document_autofill.field_alias_registry import classify_pending
from app.services.document_autofill.template_process_context import (
    POST_ADJUDICATION,
    PRE_ADJUDICATION,
    resolve_process_stage,
    resolve_template_context,
)


def test_f042_pre_adjudication():
    ctx = resolve_template_context("SNCC_F042_Informacion_Oferente.docx", detected_category="sncc_formulario")
    assert ctx.process_stage == PRE_ADJUDICATION
    assert ctx.document_usage == "formulario_oferta"


def test_d039_post_adjudication():
    ctx = resolve_template_context("SNCC_D039_Liquidacion_Contrato.docx", detected_category="contrato")
    assert ctx.process_stage == POST_ADJUDICATION


def test_adjudicatario_no_aplica_en_oferta():
    cls = classify_pending(
        alias="Nombre del Adjudicatario",
        alias_normalized="nombre_del_adjudicatario",
        canonical="nombre_adjudicatario",
        status="pendiente",
        has_value=False,
        process_stage=PRE_ADJUDICATION,
    )
    assert cls == "no_aplica_etapa"


def test_adjudicatario_critico_en_contrato():
    cls = classify_pending(
        alias="Nombre del Adjudicatario",
        alias_normalized="nombre_del_adjudicatario",
        canonical="nombre_adjudicatario",
        status="pendiente",
        has_value=False,
        process_stage=POST_ADJUDICATION,
    )
    assert cls == "critico"


def test_resolve_stage_orden_compra():
    stage = resolve_process_stage("SNCC_D027_Orden_Compra.docx", "sncc_documento")
    assert stage == POST_ADJUDICATION
